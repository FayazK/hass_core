"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["39124"],{34713:function(e,r,a){a.a(e,(async function(e,o){try{a.r(r),a.d(r,{HuiRecoveryModeCard:()=>u});var t=a(61701),d=(a(71695),a(47021),a(31622),a(57243)),c=a(50778),i=(a(54977),a(74713)),s=e([i]);i=(s.then?(await s)():s)[0];let n,l,h=e=>e,u=(0,t.Z)([(0,c.Mo)("hui-recovery-mode-card")],(function(e,r){return{F:class extends r{constructor(...r){super(...r),e(this)}},d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"setConfig",value:function(e){}},{kind:"method",key:"render",value:function(){return(0,d.dy)(n||(n=h`
      <ha-card .header=${0}>
        <div class="card-content">
          ${0}
        </div>
        <error-log-card .hass=${0} provider="core"></error-log-card>
      </ha-card>
    `),this.hass.localize("ui.panel.lovelace.cards.recovery-mode.header"),this.hass.localize("ui.panel.lovelace.cards.recovery-mode.description"),this.hass)}},{kind:"field",static:!0,key:"styles",value(){return(0,d.iv)(l||(l=h`ha-card{--ha-card-header-color:var(--primary-color)}error-log-card{display:block;padding-bottom:16px}`))}}]}}),d.oi);o()}catch(n){o(n)}}))}}]);
//# sourceMappingURL=39124.5e332084c092e430.js.map