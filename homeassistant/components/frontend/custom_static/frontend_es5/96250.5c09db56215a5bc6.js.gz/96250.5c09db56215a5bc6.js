(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["96250"],{96814:function(e,i,t){t(9359),t(31526),e.exports=function e(i){return Object.freeze(i),Object.getOwnPropertyNames(i).forEach((function(t){!i.hasOwnProperty(t)||null===i[t]||"object"!=typeof i[t]&&"function"!=typeof i[t]||Object.isFrozen(i[t])||e(i[t])})),i}},37284:function(e,i,t){"use strict";t.a(e,(async function(e,a){try{t.r(i),t.d(i,{HuiDialogDeleteCard:()=>p});var o=t(61701),n=(t(71695),t(40251),t(47021),t(96814)),s=t.n(n),c=t(57243),d=t(50778),l=t(36522),r=t(28008),h=t(11734),u=e([h]);h=(u.then?(await u)():u)[0];let f,m,g,v=e=>e,p=(0,o.Z)([(0,d.Mo)("hui-dialog-delete-card")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_cardConfig",value:void 0},{kind:"method",key:"showDialog",value:async function(e){this._params=e,this._cardConfig=e.cardConfig,Object.isFrozen(this._cardConfig)||(this._cardConfig=s()(this._cardConfig))}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,this._cardConfig=void 0,(0,l.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){return this._params?(0,c.dy)(f||(f=v`
      <ha-dialog open @closed=${0} .heading=${0}>
        <div>
          ${0}
        </div>
        <mwc-button slot="secondaryAction" @click=${0} dialogInitialFocus>
          ${0}
        </mwc-button>
        <mwc-button slot="primaryAction" class="warning" @click=${0}>
          ${0}
        </mwc-button>
      </ha-dialog>
    `),this.closeDialog,this.hass.localize("ui.panel.lovelace.cards.confirm_delete"),this._cardConfig?(0,c.dy)(m||(m=v`
                <div class="element-preview">
                  <hui-card .hass=${0} .config=${0} preview></hui-card>
                </div>
              `),this.hass,this._cardConfig):"",this.closeDialog,this.hass.localize("ui.common.cancel"),this._delete,this.hass.localize("ui.common.delete")):c.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[r.yu,(0,c.iv)(g||(g=v`.element-preview{position:relative}hui-card{margin:4px auto;max-width:500px;display:block;width:100%}`))]}},{kind:"method",key:"_delete",value:function(){var e;null!==(e=this._params)&&void 0!==e&&e.deleteCard&&(this._params.deleteCard(),this.closeDialog())}}]}}),c.oi);a()}catch(f){a(f)}}))}}]);
//# sourceMappingURL=96250.5c09db56215a5bc6.js.map