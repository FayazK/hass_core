"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["84999"],{68448:function(t,i,e){var s=e(61701),a=(e(71695),e(47021),e(57243)),n=e(50778),r=e(96194);let u,h,o,d,c,l=t=>t;(0,s.Z)([(0,n.Mo)("ha-humidifier-state")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){const t=this._computeCurrentStatus();return(0,a.dy)(u||(u=l`<div class="target">
        ${0}
      </div>

      ${0}`),(0,r.rk)(this.stateObj.state)?this._localizeState():(0,a.dy)(h||(h=l`<span class="state-label">
                ${0}
                ${0}
              </span>
              <div class="unit">${0}</div>`),this._localizeState(),this.stateObj.attributes.mode?(0,a.dy)(o||(o=l`-
                    ${0}`),this.hass.formatEntityAttributeValue(this.stateObj,"mode")):"",this._computeTarget()),t&&!(0,r.rk)(this.stateObj.state)?(0,a.dy)(d||(d=l`<div class="current">
            ${0}:
            <div class="unit">${0}</div>
          </div>`),this.hass.localize("ui.card.climate.currently"),t):"")}},{kind:"method",key:"_computeCurrentStatus",value:function(){if(this.hass&&this.stateObj)return null!=this.stateObj.attributes.current_humidity?`${this.hass.formatEntityAttributeValue(this.stateObj,"current_humidity")}`:void 0}},{kind:"method",key:"_computeTarget",value:function(){return this.hass&&this.stateObj&&null!=this.stateObj.attributes.humidity?`${this.hass.formatEntityAttributeValue(this.stateObj,"humidity")}`:""}},{kind:"method",key:"_localizeState",value:function(){if((0,r.rk)(this.stateObj.state))return this.hass.localize(`state.default.${this.stateObj.state}`);const t=this.hass.formatEntityState(this.stateObj);if(this.stateObj.attributes.action&&this.stateObj.state!==r.PX){return`${this.hass.formatEntityAttributeValue(this.stateObj,"action")} (${t})`}return t}},{kind:"field",static:!0,key:"styles",value(){return(0,a.iv)(c||(c=l`:host{display:flex;flex-direction:column;justify-content:center;white-space:nowrap}.target{color:var(--primary-text-color)}.current{color:var(--secondary-text-color)}.state-label{font-weight:700}.unit{display:inline-block;direction:ltr}`))}}]}}),a.oi)},88916:function(t,i,e){e.a(t,(async function(t,s){try{e.r(i);var a=e(61701),n=(e(52247),e(71695),e(47021),e(57243)),r=e(50778),u=(e(29891),e(68448),e(93331)),h=e(8069),o=e(62577),d=t([h]);h=(d.then?(await d)():d)[0];let c,l,f,y=t=>t;(0,a.Z)([(0,r.Mo)("hui-humidifier-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(t){if(!t||!t.entity)throw new Error("Entity must be specified");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,u.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this.hass||!this._config)return n.Ld;const t=this.hass.states[this._config.entity];return t?(0,n.dy)(l||(l=y`
      <hui-generic-entity-row .hass=${0} .config=${0}>
        <ha-humidifier-state .hass=${0} .stateObj=${0}>
        </ha-humidifier-state>
      </hui-generic-entity-row>
    `),this.hass,this._config,this.hass,t):(0,n.dy)(c||(c=y`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,o.i)(this.hass,this._config.entity))}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(f||(f=y`ha-humidifier-state{text-align:right}`))}}]}}),n.oi);s()}catch(c){s(c)}}))}}]);
//# sourceMappingURL=84999.4d7851459d180a0a.js.map