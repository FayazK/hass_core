(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["88170"],{49976:function(e,t,i){"use strict";i.d(t,{U:()=>a});const a=e=>e.stopPropagation()},73729:function(e,t,i){"use strict";i.d(t,{i:()=>f});var a=i(61701),n=i(72621),o=(i(22152),i(71695),i(47021),i(74966)),s=i(51408),r=i(57243),l=i(50778),d=i(76525);i(23334);let c,h,u,p=e=>e;const v=["button","ha-list-item"],f=(e,t)=>{var i;return(0,r.dy)(c||(c=p`
  <div class="header_title">
    <ha-icon-button .label=${0} .path=${0} dialogAction="close" class="header_button"></ha-icon-button>
    <span>${0}</span>
  </div>
`),null!==(i=null==e?void 0:e.localize("ui.common.close"))&&void 0!==i?i:"Close","M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",t)};(0,a.Z)([(0,l.Mo)("ha-dialog")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:d.gA,value:void 0},{kind:"method",key:"scrollToPos",value:function(e,t){var i;null===(i=this.contentElement)||void 0===i||i.scrollTo(e,t)}},{kind:"method",key:"renderHeading",value:function(){return(0,r.dy)(h||(h=p`<slot name="heading"> ${0} </slot>`),(0,n.Z)(i,"renderHeading",this,3)([]))}},{kind:"method",key:"firstUpdated",value:function(){var e;(0,n.Z)(i,"firstUpdated",this,3)([]),this.suppressDefaultPressSelector=[this.suppressDefaultPressSelector,v].join(", "),this._updateScrolledAttribute(),null===(e=this.contentElement)||void 0===e||e.addEventListener("scroll",this._onScroll,{passive:!0})}},{kind:"method",key:"disconnectedCallback",value:function(){(0,n.Z)(i,"disconnectedCallback",this,3)([]),this.contentElement.removeEventListener("scroll",this._onScroll)}},{kind:"field",key:"_onScroll",value(){return()=>{this._updateScrolledAttribute()}}},{kind:"method",key:"_updateScrolledAttribute",value:function(){this.contentElement&&this.toggleAttribute("scrolled",0!==this.contentElement.scrollTop)}},{kind:"field",static:!0,key:"styles",value(){return[s.W,(0,r.iv)(u||(u=p`.dialog-actions,.header_button,.header_title{direction:var(--direction)}:host([scrolled]) ::slotted(ha-dialog-header){border-bottom:1px solid var(--mdc-dialog-scroll-divider-color,rgba(0,0,0,.12))}.mdc-dialog{--mdc-dialog-scroll-divider-color:var(
          --dialog-scroll-divider-color,
          var(--divider-color)
        );z-index:var(--dialog-z-index,8);-webkit-backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));--mdc-dialog-box-shadow:var(--dialog-box-shadow, none);--mdc-typography-headline6-font-weight:400;--mdc-typography-headline6-font-size:1.574rem}.mdc-dialog__actions{justify-content:var(--justify-action-buttons,flex-end)}.mdc-dialog__actions span:first-child{flex:var(--secondary-action-button-flex,unset)}.mdc-dialog__actions span:nth-child(2){flex:var(--primary-action-button-flex,unset)}.mdc-dialog__container{align-items:var(--vertical-align-dialog,center)}.mdc-dialog__title{padding:24px 24px 0}.mdc-dialog__title:has(span){padding:12px 12px 0}.mdc-dialog__actions{padding:12px 24px}.mdc-dialog__title::before{content:unset}.mdc-dialog .mdc-dialog__content{position:var(--dialog-content-position,relative);padding:var(--dialog-content-padding,24px)}:host([hideactions]) .mdc-dialog .mdc-dialog__content{padding-bottom:max(var(--dialog-content-padding,24px),env(safe-area-inset-bottom))}.mdc-dialog .mdc-dialog__surface{position:var(--dialog-surface-position,relative);top:var(--dialog-surface-top);margin-top:var(--dialog-surface-margin-top);min-height:var(--mdc-dialog-min-height,auto);border-radius:var(--ha-dialog-border-radius,28px);-webkit-backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);background:var(--ha-dialog-surface-background,var(--mdc-theme-surface,#fff))}:host([flexContent]) .mdc-dialog .mdc-dialog__content{display:flex;flex-direction:column}.header_title{display:flex;align-items:center}.header_title span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;padding-left:4px}.header_button{text-decoration:none;color:inherit;inset-inline-start:initial;inset-inline-end:-12px}.dialog-actions{inset-inline-start:initial!important;inset-inline-end:0px!important}`))]}}]}}),o.M)},92824:function(e,t,i){"use strict";var a=i(61701),n=i(72621),o=(i(71695),i(40251),i(47021),i(60930)),s=i(9714),r=i(57243),l=i(50778),d=i(22381),c=i(76320);i(23334);let h,u,p,v,f=e=>e;(0,a.Z)([(0,l.Mo)("ha-select")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"icon",value(){return!1}},{kind:"field",decorators:[(0,l.Cb)({type:Boolean,reflect:!0})],key:"clearable",value(){return!1}},{kind:"field",decorators:[(0,l.Cb)({attribute:"inline-arrow",type:Boolean})],key:"inlineArrow",value(){return!1}},{kind:"field",decorators:[(0,l.Cb)()],key:"options",value:void 0},{kind:"method",key:"render",value:function(){return(0,r.dy)(h||(h=f`
      ${0}
      ${0}
    `),(0,n.Z)(i,"render",this,3)([]),this.clearable&&!this.required&&!this.disabled&&this.value?(0,r.dy)(u||(u=f`<ha-icon-button label="clear" @click=${0} .path=${0}></ha-icon-button>`),this._clearValue,"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"):r.Ld)}},{kind:"method",key:"renderLeadingIcon",value:function(){return this.icon?(0,r.dy)(p||(p=f`<span class="mdc-select__icon"><slot name="icon"></slot></span>`)):r.Ld}},{kind:"method",key:"connectedCallback",value:function(){(0,n.Z)(i,"connectedCallback",this,3)([]),window.addEventListener("translations-updated",this._translationsUpdated)}},{kind:"method",key:"firstUpdated",value:async function(){var e;((0,n.Z)(i,"firstUpdated",this,3)([]),this.inlineArrow)&&(null===(e=this.shadowRoot)||void 0===e||null===(e=e.querySelector(".mdc-select__selected-text-container"))||void 0===e||e.classList.add("inline-arrow"))}},{kind:"method",key:"updated",value:function(e){if((0,n.Z)(i,"updated",this,3)([e]),e.has("inlineArrow")){var t;const e=null===(t=this.shadowRoot)||void 0===t?void 0:t.querySelector(".mdc-select__selected-text-container");this.inlineArrow?null==e||e.classList.add("inline-arrow"):null==e||e.classList.remove("inline-arrow")}e.get("options")&&(this.layoutOptions(),this.selectByValue(this.value))}},{kind:"method",key:"disconnectedCallback",value:function(){(0,n.Z)(i,"disconnectedCallback",this,3)([]),window.removeEventListener("translations-updated",this._translationsUpdated)}},{kind:"method",key:"_clearValue",value:function(){!this.disabled&&this.value&&(this.valueSetDirectly=!0,this.select(-1),this.mdcFoundation.handleChange())}},{kind:"field",key:"_translationsUpdated",value(){return(0,d.D)((async()=>{await(0,c.y)(),this.layoutOptions()}),500)}},{kind:"field",static:!0,key:"styles",value(){return[s.W,(0,r.iv)(v||(v=f`.mdc-select:not(.mdc-select--disabled) .mdc-select__icon,ha-icon-button{color:var(--secondary-text-color)}:host([clearable]){position:relative}.mdc-select__anchor{width:var(--ha-select-min-width,200px)}.mdc-select--filled .mdc-select__anchor{height:var(--ha-select-height,56px)}.mdc-select--filled .mdc-floating-label{inset-inline-start:12px;inset-inline-end:initial;direction:var(--direction)}.mdc-select--filled.mdc-select--with-leading-icon .mdc-floating-label{inset-inline-start:48px;inset-inline-end:initial;direction:var(--direction)}.mdc-select .mdc-select__anchor{padding-inline-start:12px;padding-inline-end:0px;direction:var(--direction)}.mdc-select__anchor .mdc-floating-label--float-above{transform-origin:var(--float-start)}.mdc-select__selected-text-container{padding-inline-end:var(--select-selected-text-padding-end,0px)}:host([clearable]) .mdc-select__selected-text-container{padding-inline-end:var(--select-selected-text-padding-end,12px)}ha-icon-button{position:absolute;top:10px;right:28px;--mdc-icon-button-size:36px;--mdc-icon-size:20px;inset-inline-start:initial;inset-inline-end:28px;direction:var(--direction)}.inline-arrow{flex-grow:0}`))]}}]}}),o.K)},17170:function(e,t,i){"use strict";i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HaSpinner:()=>p});var n=i(61701),o=i(72621),s=(i(71695),i(47021),i(97677)),r=i(43580),l=i(57243),d=i(50778),c=e([s]);s=(c.then?(await c)():c)[0];let h,u=e=>e,p=(0,n.Z)([(0,d.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,d.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,o.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value(){return[r.Z,(0,l.iv)(h||(h=u`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`))]}}]}}),s.Z);a()}catch(h){a(h)}}))},63251:function(e,t,i){"use strict";i.a(e,(async function(e,a){try{i.r(t);var n=i(61701),o=(i(71695),i(9359),i(70104),i(40251),i(47021),i(87319),i(57243)),s=i(50778),r=i(27486),l=i(36522),d=i(49976),c=i(17170),h=(i(92824),i(73729),i(56785)),u=i(67044),p=i(76131),v=i(28008),f=i(90698),g=e([c]);c=(g.then?(await g)():g)[0];let m,k,_,y,b,x=e=>e;const w=(0,r.Z)((e=>{const t=""!==e.disk_life_time?30:10,i=1e3*e.disk_used/60/t,a=4*e.startup_time/60;return 10*Math.ceil((i+a)/10)}));(0,n.Z)([(0,s.Mo)("dialog-move-datadisk")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_hostInfo",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_selectedDevice",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_disks",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_osInfo",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_moving",value(){return!1}},{kind:"method",key:"showDialog",value:async function(e){this._hostInfo=e.hostInfo;try{this._osInfo=await(0,u.AP)(this.hass);const e=await(0,u.ou)(this.hass);e.devices.length>0?this._disks=e.disks:(this.closeDialog(),await(0,p.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.storage.datadisk.no_devices_title"),text:this.hass.localize("ui.panel.config.storage.datadisk.no_devices_text")}))}catch(t){this.closeDialog(),await(0,p.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.hardware.available_hardware.failed_to_get"),text:(0,h.js)(t)})}}},{kind:"method",key:"closeDialog",value:function(){this._selectedDevice=void 0,this._disks=void 0,this._moving=!1,this._hostInfo=void 0,this._osInfo=void 0,(0,l.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){return this._hostInfo&&this._osInfo&&this._disks?(0,o.dy)(m||(m=x`
      <ha-dialog open scrimClickAction escapeKeyAction .heading=${0} @closed=${0} ?hideActions=${0}>
        ${0}
      </ha-dialog>
    `),this._moving?this.hass.localize("ui.panel.config.storage.datadisk.moving"):this.hass.localize("ui.panel.config.storage.datadisk.title"),this.closeDialog,this._moving,this._moving?(0,o.dy)(k||(k=x`
              <ha-spinner aria-label="Moving" size="large"> </ha-spinner>
              <p class="progress-text">
                ${0}
              </p>
            `),this.hass.localize("ui.panel.config.storage.datadisk.moving_desc")):(0,o.dy)(_||(_=x`
              ${0}
              <br/><br/>

              <ha-select .label=${0} @selected=${0} @closed=${0} dialogInitialFocus fixedMenuPosition>
                ${0}
              </ha-select>

              <mwc-button slot="secondaryAction" @click=${0} dialogInitialFocus>
                ${0}
              </mwc-button>

              <mwc-button .disabled=${0} slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),this.hass.localize("ui.panel.config.storage.datadisk.description",{current_path:this._osInfo.data_disk,time:w(this._hostInfo)}),this.hass.localize("ui.panel.config.storage.datadisk.select_device"),this._selectDevice,d.U,this._disks.map((e=>(0,o.dy)(y||(y=x`<mwc-list-item twoline .value=${0}>
                      <span>${0} ${0}</span>
                      <span slot="secondary">
                        ${0}
                      </span>
                    </mwc-list-item>`),e.id,e.vendor,e.model,this.hass.localize("ui.panel.config.storage.datadisk.extra_information",{size:(0,f.d)(e.size),serial:e.serial})))),this.closeDialog,this.hass.localize("ui.panel.config.storage.datadisk.cancel"),!this._selectedDevice,this._moveDatadisk,this.hass.localize("ui.panel.config.storage.datadisk.move"))):o.Ld}},{kind:"method",key:"_selectDevice",value:function(e){this._selectedDevice=e.target.value}},{kind:"method",key:"_moveDatadisk",value:async function(){this._moving=!0;try{await(0,u.Sx)(this.hass,this._selectedDevice)}catch(e){this.hass.connection.connected&&!(0,h.yz)(e)&&(0,p.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.storage.datadisk.failed_to_move"),text:(0,h.js)(e)})}finally{this.closeDialog()}}},{kind:"get",static:!0,key:"styles",value:function(){return[v.Qx,v.yu,(0,o.iv)(b||(b=x`.progress-text,ha-spinner{text-align:center}ha-select{width:100%}ha-spinner{display:block;margin:32px}`))]}}]}}),o.oi);a()}catch(m){a(m)}}))},22152:function(){Element.prototype.toggleAttribute||(Element.prototype.toggleAttribute=function(e,t){return void 0!==t&&(t=!!t),this.hasAttribute(e)?!!t||(this.removeAttribute(e),!1):!1!==t&&(this.setAttribute(e,""),!0)})},90698:function(e,t,i){"use strict";i.d(t,{d:()=>a});i(49278),i(95078);const a=(e=0,t=2)=>{if(0===e)return"0 Bytes";t=t<0?0:t;const i=Math.floor(Math.log(e)/Math.log(1024));return`${parseFloat((e/1024**i).toFixed(t))} ${["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"][i]}`}},86256:function(e,t,i){"use strict";var a=i(88045),n=i(72616),o=i(95011),s=RangeError;e.exports=function(e){var t=n(o(this)),i="",r=a(e);if(r<0||r===1/0)throw new s("Wrong number of repetitions");for(;r>0;(r>>>=1)&&(t+=t))1&r&&(i+=t);return i}},35638:function(e,t,i){"use strict";var a=i(72878);e.exports=a(1..valueOf)},49278:function(e,t,i){"use strict";var a=i(40810),n=i(72878),o=i(88045),s=i(35638),r=i(86256),l=i(29660),d=RangeError,c=String,h=Math.floor,u=n(r),p=n("".slice),v=n(1..toFixed),f=function(e,t,i){return 0===t?i:t%2==1?f(e,t-1,i*e):f(e*e,t/2,i)},g=function(e,t,i){for(var a=-1,n=i;++a<6;)n+=t*e[a],e[a]=n%1e7,n=h(n/1e7)},m=function(e,t){for(var i=6,a=0;--i>=0;)a+=e[i],e[i]=h(a/t),a=a%t*1e7},k=function(e){for(var t=6,i="";--t>=0;)if(""!==i||0===t||0!==e[t]){var a=c(e[t]);i=""===i?a:i+u("0",7-a.length)+a}return i};a({target:"Number",proto:!0,forced:l((function(){return"0.000"!==v(8e-5,3)||"1"!==v(.9,0)||"1.25"!==v(1.255,2)||"1000000000000000128"!==v(0xde0b6b3a7640080,0)}))||!l((function(){v({})}))},{toFixed:function(e){var t,i,a,n,r=s(this),l=o(e),h=[0,0,0,0,0,0],v="",_="0";if(l<0||l>20)throw new d("Incorrect fraction digits");if(r!=r)return"NaN";if(r<=-1e21||r>=1e21)return c(r);if(r<0&&(v="-",r=-r),r>1e-21)if(i=(t=function(e){for(var t=0,i=e;i>=4096;)t+=12,i/=4096;for(;i>=2;)t+=1,i/=2;return t}(r*f(2,69,1))-69)<0?r*f(2,-t,1):r/f(2,t,1),i*=4503599627370496,(t=52-t)>0){for(g(h,0,i),a=l;a>=7;)g(h,1e7,0),a-=7;for(g(h,f(10,a,1),0),a=t-1;a>=23;)m(h,1<<23),a-=23;m(h,1<<a),g(h,1,1),m(h,2),_=k(h)}else g(h,0,i),g(h,1<<-t,0),_=k(h)+u("0",l);return _=l>0?v+((n=_.length)<=l?"0."+u("0",l-n)+_:p(_,0,n-l)+"."+p(_,n-l)):v+_}})},68783:function(e,t,i){"use strict";i.a(e,(async function(e,a){try{i.d(t,{A:()=>c});i(71695),i(47021);var n=i(64699),o=i(15073),s=i(81048),r=i(31027),l=i(57243),d=e([o]);o=(d.then?(await d)():d)[0];let h,u=e=>e;var c=class extends r.P{constructor(){super(...arguments),this.localize=new o.V(this)}render(){return(0,l.dy)(h||(h=u`
      <svg part="base" class="spinner" role="progressbar" aria-label=${0}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `),this.localize.term("loading"))}};c.styles=[s.N,n.D],a()}catch(h){a(h)}}))},64699:function(e,t,i){"use strict";i.d(t,{D:()=>n});let a;var n=(0,i(57243).iv)(a||(a=(e=>e)`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`))},97677:function(e,t,i){"use strict";i.a(e,(async function(e,a){try{i.d(t,{Z:()=>n.A});var n=i(68783),o=(i(64699),i(15073)),s=i(21262),r=(i(81048),i(31027),i(52812),e([o,s,n]));[o,s,n]=r.then?(await r)():r,a()}catch(l){a(l)}}))},43580:function(e,t,i){"use strict";i.d(t,{Z:()=>a.D});var a=i(64699);i(52812)},92903:function(e,t,i){"use strict";i.d(t,{XM:()=>a.XM,Xe:()=>a.Xe,pX:()=>a.pX});var a=i(45779)}}]);
//# sourceMappingURL=88170.fbed635c0e0f1f05.js.map