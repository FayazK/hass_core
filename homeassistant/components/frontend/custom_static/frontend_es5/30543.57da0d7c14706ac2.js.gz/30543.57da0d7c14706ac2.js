"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["30543"],{28506:function(e,t,n){n.r(t);var o=n(61701),a=(n(71695),n(47021),n(57243)),i=n(50778),r=(n(59826),n(54202),n(36522)),c=n(83523),s=n(58776),l=n(17409);let u,d,h=e=>e;(0,o.Z)([(0,i.Mo)("onboarding-restore-backup-no-cloud-backup")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,i.Cb)({attribute:!1})],key:"localize",value:void 0},{kind:"method",key:"render",value:function(){return(0,a.dy)(u||(u=h`
      <ha-icon-button-arrow-prev .label=${0} @click=${0}></ha-icon-button-arrow-prev>
      <h1>
        ${0}
      </h1>
      <div class="description">
        ${0}
      </div>
      <div class="actions">
        <ha-button @click=${0}>
          ${0}
        </ha-button>
        <a href="https://www.nabucasa.com/config/backups/" target="_blank" rel="noreferrer noopener">
          <ha-button>
            ${0}
          </ha-button>
        </a>
      </div>
    `),this.localize("ui.panel.page-onboarding.restore.back"),this._back,this.localize("ui.panel.page-onboarding.restore.ha-cloud.no_cloud_backup"),this.localize("ui.panel.page-onboarding.restore.ha-cloud.no_cloud_backup_description"),this._signOut,this.localize("ui.panel.page-onboarding.restore.ha-cloud.sign_out"),this.localize("ui.panel.page-onboarding.restore.ha-cloud.learn_more"))}},{kind:"method",key:"_back",value:function(){(0,c.c)(`${location.pathname}?${(0,s.pc)("page")}`)}},{kind:"method",key:"_signOut",value:function(){(0,r.B)(this,"sign-out")}},{kind:"get",static:!0,key:"styles",value:function(){return[l.I,(0,a.iv)(d||(d=h`h1,p{text-align:left}.description{font-size:1rem;line-height:1.5rem;margin-top:24px;margin-bottom:32px}.actions{display:flex;justify-content:space-between}`))]}}]}}),a.oi)}}]);
//# sourceMappingURL=30543.57da0d7c14706ac2.js.map