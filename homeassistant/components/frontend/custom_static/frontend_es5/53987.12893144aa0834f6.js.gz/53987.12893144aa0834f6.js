"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["53987"],{17170:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HaSpinner:()=>g});var o=i(61701),n=i(72621),s=(i(71695),i(47021),i(97677)),r=i(43580),l=i(57243),d=i(50778),c=e([s]);s=(c.then?(await c)():c)[0];let h,u=e=>e,g=(0,o.Z)([(0,d.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,d.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,n.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value(){return[r.Z,(0,l.iv)(h||(h=u`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`))]}}]}}),s.Z);a()}catch(h){a(h)}}))},60101:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HuiDialogEditViewHeader:()=>C});var o=i(61701),n=(i(71695),i(19423),i(40251),i(47021),i(57243)),s=i(50778),r=i(35359),l=i(36522),d=i(49976),c=i(48045),h=(i(59826),i(17170)),u=(i(73729),i(95198),i(64889),i(76131)),g=i(28008),m=(i(68805),e([h]));h=(m.then?(await m)():m)[0];let v,p,f,y,_,k=e=>e;const b="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",w="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",$="M3 6V8H14V6H3M3 10V12H14V10H3M20 10.1C19.9 10.1 19.7 10.2 19.6 10.3L18.6 11.3L20.7 13.4L21.7 12.4C21.9 12.2 21.9 11.8 21.7 11.6L20.4 10.3C20.3 10.2 20.2 10.1 20 10.1M18.1 11.9L12 17.9V20H14.1L20.2 13.9L18.1 11.9M3 14V16H10V14H3Z";let C=(0,o.Z)([(0,s.Mo)("hui-dialog-edit-view-header")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_saving",value(){return!1}},{kind:"field",decorators:[(0,s.SB)()],key:"_dirty",value(){return!1}},{kind:"field",decorators:[(0,s.SB)()],key:"_yamlMode",value(){return!1}},{kind:"field",decorators:[(0,s.IO)("ha-yaml-editor")],key:"_editor",value:void 0},{kind:"method",key:"updated",value:function(e){if(this._yamlMode&&e.has("_yamlMode")){var t;const e=Object.assign({},this._config);null===(t=this._editor)||void 0===t||t.setValue(e)}}},{kind:"method",key:"showDialog",value:function(e){this._params=e,this._dirty=!1,this._config=this._params.config}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,this._config=void 0,this._yamlMode=!1,this._dirty=!1,this._saving=!1,(0,l.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){if(!this._params||!this.hass)return n.Ld;let e;e=this._yamlMode?(0,n.dy)(v||(v=k`
        <ha-yaml-editor .hass=${0} dialogInitialFocus @value-changed=${0}></ha-yaml-editor>
      `),this.hass,this._viewYamlChanged):(0,n.dy)(p||(p=k`
        <hui-view-header-settings-editor .hass=${0} .config=${0} @config-changed=${0}></hui-view-header-settings-editor>
      `),this.hass,this._config,this._configChanged);const t=this.hass.localize("ui.panel.lovelace.editor.edit_view_header.header");return(0,n.dy)(f||(f=k`
      <ha-dialog open scrimClickAction escapeKeyAction @closed=${0} .heading=${0} class=${0}>
        <ha-dialog-header show-border slot="heading">
          <ha-icon-button slot="navigationIcon" dialogAction="cancel" .label=${0} .path=${0}></ha-icon-button>
          <h2 slot="title">${0}</h2>
          <ha-button-menu slot="actionItems" fixed corner="BOTTOM_END" menu-corner="END" @action=${0} @closed=${0}>
            <ha-icon-button slot="trigger" .label=${0} .path=${0}></ha-icon-button>
            <ha-list-item graphic="icon">
              ${0}
              <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
            </ha-list-item>
          </ha-button-menu>
        </ha-dialog-header>
        ${0}
        <ha-button slot="primaryAction" .disabled=${0} @click=${0}>
          ${0}
          ${0}</ha-button>
      </ha-dialog>
    `),this.closeDialog,t,(0,r.$)({"yaml-mode":this._yamlMode}),this.hass.localize("ui.common.close"),b,t,this._handleAction,d.U,this.hass.localize("ui.common.menu"),w,this.hass.localize("ui.panel.lovelace.editor.edit_view_header.edit_"+(this._yamlMode?"ui":"yaml")),$,e,!this._config||this._saving||!this._dirty,this._save,this._saving?(0,n.dy)(y||(y=k`<ha-spinner size="small" aria-label="Saving"></ha-spinner>`)):n.Ld,this.hass.localize("ui.common.save"))}},{kind:"method",key:"_handleAction",value:async function(e){if(e.stopPropagation(),e.preventDefault(),0===e.detail.index)this._yamlMode=!this._yamlMode}},{kind:"method",key:"_configChanged",value:function(e){e.detail&&e.detail.config&&!(0,c.v)(this._config,e.detail.config)&&(this._config=e.detail.config,this._dirty=!0)}},{kind:"method",key:"_viewYamlChanged",value:function(e){e.stopPropagation(),e.detail.isValid&&(this._config=e.detail.value,this._dirty=!0)}},{kind:"method",key:"_save",value:async function(){if(this._params&&this._config){this._saving=!0;try{await this._params.saveConfig(this._config),this.closeDialog()}catch(e){(0,u.showAlertDialog)(this,{text:`${this.hass.localize("ui.panel.lovelace.editor.edit_view_header.saving_failed")}: ${e.message}`})}finally{this._saving=!1}}}},{kind:"get",static:!0,key:"styles",value:function(){return[g.yu,(0,n.iv)(_||(_=k`ha-dialog{--vertical-align-dialog:flex-start;--dialog-surface-margin-top:40px}@media all and (max-width:450px),all and (max-height:500px){ha-dialog{--dialog-surface-margin-top:0px}}ha-dialog.yaml-mode{--dialog-content-padding:0}h2{margin:0;font-size:inherit;font-weight:inherit}@media all and (min-width:600px){ha-dialog{--mdc-dialog-min-width:600px}}`))]}}]}}),n.oi);a()}catch(v){a(v)}}))},68805:function(e,t,i){var a=i(61701),o=i(72621),n=(i(71695),i(19423),i(47021),i(57243)),s=i(50778),r=i(27486),l=i(36522),d=i(20172),c=(i(29073),i(6331)),h=i(62201);let u,g=e=>e;(0,a.Z)([(0,s.Mo)("hui-view-header-settings-editor")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,s.SB)({attribute:!1})],key:"narrow",value(){return!1}},{kind:"field",key:"_unsubMql",value:void 0},{kind:"method",key:"connectedCallback",value:function(){(0,o.Z)(i,"connectedCallback",this,3)([]),this._unsubMql=(0,h.K)("(max-width: 600px)",(e=>{this.narrow=e}))}},{kind:"method",key:"disconnectedCallback",value:function(){var e;(0,o.Z)(i,"disconnectedCallback",this,3)([]),null===(e=this._unsubMql)||void 0===e||e.call(this),this._unsubMql=void 0}},{kind:"field",key:"_schema",value(){return(0,r.Z)(((e,t,i)=>[{name:"layout",selector:{select:{mode:"box",box_max_columns:i?1:3,options:["responsive","start","center"].map((i=>({value:i,label:e(`ui.panel.lovelace.editor.edit_view_header.settings.layout_options.${"start"===i&&t?`${i}_rtl`:i}`),description:e(`ui.panel.lovelace.editor.edit_view_header.settings.layout_options.${i}_description`),image:{src:`/static/images/form/view_header_layout_${i}.svg`,src_dark:`/static/images/form/view_header_layout_${i}_dark.svg`,flip_rtl:!0}})))}}},{name:"badges_position",selector:{select:{mode:"box",options:["bottom","top"].map((t=>({value:t,label:e(`ui.panel.lovelace.editor.edit_view_header.settings.badges_position_options.${t}`),image:{src:`/static/images/form/view_header_badges_position_${t}.svg`,src_dark:`/static/images/form/view_header_badges_position_${t}_dark.svg`,flip_rtl:!0}})))}}}]))}},{kind:"method",key:"render",value:function(){var e,t;if(!this.hass)return n.Ld;const i={layout:(null===(e=this.config)||void 0===e?void 0:e.layout)||c.AU,badges_position:(null===(t=this.config)||void 0===t?void 0:t.badges_position)||c.D$},a=this.narrow,o=(0,d.HE)(this.hass),s=this._schema(this.hass.localize,o,a);return(0,n.dy)(u||(u=g`
      <ha-form .hass=${0} .data=${0} .schema=${0} .computeLabel=${0} @value-changed=${0}></ha-form>
    `),this.hass,i,s,this._computeLabel,this._valueChanged)}},{kind:"method",key:"_valueChanged",value:function(e){e.stopPropagation();const t=e.detail.value,i=Object.assign(Object.assign({},this.config),t);(0,l.B)(this,"config-changed",{config:i})}},{kind:"field",key:"_computeLabel",value(){return e=>{switch(e.name){case"layout":case"badges_position":return this.hass.localize(`ui.panel.lovelace.editor.edit_view_header.settings.${e.name}`);default:return""}}}}]}}),n.oi)},48734:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{P5:()=>g,Ve:()=>v});var o=i(16485),n=(i(71695),i(9359),i(70104),i(19423),i(19134),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),i(97003),i(47021),e([o]));o=(n.then?(await n)():n)[0];const r=new Set,l=new Map;let d,c="ltr",h="en";const u="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(u){const p=new MutationObserver(m);c=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language,p.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function g(...e){e.map((e=>{const t=e.$code.toLowerCase();l.has(t)?l.set(t,Object.assign(Object.assign({},l.get(t)),e)):l.set(t,e),d||(d=e)})),m()}function m(){u&&(c=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language),[...r.keys()].map((e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()}))}class v{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){r.add(this.host)}hostDisconnected(){r.delete(this.host)}dir(){return`${this.host.dir||c}`.toLowerCase()}lang(){return`${this.host.lang||h}`.toLowerCase()}getTranslationData(e){var t,i;const a=new Intl.Locale(e.replace(/_/g,"-")),o=null==a?void 0:a.language.toLowerCase(),n=null!==(i=null===(t=null==a?void 0:a.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==i?i:"";return{locale:a,language:o,region:n,primary:l.get(`${o}-${n}`),secondary:l.get(o)}}exists(e,t){var i;const{primary:a,secondary:o}=this.getTranslationData(null!==(i=t.lang)&&void 0!==i?i:this.lang());return t=Object.assign({includeFallback:!1},t),!!(a&&a[e]||o&&o[e]||t.includeFallback&&d&&d[e])}term(e,...t){const{primary:i,secondary:a}=this.getTranslationData(this.lang());let o;if(i&&i[e])o=i[e];else if(a&&a[e])o=a[e];else{if(!d||!d[e])return console.error(`No translation found for: ${String(e)}`),String(e);o=d[e]}return"function"==typeof o?o(...t):o}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,i){return new Intl.RelativeTimeFormat(this.lang(),i).format(e,t)}}a()}catch(s){a(s)}}))},68783:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{A:()=>c});i(71695),i(47021);var o=i(64699),n=i(15073),s=i(81048),r=i(31027),l=i(57243),d=e([n]);n=(d.then?(await d)():d)[0];let h,u=e=>e;var c=class extends r.P{constructor(){super(...arguments),this.localize=new n.V(this)}render(){return(0,l.dy)(h||(h=u`
      <svg part="base" class="spinner" role="progressbar" aria-label=${0}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `),this.localize.term("loading"))}};c.styles=[s.N,o.D],a()}catch(h){a(h)}}))},31027:function(e,t,i){i.d(t,{P:()=>r});i(71695),i(9359),i(31526),i(46692),i(47021);var a,o=i(52812),n=i(57243),s=i(50778),r=class extends n.oi{constructor(){super(),(0,o.Ko)(this,a,!1),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach((([e,t])=>{this.constructor.define(e,t)}))}emit(e,t){const i=new CustomEvent(e,(0,o.ih)({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(i),i}static define(e,t=this,i={}){const a=customElements.get(e);if(!a){try{customElements.define(e,t,i)}catch(s){customElements.define(e,class extends t{},i)}return}let o=" (unknown version)",n=o;"version"in t&&t.version&&(o=" v"+t.version),"version"in a&&a.version&&(n=" v"+a.version),o&&n&&o===n||console.warn(`Attempted to register <${e}>${o}, but <${e}>${n} has already been registered.`)}attributeChangedCallback(e,t,i){(0,o.ac)(this,a)||(this.constructor.elementProperties.forEach(((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])})),(0,o.qx)(this,a,!0)),super.attributeChangedCallback(e,t,i)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach(((t,i)=>{e.has(i)&&null==this[i]&&(this[i]=t)}))}};a=new WeakMap,r.version="2.20.1",r.dependencies={},(0,o.u2)([(0,s.Cb)()],r.prototype,"dir",2),(0,o.u2)([(0,s.Cb)()],r.prototype,"lang",2)},15073:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{V:()=>r});var o=i(21262),n=i(48734),s=e([n,o]);[n,o]=s.then?(await s)():s;var r=class extends n.Ve{};(0,n.P5)(o.K),a()}catch(l){a(l)}}))},21262:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{K:()=>r});var o=i(48734),n=e([o]);o=(n.then?(await n)():n)[0];var s={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};(0,o.P5)(s);var r=s;a()}catch(l){a(l)}}))},64699:function(e,t,i){i.d(t,{D:()=>o});let a;var o=(0,i(57243).iv)(a||(a=(e=>e)`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`))},52812:function(e,t,i){i.d(t,{EZ:()=>g,Ko:()=>f,ac:()=>p,ih:()=>u,qx:()=>y,u2:()=>m});i(63721),i(52247),i(71695),i(40251),i(47021);var a=Object.defineProperty,o=Object.defineProperties,n=Object.getOwnPropertyDescriptor,s=Object.getOwnPropertyDescriptors,r=Object.getOwnPropertySymbols,l=Object.prototype.hasOwnProperty,d=Object.prototype.propertyIsEnumerable,c=e=>{throw TypeError(e)},h=(e,t,i)=>t in e?a(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i,u=(e,t)=>{for(var i in t||(t={}))l.call(t,i)&&h(e,i,t[i]);if(r)for(var i of r(t))d.call(t,i)&&h(e,i,t[i]);return e},g=(e,t)=>o(e,s(t)),m=(e,t,i,o)=>{for(var s,r=o>1?void 0:o?n(t,i):t,l=e.length-1;l>=0;l--)(s=e[l])&&(r=(o?s(t,i,r):s(r))||r);return o&&r&&a(t,i,r),r},v=(e,t,i)=>t.has(e)||c("Cannot "+i),p=(e,t,i)=>(v(e,t,"read from private field"),i?i.call(e):t.get(e)),f=(e,t,i)=>t.has(e)?c("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,i),y=(e,t,i,a)=>(v(e,t,"write to private field"),a?a.call(e,i):t.set(e,i),i)},81048:function(e,t,i){i.d(t,{N:()=>o});let a;var o=(0,i(57243).iv)(a||(a=(e=>e)`:host{box-sizing:border-box}:host *,:host ::after,:host ::before{box-sizing:inherit}[hidden]{display:none!important}`))},97677:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{Z:()=>o.A});var o=i(68783),n=(i(64699),i(15073)),s=i(21262),r=(i(81048),i(31027),i(52812),e([n,s,o]));[n,s,o]=r.then?(await r)():r,a()}catch(l){a(l)}}))},43580:function(e,t,i){i.d(t,{Z:()=>a.D});var a=i(64699);i(52812)}}]);
//# sourceMappingURL=53987.12893144aa0834f6.js.map