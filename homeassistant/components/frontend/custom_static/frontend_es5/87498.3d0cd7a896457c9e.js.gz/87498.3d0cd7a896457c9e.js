"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["87498"],{23575:function(e,t,i){i.d(t,{N:()=>s,Z:()=>r});i(19423);const s=(e,t,i)=>e.subscribeMessage((e=>t(e)),Object.assign({type:"render_template"},i)),r=(e,t,i,s,r)=>e.connection.subscribeMessage(r,{type:"template/start_preview",flow_id:t,flow_type:i,user_input:s})},20699:function(e,t,i){i.a(e,(async function(e,s){try{i.r(t);var r=i(61701),l=i(72621),a=(i(71695),i(61893),i(9359),i(70104),i(40251),i(47021),i(57243)),n=i(50778),o=i(22381),d=i(23575),h=i(28820),u=i(36522),_=(i(99426),e([h]));h=(_.then?(await _)():_)[0];let c,p,v,b,f,y,w,k,m=e=>e;(0,r.Z)([(0,n.Mo)("flow-preview-template")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"flowType",value:void 0},{kind:"field",key:"handler",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stepId",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"flowId",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stepData",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_preview",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_listeners",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_error",value:void 0},{kind:"field",key:"_unsub",value:void 0},{kind:"method",key:"disconnectedCallback",value:function(){(0,l.Z)(i,"disconnectedCallback",this,3)([]),this._unsub&&(this._unsub.then((e=>e())),this._unsub=void 0)}},{kind:"method",key:"willUpdate",value:function(e){e.has("stepData")&&this._debouncedSubscribePreview()}},{kind:"method",key:"render",value:function(){var e;return this._error?(0,a.dy)(c||(c=m`<ha-alert alert-type="error">${0}</ha-alert>`),this._error):(0,a.dy)(p||(p=m`<entity-preview-row .hass=${0} .stateObj=${0}></entity-preview-row>
      ${0}
      ${0} `),this.hass,this._preview,null!==(e=this._listeners)&&void 0!==e&&e.time?(0,a.dy)(v||(v=m`
            <p>
              ${0}
            </p>
          `),this.hass.localize("ui.dialogs.helper_settings.template.time")):a.Ld,this._listeners?this._listeners.all?(0,a.dy)(b||(b=m`
              <p class="all_listeners">
                ${0}
              </p>
            `),this.hass.localize("ui.dialogs.helper_settings.template.all_listeners")):this._listeners.domains.length||this._listeners.entities.length?(0,a.dy)(f||(f=m`
                <p>
                  ${0}
                </p>
                <ul>
                  ${0}
                  ${0}
                </ul>
              `),this.hass.localize("ui.dialogs.helper_settings.template.listeners"),this._listeners.domains.sort().map((e=>(0,a.dy)(y||(y=m`
                        <li>
                          <b>${0}</b>: ${0}
                        </li>
                      `),this.hass.localize("ui.dialogs.helper_settings.template.domain"),e))),this._listeners.entities.sort().map((e=>(0,a.dy)(w||(w=m`
                        <li>
                          <b>${0}</b>: ${0}
                        </li>
                      `),this.hass.localize("ui.dialogs.helper_settings.template.entity"),e)))):this._listeners.time?a.Ld:(0,a.dy)(k||(k=m`<p class="all_listeners">
                  ${0}
                </p>`),this.hass.localize("ui.dialogs.helper_settings.template.no_listeners")):a.Ld)}},{kind:"field",key:"_setPreview",value(){return e=>{if("error"in e)return this._error=e.error,void(this._preview=void 0);this._error=void 0,this._listeners=e.listeners;const t=(new Date).toISOString();this._preview={entity_id:`${this.stepId}.___flow_preview___`,last_changed:t,last_updated:t,context:{id:"",parent_id:null,user_id:null},attributes:e.attributes,state:e.state}}}},{kind:"field",key:"_debouncedSubscribePreview",value(){return(0,o.D)((()=>{this._subscribePreview()}),250)}},{kind:"method",key:"_subscribePreview",value:async function(){if(this._unsub&&((await this._unsub)(),this._unsub=void 0),"config_flow"===this.flowType||"options_flow"===this.flowType)try{this._unsub=(0,d.Z)(this.hass,this.flowId,this.flowType,this.stepData,this._setPreview),await this._unsub,(0,u.B)(this,"set-flow-errors",{errors:{}})}catch(e){"string"==typeof e.message?this._error=e.message:(this._error=void 0,(0,u.B)(this,"set-flow-errors",e.message)),this._unsub=void 0,this._preview=void 0}}}]}}),a.oi);s()}catch(c){s(c)}}))}}]);
//# sourceMappingURL=87498.3d0cd7a896457c9e.js.map