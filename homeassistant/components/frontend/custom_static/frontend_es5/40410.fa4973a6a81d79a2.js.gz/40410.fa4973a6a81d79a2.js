/*! For license information please see 40410.fa4973a6a81d79a2.js.LICENSE.txt */
"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["40410"],{29567:function(e,t,i){i.d(t,{h:()=>o});i(52247),i(71695),i(9359),i(31526),i(47021);var a=i(57243),s=i(92903);const o=(0,s.XM)(class extends s.Xe{constructor(e){if(super(e),this._element=void 0,e.type!==s.pX.CHILD)throw new Error("dynamicElementDirective can only be used in content bindings")}update(e,[t,i]){return this._element&&this._element.localName===t?(i&&Object.entries(i).forEach((([e,t])=>{this._element[e]=t})),a.Jb):this.render(t,i)}render(e,t){return this._element=document.createElement(e),t&&Object.entries(t).forEach((([e,t])=>{this._element[e]=t})),this._element}})},59826:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(31622)),o=i(57243),n=i(50778),d=i(22344);let r,l=e=>e;(0,a.Z)([(0,n.Mo)("ha-button")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",static:!0,key:"styles",value(){return[d.W,(0,o.iv)(r||(r=l`::slotted([slot=icon]){margin-inline-start:0px;margin-inline-end:8px;direction:var(--direction);display:block}.mdc-button{height:var(--button-height,36px)}.trailing-icon{display:flex}.slot-container{overflow:var(--button-slot-container-overflow,visible)}:host([destructive]){--mdc-theme-primary:var(--error-color)}`))]}}]}}),s.Button)},95198:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778);let n,d,r=e=>e;(0,a.Z)([(0,o.Mo)("ha-dialog-header")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"method",key:"render",value:function(){return(0,s.dy)(n||(n=r`
      <header class="header">
        <div class="header-bar">
          <section class="header-navigation-icon">
            <slot name="navigationIcon"></slot>
          </section>
          <section class="header-content">
            <div class="header-title">
              <slot name="title"></slot>
            </div>
            <div class="header-subtitle">
              <slot name="subtitle"></slot>
            </div>
          </section>
          <section class="header-action-items">
            <slot name="actionItems"></slot>
          </section>
        </div>
        <slot></slot>
      </header>
    `))}},{kind:"get",static:!0,key:"styles",value:function(){return[(0,s.iv)(d||(d=r`:host{display:block}:host([show-border]){border-bottom:1px solid var(--mdc-dialog-scroll-divider-color,rgba(0,0,0,.12))}.header-bar{display:flex;flex-direction:row;align-items:flex-start;padding:4px;box-sizing:border-box}.header-content{flex:1;padding:10px 4px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.header-title{font-size:22px;line-height:28px;font-weight:400}.header-subtitle{font-size:14px;line-height:20px;color:var(--secondary-text-color)}@media all and (min-width:450px) and (min-height:500px){.header-bar{padding:12px}}.header-action-items,.header-navigation-icon{flex:none;min-width:8px;height:100%;display:flex;flex-direction:row}`))]}}]}}),s.oi)},73729:function(e,t,i){i.d(t,{i:()=>g});var a=i(61701),s=i(72621),o=(i(22152),i(71695),i(47021),i(74966)),n=i(51408),d=i(57243),r=i(50778),l=i(76525);i(23334);let c,h,p,m=e=>e;const u=["button","ha-list-item"],g=(e,t)=>{var i;return(0,d.dy)(c||(c=m`
  <div class="header_title">
    <ha-icon-button .label=${0} .path=${0} dialogAction="close" class="header_button"></ha-icon-button>
    <span>${0}</span>
  </div>
`),null!==(i=null==e?void 0:e.localize("ui.common.close"))&&void 0!==i?i:"Close","M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",t)};(0,a.Z)([(0,r.Mo)("ha-dialog")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",key:l.gA,value:void 0},{kind:"method",key:"scrollToPos",value:function(e,t){var i;null===(i=this.contentElement)||void 0===i||i.scrollTo(e,t)}},{kind:"method",key:"renderHeading",value:function(){return(0,d.dy)(h||(h=m`<slot name="heading"> ${0} </slot>`),(0,s.Z)(i,"renderHeading",this,3)([]))}},{kind:"method",key:"firstUpdated",value:function(){var e;(0,s.Z)(i,"firstUpdated",this,3)([]),this.suppressDefaultPressSelector=[this.suppressDefaultPressSelector,u].join(", "),this._updateScrolledAttribute(),null===(e=this.contentElement)||void 0===e||e.addEventListener("scroll",this._onScroll,{passive:!0})}},{kind:"method",key:"disconnectedCallback",value:function(){(0,s.Z)(i,"disconnectedCallback",this,3)([]),this.contentElement.removeEventListener("scroll",this._onScroll)}},{kind:"field",key:"_onScroll",value(){return()=>{this._updateScrolledAttribute()}}},{kind:"method",key:"_updateScrolledAttribute",value:function(){this.contentElement&&this.toggleAttribute("scrolled",0!==this.contentElement.scrollTop)}},{kind:"field",static:!0,key:"styles",value(){return[n.W,(0,d.iv)(p||(p=m`.dialog-actions,.header_button,.header_title{direction:var(--direction)}:host([scrolled]) ::slotted(ha-dialog-header){border-bottom:1px solid var(--mdc-dialog-scroll-divider-color,rgba(0,0,0,.12))}.mdc-dialog{--mdc-dialog-scroll-divider-color:var(
          --dialog-scroll-divider-color,
          var(--divider-color)
        );z-index:var(--dialog-z-index,8);-webkit-backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));--mdc-dialog-box-shadow:var(--dialog-box-shadow, none);--mdc-typography-headline6-font-weight:400;--mdc-typography-headline6-font-size:1.574rem}.mdc-dialog__actions{justify-content:var(--justify-action-buttons,flex-end)}.mdc-dialog__actions span:first-child{flex:var(--secondary-action-button-flex,unset)}.mdc-dialog__actions span:nth-child(2){flex:var(--primary-action-button-flex,unset)}.mdc-dialog__container{align-items:var(--vertical-align-dialog,center)}.mdc-dialog__title{padding:24px 24px 0}.mdc-dialog__title:has(span){padding:12px 12px 0}.mdc-dialog__actions{padding:12px 24px}.mdc-dialog__title::before{content:unset}.mdc-dialog .mdc-dialog__content{position:var(--dialog-content-position,relative);padding:var(--dialog-content-padding,24px)}:host([hideactions]) .mdc-dialog .mdc-dialog__content{padding-bottom:max(var(--dialog-content-padding,24px),env(safe-area-inset-bottom))}.mdc-dialog .mdc-dialog__surface{position:var(--dialog-surface-position,relative);top:var(--dialog-surface-top);margin-top:var(--dialog-surface-margin-top);min-height:var(--mdc-dialog-min-height,auto);border-radius:var(--ha-dialog-border-radius,28px);-webkit-backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);background:var(--ha-dialog-surface-background,var(--mdc-theme-surface,#fff))}:host([flexContent]) .mdc-dialog .mdc-dialog__content{display:flex;flex-direction:column}.header_title{display:flex;align-items:center}.header_title span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;padding-left:4px}.header_button{text-decoration:none;color:inherit;inset-inline-start:initial;inset-inline-end:-12px}.dialog-actions{inset-inline-start:initial!important;inset-inline-end:0px!important}`))]}}]}}),o.M)},13928:function(e,t,i){i.r(t),i.d(t,{HaIconNext:()=>d});var a=i(61701),s=(i(71695),i(47021),i(50778)),o=i(5111),n=i(37583);let d=(0,a.Z)([(0,s.Mo)("ha-icon-next")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)()],key:"path",value(){return"rtl"===o.E.document.dir?"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z":"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"}}]}}),n.HaSvgIcon)},74633:function(e,t,i){var a=i(61701),s=i(72621),o=(i(71695),i(47021),i(78755)),n=i(57243),d=i(50778);let r,l=e=>e;(0,a.Z)([(0,d.Mo)("ha-md-list-item")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",static:!0,key:"styles",value(){return[...(0,s.Z)(i,"styles",this),(0,n.iv)(r||(r=l`:host{--ha-icon-display:block;--md-sys-color-primary:var(--primary-text-color);--md-sys-color-secondary:var(--secondary-text-color);--md-sys-color-surface:var(--card-background-color);--md-sys-color-on-surface:var(--primary-text-color);--md-sys-color-on-surface-variant:var(--secondary-text-color)}md-item{overflow:var(--md-item-overflow,hidden);align-items:var(--md-item-align-items,center)}`))]}}]}}),o.g)},19993:function(e,t,i){var a=i(61701),s=i(72621),o=(i(71695),i(47021),i(623)),n=i(57243),d=i(50778);let r,l=e=>e;(0,a.Z)([(0,d.Mo)("ha-md-list")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",static:!0,key:"styles",value(){return[...(0,s.Z)(i,"styles",this),(0,n.iv)(r||(r=l`:host{--md-sys-color-surface:var(--card-background-color)}`))]}}]}}),o.j)},17170:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t),i.d(t,{HaSpinner:()=>m});var s=i(61701),o=i(72621),n=(i(71695),i(47021),i(97677)),d=i(43580),r=i(57243),l=i(50778),c=e([n]);n=(c.then?(await c)():c)[0];let h,p=e=>e,m=(0,s.Z)([(0,l.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,o.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value(){return[d.Z,(0,r.iv)(h||(h=p`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`))]}}]}}),n.Z);a()}catch(h){a(h)}}))},88935:function(e,t,i){i.d(t,{Cu:()=>_,Ex:()=>r,R9:()=>c,_T:()=>h,fC:()=>l,gK:()=>p,lN:()=>y,nJ:()=>f,tB:()=>u,td:()=>d,uV:()=>g,xO:()=>v,xr:()=>m});i(71695),i(9359),i(56475),i(1331),i(70104),i(40251),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),i(47021);var a=i(83523),s=i(71857),o=i(72344),n=i(22274);let d=function(e){return e.THREAD="thread",e.WIFI="wifi",e.ETHERNET="ethernet",e.UNKNOWN="unknown",e}({});const r=e=>{var t;return null===(t=e.auth.external)||void 0===t?void 0:t.config.canCommissionMatter},l=async e=>{if((0,o.p)(e,"thread")){const t=(await(0,n.r9)(e)).datasets.find((e=>e.preferred));if(t)return e.auth.external.fireMessage({type:"matter/commission",payload:{active_operational_dataset:(await(0,n.EM)(e,t.dataset_id)).tlv,border_agent_id:t.preferred_border_agent_id,mac_extended_address:t.preferred_extended_address,extended_pan_id:t.extended_pan_id}})}return e.auth.external.fireMessage({type:"matter/commission"})},c=(e,t)=>{let i;const o=(0,s.q4)(e.connection,(e=>{if(!i)return void(i=new Set(Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0])))).map((e=>e.id))));const s=Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0]))&&!i.has(e.id)));s.length&&(o(),i=void 0,null==t||t(),(0,a.c)(`/config/devices/device/${s[0].id}`))}));return()=>{o(),i=void 0}},h=(e,t)=>e.callWS({type:"matter/commission",code:t}),p=(e,t)=>e.callWS({type:"matter/commission_on_network",pin:t}),m=(e,t,i)=>e.callWS({type:"matter/set_wifi_credentials",network_name:t,password:i}),u=(e,t)=>e.callWS({type:"matter/set_thread",thread_operation_dataset:t}),g=(e,t)=>e.callWS({type:"matter/node_diagnostics",device_id:t}),v=(e,t)=>e.callWS({type:"matter/ping_node",device_id:t}),y=(e,t)=>e.callWS({type:"matter/open_commissioning_window",device_id:t}),f=(e,t,i)=>e.callWS({type:"matter/remove_matter_fabric",device_id:t,fabric_index:i}),_=(e,t)=>e.callWS({type:"matter/interview_node",device_id:t})},22274:function(e,t,i){i.d(t,{EM:()=>n,NO:()=>c,Xt:()=>r,h:()=>s,jK:()=>d,lR:()=>l,r9:()=>o});class a{constructor(){this.routers=void 0,this.routers={}}processEvent(e){return"router_discovered"===e.type?this.routers[e.key]=e.data:"router_removed"===e.type&&delete this.routers[e.key],Object.values(this.routers)}}const s=(e,t)=>{const i=new a;return e.connection.subscribeMessage((e=>t(i.processEvent(e))),{type:"thread/discover_routers"})},o=e=>e.callWS({type:"thread/list_datasets"}),n=(e,t)=>e.callWS({type:"thread/get_dataset_tlv",dataset_id:t}),d=(e,t,i)=>e.callWS({type:"thread/add_dataset_tlv",source:t,tlv:i}),r=(e,t)=>e.callWS({type:"thread/delete_dataset",dataset_id:t}),l=(e,t)=>e.callWS({type:"thread/set_preferred_dataset",dataset_id:t}),c=(e,t,i,a)=>e.callWS({type:"thread/set_preferred_border_agent",dataset_id:t,border_agent_id:i,extended_address:a})},25679:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t);var s=i(61701),o=(i(71695),i(40251),i(19134),i(97003),i(69797),i(47021),i(57243)),n=i(50778),d=i(29567),r=i(36522),l=(i(95198),i(23334),i(54202),i(59826),i(73729),i(88935)),c=i(28008),h=(i(65468),i(92252),i(10559),i(5676),i(45869),i(20933),i(33638)),p=i(79849),m=i(72473),u=e([h,p]);[h,p]=u.then?(await u)():u;let g,v,y,f,_,b,k,x=e=>e;const $="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",w={main:void 0,new:"main",existing:"main",google_home:"existing",google_home_fallback:"google_home",apple_home:"existing",generic:"existing",commissioning:void 0};(0,s.Z)([(0,n.Mo)("dialog-matter-add-device")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_open",value(){return!1}},{kind:"field",decorators:[(0,n.SB)()],key:"_pairingCode",value(){return""}},{kind:"field",decorators:[(0,n.SB)()],key:"_step",value(){return"main"}},{kind:"field",key:"_unsub",value:void 0},{kind:"method",key:"showDialog",value:function(){this._open=!0,this._unsub=(0,l.R9)(this.hass,(()=>this.closeDialog()))}},{kind:"method",key:"closeDialog",value:function(){var e;this._open=!1,this._step="main",this._pairingCode="",null===(e=this._unsub)||void 0===e||e.call(this),this._unsub=void 0,(0,r.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"_handleStepSelected",value:function(e){this._step=e.detail.step,this._pairingCode=""}},{kind:"method",key:"_handlePairingCodeChanged",value:function(e){this._pairingCode=e.detail.code}},{kind:"method",key:"_back",value:function(){const e=w[this._step];e&&(this._step=e)}},{kind:"method",key:"_renderStep",value:function(){return(0,o.dy)(g||(g=x`
      <div @pairing-code-changed=${0} @step-selected=${0} .hass=${0}>
        ${0}
      </div>
    `),this._handlePairingCodeChanged,this._handleStepSelected,this.hass,(0,d.h)(`matter-add-device-${this._step.replaceAll("_","-")}`,{hass:this.hass}))}},{kind:"method",key:"_addDevice",value:async function(){const e=this._pairingCode,t=this._step;try{this._step="commissioning",await(0,l._T)(this.hass,e)}catch(i){(0,m.C)(this,{message:this.hass.localize("ui.dialogs.matter-add-device.add_device_failed"),duration:2e3})}this._step=t}},{kind:"method",key:"_renderActions",value:function(){return"apple_home"===this._step||"google_home_fallback"===this._step||"generic"===this._step?(0,o.dy)(v||(v=x`
        <ha-button slot="primaryAction" @click=${0} .disabled=${0}>
          ${0}
        </ha-button>
      `),this._addDevice,!this._pairingCode,this.hass.localize("ui.dialogs.matter-add-device.add_device")):"new"===this._step?(0,o.dy)(y||(y=x`
        <ha-button slot="primaryAction" @click=${0}>
          ${0}
        </ha-button>
      `),this.closeDialog,this.hass.localize("ui.common.ok")):o.Ld}},{kind:"method",key:"render",value:function(){if(!this._open)return o.Ld;const e=this.hass.localize(`ui.dialogs.matter-add-device.${this._step}.header`),t=w[this._step],i=this._renderActions();return(0,o.dy)(f||(f=x`
      <ha-dialog open @closed=${0} .heading=${0} ?hideActions=${0} scrimClickAction escapeKeyAction>
        <ha-dialog-header slot="heading">
          ${0}
          <span slot="title">${0}</span>
        </ha-dialog-header>
        ${0} ${0}
      </ha-dialog>
    `),this.closeDialog,e,i===o.Ld,t?(0,o.dy)(_||(_=x`
                <ha-icon-button-arrow-prev slot="navigationIcon" .hass=${0} @click=${0}></ha-icon-button-arrow-prev>
              `),this.hass,this._back):(0,o.dy)(b||(b=x`
                <ha-icon-button slot="navigationIcon" dialogAction="cancel" .label=${0} .path=${0}></ha-icon-button>
              `),this.hass.localize("ui.common.close"),$),e,this._renderStep(),i)}},{kind:"field",static:!0,key:"styles",value(){return[c.yu,(0,o.iv)(k||(k=x`:host{--horizontal-padding:24px}ha-dialog{--dialog-content-padding:0;--mdc-dialog-min-width:450px;--mdc-dialog-max-width:450px}@media all and (max-width:450px),all and (max-height:500px){:host{--horizontal-padding:16px}ha-dialog{--mdc-dialog-min-width:calc(
            100vw - env(safe-area-inset-right) - env(safe-area-inset-left)
          );--mdc-dialog-max-width:calc(
            100vw - env(safe-area-inset-right) - env(safe-area-inset-left)
          )}}.loading{padding:24px;display:flex;align-items:center;justify-content:center}`))]}}]}}),o.oi);a()}catch(g){a(g)}}))},65468:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(83166),i(74826));let r,l,c,h=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-apple-home")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_code",value(){return""}},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=h`
      <div class="content">
        <ol>
          <li>
            ${0}
          </li>
          <li>
            ${0}
          </li>
          <li>
            ${0}
          </li>
        </ol>
        <br/>
        <p>
          ${0}
        </p>
        <ha-textfield label=${0} .value=${0} @input=${0}></ha-textfield>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.apple_home.step_1",{accessory_settings:(0,s.dy)(l||(l=h`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.apple_home.accessory_settings"))}),this.hass.localize("ui.dialogs.matter-add-device.apple_home.step_2",{turn_on_pairing_mode:(0,s.dy)(c||(c=h`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.apple_home.turn_on_pairing_mode"))}),this.hass.localize("ui.dialogs.matter-add-device.apple_home.step_3"),this.hass.localize("ui.dialogs.matter-add-device.apple_home.code_instructions"),this.hass.localize("ui.dialogs.matter-add-device.apple_home.setup_code"),this._code,this._onCodeChanged)}},{kind:"method",key:"_onCodeChanged",value:function(e){const t=e.currentTarget.value;this._code=t,(0,n.B)(this,"pairing-code-changed",{code:t})}},{kind:"field",static:!0,key:"styles",value(){return[d.F]}}]}}),s.oi)},79849:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(74826),d=i(17170),r=e([d]);d=(r.then?(await r)():r)[0];let l,c,h=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-commissioning")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"render",value:function(){return(0,s.dy)(l||(l=h`
      <div class="content">
        <ha-spinner size="medium"></ha-spinner>
        <p>
          ${0}
        </p>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.commissioning.note"))}},{kind:"field",static:!0,key:"styles",value(){return[n.F,(0,s.iv)(c||(c=h`.content{display:flex;align-items:center;flex-direction:column;text-align:center}ha-spinner{margin-bottom:24px}`))]}}]}}),s.oi);t()}catch(l){t(l)}}))},92252:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(74826));let r,l,c=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-existing")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=c`
      <div class="content">
        <p>
          ${0}
        </p>
      </div>

      <ha-md-list>
        <ha-md-list-item interactive type="button" .step=${0} @click=${0} @keydown=${0}>
          <img src="/static/images/logo_google_home.png" alt="" class="logo" slot="start"/>
          <span slot="headline">
            ${0}
          </span>
          <ha-icon-next slot="end"></ha-icon-next>
        </ha-md-list-item>
        <ha-md-list-item interactive type="button" .step=${0} @click=${0} @keydown=${0}>
          <img src="/static/images/logo_apple_home.png" alt="" class="logo" slot="start"/>
          <span slot="headline">
            ${0}
          </span>
          <ha-icon-next slot="end"></ha-icon-next>
        </ha-md-list-item>
        <ha-md-list-item interactive type="button" .step=${0} @click=${0} @keydown=${0}>
          <div class="logo" slot="start">
            <ha-svg-icon path=${0}></ha-svg-icon>
          </div>
          <span slot="headline">
            ${0}
          </span>
          <ha-icon-next slot="end"></ha-icon-next>
        </ha-md-list-item>
      </ha-md-list>
    `),this.hass.localize("ui.dialogs.matter-add-device.existing.question"),"google_home",this._onItemClick,this._onItemClick,this.hass.localize("ui.dialogs.matter-add-device.existing.answer_google_home"),"apple_home",this._onItemClick,this._onItemClick,this.hass.localize("ui.dialogs.matter-add-device.existing.answer_apple_home"),"generic",this._onItemClick,this._onItemClick,"M12,3L2,12H5V20H19V12H22L12,3M12,8.5C14.34,8.5 16.46,9.43 18,10.94L16.8,12.12C15.58,10.91 13.88,10.17 12,10.17C10.12,10.17 8.42,10.91 7.2,12.12L6,10.94C7.54,9.43 9.66,8.5 12,8.5M12,11.83C13.4,11.83 14.67,12.39 15.6,13.3L14.4,14.47C13.79,13.87 12.94,13.5 12,13.5C11.06,13.5 10.21,13.87 9.6,14.47L8.4,13.3C9.33,12.39 10.6,11.83 12,11.83M12,15.17C12.94,15.17 13.7,15.91 13.7,16.83C13.7,17.75 12.94,18.5 12,18.5C11.06,18.5 10.3,17.75 10.3,16.83C10.3,15.91 11.06,15.17 12,15.17Z",this.hass.localize("ui.dialogs.matter-add-device.existing.answer_generic"))}},{kind:"method",key:"_onItemClick",value:function(e){if("keydown"===e.type&&"Enter"!==e.key&&" "!==e.key)return;const t=e.currentTarget.step;(0,n.B)(this,"step-selected",{step:t})}},{kind:"field",static:!0,key:"styles",value(){return[d.F,(0,s.iv)(l||(l=c`.logo{width:48px;height:48px;border-radius:12px;border:1px solid var(--divider-color);padding:10px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;object-fit:contain}.logo ha-svg-icon{--mdc-icon-size:36px}`))]}}]}}),s.oi)},10559:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(83166),i(74826));let r,l=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-generic")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_code",value(){return""}},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=l`
      <div class="content">
        <p>
          ${0}
        </p>
        <ha-textfield label=${0} .value=${0} @input=${0}></ha-textfield>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.generic.code_instructions"),this.hass.localize("ui.dialogs.matter-add-device.generic.setup_code"),this._code,this._onCodeChanged)}},{kind:"method",key:"_onCodeChanged",value:function(e){const t=e.currentTarget.value;this._code=t,(0,n.B)(this,"pairing-code-changed",{code:t})}},{kind:"field",static:!0,key:"styles",value(){return[d.F]}}]}}),s.oi)},45869:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(83166),i(74826));let r,l,c,h,p=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-google-home-fallback")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_code",value(){return""}},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=p`
      <div class="content">
        <ol>
          <li>
            ${0}
          </li>
          <li>
            ${0}
          </li>
          <li>
            ${0}
          </li>
        </ol>
        <br/>
        <p>
          ${0}
        </p>
        <ha-textfield label=${0} .value=${0} @input=${0}></ha-textfield>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.step_1"),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.step_2",{linked_matter_apps_services:(0,s.dy)(l||(l=p`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.linked_matter_apps_services"))}),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.step_3",{link_apps_services:(0,s.dy)(c||(c=p`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.link_apps_services")),use_pairing_code:(0,s.dy)(h||(h=p`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.use_pairing_code"))}),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.code_instructions"),this.hass.localize("ui.dialogs.matter-add-device.google_home_fallback.pairing_code"),this._code,this._onCodeChanged)}},{kind:"method",key:"_onCodeChanged",value:function(e){const t=e.currentTarget.value;this._code=t,(0,n.B)(this,"pairing-code-changed",{code:t})}},{kind:"field",static:!0,key:"styles",value(){return[d.F]}}]}}),s.oi)},5676:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(74826));let r,l,c,h,p=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-google-home")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=p`
      <div class="content">
        <ol>
          <li>
            ${0}
          </li>
          <li>
            ${0}
          </li>
          <li>
            ${0}
            <span class="link" type="button" tabindex="0" @keydown=${0} @click=${0}>
              ${0}
            </span>
          </li>
          <li>
            ${0}
          </li>
        </ol>
        <br/>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.google_home.step_1"),this.hass.localize("ui.dialogs.matter-add-device.google_home.step_2",{linked_matter_apps_services:(0,s.dy)(l||(l=p`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.google_home.linked_matter_apps_services"))}),this.hass.localize("ui.dialogs.matter-add-device.google_home.step_3",{link_apps_services:(0,s.dy)(c||(c=p`<b>${0}</b>`),this.hass.localize("ui.dialogs.matter-add-device.google_home.link_apps_services")),home_assistant:(0,s.dy)(h||(h=p`<b>ASCIA</b>`))}),this._nextStep,this._nextStep,this.hass.localize("ui.dialogs.matter-add-device.google_home.no_home_assistant"),this.hass.localize("ui.dialogs.matter-add-device.google_home.redirect"))}},{kind:"method",key:"_nextStep",value:function(){(0,n.B)(this,"step-selected",{step:"google_home_fallback"})}},{kind:"field",static:!0,key:"styles",value(){return[d.F]}}]}}),s.oi)},20933:function(e,t,i){var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(36522),d=(i(13928),i(74633),i(19993),i(74826));let r,l=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-main")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"render",value:function(){return(0,s.dy)(r||(r=l`
      <div class="content">
        <p class="text">
          ${0}
        </p>
      </div>
      <ha-md-list>
        <ha-md-list-item interactive type="button" .step=${0} @click=${0} @keydown=${0}>
          <span slot="headline">
            ${0}
          </span>
          <span slot="supporting-text">
            ${0}
          </span>
          <ha-icon-next slot="end"></ha-icon-next>
        </ha-md-list-item>
        <ha-md-list-item interactive type="button" .step=${0} @click=${0} @keydown=${0}>
          <span slot="headline">
            ${0}
          </span>
          <span slot="supporting-text">
            ${0}
          </span>
          <ha-icon-next slot="end"></ha-icon-next>
        </ha-md-list-item>
      </ha-md-list>
    `),this.hass.localize("ui.dialogs.matter-add-device.main.question"),"new",this._onItemClick,this._onItemClick,this.hass.localize("ui.dialogs.matter-add-device.main.answer_new"),this.hass.localize("ui.dialogs.matter-add-device.main.answer_new_description"),"existing",this._onItemClick,this._onItemClick,this.hass.localize("ui.dialogs.matter-add-device.main.answer_existing"),this.hass.localize("ui.dialogs.matter-add-device.main.answer_existing_description"))}},{kind:"method",key:"_onItemClick",value:function(e){if("keydown"===e.type&&"Enter"!==e.key&&" "!==e.key)return;const t=e.currentTarget.step;(0,n.B)(this,"step-selected",{step:t})}},{kind:"field",static:!0,key:"styles",value(){return[d.F]}}]}}),s.oi)},33638:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(61701),s=(i(71695),i(47021),i(57243)),o=i(50778),n=i(17170),d=i(88935),r=i(74826),l=e([n]);n=(l.then?(await l)():l)[0];let c,h,p,m=e=>e;(0,a.Z)([(0,o.Mo)("matter-add-device-new")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"firstUpdated",value:function(){(0,d.Ex)(this.hass)&&(0,d.fC)(this.hass)}},{kind:"method",key:"render",value:function(){return(0,d.Ex)(this.hass)?(0,s.dy)(c||(c=m`
        <div class="content">
          <ha-spinner size="medium"></ha-spinner>
        </div>
      `)):(0,s.dy)(h||(h=m`
      <div class="content">
        <p>${0}</p>
        <p>
          ${0}
        </p>
        <div class="app-qr">
          <a target="_blank" rel="noreferrer noopener" href="https://apps.apple.com/app/home-assistant/id1099568401?mt=8">
            <img loading="lazy" src="/static/images/appstore.svg" alt=${0} class="icon"/>
            <img loading="lazy" src="/static/images/qr-appstore.svg" alt=${0}/>
          </a>
          <a target="_blank" rel="noreferrer noopener" href="https://play.google.com/store/apps/details?id=io.homeassistant.companion.android">
            <img loading="lazy" src="/static/images/playstore.svg" alt=${0} class="icon"/>
            <img loading="lazy" src="/static/images/qr-playstore.svg" alt=${0}/>
          </a>
        </div>
      </div>
    `),this.hass.localize("ui.dialogs.matter-add-device.new.note"),this.hass.localize("ui.dialogs.matter-add-device.new.download_app"),this.hass.localize("ui.dialogs.matter-add-device.new.appstore"),this.hass.localize("ui.dialogs.matter-add-device.new.appstore"),this.hass.localize("ui.dialogs.matter-add-device.new.playstore"),this.hass.localize("ui.dialogs.matter-add-device.new.playstore"))}},{kind:"field",static:!0,key:"styles",value(){return[r.F,(0,s.iv)(p||(p=m`.app-qr{margin:24px auto 0;display:flex;justify-content:space-between;padding:0 24px;box-sizing:border-box;gap:16px;width:100%;max-width:400px}.app-qr a,.app-qr img{flex:1}`))]}}]}}),s.oi);t()}catch(c){t(c)}}))},74826:function(e,t,i){i.d(t,{F:()=>s});let a;const s=(0,i(57243).iv)(a||(a=(e=>e)`.content{padding:16px var(--horizontal-padding,16px)}p{margin:0}li,p:not(:last-child){margin-bottom:8px}ol{padding-inline-start:20px;margin-block-start:0;margin-block-end:8px}.link{color:var(--primary-color);cursor:pointer;text-decoration:underline}ha-md-list{padding:0;--md-list-item-leading-space:var(--horizontal-padding, 16px);--md-list-item-trailing-space:var(--horizontal-padding, 16px);margin-bottom:16px}ha-textfield{width:100%}`))},78755:function(e,t,i){i.d(t,{g:()=>$});var a=i(9065),s=i(50778),o=(i(71695),i(19423),i(47021),i(57618),i(26499),i(23111),i(57243)),n=i(35359),d=i(79840),r=i(13823),l=i(64840);let c,h,p,m,u,g,v,y,f=e=>e;const _=(0,r.T)(o.oi);class b extends _{constructor(){super(...arguments),this.disabled=!1,this.type="text",this.isListItem=!0,this.href="",this.target=""}get isDisabled(){return this.disabled&&"link"!==this.type}willUpdate(e){this.href&&(this.type="link"),super.willUpdate(e)}render(){return this.renderListItem((0,o.dy)(c||(c=f`
      <md-item>
        <div slot="container">
          ${0} ${0}
        </div>
        <slot name="start" slot="start"></slot>
        <slot name="end" slot="end"></slot>
        ${0}
      </md-item>
    `),this.renderRipple(),this.renderFocusRing(),this.renderBody()))}renderListItem(e){const t="link"===this.type;let i;switch(this.type){case"link":i=(0,d.i0)(h||(h=f`a`));break;case"button":i=(0,d.i0)(p||(p=f`button`));break;default:i=(0,d.i0)(m||(m=f`li`))}const a="text"!==this.type,s=t&&this.target?this.target:o.Ld;return(0,d.dy)(u||(u=f`
      <${0}
        id="item"
        tabindex="${0}"
        ?disabled=${0}
        role="listitem"
        aria-selected=${0}
        aria-checked=${0}
        aria-expanded=${0}
        aria-haspopup=${0}
        class="list-item ${0}"
        href=${0}
        target=${0}
        @focus=${0}
      >${0}</${0}>
    `),i,this.isDisabled||!a?-1:0,this.isDisabled,this.ariaSelected||o.Ld,this.ariaChecked||o.Ld,this.ariaExpanded||o.Ld,this.ariaHasPopup||o.Ld,(0,n.$)(this.getRenderClasses()),this.href||o.Ld,s,this.onFocus,e,i)}renderRipple(){return"text"===this.type?o.Ld:(0,o.dy)(g||(g=f` <md-ripple part="ripple" for="item" ?disabled=${0}></md-ripple>`),this.isDisabled)}renderFocusRing(){return"text"===this.type?o.Ld:(0,o.dy)(v||(v=f` <md-focus-ring @visibility-changed=${0} part="focus-ring" for="item" inward></md-focus-ring>`),this.onFocusRingVisibilityChanged)}onFocusRingVisibilityChanged(e){}getRenderClasses(){return{disabled:this.isDisabled}}renderBody(){return(0,o.dy)(y||(y=f`
      <slot></slot>
      <slot name="overline" slot="overline"></slot>
      <slot name="headline" slot="headline"></slot>
      <slot name="supporting-text" slot="supporting-text"></slot>
      <slot name="trailing-supporting-text" slot="trailing-supporting-text"></slot>
    `))}onFocus(){-1===this.tabIndex&&this.dispatchEvent((0,l.oh)())}focus(){var e;null===(e=this.listItemRoot)||void 0===e||e.focus()}}b.shadowRootOptions=Object.assign(Object.assign({},o.oi.shadowRootOptions),{},{delegatesFocus:!0}),(0,a.__decorate)([(0,s.Cb)({type:Boolean,reflect:!0})],b.prototype,"disabled",void 0),(0,a.__decorate)([(0,s.Cb)({reflect:!0})],b.prototype,"type",void 0),(0,a.__decorate)([(0,s.Cb)({type:Boolean,attribute:"md-list-item",reflect:!0})],b.prototype,"isListItem",void 0),(0,a.__decorate)([(0,s.Cb)()],b.prototype,"href",void 0),(0,a.__decorate)([(0,s.Cb)()],b.prototype,"target",void 0),(0,a.__decorate)([(0,s.IO)(".list-item")],b.prototype,"listItemRoot",void 0);let k;const x=(0,o.iv)(k||(k=(e=>e)`.list-item.disabled,[slot=container]{pointer-events:none}:host{display:flex;-webkit-tap-highlight-color:transparent;--md-ripple-hover-color:var(--md-list-item-hover-state-layer-color, var(--md-sys-color-on-surface, #1d1b20));--md-ripple-hover-opacity:var(--md-list-item-hover-state-layer-opacity, 0.08);--md-ripple-pressed-color:var(--md-list-item-pressed-state-layer-color, var(--md-sys-color-on-surface, #1d1b20));--md-ripple-pressed-opacity:var(--md-list-item-pressed-state-layer-opacity, 0.12)}:host(:is([type=button]:not([disabled]),[type=link])){cursor:pointer}md-focus-ring{z-index:1;--md-focus-ring-shape:8px}a,button,li{background:0 0;border:none;cursor:inherit;padding:0;margin:0;text-align:unset;text-decoration:none}.list-item,md-item,md-ripple{border-radius:inherit}.list-item{display:flex;flex:1;max-width:inherit;min-width:inherit;outline:0;-webkit-tap-highlight-color:transparent;width:100%}.list-item.interactive{cursor:pointer}.list-item.disabled{opacity:var(--md-list-item-disabled-opacity, .3)}md-item{flex:1;height:100%;color:var(--md-list-item-label-text-color,var(--md-sys-color-on-surface,#1d1b20));font-family:var(--md-list-item-label-text-font, var(--md-sys-typescale-body-large-font, var(--md-ref-typeface-plain, Roboto)));font-size:var(--md-list-item-label-text-size, var(--md-sys-typescale-body-large-size, 1rem));line-height:var(--md-list-item-label-text-line-height, var(--md-sys-typescale-body-large-line-height, 1.5rem));font-weight:var(--md-list-item-label-text-weight,var(--md-sys-typescale-body-large-weight,var(--md-ref-typeface-weight-regular,400)));min-height:var(--md-list-item-one-line-container-height,56px);padding-top:var(--md-list-item-top-space,12px);padding-bottom:var(--md-list-item-bottom-space,12px);padding-inline-start:var(--md-list-item-leading-space,16px);padding-inline-end:var(--md-list-item-trailing-space,16px)}md-item[multiline]{min-height:var(--md-list-item-two-line-container-height,72px)}[slot=supporting-text]{color:var(--md-list-item-supporting-text-color,var(--md-sys-color-on-surface-variant,#49454f));font-family:var(--md-list-item-supporting-text-font, var(--md-sys-typescale-body-medium-font, var(--md-ref-typeface-plain, Roboto)));font-size:var(--md-list-item-supporting-text-size, var(--md-sys-typescale-body-medium-size, .875rem));line-height:var(--md-list-item-supporting-text-line-height, var(--md-sys-typescale-body-medium-line-height, 1.25rem));font-weight:var(--md-list-item-supporting-text-weight,var(--md-sys-typescale-body-medium-weight,var(--md-ref-typeface-weight-regular,400)))}[slot=trailing-supporting-text]{color:var(--md-list-item-trailing-supporting-text-color,var(--md-sys-color-on-surface-variant,#49454f));font-family:var(--md-list-item-trailing-supporting-text-font, var(--md-sys-typescale-label-small-font, var(--md-ref-typeface-plain, Roboto)));font-size:var(--md-list-item-trailing-supporting-text-size, var(--md-sys-typescale-label-small-size, .6875rem));line-height:var(--md-list-item-trailing-supporting-text-line-height, var(--md-sys-typescale-label-small-line-height, 1rem));font-weight:var(--md-list-item-trailing-supporting-text-weight,var(--md-sys-typescale-label-small-weight,var(--md-ref-typeface-weight-medium,500)))}:is([slot=start],[slot=end])::slotted(*){fill:currentColor}[slot=start]{color:var(--md-list-item-leading-icon-color,var(--md-sys-color-on-surface-variant,#49454f))}[slot=end]{color:var(--md-list-item-trailing-icon-color,var(--md-sys-color-on-surface-variant,#49454f))}@media(forced-colors:active){.disabled slot{color:GrayText}.list-item.disabled{color:GrayText;opacity:1}}`));let $=class extends b{};$.styles=[x],$=(0,a.__decorate)([(0,s.Mo)("md-list-item")],$)},623:function(e,t,i){i.d(t,{j:()=>m});var a=i(9065),s=i(50778),o=(i(67351),i(71695),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),i(47021),i(57243)),n=i(7750);let d,r=e=>e;const l=new Set(Object.values(n.E));class c extends o.oi{get items(){return this.listController.items}constructor(){super(),this.listController=new n.g({isItem:e=>e.hasAttribute("md-list-item"),getPossibleItems:()=>this.slotItems,isRtl:()=>"rtl"===getComputedStyle(this).direction,deactivateItem:e=>{e.tabIndex=-1},activateItem:e=>{e.tabIndex=0},isNavigableKey:e=>l.has(e),isActivatable:e=>!e.disabled&&"text"!==e.type}),this.internals=this.attachInternals(),o.sk||(this.internals.role="list",this.addEventListener("keydown",this.listController.handleKeydown))}render(){return(0,o.dy)(d||(d=r`
      <slot @deactivate-items=${0} @request-activation=${0} @slotchange=${0}>
      </slot>
    `),this.listController.onDeactivateItems,this.listController.onRequestActivation,this.listController.onSlotchange)}activateNextItem(){return this.listController.activateNextItem()}activatePreviousItem(){return this.listController.activatePreviousItem()}}(0,a.__decorate)([(0,s.NH)({flatten:!0})],c.prototype,"slotItems",void 0);let h;const p=(0,o.iv)(h||(h=(e=>e)`:host{background:var(--md-list-container-color,var(--md-sys-color-surface,#fef7ff));color:unset;display:flex;flex-direction:column;outline:0;padding:8px 0;position:relative}`));let m=class extends c{};m.styles=[p],m=(0,a.__decorate)([(0,s.Mo)("md-list")],m)},79840:function(e,t,i){i.d(t,{i0:()=>n,dy:()=>l});i(52247),i(71695),i(92745),i(52805),i(9359),i(48136),i(47021);var a=i(2841);const s=Symbol.for(""),o=e=>{if((null==e?void 0:e.r)===s)return null==e?void 0:e._$litStatic$},n=(e,...t)=>({_$litStatic$:t.reduce(((t,i,a)=>t+(e=>{if(void 0!==e._$litStatic$)return e._$litStatic$;throw Error(`Value passed to 'literal' function must be a 'literal' result: ${e}. Use 'unsafeStatic' to pass non-literal values, but\n            take care to ensure page security.`)})(i)+e[a+1]),e[0]),r:s}),d=new Map,r=e=>(t,...i)=>{const a=i.length;let s,n;const r=[],l=[];let c,h=0,p=!1;for(;h<a;){for(c=t[h];h<a&&void 0!==(n=i[h],s=o(n));)c+=s+t[++h],p=!0;h!==a&&l.push(n),r.push(c),h++}if(h===a&&r.push(t[a]),p){const e=r.join("$$lit$$");void 0===(t=d.get(e))&&(r.raw=r,d.set(e,t=r)),i=l}return e(t,...i)},l=r(a.dy);r(a.YP)}}]);
//# sourceMappingURL=40410.fa4973a6a81d79a2.js.map