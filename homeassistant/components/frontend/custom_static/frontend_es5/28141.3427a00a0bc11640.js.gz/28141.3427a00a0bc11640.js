"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["28141"],{95361:function(i,t,s){s.a(i,(async function(i,e){try{s.r(t);var a=s(61701),n=(s(71695),s(9359),s(70104),s(40251),s(47021),s(2060),s(31622),s(57243)),o=s(50778),c=s(36522),l=s(17170),d=(s(7285),s(73729)),h=s(88935),r=s(28008),u=i([l]);l=(u.then?(await u)():u)[0];let p,g,m,v,_,f,y,k=i=>i;const $="M13,13H11V7H13M13,17H11V15H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",L="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z",w="M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z";(0,a.Z)([(0,o.Mo)("dialog-matter-ping-node")],(function(i,t){return{F:class extends t{constructor(...t){super(...t),i(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"device_id",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_status",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_pingResultEntries",value:void 0},{kind:"method",key:"showDialog",value:async function(i){this.device_id=i.device_id}},{kind:"method",key:"render",value:function(){return this.device_id?(0,n.dy)(p||(p=k`
      <ha-dialog open @closed=${0} .heading=${0}>
        ${0}
      </ha-dialog>
    `),this.closeDialog,(0,d.i)(this.hass,this.hass.localize("ui.panel.config.matter.ping_node.title")),"failed"===this._status?(0,n.dy)(g||(g=k`
              <div class="flex-container">
                <ha-svg-icon .path=${0} class="failed"></ha-svg-icon>
                <div class="status">
                  <p>
                    ${0}
                  </p>
                </div>
              </div>
              <mwc-button slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),w,this.hass.localize(this._pingResultEntries?"ui.panel.config.matter.ping_node.no_ip_found":"ui.panel.config.matter.ping_node.ping_failed"),this.closeDialog,this.hass.localize("ui.common.close")):this._pingResultEntries?(0,n.dy)(m||(m=k`
                <h2>
                  ${0}
                </h2>
                <mwc-list>
                  ${0}
                </mwc-list>
                <mwc-button slot="primaryAction" @click=${0}>
                  ${0}
                </mwc-button>
              `),this.hass.localize("ui.panel.config.matter.ping_node.ping_complete"),this._pingResultEntries.map((([i,t])=>(0,n.dy)(v||(v=k`<ha-list-item hasMeta noninteractive>${0}
                        <ha-svg-icon slot="meta" .path=${0} class=${0}></ha-svg-icon>
                      </ha-list-item>`),i,t?L:$,t?"success":"failed"))),this.closeDialog,this.hass.localize("ui.common.close")):"started"===this._status?(0,n.dy)(_||(_=k`
                  <div class="flex-container">
                    <ha-spinner></ha-spinner>
                    <div class="status">
                      <p>
                        <b>
                          ${0}
                        </b>
                      </p>
                    </div>
                  </div>
                  <mwc-button slot="primaryAction" @click=${0}>
                    ${0}
                  </mwc-button>
                `),this.hass.localize("ui.panel.config.matter.ping_node.in_progress"),this.closeDialog,this.hass.localize("ui.common.close")):(0,n.dy)(f||(f=k`
                  <p>
                    ${0}
                  </p>
                  <p>
                    <em>
                      ${0}
                    </em>
                  </p>
                  <mwc-button slot="primaryAction" @click=${0}>
                    ${0}
                  </mwc-button>
                `),this.hass.localize("ui.panel.config.matter.ping_node.introduction"),this.hass.localize("ui.panel.config.matter.ping_node.battery_device_warning"),this._startPing,this.hass.localize("ui.panel.config.matter.ping_node.start_ping"))):n.Ld}},{kind:"method",key:"_startPing",value:async function(){if(this.hass){this._status="started";try{const i=await(0,h.xO)(this.hass,this.device_id),t=Object.entries(i);0===t.length&&(this._status="failed"),this._pingResultEntries=t}catch(i){this._status="failed"}}}},{kind:"method",key:"closeDialog",value:function(){this.device_id=void 0,this._status=void 0,this._pingResultEntries=void 0,(0,c.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"get",static:!0,key:"styles",value:function(){return[r.Qx,r.yu,(0,n.iv)(y||(y=k`.success{color:var(--success-color)}.failed{color:var(--error-color)}.flex-container{display:flex;align-items:center}.stages{margin-top:16px}.stage{padding:8px}mwc-list{--mdc-list-side-padding:0}.flex-container ha-spinner,.flex-container ha-svg-icon{margin-right:20px}.flex-container ha-svg-icon{width:68px;height:48px}`))]}}]}}),n.oi);e()}catch(p){e(p)}}))}}]);
//# sourceMappingURL=28141.3427a00a0bc11640.js.map