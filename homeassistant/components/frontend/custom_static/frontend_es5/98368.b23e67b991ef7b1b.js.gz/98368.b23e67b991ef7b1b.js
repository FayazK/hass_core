"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["98368"],{13592:function(t,e,i){i.a(t,(async function(t,s){try{i.r(e);var a=i(61701),n=(i(71695),i(47021),i(31622),i(57243)),r=i(50778),o=i(95975),d=i(14473),c=i(96194),l=t([o]);o=(l.then?(await l)():l)[0];let u,h,f=t=>t;(0,a.Z)([(0,r.Mo)("more-info-automation")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){return this.hass&&this.stateObj?(0,n.dy)(u||(u=f`
      <hr/>
      <div class="flex">
        <div>${0}:</div>
        <ha-relative-time .hass=${0} .datetime=${0} capitalize></ha-relative-time>
      </div>

      <div class="actions">
        <mwc-button @click=${0} .disabled=${0}>
          ${0}
        </mwc-button>
      </div>
    `),this.hass.localize("ui.card.automation.last_triggered"),this.hass,this.stateObj.attributes.last_triggered,this._runActions,(0,c.rk)(this.stateObj.state),this.hass.localize("ui.card.automation.trigger")):n.Ld}},{kind:"method",key:"_runActions",value:function(){(0,d.Es)(this.hass,this.stateObj.entity_id)}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(h||(h=f`.flex{display:flex;justify-content:space-between}.actions{margin:8px 0;display:flex;flex-wrap:wrap;justify-content:center}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`))}}]}}),n.oi);s()}catch(u){s(u)}}))}}]);
//# sourceMappingURL=98368.b23e67b991ef7b1b.js.map