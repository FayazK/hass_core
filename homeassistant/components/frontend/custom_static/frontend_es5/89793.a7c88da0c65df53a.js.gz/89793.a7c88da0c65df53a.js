"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["89793"],{5828:function(e,i,a){a.r(i),a.d(i,{HaIconButtonPrev:()=>c});var t=a(61701),n=(a(71695),a(47021),a(57243)),s=a(50778),o=a(5111);a(23334);let d,l=e=>e;let c=(0,t.Z)([(0,s.Mo)("ha-icon-button-prev")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"disabled",value(){return!1}},{kind:"field",decorators:[(0,s.Cb)()],key:"label",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_icon",value(){return"rtl"===o.E.document.dir?"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z":"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"}},{kind:"method",key:"render",value:function(){var e;return(0,n.dy)(d||(d=l`
      <ha-icon-button .disabled=${0} .label=${0} .path=${0}></ha-icon-button>
    `),this.disabled,this.label||(null===(e=this.hass)||void 0===e?void 0:e.localize("ui.common.back"))||"Back",this._icon)}}]}}),n.oi)},51784:function(e,i,a){a.d(i,{dJ:()=>g,zB:()=>_});var t=a(61701),n=a(72621),s=(a(52247),a(71695),a(19423),a(40251),a(47021),a(67840)),o=a(88854),d=a(57243),l=a(50778);let c,r,h=e=>e;s.A.addInitializer((async e=>{await e.updateComplete;const i=e;i.dialog.prepend(i.scrim),i.scrim.style.inset=0,i.scrim.style.zIndex=0;const{getOpenAnimation:a,getCloseAnimation:t}=i;i.getOpenAnimation=()=>{var e,i;const t=a.call(void 0);return t.container=[...null!==(e=t.container)&&void 0!==e?e:[],...null!==(i=t.dialog)&&void 0!==i?i:[]],t.dialog=[],t},i.getCloseAnimation=()=>{var e,i;const a=t.call(void 0);return a.container=[...null!==(e=a.container)&&void 0!==e?e:[],...null!==(i=a.dialog)&&void 0!==i?i:[]],a.dialog=[],a}}));(0,t.Z)([(0,l.Mo)("ha-md-dialog")],(function(e,i){class t extends i{constructor(){super(),e(this),this.addEventListener("cancel",this._handleCancel),"function"!=typeof HTMLDialogElement&&(this.addEventListener("open",this._handleOpen),r||(r=a.e("73854").then(a.bind(a,85893)))),void 0===this.animate&&(this.quick=!0),void 0===this.animate&&(this.quick=!0)}}return{F:t,d:[{kind:"field",decorators:[(0,l.Cb)({attribute:"disable-cancel-action",type:Boolean})],key:"disableCancelAction",value(){return!1}},{kind:"field",key:"_polyfillDialogRegistered",value(){return!1}},{kind:"method",key:"_handleOpen",value:async function(e){var i;if(e.preventDefault(),this._polyfillDialogRegistered)return;this._polyfillDialogRegistered=!0,this._loadPolyfillStylesheet("/static/polyfills/dialog-polyfill.css");const a=null===(i=this.shadowRoot)||void 0===i?void 0:i.querySelector("dialog");(await r).default.registerDialog(a),this.removeEventListener("open",this._handleOpen),this.show()}},{kind:"method",key:"_loadPolyfillStylesheet",value:async function(e){const i=document.createElement("link");return i.rel="stylesheet",i.href=e,new Promise(((a,t)=>{var n;i.onload=()=>a(),i.onerror=()=>t(new Error(`Stylesheet failed to load: ${e}`)),null===(n=this.shadowRoot)||void 0===n||n.appendChild(i)}))}},{kind:"method",key:"_handleCancel",value:function(e){if(this.disableCancelAction){var i;e.preventDefault();const a=null===(i=this.shadowRoot)||void 0===i?void 0:i.querySelector("dialog .container");void 0!==this.animate&&(null==a||a.animate([{transform:"rotate(-1deg)","animation-timing-function":"ease-in"},{transform:"rotate(1.5deg)","animation-timing-function":"ease-out"},{transform:"rotate(0deg)","animation-timing-function":"ease-in"}],{duration:200,iterations:2}))}}},{kind:"field",static:!0,key:"styles",value(){return[...(0,n.Z)(t,"styles",this),(0,d.iv)(c||(c=h`:host{--md-dialog-container-color:var(--card-background-color);--md-dialog-headline-color:var(--primary-text-color);--md-dialog-supporting-text-color:var(--primary-text-color);--md-sys-color-scrim:#000000;--md-dialog-headline-weight:400;--md-dialog-headline-size:1.574rem;--md-dialog-supporting-text-size:1rem;--md-dialog-supporting-text-line-height:1.5rem}:host([type=alert]){min-width:320px}@media all and (max-width:450px),all and (max-height:500px){:host(:not([type=alert])){min-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));max-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));min-height:100%;max-height:100%;--md-dialog-container-shape:0}}::slotted(ha-dialog-header[slot=headline]){display:contents}.scroller{overflow:var(--dialog-content-overflow,auto)}slot[name=content]::slotted(*){padding:var(--dialog-content-padding,24px)}.scrim{z-index:10}`))]}}]}}),s.A);const u=Object.assign(Object.assign({},o.I),{},{dialog:[[[{transform:"translateY(50px)"},{transform:"translateY(0)"}],{duration:500,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:0},{opacity:1}],{duration:50,easing:"linear",pseudoElement:"::before"}]]}),p=Object.assign(Object.assign({},o.G),{},{dialog:[[[{transform:"translateY(0)"},{transform:"translateY(50px)"}],{duration:150,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:"1"},{opacity:"0"}],{delay:100,duration:50,easing:"linear",pseudoElement:"::before"}]]}),g=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?u:o.I,_=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?p:o.G},35956:function(e,i,a){a.a(e,(async function(e,t){try{a.r(i);var n=a(61701),s=(a(71695),a(92745),a(19423),a(40251),a(92519),a(42179),a(89256),a(24931),a(88463),a(57449),a(19814),a(47021),a(57243)),o=a(50778),d=a(72344),l=a(36522),c=a(87865),r=(a(59826),a(95198),a(23334),a(5828),a(13928),a(51784),a(19993),a(74633),a(34326),a(37583),a(26779)),h=a(28008),u=a(72473),p=a(68545),g=(a(5131),a(6384)),_=e([p,g,r]);[p,g,r]=_.then?(await _)():_;let m,f,k,b,v,y,x,w,$,L,C,O,S,z=e=>e;const j="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",A="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",M="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",H=["welcome","key","setup","schedule","data","locations"],D=new Set(["setup"]),V=new Set(["schedule","data","locations"]),B={automatic_backups_configured:!1,create_backup:{agent_ids:[],include_folders:[],include_database:!0,include_addons:[],include_all_addons:!0,password:null,name:null},retention:{copies:3,days:null},schedule:{recurrence:r.wy.DAILY,time:null,days:[]},agents:{},last_attempted_automatic_backup:null,last_completed_automatic_backup:null,next_automatic_backup:null,next_automatic_backup_additional:!1};(0,n.Z)([(0,o.Mo)("ha-dialog-backup-onboarding")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_opened",value(){return!1}},{kind:"field",decorators:[(0,o.SB)()],key:"_step",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,o.IO)("ha-md-dialog")],key:"_dialog",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_config",value:void 0},{kind:"method",key:"showDialog",value:function(e){var i;this._params=e,null!==(i=this._params.config)&&void 0!==i&&i.create_backup.password?(this._config=this._params.config,this._step="setup"):(this._step=this._firstStep,this._config=Object.assign(Object.assign({},B),{},{create_backup:Object.assign(Object.assign({},B.create_backup),{},{agent_ids:this._defaultAgents,password:(0,r.Ty)()})})),this._opened=!0}},{kind:"method",key:"closeDialog",value:function(){return this._params.cancel&&this._params.cancel(),this._opened&&(0,l.B)(this,"dialog-closed",{dialog:this.localName}),this._opened=!1,this._step=void 0,this._config=void 0,this._params=void 0,!0}},{kind:"get",key:"_firstStep",value:function(){var e;return null!==(e=this._params)&&void 0!==e&&e.skipWelcome?H[1]:H[0]}},{kind:"method",key:"_save",value:async function(e=!1){if(!this._config)return;const i={create_backup:{password:this._config.create_backup.password,include_database:this._config.create_backup.include_database,agent_ids:this._config.create_backup.agent_ids},schedule:this._config.schedule,retention:this._config.retention,automatic_backups_configured:e};(0,d.p)(this.hass,"hassio")&&(i.create_backup.include_folders=this._config.create_backup.include_folders||[],i.create_backup.include_all_addons=this._config.create_backup.include_all_addons,i.create_backup.include_addons=this._config.create_backup.include_addons||[]),await(0,r._r)(this.hass,i)}},{kind:"method",key:"_done",value:async function(){try{var e;await this._save(!0),null===(e=this._params)||void 0===e||e.submit(!0),this._dialog.close()}catch(i){console.error(i),(0,u.C)(this,{message:"Failed to save backup configuration"})}}},{kind:"method",key:"_previousStep",value:function(){const e=H.indexOf(this._step);0!==e&&(this._step=H[e-1])}},{kind:"method",key:"_nextStep",value:function(){this._step&&V.has(this._step)&&this._save();const e=H.indexOf(this._step);e!==H.length-1&&(this._step=H[e+1])}},{kind:"method",key:"updated",value:function(e){e.has("_step")&&"key"===this._step&&this._save()}},{kind:"method",key:"render",value:function(){if(!this._opened||!this._params||!this._step)return s.Ld;const e=this._step===H[H.length-1],i=this._step===this._firstStep;return(0,s.dy)(m||(m=z`
      <ha-md-dialog disable-cancel-action open @closed=${0}>
        <ha-dialog-header slot="headline">
          ${0}

          <span slot="title">${0}</span>
        </ha-dialog-header>
        <div slot="content">${0}</div>
        ${0}
      </ha-md-dialog>
    `),this.closeDialog,i?(0,s.dy)(f||(f=z`
                <ha-icon-button slot="navigationIcon" .label=${0} .path=${0} @click=${0}></ha-icon-button>
              `),this.hass.localize("ui.common.close"),j,this.closeDialog):(0,s.dy)(k||(k=z`
                <ha-icon-button-prev slot="navigationIcon" @click=${0}></ha-icon-button-prev>
              `),this._previousStep),this._stepTitle,this._renderStepContent(),D.has(this._step)?s.Ld:(0,s.dy)(b||(b=z`
              <div slot="actions">
                ${0}
              </div>
            `),e?(0,s.dy)(v||(v=z`
                      <ha-button @click=${0} .disabled=${0}>
                        ${0}
                      </ha-button>
                    `),this._done,!this._isStepValid(),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.save_and_create")):(0,s.dy)(y||(y=z`
                      <ha-button @click=${0} .disabled=${0}>
                        ${0}
                      </ha-button>
                    `),this._nextStep,!this._isStepValid(),this.hass.localize("ui.common.next"))))}},{kind:"get",key:"_defaultAgents",value:function(){var e;const i=[];return(0,d.p)(this.hass,"hassio")?i.push(r.Kn):i.push(r.UR),null!==(e=this._params)&&void 0!==e&&null!==(e=e.cloudStatus)&&void 0!==e&&e.logged_in&&i.push(r.$u),i}},{kind:"method",key:"_useRecommended",value:function(){var e;null!==(e=this._config)&&void 0!==e&&e.create_backup.password?(this._config=Object.assign(Object.assign({},B),{},{create_backup:Object.assign(Object.assign({},B.create_backup),{},{agent_ids:this._defaultAgents,password:this._config.create_backup.password})}),this._done()):this.showDialog(this._params)}},{kind:"get",key:"_stepTitle",value:function(){switch(this._step){case"key":case"setup":case"schedule":case"data":case"locations":return this.hass.localize(`ui.panel.config.backup.dialogs.onboarding.${this._step}.title`);default:return""}}},{kind:"method",key:"_isStepValid",value:function(){var e,i,a;switch(this._step){case"key":case"setup":default:return!0;case"schedule":return!(null===(e=this._config)||void 0===e||!e.schedule);case"data":return!(null===(i=this._config)||void 0===i||!i.schedule);case"locations":return!(null===(a=this._config)||void 0===a||!a.create_backup.agent_ids.length)}}},{kind:"method",key:"_renderStepContent",value:function(){if(!this._config)return s.Ld;switch(this._step){case"welcome":return(0,s.dy)(x||(x=z`
          <div class="welcome">
            <img src="/static/images/voice-assistant/hi.png" alt="Casita ASCIA logo"/>
            <h1>
              ${0}
            </h1>
            <p class="secondary">
              ${0}
            </p>
          </div>
        `),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.welcome.title"),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.welcome.description"));case"key":return(0,s.dy)(w||(w=z`
          <p>
            ${0}
          </p>
          <div class="encryption-key">
            <p>${0}</p>
            <ha-icon-button .path=${0} @click=${0}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-button slot="end" @click=${0}>
                <ha-svg-icon .path=${0} slot="icon"></ha-svg-icon>
                ${0}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.key.description"),this._config.create_backup.password,A,this._copyKeyToClipboard,this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit"),this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description"),this._downloadKey,M,this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action"));case"setup":return(0,s.dy)($||($=z`
          <ha-md-list class="full">
            <ha-md-list-item type="button" @click=${0}>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-icon-next slot="end"></ha-icon-next>
            </ha-md-list-item>
            <ha-md-list-item type="button" @click=${0}>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-icon-next slot="end"></ha-icon-next>
            </ha-md-list-item>
          </ha-md-list>
        `),this._useRecommended,this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.recommended_heading"),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.recommended_description"),this._nextStep,this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.custom_heading"),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.custom_description"));case"schedule":return(0,s.dy)(L||(L=z`
          <p>
            ${0}
          </p>
          <ha-backup-config-schedule .hass=${0} .value=${0} @value-changed=${0}></ha-backup-config-schedule>
        `),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.schedule.description"),this.hass,this._config,this._scheduleChanged);case"data":return(0,s.dy)(C||(C=z`
          <p>
            ${0}
          </p>
          <ha-backup-config-data .hass=${0} .value=${0} @value-changed=${0} force-home-assistant hide-addon-version></ha-backup-config-data>
        `),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.data.description"),this.hass,this._dataConfig(this._config),this._dataChanged);case"locations":return(0,s.dy)(O||(O=z`
          <p>
            ${0}
          </p>
          <ha-backup-config-agents .hass=${0} .value=${0} .cloudStatus=${0} @value-changed=${0}></ha-backup-config-agents>
        `),this.hass.localize("ui.panel.config.backup.dialogs.onboarding.locations.description"),this.hass,this._config.create_backup.agent_ids,this._params.cloudStatus,this._agentsConfigChanged)}return s.Ld}},{kind:"method",key:"_downloadKey",value:function(){var e;const i=null===(e=this._config)||void 0===e?void 0:e.create_backup.password;i&&(0,r.VY)(this.hass,i)}},{kind:"method",key:"_copyKeyToClipboard",value:async function(){await(0,c.v)(this._config.create_backup.password,this.renderRoot.querySelector("div")),(0,u.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}},{kind:"method",key:"_dataConfig",value:function(e){const{include_addons:i,include_all_addons:a,include_database:t,include_folders:n}=e.create_backup;return{include_homeassistant:!0,include_database:t,include_folders:n||void 0,include_all_addons:a,include_addons:i||void 0}}},{kind:"method",key:"_dataChanged",value:function(e){const i=e.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{create_backup:Object.assign(Object.assign({},this._config.create_backup),{},{include_database:i.include_database,include_folders:i.include_folders||null,include_all_addons:i.include_all_addons,include_addons:i.include_addons||null})})}},{kind:"method",key:"_scheduleChanged",value:function(e){const i=e.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{schedule:i.schedule,retention:i.retention})}},{kind:"method",key:"_agentsConfigChanged",value:function(e){const i=e.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{create_backup:Object.assign(Object.assign({},this._config.create_backup),{},{agent_ids:i})})}},{kind:"get",static:!0,key:"styles",value:function(){return[h.Qx,h.yu,(0,s.iv)(S||(S=z`.encryption-key p,.welcome{text-align:center}ha-md-dialog{width:90vw;max-width:560px;--dialog-content-padding:8px 24px;max-height:min(605px,100% - 48px)}ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-md-list.full{--md-list-item-leading-space:24px;--md-list-item-trailing-space:24px;margin-left:-24px;margin-right:-24px}@media all and (max-width:450px),all and (max-height:500px){ha-md-dialog{max-width:none}div[slot=content]{margin-top:0}}p{margin-top:0}.encryption-key{border:1px solid var(--divider-color);background-color:var(--primary-background-color);border-radius:8px;padding:16px;display:flex;flex-direction:row;align-items:center;gap:24px}.encryption-key p{margin:0;flex:1;font-family:"Roboto Mono",Consolas,Menlo,monospace;font-size:20px;font-style:normal;font-weight:400;line-height:28px}.encryption-key ha-icon-button{flex:none;margin:-16px}`))]}}]}}),s.oi);t()}catch(m){t(m)}}))}}]);
//# sourceMappingURL=89793.a7c88da0c65df53a.js.map