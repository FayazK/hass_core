"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["20720"],{38406:function(i,e,t){t.a(i,(async function(i,s){try{t.r(e);var a=t(61701),n=(t(71695),t(40251),t(47021),t(31622),t(57243)),o=t(50778),c=t(36522),l=t(17170),r=t(73729),d=t(88935),h=t(28008),u=i([l]);l=(u.then?(await u)():u)[0];let v,p,g,m,f,_,w=i=>i;const y="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z",k="M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z";(0,a.Z)([(0,o.Mo)("dialog-matter-reinterview-node")],(function(i,e){return{F:class extends e{constructor(...e){super(...e),i(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"device_id",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_status",value:void 0},{kind:"method",key:"showDialog",value:async function(i){this.device_id=i.device_id}},{kind:"method",key:"render",value:function(){return this.device_id?(0,n.dy)(v||(v=w`
      <ha-dialog open @closed=${0} .heading=${0}>
        ${0}
      </ha-dialog>
    `),this.closeDialog,(0,r.i)(this.hass,this.hass.localize("ui.panel.config.matter.reinterview_node.title")),this._status?"started"===this._status?(0,n.dy)(g||(g=w`
                <div class="flex-container">
                  <ha-spinner></ha-spinner>
                  <div class="status">
                    <p>
                      <b>
                        ${0}
                      </b>
                    </p>
                    <p>
                      ${0}
                    </p>
                  </div>
                </div>
                <mwc-button slot="primaryAction" @click=${0}>
                  ${0}
                </mwc-button>
              `),this.hass.localize("ui.panel.config.matter.reinterview_node.in_progress"),this.hass.localize("ui.panel.config.matter.reinterview_node.run_in_background"),this.closeDialog,this.hass.localize("ui.common.close")):"failed"===this._status?(0,n.dy)(m||(m=w`
                  <div class="flex-container">
                    <ha-svg-icon .path=${0} class="failed"></ha-svg-icon>
                    <div class="status">
                      <p>
                        ${0}
                      </p>
                    </div>
                  </div>
                  <mwc-button slot="primaryAction" @click=${0}>
                    ${0}
                  </mwc-button>
                `),k,this.hass.localize("ui.panel.config.matter.reinterview_node.interview_failed"),this.closeDialog,this.hass.localize("ui.common.close")):"finished"===this._status?(0,n.dy)(f||(f=w`
                    <div class="flex-container">
                      <ha-svg-icon .path=${0} class="success"></ha-svg-icon>
                      <div class="status">
                        <p>
                          ${0}
                        </p>
                      </div>
                    </div>
                    <mwc-button slot="primaryAction" @click=${0}>
                      ${0}
                    </mwc-button>
                  `),y,this.hass.localize("ui.panel.config.matter.reinterview_node.interview_complete"),this.closeDialog,this.hass.localize("ui.common.close")):n.Ld:(0,n.dy)(p||(p=w`
              <p>
                ${0}
              </p>
              <p>
                <em>
                  ${0}
                </em>
              </p>
              <mwc-button slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),this.hass.localize("ui.panel.config.matter.reinterview_node.introduction"),this.hass.localize("ui.panel.config.matter.reinterview_node.battery_device_warning"),this._startReinterview,this.hass.localize("ui.panel.config.matter.reinterview_node.start_reinterview"))):n.Ld}},{kind:"method",key:"_startReinterview",value:async function(){if(this.hass){this._status="started";try{await(0,d.Cu)(this.hass,this.device_id),this._status="finished"}catch(i){this._status="failed"}}}},{kind:"method",key:"closeDialog",value:function(){this.device_id=void 0,this._status=void 0,(0,c.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"get",static:!0,key:"styles",value:function(){return[h.yu,(0,n.iv)(_||(_=w`.success{color:var(--success-color)}.failed{color:var(--error-color)}.flex-container{display:flex;align-items:center}.stages{margin-top:16px}.stage ha-svg-icon{width:16px;height:16px}.stage{padding:8px}ha-svg-icon{width:68px;height:48px}.flex-container ha-spinner,.flex-container ha-svg-icon{margin-right:20px}`))]}}]}}),n.oi);s()}catch(v){s(v)}}))}}]);
//# sourceMappingURL=20720.ebd9cd4a5d38f24c.js.map