"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["83537"],{40445:function(t,i,e){e.a(t,(async function(t,n){try{e.r(i);var s=e(61701),o=(e(52247),e(71695),e(9359),e(52924),e(47021),e(57243)),a=e(50778),h=e(73358),r=e(73850),u=(e(29891),e(93331)),c=e(8069),d=e(62577),f=t([c]);c=(f.then?(await f)():f)[0];let g,l,y,k,v=t=>t;(0,s.Z)([(0,a.Mo)("hui-group-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_config",value:void 0},{kind:"method",key:"_computeCanToggle",value:function(t,i){return i.some((i=>{const e=(0,r.M)(i);var n;return"group"===e?this._computeCanToggle(t,null===(n=this.hass)||void 0===n?void 0:n.states[i].attributes.entity_id):h.Kk.has(e)}))}},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,u.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const t=this.hass.states[this._config.entity];return t?(0,o.dy)(l||(l=v`
      <hui-generic-entity-row .hass=${0} .config=${0}>
        ${0}
      </hui-generic-entity-row>
    `),this.hass,this._config,this._computeCanToggle(this.hass,t.attributes.entity_id)?(0,o.dy)(y||(y=v`
              <ha-entity-toggle .hass=${0} .stateObj=${0}></ha-entity-toggle>
            `),this.hass,t):(0,o.dy)(k||(k=v`
              <div class="text-content">
                ${0}
              </div>
            `),this.hass.formatEntityState(t))):(0,o.dy)(g||(g=v`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,d.i)(this.hass,this._config.entity))}}]}}),o.oi);n()}catch(g){n(g)}}))}}]);
//# sourceMappingURL=83537.b8967af78042d453.js.map