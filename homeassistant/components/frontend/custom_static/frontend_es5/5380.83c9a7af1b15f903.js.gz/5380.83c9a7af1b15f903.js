"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["5380"],{57548:function(t,i,n){n.a(t,(async function(t,s){try{n.r(i);var e=n(61701),o=(n(52247),n(71695),n(40251),n(47021),n(31622),n(57243)),a=n(50778),r=n(96194),h=n(93331),c=n(8069),u=n(62577),d=n(55370),l=t([c]);c=(l.then?(await l)():l)[0];let f,g,y,k=t=>t;(0,e.Z)([(0,a.Mo)("hui-input-button-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,h.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const t=this.hass.states[this._config.entity];return t?(0,o.dy)(g||(g=k`
      <hui-generic-entity-row .hass=${0} .config=${0}>
        <mwc-button @click=${0} .disabled=${0}>
          ${0}
        </mwc-button>
      </hui-generic-entity-row>
    `),this.hass,this._config,this._pressButton,t.state===r.nZ,this.hass.localize("ui.card.button.press")):(0,o.dy)(f||(f=k`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,u.i)(this.hass,this._config.entity))}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(y||(y=k`mwc-button:last-child{margin-right:-.57em;margin-inline-end:-.57em;margin-inline-start:initial}`))}},{kind:"method",key:"_pressButton",value:async function(t){var i;t.stopPropagation(),null!==(i=this._config)&&void 0!==i&&i.confirmation&&!(await(0,d.g)(this,this.hass,this._config.confirmation,this.hass.localize("ui.card.button.press")))||this.hass.callService("input_button","press",{entity_id:this._config.entity})}}]}}),o.oi);s()}catch(f){s(f)}}))}}]);
//# sourceMappingURL=5380.83c9a7af1b15f903.js.map