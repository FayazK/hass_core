(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["55966"],{96814:function(i,e,a){a(9359),a(31526),i.exports=function i(e){return Object.freeze(e),Object.getOwnPropertyNames(e).forEach((function(a){!e.hasOwnProperty(a)||null===e[a]||"object"!=typeof e[a]&&"function"!=typeof e[a]||Object.isFrozen(e[a])||i(e[a])})),e}},58064:function(i,e,a){"use strict";a.a(i,(async function(i,t){try{a.r(e),a.d(e,{HuiDialogSuggestBadge:()=>$});var s=a(61701),o=(a(71695),a(9359),a(70104),a(40251),a(47021),a(96814)),n=a.n(o),d=a(57243),l=a(50778),h=a(36522),r=(a(64889),a(17170)),c=a(28008),g=a(58885),u=a(69040),m=a(27353),f=a(2593),v=i([r,u]);[r,u]=v.then?(await v)():v;let p,_,y,b,k,w,C,x=i=>i,$=(0,s.Z)([(0,l.Mo)("hui-dialog-suggest-badge")],(function(i,e){return{F:class extends e{constructor(...e){super(...e),i(this)}},d:[{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_badgeConfig",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_saving",value(){return!1}},{kind:"field",decorators:[(0,l.IO)("ha-yaml-editor")],key:"_yamlEditor",value:void 0},{kind:"method",key:"showDialog",value:function(i){this._params=i,this._badgeConfig=i.badgeConfig,Object.isFrozen(this._badgeConfig)||(this._badgeConfig=n()(this._badgeConfig)),this._yamlEditor&&this._yamlEditor.setValue(this._badgeConfig)}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,this._badgeConfig=void 0,(0,h.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"_renderPreview",value:function(){return this._badgeConfig?(0,d.dy)(p||(p=x`
        <div class="element-preview">
          ${0}
        </div>
      `),this._badgeConfig.map((i=>(0,d.dy)(_||(_=x`
              <hui-badge .hass=${0} .config=${0} preview></hui-badge>
            `),this.hass,i)))):d.Ld}},{kind:"method",key:"render",value:function(){return this._params?(0,d.dy)(y||(y=x`
      <ha-dialog open scrimClickAction @closed=${0} .heading=${0}>
        <div>
          ${0}
          ${0}
        </div>
        <mwc-button slot="secondaryAction" @click=${0} dialogInitialFocus>
          ${0}
        </mwc-button>
        ${0}
      </ha-dialog>
    `),this.closeDialog,this.hass.localize("ui.panel.lovelace.editor.suggest_badge.header"),this._renderPreview(),this._params.yaml&&this._badgeConfig?(0,d.dy)(b||(b=x`
                <div class="editor">
                  <ha-yaml-editor .hass=${0} .defaultValue=${0}></ha-yaml-editor>
                </div>
              `),this.hass,this._badgeConfig):d.Ld,this.closeDialog,this._params.yaml?this.hass.localize("ui.common.close"):this.hass.localize("ui.common.cancel"),this._params.yaml?d.Ld:(0,d.dy)(k||(k=x`
              <mwc-button slot="primaryAction" .disabled=${0} @click=${0}>
                ${0}
              </mwc-button>
            `),this._saving,this._save,this._saving?(0,d.dy)(w||(w=x`
                      <ha-spinner aria-label="Saving" size="small"></ha-spinner>
                    `)):this.hass.localize("ui.panel.lovelace.editor.suggest_badge.add"))):d.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[c.yu,(0,d.iv)(C||(C=x`@media all and (max-width:450px),all and (max-height:500px){ha-dialog{max-height:100%;height:100%}}@media all and (min-width:850px){ha-dialog{width:845px}}ha-dialog{max-width:845px;--dialog-z-index:6}.hidden{display:none}.element-preview{position:relative;display:flex;align-items:flex-start;flex-wrap:wrap;justify-content:center;gap:8px;margin:0}.editor{padding-top:16px}`))]}},{kind:"method",key:"_computeNewConfig",value:function(i,e){const{viewIndex:a}=(0,f.jb)(e),t=this._badgeConfig;return(0,m.xy)(i,[a],t)}},{kind:"method",key:"_save",value:async function(){var i,e,a;if(!(null!==(i=this._params)&&void 0!==i&&i.lovelaceConfig&&null!==(e=this._params)&&void 0!==e&&e.path&&null!==(a=this._params)&&void 0!==a&&a.saveConfig&&this._badgeConfig))return;this._saving=!0;const t=this._computeNewConfig(this._params.lovelaceConfig,this._params.path);await this._params.saveConfig(t),this._saving=!1,(0,g.f)(this,this.hass),this.closeDialog()}}]}}),d.oi);t()}catch(p){t(p)}}))},58885:function(i,e,a){"use strict";a.d(e,{f:()=>s});var t=a(72473);const s=(i,e)=>(0,t.C)(i,{message:e.localize("ui.common.successfully_saved")})}}]);
//# sourceMappingURL=55966.6677caf62d103e7f.js.map