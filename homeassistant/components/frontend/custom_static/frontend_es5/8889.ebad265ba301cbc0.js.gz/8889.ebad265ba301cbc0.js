"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["8889"],{78244:function(a,t,e){var i=e(61701),s=(e(71695),e(47021),e(6942)),n=e(50778);(0,i.Z)([(0,n.Mo)("ha-fade-in")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,n.Cb)()],key:"name",value(){return"fadeIn"}},{kind:"field",decorators:[(0,n.Cb)()],key:"fill",value(){return"both"}},{kind:"field",decorators:[(0,n.Cb)({type:Boolean})],key:"play",value(){return!0}},{kind:"field",decorators:[(0,n.Cb)({type:Number})],key:"iterations",value(){return 1}}]}}),s.Z)},55195:function(a,t,e){var i=e(61701),s=(e(71695),e(47021),e(27486)),n=e(57243),o=e(50778),d=(e(54977),e(19993),e(74633),e(59826),e(29232),e(36522));let l,c,r=a=>a;(0,i.Z)([(0,o.Mo)("ha-backup-details-restore")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"localize",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Object})],key:"backup",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"ha-required"})],key:"haRequired",value(){return!1}},{kind:"field",decorators:[(0,o.Cb)({attribute:"translation-key-panel"})],key:"translationKeyPanel",value(){return"config.backup"}},{kind:"field",decorators:[(0,o.SB)()],key:"_selectedData",value:void 0},{kind:"method",key:"willUpdate",value:function(){!this.hasUpdated&&this.haRequired&&(this._selectedData={homeassistant_included:!0,folders:[],addons:[],homeassistant_version:this.backup.homeassistant_version,database_included:this.backup.database_included})}},{kind:"method",key:"render",value:function(){return(0,n.dy)(l||(l=r`
      <ha-card>
        <div class="card-header">
          ${0}
        </div>
        <div class="card-content">
          <ha-backup-data-picker .translationKeyPanel=${0} .localize=${0} .hass=${0} .data=${0} .value=${0} @value-changed=${0} .requiredItems=${0}>
          </ha-backup-data-picker>
        </div>
        <div class="card-actions">
          <ha-button @click=${0} .disabled=${0} destructive>
            ${0}
          </ha-button>
        </div>
      </ha-card>
    `),this.localize(`ui.panel.${this.translationKeyPanel}.details.restore.title`),this.translationKeyPanel,this.localize,this.hass,this.backup,this._selectedData,this._selectedBackupChanged,this._isHomeAssistantRequired(this.haRequired),this._restore,this._isRestoreDisabled,this.localize(`ui.panel.${this.translationKeyPanel}.details.restore.action`))}},{kind:"method",key:"_restore",value:function(){(0,d.B)(this,"backup-restore",{selectedData:this._selectedData})}},{kind:"method",key:"_selectedBackupChanged",value:function(a){a.stopPropagation(),this._selectedData=a.detail.value}},{kind:"field",key:"_isHomeAssistantRequired",value(){return(0,s.Z)((a=>a?["config"]:[]))}},{kind:"get",key:"_isRestoreDisabled",value:function(){var a,t;return!this._selectedData||this.haRequired&&!this._selectedData.homeassistant_included||!(null!==(a=this._selectedData)&&void 0!==a&&a.database_included||null!==(t=this._selectedData)&&void 0!==t&&t.homeassistant_included||this._selectedData.addons.length||this._selectedData.folders.length)}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(c||(c=r`:host{max-width:690px;width:100%;margin:0 auto;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}`))}}]}}),n.oi)},83457:function(a,t,e){e.a(a,(async function(a,t){try{var i=e(61701),s=(e(71695),e(47021),e(57243)),n=e(50778),o=(e(54977),e(19993),e(74633),e(64214)),d=e(26779),l=e(90698),c=a([o,d]);[o,d]=c.then?(await c)():c;let r,h,u=a=>a;(0,i.Z)([(0,n.Mo)("ha-backup-details-summary")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({type:Object})],key:"backup",value:void 0},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"hassio"})],key:"isHassio",value(){return!1}},{kind:"method",key:"render",value:function(){const a=new Date(this.backup.date),t=(0,o.o0)(a,this.hass.locale,this.hass.config);return(0,s.dy)(r||(r=u`
      <ha-card>
        <div class="card-header">
          ${0}
        </div>
        <div class="card-content">
          <ha-md-list class="summary">
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
            </ha-md-list-item>
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
            </ha-md-list-item>
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">${0}</span>
            </ha-md-list-item>
          </ha-md-list>
        </div>
      </ha-card>
    `),this.hass.localize("ui.panel.config.backup.details.summary.title"),this.hass.localize("ui.panel.config.backup.backup_type"),this.hass.localize(`ui.panel.config.backup.type.${(0,d.Vn)(this.backup,this.isHassio)}`),this.hass.localize("ui.panel.config.backup.details.summary.size"),(0,l.d)((0,d.En)(this.backup)),this.hass.localize("ui.panel.config.backup.details.summary.created"),t)}},{kind:"field",static:!0,key:"styles",value(){return(0,s.iv)(h||(h=u`:host{max-width:690px;width:100%;margin:0 auto;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list.summary ha-md-list-item{--md-list-item-supporting-text-size:1rem;--md-list-item-label-text-size:0.875rem;--md-list-item-label-text-color:var(--secondary-text-color);--md-list-item-supporting-text-color:var(--primary-text-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}`))}}]}}),s.oi);t()}catch(r){t(r)}}))},96804:function(a,t,e){e.d(t,{U:()=>n});e(71695),e(40251),e(47021);var i=e(36522);const s=()=>Promise.all([e.e("7442"),e.e("51747")]).then(e.bind(e,60906)),n=(a,t)=>{(0,i.B)(a,"show-dialog",{dialogTag:"ha-dialog-restore-backup",dialogImport:s,dialogParams:t})}},13526:function(a,t,e){e.a(a,(async function(a,i){try{e.r(t);var s=e(61701),n=e(72621),o=(e(19083),e(71695),e(61893),e(9359),e(56475),e(70104),e(19423),e(40251),e(61006),e(47021),e(57243)),d=e(50778),l=e(73850),c=e(83523),r=(e(99426),e(59826),e(34273),e(54977),e(78244),e(17170)),h=(e(23334),e(7285),e(19993),e(74633),e(83457)),u=(e(55195),e(26779)),p=(e(87979),e(88238)),k=e(96804),m=e(36522),g=e(76131),b=e(9807),v=e(72344),f=a([r,h,b,u]);[r,h,b,u]=f.then?(await f)():f;let y,_,$,x,w,A,z,H,C,M,V,B,D,L,Z=a=>a;const R="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",j="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",q="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",I="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M12,4A6,6 0 0,0 6,10C6,13.31 8.69,16 12.1,16L11.22,13.77C10.95,13.29 11.11,12.68 11.59,12.4L12.45,11.9C12.93,11.63 13.54,11.79 13.82,12.27L15.74,14.69C17.12,13.59 18,11.9 18,10A6,6 0 0,0 12,4M12,9A1,1 0 0,1 13,10A1,1 0 0,1 12,11A1,1 0 0,1 11,10A1,1 0 0,1 12,9M7,18A1,1 0 0,0 6,19A1,1 0 0,0 7,20A1,1 0 0,0 8,19A1,1 0 0,0 7,18M12.09,13.27L14.58,19.58L17.17,18.08L12.95,12.77L12.09,13.27Z",P="M4,5C2.89,5 2,5.89 2,7V17C2,18.11 2.89,19 4,19H20C21.11,19 22,18.11 22,17V7C22,5.89 21.11,5 20,5H4M4.5,7A1,1 0 0,1 5.5,8A1,1 0 0,1 4.5,9A1,1 0 0,1 3.5,8A1,1 0 0,1 4.5,7M7,7H20V17H7V7M8,8V16H11V8H8M12,8V16H15V8H12M16,8V16H19V8H16M9,9H10V10H9V9M13,9H14V10H13V9M17,9H18V10H17V9Z",U=a=>{var t;const e=Object.keys(a.agents),i=null!==(t=a.failed_agent_ids)&&void 0!==t?t:[];return[...e.filter((a=>!i.includes(a))),...i].map((t=>{var e;const s=null!==(e=a.agents[t])&&void 0!==e?e:{protected:!1,size:0};return Object.assign(Object.assign({},s),{},{id:t,success:!i.includes(t)})})).sort(((a,t)=>(0,u.Ef)(a.id,t.id)))};(0,s.Z)([(0,d.Mo)("ha-config-backup-details")],(function(a,t){class e extends t{constructor(...t){super(...t),a(this)}}return{F:e,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.Cb)({type:Boolean})],key:"narrow",value(){return!1}},{kind:"field",decorators:[(0,d.Cb)({attribute:"backup-id"})],key:"backupId",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"agents",value(){return[]}},{kind:"field",decorators:[(0,d.SB)()],key:"_backup",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_agents",value(){return[]}},{kind:"field",decorators:[(0,d.SB)()],key:"_error",value:void 0},{kind:"method",key:"firstUpdated",value:function(a){(0,n.Z)(e,"firstUpdated",this,3)([a]),this.backupId?this._fetchBackup():this._error="Backup id not defined"}},{kind:"method",key:"render",value:function(){var a;if(!this.hass)return o.Ld;const t=(0,v.p)(this.hass,"hassio");return(0,o.dy)(y||(y=Z`
      <hass-subpage back-path="/config/backup/backups" .hass=${0} .narrow=${0} .header=${0}>
        <ha-button-menu slot="toolbar-icon" @action=${0}>
          <ha-icon-button slot="trigger" .label=${0} .path=${0}></ha-icon-button>
          <ha-list-item graphic="icon">
            <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
            ${0}
          </ha-list-item>
          <ha-list-item graphic="icon" class="warning">
            <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
            ${0}
          </ha-list-item>
        </ha-button-menu>
        <div class="content">
          ${0}
          ${0}
        </div>
      </hass-subpage>
    `),this.hass,this.narrow,(null===(a=this._backup)||void 0===a?void 0:a.name)||this.hass.localize("ui.panel.config.backup.details.header"),this._handleAction,this.hass.localize("ui.common.menu"),j,q,this.hass.localize("ui.common.download"),R,this.hass.localize("ui.common.delete"),this._error&&(0,o.dy)(_||(_=Z`<ha-alert alert-type="error">${0}</ha-alert>`),this._error),null===this._backup?(0,o.dy)($||($=Z`
                <ha-alert alert-type="warning" .title=${0}>
                  ${0}
                </ha-alert>
              `),this.hass.localize("ui.panel.config.backup.details.not_found"),this.hass.localize("ui.panel.config.backup.details.not_found_description",{backupId:this.backupId})):this._backup?(0,o.dy)(w||(w=Z`
                  <ha-backup-details-summary .backup=${0} .hass=${0} .localize=${0} .isHassio=${0}></ha-backup-details-summary>
                  <ha-backup-details-restore .backup=${0} @backup-restore=${0} .hass=${0} .localize=${0}></ha-backup-details-restore>
                  <ha-card>
                    <div class="card-header">
                      ${0}
                    </div>
                    <div class="card-content">
                      <ha-md-list>
                        ${0}
                      </ha-md-list>
                    </div>
                  </ha-card>
                `),this._backup,this.hass,this.hass.localize,t,this._backup,this._restore,this.hass,this.hass.localize,this.hass.localize("ui.panel.config.backup.details.locations.title"),this._agents.map((a=>{var t;const e=a.id,i=(0,l.M)(e),s=(0,u.Sw)(this.hass.localize,e,this.agents),n=a.success,d=!a.success,c=!a.protected;return(0,o.dy)(A||(A=Z`
                            <ha-md-list-item>
                              ${0}
                              <div slot="headline">${0}</div>
                                <div slot="supporting-text">
                                   ${0}
                                </div>
                              
                              ${0}
                            </ha-md-list-item>
                          `),(0,u.V1)(e)?(0,o.dy)(z||(z=Z`
                                      <ha-svg-icon .path=${0} slot="start">
                                      </ha-svg-icon>
                                    `),I):(0,u.BR)(e)?(0,o.dy)(H||(H=Z`
                                        <ha-svg-icon .path=${0} slot="start"></ha-svg-icon>
                                      `),P):(0,o.dy)(C||(C=Z`
                                        <img .src=${0} crossorigin="anonymous" referrerpolicy="no-referrer" alt=${0} slot="start"/>
                                      `),(0,p.X1)({domain:i,type:"icon",useFallback:!0,darkOptimized:null===(t=this.hass.themes)||void 0===t?void 0:t.darkMode}),`${i} logo`),s,d?(0,o.dy)(M||(M=Z`
                                           <span class="dot error"></span>
                                           <span>
                                             ${0}
                                           </span>
                                         `),this.hass.localize("ui.panel.config.backup.details.locations.backup_failed")):c?(0,o.dy)(V||(V=Z`
                                             <span class="dot warning"></span>
                                             <span>
                                               ${0}</span>
                                           `),this.hass.localize("ui.panel.config.backup.details.locations.unencrypted")):(0,o.dy)(B||(B=Z`
                                             <span class="dot success"></span>
                                             <span>${0}</span>
                                           `),this.hass.localize("ui.panel.config.backup.details.locations.encrypted")),n?(0,o.dy)(D||(D=Z`
                                      <ha-button-menu slot="end" @action=${0} .agent=${0} fixed>
                                        <ha-icon-button slot="trigger" .label=${0} .path=${0}></ha-icon-button>
                                        <ha-list-item graphic="icon">
                                          <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
                                          ${0}
                                        </ha-list-item>
                                      </ha-button-menu>
                                    `),this._handleAgentAction,e,this.hass.localize("ui.common.menu"),j,q,this.hass.localize("ui.panel.config.backup.details.locations.download")):o.Ld)}))):(0,o.dy)(x||(x=Z`<ha-fade-in .delay=${0}><ha-spinner></ha-spinner></ha-fade-in>`),1e3))}},{kind:"method",key:"_restore",value:function(a){this._backup&&a.detail.selectedData&&(0,k.U)(this,{backup:this._backup,selectedData:a.detail.selectedData})}},{kind:"method",key:"_fetchBackup",value:async function(){try{const a=await(0,u.Ye)(this.hass,this.backupId);this._backup=a.backup,this._agents=U(a.backup)}catch(a){this._error=(null==a?void 0:a.message)||this.hass.localize("ui.panel.config.backup.details.error")}}},{kind:"method",key:"_handleAction",value:function(a){switch(a.detail.index){case 0:this._downloadBackup();break;case 1:this._deleteBackup()}}},{kind:"method",key:"_handleAgentAction",value:function(a){const t=a.currentTarget.agent;this._downloadBackup(t)}},{kind:"method",key:"_downloadBackup",value:async function(a){await(0,b.w)(this.hass,this,this._backup,this.config,a)}},{kind:"method",key:"_deleteBackup",value:async function(){await(0,g.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.backup.dialogs.delete.title"),text:this.hass.localize("ui.panel.config.backup.dialogs.delete.text"),confirmText:this.hass.localize("ui.common.delete"),destructive:!0})&&(await(0,u.Ug)(this.hass,this._backup.backup_id),(0,m.B)(this,"ha-refresh-backup-info"),(0,c.c)("/config/backup"))}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(L||(L=Z`.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:grid}ha-spinner{margin:24px auto}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item img{width:48px}ha-md-list-item ha-svg-icon[slot=start]{--mdc-icon-size:48px;color:var(--primary-text-color)}.warning,.warning ha-svg-icon{color:var(--error-color)}ha-button.danger{--mdc-theme-primary:var(--error-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}.dot{display:block;position:relative;width:8px;height:8px;background-color:var(--disabled-color);border-radius:50%;flex:none}.dot.success{background-color:var(--success-color)}.dot.warning{background-color:var(--warning-color)}.dot.error{background-color:var(--error-color)}.card-header{padding-bottom:8px}`))}}]}}),o.oi);i()}catch(y){i(y)}}))}}]);
//# sourceMappingURL=8889.ebad265ba301cbc0.js.map