"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["32197"],{17170:function(e,t,r){r.a(e,(async function(e,n){try{r.r(t),r.d(t,{HaSpinner:()=>p});var i=r(61701),a=r(72621),s=(r(71695),r(47021),r(97677)),o=r(43580),c=r(57243),l=r(50778),d=e([s]);s=(d.then?(await d)():d)[0];let h,u=e=>e,p=(0,i.Z)([(0,l.Mo)("ha-spinner")],(function(e,t){class r extends t{constructor(...t){super(...t),e(this)}}return{F:r,d:[{kind:"field",decorators:[(0,l.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,a.Z)(r,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value(){return[o.Z,(0,c.iv)(h||(h=u`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`))]}}]}}),s.Z);n()}catch(h){n(h)}}))},50957:function(e,t,r){r.a(e,(async function(e,n){try{r.r(t),r.d(t,{HuiStartingCard:()=>m});var i=r(61701),a=r(72621),s=(r(71695),r(47021),r(31622),r(94277)),o=r(57243),c=r(50778),l=r(36522),d=(r(54977),r(17170)),h=e([d]);d=(h.then?(await h)():h)[0];let u,p,f=e=>e,m=(0,i.Z)([(0,c.Mo)("hui-starting-card")],(function(e,t){class r extends t{constructor(...t){super(...t),e(this)}}return{F:r,d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 2}},{kind:"method",key:"setConfig",value:function(e){}},{kind:"method",key:"updated",value:function(e){(0,a.Z)(r,"updated",this,3)([e]),e.has("hass")&&this.hass.config&&this.hass.config.state!==s.UE&&(0,l.B)(this,"config-refresh")}},{kind:"method",key:"render",value:function(){return this.hass?(0,o.dy)(u||(u=f`
      <div class="content">
        <ha-spinner></ha-spinner>
        ${0}
      </div>
    `),this.hass.localize("ui.panel.lovelace.cards.starting.description")):o.Ld}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(p||(p=f`:host{display:block;height:calc(100vh - var(--header-height))}ha-spinner{margin-bottom:20px}.content{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}`))}}]}}),o.oi);n()}catch(u){n(u)}}))},48734:function(e,t,r){r.a(e,(async function(e,n){try{r.d(t,{P5:()=>p,Ve:()=>m});var i=r(16485),a=(r(71695),r(9359),r(70104),r(19423),r(19134),r(92519),r(42179),r(89256),r(24931),r(88463),r(57449),r(19814),r(97003),r(47021),e([i]));i=(a.then?(await a)():a)[0];const o=new Set,c=new Map;let l,d="ltr",h="en";const u="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(u){const v=new MutationObserver(f);d=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language,v.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function p(...e){e.map((e=>{const t=e.$code.toLowerCase();c.has(t)?c.set(t,Object.assign(Object.assign({},c.get(t)),e)):c.set(t,e),l||(l=e)})),f()}function f(){u&&(d=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language),[...o.keys()].map((e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()}))}class m{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){o.add(this.host)}hostDisconnected(){o.delete(this.host)}dir(){return`${this.host.dir||d}`.toLowerCase()}lang(){return`${this.host.lang||h}`.toLowerCase()}getTranslationData(e){var t,r;const n=new Intl.Locale(e.replace(/_/g,"-")),i=null==n?void 0:n.language.toLowerCase(),a=null!==(r=null===(t=null==n?void 0:n.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==r?r:"";return{locale:n,language:i,region:a,primary:c.get(`${i}-${a}`),secondary:c.get(i)}}exists(e,t){var r;const{primary:n,secondary:i}=this.getTranslationData(null!==(r=t.lang)&&void 0!==r?r:this.lang());return t=Object.assign({includeFallback:!1},t),!!(n&&n[e]||i&&i[e]||t.includeFallback&&l&&l[e])}term(e,...t){const{primary:r,secondary:n}=this.getTranslationData(this.lang());let i;if(r&&r[e])i=r[e];else if(n&&n[e])i=n[e];else{if(!l||!l[e])return console.error(`No translation found for: ${String(e)}`),String(e);i=l[e]}return"function"==typeof i?i(...t):i}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,r){return new Intl.RelativeTimeFormat(this.lang(),r).format(e,t)}}n()}catch(s){n(s)}}))},68783:function(e,t,r){r.a(e,(async function(e,n){try{r.d(t,{A:()=>d});r(71695),r(47021);var i=r(64699),a=r(15073),s=r(81048),o=r(31027),c=r(57243),l=e([a]);a=(l.then?(await l)():l)[0];let h,u=e=>e;var d=class extends o.P{constructor(){super(...arguments),this.localize=new a.V(this)}render(){return(0,c.dy)(h||(h=u`
      <svg part="base" class="spinner" role="progressbar" aria-label=${0}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `),this.localize.term("loading"))}};d.styles=[s.N,i.D],n()}catch(h){n(h)}}))},31027:function(e,t,r){r.d(t,{P:()=>o});r(71695),r(9359),r(31526),r(46692),r(47021);var n,i=r(52812),a=r(57243),s=r(50778),o=class extends a.oi{constructor(){super(),(0,i.Ko)(this,n,!1),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach((([e,t])=>{this.constructor.define(e,t)}))}emit(e,t){const r=new CustomEvent(e,(0,i.ih)({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(r),r}static define(e,t=this,r={}){const n=customElements.get(e);if(!n){try{customElements.define(e,t,r)}catch(s){customElements.define(e,class extends t{},r)}return}let i=" (unknown version)",a=i;"version"in t&&t.version&&(i=" v"+t.version),"version"in n&&n.version&&(a=" v"+n.version),i&&a&&i===a||console.warn(`Attempted to register <${e}>${i}, but <${e}>${a} has already been registered.`)}attributeChangedCallback(e,t,r){(0,i.ac)(this,n)||(this.constructor.elementProperties.forEach(((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])})),(0,i.qx)(this,n,!0)),super.attributeChangedCallback(e,t,r)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach(((t,r)=>{e.has(r)&&null==this[r]&&(this[r]=t)}))}};n=new WeakMap,o.version="2.20.1",o.dependencies={},(0,i.u2)([(0,s.Cb)()],o.prototype,"dir",2),(0,i.u2)([(0,s.Cb)()],o.prototype,"lang",2)},15073:function(e,t,r){r.a(e,(async function(e,n){try{r.d(t,{V:()=>o});var i=r(21262),a=r(48734),s=e([a,i]);[a,i]=s.then?(await s)():s;var o=class extends a.Ve{};(0,a.P5)(i.K),n()}catch(c){n(c)}}))},21262:function(e,t,r){r.a(e,(async function(e,n){try{r.d(t,{K:()=>o});var i=r(48734),a=e([i]);i=(a.then?(await a)():a)[0];var s={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};(0,i.P5)(s);var o=s;n()}catch(c){n(c)}}))},64699:function(e,t,r){r.d(t,{D:()=>i});let n;var i=(0,r(57243).iv)(n||(n=(e=>e)`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`))},52812:function(e,t,r){r.d(t,{EZ:()=>p,Ko:()=>g,ac:()=>v,ih:()=>u,qx:()=>y,u2:()=>f});r(63721),r(52247),r(71695),r(40251),r(47021);var n=Object.defineProperty,i=Object.defineProperties,a=Object.getOwnPropertyDescriptor,s=Object.getOwnPropertyDescriptors,o=Object.getOwnPropertySymbols,c=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=e=>{throw TypeError(e)},h=(e,t,r)=>t in e?n(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,u=(e,t)=>{for(var r in t||(t={}))c.call(t,r)&&h(e,r,t[r]);if(o)for(var r of o(t))l.call(t,r)&&h(e,r,t[r]);return e},p=(e,t)=>i(e,s(t)),f=(e,t,r,i)=>{for(var s,o=i>1?void 0:i?a(t,r):t,c=e.length-1;c>=0;c--)(s=e[c])&&(o=(i?s(t,r,o):s(o))||o);return i&&o&&n(t,r,o),o},m=(e,t,r)=>t.has(e)||d("Cannot "+r),v=(e,t,r)=>(m(e,t,"read from private field"),r?r.call(e):t.get(e)),g=(e,t,r)=>t.has(e)?d("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,r),y=(e,t,r,n)=>(m(e,t,"write to private field"),n?n.call(e,r):t.set(e,r),r)},81048:function(e,t,r){r.d(t,{N:()=>i});let n;var i=(0,r(57243).iv)(n||(n=(e=>e)`:host{box-sizing:border-box}:host *,:host ::after,:host ::before{box-sizing:inherit}[hidden]{display:none!important}`))},97677:function(e,t,r){r.a(e,(async function(e,n){try{r.d(t,{Z:()=>i.A});var i=r(68783),a=(r(64699),r(15073)),s=r(21262),o=(r(81048),r(31027),r(52812),e([a,s,i]));[a,s,i]=o.then?(await o)():o,n()}catch(c){n(c)}}))},43580:function(e,t,r){r.d(t,{Z:()=>n.D});var n=r(64699);r(52812)}}]);
//# sourceMappingURL=32197.8a5dcfa06bfd4ca3.js.map