"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["65430"],{78244:function(t,i,n){var e=n(61701),a=(n(71695),n(47021),n(6942)),o=n(50778);(0,e.Z)([(0,o.Mo)("ha-fade-in")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,o.Cb)()],key:"name",value(){return"fadeIn"}},{kind:"field",decorators:[(0,o.Cb)()],key:"fill",value(){return"both"}},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"play",value(){return!0}},{kind:"field",decorators:[(0,o.Cb)({type:Number})],key:"iterations",value(){return 1}}]}}),a.Z)},48189:function(t,i,n){n.a(t,(async function(t,e){try{n.r(i);var a=n(61701),o=(n(52247),n(71695),n(9359),n(1331),n(19423),n(40251),n(47021),n(57243)),s=n(50778),c=(n(99426),n(59826),n(1888),n(34273),n(54977),n(78244),n(17170)),r=(n(23334),n(7285),n(19993),n(74633),n(26779)),l=(n(87979),n(29232),n(12660)),d=n(36522),p=t([c,r,l]);[c,r,l]=p.then?(await p)():p;let h,u,g,f,y,k,m,b,_,v,x=t=>t;(0,a.Z)([(0,s.Mo)("ha-config-backup-location")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value(){return!1}},{kind:"field",decorators:[(0,s.Cb)({attribute:"agent-id"})],key:"agentId",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"agents",value(){return[]}},{kind:"field",decorators:[(0,s.SB)()],key:"_agent",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_error",value:void 0},{kind:"method",key:"willUpdate",value:function(t){t.has("agentId")&&(this.agentId?this._fetchAgent():this._error="Agent id not defined")}},{kind:"method",key:"render",value:function(){if(!this.hass)return o.Ld;const t=this._isEncryptionTurnedOn();return(0,o.dy)(h||(h=x`
      <hass-subpage back-path="/config/backup/settings" .hass=${0} .narrow=${0} .header=${0}>
        <div class="content">
          ${0}
          ${0}
        </div>
      </hass-subpage>
    `),this.hass,this.narrow,this._agent&&(0,r.Sw)(this.hass.localize,this.agentId,this.agents)||this.hass.localize("ui.panel.config.backup.location.header"),this._error&&(0,o.dy)(u||(u=x`<ha-alert alert-type="error">${0}</ha-alert>`),this._error),null===this._agent?(0,o.dy)(g||(g=x`
                <ha-alert alert-type="warning" .title=${0}>
                  ${0}
                </ha-alert>
              `),this.hass.localize("ui.panel.config.backup.location.not_found"),this.hass.localize("ui.panel.config.backup.location.not_found_description",{agentId:this.agentId})):this.agentId?(0,o.dy)(y||(y=x`
                  ${0}
                  <ha-card>
                    <div class="card-header">
                      ${0}
                    </div>
                    <div class="card-content">
                      <p>
                        ${0}
                      </p>
                      <ha-md-list>
                        ${0}
                      </ha-md-list>
                    </div>
                  </ha-card>
                `),r.$u===this.agentId?(0,o.dy)(k||(k=x`
                        <ha-card>
                          <div class="card-header">
                            ${0}
                          </div>
                          <div class="card-content">
                            <p>
                              ${0}
                            </p>
                          </div>
                        </ha-card>
                      `),this.hass.localize("ui.panel.config.backup.location.configuration.title"),this.hass.localize("ui.panel.config.backup.location.configuration.cloud_description")):o.Ld,this.hass.localize("ui.panel.config.backup.location.encryption.title"),this.hass.localize("ui.panel.config.backup.location.encryption.description"),r.$u===this.agentId?(0,o.dy)(m||(m=x`
                              <ha-md-list-item>
                                <span slot="headline">
                                  ${0}
                                </span>
                                <span slot="supporting-text">
                                  ${0}
                                </span>
                                <a href="https://www.nabucasa.com/config/backups/" target="_blank" slot="end" rel="noreferrer noopener">
                                  <ha-button>
                                    ${0}
                                  </ha-button>
                                </a>
                              </ha-md-list-item>
                            `),this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted"),this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_cloud_description"),this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_cloud_learn_more")):t?(0,o.dy)(b||(b=x`
                                <ha-md-list-item>
                                  <span slot="headline">
                                    ${0}
                                  </span>
                                  <span slot="supporting-text">
                                    ${0}
                                  </span>

                                  <ha-button slot="end" @click=${0} destructive>
                                    ${0}
                                  </ha-button>
                                </ha-md-list-item>
                              `),this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted"),this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_description"),this._turnOffEncryption,this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off")):(0,o.dy)(_||(_=x`
                                <ha-alert alert-type="warning" .title=${0}>
                                  ${0}
                                </ha-alert>
                                <ha-md-list-item>
                                  <span slot="headline">
                                    ${0}
                                  </span>
                                  <span slot="supporting-text">
                                    ${0}
                                  </span>

                                  <ha-button slot="end" @click=${0}>
                                    ${0}
                                  </ha-button>
                                </ha-md-list-item>
                              `),this.hass.localize("ui.panel.config.backup.location.encryption.warning_encryption_turn_off"),this.hass.localize("ui.panel.config.backup.location.encryption.warning_encryption_turn_off_description"),this.hass.localize("ui.panel.config.backup.location.encryption.location_unencrypted"),this.hass.localize("ui.panel.config.backup.location.encryption.location_unencrypted_description"),this._turnOnEncryption,this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_on"))):(0,o.dy)(f||(f=x`<ha-fade-in .delay=${0}><ha-spinner></ha-spinner></ha-fade-in>`),1e3))}},{kind:"method",key:"_isEncryptionTurnedOn",value:function(){var t;const i=null===(t=this.config)||void 0===t?void 0:t.agents[this.agentId];return!i||i.protected}},{kind:"method",key:"_fetchAgent",value:async function(){try{const{agents:t}=await(0,r.xc)(this.hass),i=t.find((t=>t.agent_id===this.agentId));if(!i)throw new Error("Agent not found");this._agent=i}catch(t){this._error=(null==t?void 0:t.message)||this.hass.localize("ui.panel.config.backup.details.error")}}},{kind:"method",key:"_updateAgentEncryption",value:async function(t){var i,n;const e=Object.assign(Object.assign({},null===(i=this.config)||void 0===i?void 0:i.agents),{},{[this.agentId]:Object.assign(Object.assign({},null===(n=this.config)||void 0===n?void 0:n.agents[this.agentId]),{},{protected:t})});await(0,r._r)(this.hass,{agents:e}),(0,d.B)(this,"ha-refresh-backup-config")}},{kind:"method",key:"_turnOnEncryption",value:function(){this._updateAgentEncryption(!0)}},{kind:"method",key:"_turnOffEncryption",value:async function(){await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_title"),text:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_text"),confirmText:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_action"),dismissText:this.hass.localize("ui.common.cancel"),destructive:!0})&&this._updateAgentEncryption(!1)}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(v||(v=x`.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}.dot,ha-backup-data-picker{display:block}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item img{width:48px}ha-md-list-item ha-svg-icon[slot=start]{--mdc-icon-size:48px;color:var(--primary-text-color)}ha-md-list.summary ha-md-list-item{--md-list-item-supporting-text-size:1rem;--md-list-item-label-text-size:0.875rem;--md-list-item-label-text-color:var(--secondary-text-color);--md-list-item-supporting-text-color:var(--primary-text-color)}.warning,.warning ha-svg-icon{color:var(--error-color)}ha-button.danger{--mdc-theme-primary:var(--error-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}.dot{position:relative;width:8px;height:8px;background-color:var(--disabled-color);border-radius:50%;flex:none}.dot.success{background-color:var(--success-color)}.dot.error{background-color:var(--error-color)}.card-header{padding-bottom:8px}ha-spinner{margin:24px auto}`))}}]}}),o.oi);e()}catch(h){e(h)}}))}}]);
//# sourceMappingURL=65430.0a5957bc8a09e0d9.js.map