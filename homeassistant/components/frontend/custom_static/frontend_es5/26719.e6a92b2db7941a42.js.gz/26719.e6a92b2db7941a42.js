"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["26719"],{50602:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{SL:()=>d,l4:()=>u,sJ:()=>c,uf:()=>p});var n=i(16485),s=(i(19083),i(19423),i(11740),i(61006),i(20382)),r=i(34618),o=e([n]);n=(o.then?(await o)():o)[0];const d=e=>c(e.attributes),c=(e,t)=>!!e.unit_of_measurement||!!e.state_class||(t||[]).includes(e.device_class||""),l=e=>{switch(e.number_format){case s.y4.comma_decimal:return["en-US","en"];case s.y4.decimal_comma:return["de","es","it"];case s.y4.space_comma:return["fr","sv","cs"];case s.y4.system:return;default:return e.language}},p=(e,t,i)=>{const a=t?l(t):void 0;return Number.isNaN=Number.isNaN||function e(t){return"number"==typeof t&&e(t)},(null==t?void 0:t.number_format)===s.y4.none||Number.isNaN(Number(e))?Number.isNaN(Number(e))||""===e||(null==t?void 0:t.number_format)!==s.y4.none?"string"==typeof e?e:`${(0,r.N)(e,null==i?void 0:i.maximumFractionDigits).toString()}${"currency"===(null==i?void 0:i.style)?` ${i.currency}`:""}`:new Intl.NumberFormat("en-US",h(e,Object.assign(Object.assign({},i),{},{useGrouping:!1}))).format(Number(e)):new Intl.NumberFormat(a,h(e,i)).format(Number(e))},u=(e,t)=>{var i;const a=null==t?void 0:t.display_precision;return null!=a?{maximumFractionDigits:a,minimumFractionDigits:a}:Number.isInteger(Number(null==e||null===(i=e.attributes)||void 0===i?void 0:i.step))&&Number.isInteger(Number(null==e?void 0:e.state))?{maximumFractionDigits:0}:void 0},h=(e,t)=>{const i=Object.assign({maximumFractionDigits:2},t);if("string"!=typeof e)return i;if(!t||void 0===t.minimumFractionDigits&&void 0===t.maximumFractionDigits){const t=e.indexOf(".")>-1?e.split(".")[1].length:0;i.minimumFractionDigits=t,i.maximumFractionDigits=t}return i};a()}catch(d){a(d)}}))},34618:function(e,t,i){i.d(t,{N:()=>a});const a=(e,t=2)=>Math.round(e*10**t)/10**t},54977:function(e,t,i){var a=i(61701),n=(i(71695),i(47021),i(57243)),s=i(50778);let r,o,d,c=e=>e;(0,a.Z)([(0,s.Mo)("ha-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,reflect:!0})],key:"raised",value(){return!1}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(r||(r=c`:host{background:var(--custom-background-color,var(--card-background-color,#fff));-webkit-backdrop-filter:var(--ha-card-backdrop-filter,none);backdrop-filter:var(--ha-card-backdrop-filter,none);box-shadow:var(--ha-card-box-shadow,none);box-sizing:border-box;border-radius:var(--ha-card-border-radius,16px);color:var(--primary-text-color);display:block;transition:.3s ease-out;position:relative}:host([raised]){border:none;box-shadow:var(--ha-card-box-shadow,0px 2px 1px -1px rgba(0,0,0,.2),0px 1px 1px 0px rgba(0,0,0,.14),0px 1px 3px 0px rgba(0,0,0,.12))}.card-header,:host ::slotted(.card-header){color:var(--ha-card-header-color,var(--primary-text-color));font-family:var(--ha-card-header-font-family, inherit);font-size:var(--ha-card-header-font-size, 24px);letter-spacing:-.012em;line-height:48px;padding:12px 16px 16px;display:block;margin-block-start:0px;margin-block-end:0px;font-weight:400}:host ::slotted(.card-content:not(:first-child)),slot:not(:first-child)::slotted(.card-content){padding-top:0px;margin-top:-8px}:host ::slotted(.card-content){padding:16px}:host ::slotted(.card-actions){border-top:1px solid var(--divider-color,#e8e8e8);padding:5px 16px}`))}},{kind:"method",key:"render",value:function(){return(0,n.dy)(o||(o=c`
      ${0}
      <slot></slot>
    `),this.header?(0,n.dy)(d||(d=c`<h1 class="card-header">${0}</h1>`),this.header):n.Ld)}}]}}),n.oi)},41307:function(e,t,i){var a=i(61701),n=i(72621),s=(i(71695),i(40251),i(47021),i(57243)),r=i(50778),o=i(35359),d=i(36522),c=i(76320);i(37583);let l,p,u,h,f=e=>e;(0,a.Z)([(0,r.Mo)("ha-expansion-panel")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,r.Cb)({type:Boolean,reflect:!0})],key:"expanded",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({type:Boolean,reflect:!0})],key:"outlined",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({attribute:"left-chevron",type:Boolean,reflect:!0})],key:"leftChevron",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({attribute:"no-collapse",type:Boolean,reflect:!0})],key:"noCollapse",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,r.Cb)()],key:"secondary",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_showContent",value(){return this.expanded}},{kind:"field",decorators:[(0,r.IO)(".container")],key:"_container",value:void 0},{kind:"method",key:"render",value:function(){const e=this.noCollapse?s.Ld:(0,s.dy)(l||(l=f`
          <ha-svg-icon .path=${0} class="summary-icon ${0}"></ha-svg-icon>
        `),"M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z",(0,o.$)({expanded:this.expanded}));return(0,s.dy)(p||(p=f`
      <div class="top ${0}">
        <div id="summary" class=${0} @click=${0} @keydown=${0} @focus=${0} @blur=${0} role="button" tabindex=${0} aria-expanded=${0} aria-controls="sect1">
          ${0}
          <slot name="leading-icon"></slot>
          <slot name="header">
            <div class="header">
              ${0}
              <slot class="secondary" name="secondary">${0}</slot>
            </div>
          </slot>
          ${0}
          <slot name="icons"></slot>
        </div>
      </div>
      <div class="container ${0}" @transitionend=${0} role="region" aria-labelledby="summary" aria-hidden=${0} tabindex="-1">
        ${0}
      </div>
    `),(0,o.$)({expanded:this.expanded}),(0,o.$)({noCollapse:this.noCollapse}),this._toggleContainer,this._toggleContainer,this._focusChanged,this._focusChanged,this.noCollapse?-1:0,this.expanded,this.leftChevron?e:s.Ld,this.header,this.secondary,this.leftChevron?s.Ld:e,(0,o.$)({expanded:this.expanded}),this._handleTransitionEnd,!this.expanded,this._showContent?(0,s.dy)(u||(u=f`<slot></slot>`)):"")}},{kind:"method",key:"willUpdate",value:function(e){(0,n.Z)(i,"willUpdate",this,3)([e]),e.has("expanded")&&(this._showContent=this.expanded,setTimeout((()=>{this._container.style.overflow=this.expanded?"initial":"hidden"}),300))}},{kind:"method",key:"_handleTransitionEnd",value:function(){this._container.style.removeProperty("height"),this._container.style.overflow=this.expanded?"initial":"hidden",this._showContent=this.expanded}},{kind:"method",key:"_toggleContainer",value:async function(e){if(e.defaultPrevented)return;if("keydown"===e.type&&"Enter"!==e.key&&" "!==e.key)return;if(e.preventDefault(),this.noCollapse)return;const t=!this.expanded;(0,d.B)(this,"expanded-will-change",{expanded:t}),this._container.style.overflow="hidden",t&&(this._showContent=!0,await(0,c.y)());const i=this._container.scrollHeight;this._container.style.height=`${i}px`,t||setTimeout((()=>{this._container.style.height="0px"}),0),this.expanded=t,(0,d.B)(this,"expanded-changed",{expanded:this.expanded})}},{kind:"method",key:"_focusChanged",value:function(e){this.noCollapse||this.shadowRoot.querySelector(".top").classList.toggle("focused","focus"===e.type)}},{kind:"field",static:!0,key:"styles",value(){return(0,s.iv)(h||(h=f`:host{display:block}.top{display:flex;align-items:center;border-radius:var(--ha-card-border-radius,12px)}.top.expanded{border-bottom-left-radius:0px;border-bottom-right-radius:0px}.top.focused{background:var(--input-fill-color)}:host([outlined]){box-shadow:none;border-width:1px;border-style:solid;border-color:var(--outline-color);border-radius:var(--ha-card-border-radius,12px)}.summary-icon{transition:transform 150ms cubic-bezier(.4, 0, .2, 1);direction:var(--direction);margin-left:8px;margin-inline-start:8px;margin-inline-end:initial}::slotted([slot=leading-icon]),:host([left-chevron]) .summary-icon{margin-left:0;margin-right:8px;margin-inline-start:0;margin-inline-end:8px}#summary{flex:1;display:flex;padding:var(--expansion-panel-summary-padding,0 8px);min-height:48px;align-items:center;cursor:pointer;overflow:hidden;font-weight:500;outline:0}#summary.noCollapse{cursor:default}.summary-icon.expanded{transform:rotate(180deg)}.header,::slotted([slot=header]){flex:1}.container{padding:var(--expansion-panel-content-padding,0 8px);overflow:hidden;transition:height .3s cubic-bezier(.4, 0, .2, 1);height:0px}.container.expanded{height:auto}.secondary{display:block;color:var(--secondary-text-color);font-size:12px}`))}}]}}),s.oi)},65981:function(e,t,i){i.r(t),i.d(t,{HaIcon:()=>R});var a=i(61701),n=i(72621),s=(i(19083),i(71695),i(40251),i(61006),i(47021),i(57243)),r=i(50778),o=i(36522),d=i(22381),c=i(80654),l=(i(92745),i(9359),i(31526),i(27608)),p=i(27486),u=i(37394);const h=JSON.parse('{"version":"7.4.47","parts":[{"file":"7a7139d465f1f41cb26ab851a17caa21a9331234"},{"start":"account-supervisor-circle-","file":"9561286c4c1021d46b9006596812178190a7cc1c"},{"start":"alpha-r-c","file":"eb466b7087fb2b4d23376ea9bc86693c45c500fa"},{"start":"arrow-decision-o","file":"4b3c01b7e0723b702940c5ac46fb9e555646972b"},{"start":"baby-f","file":"2611401d85450b95ab448ad1d02c1a432b409ed2"},{"start":"battery-hi","file":"89bcd31855b34cd9d31ac693fb073277e74f1f6a"},{"start":"blur-r","file":"373709cd5d7e688c2addc9a6c5d26c2d57c02c48"},{"start":"briefcase-account-","file":"a75956cf812ee90ee4f656274426aafac81e1053"},{"start":"calendar-question-","file":"3253f2529b5ebdd110b411917bacfacb5b7063e6"},{"start":"car-lig","file":"74566af3501ad6ae58ad13a8b6921b3cc2ef879d"},{"start":"cellphone-co","file":"7677f1cfb2dd4f5562a2aa6d3ae43a2e6997b21a"},{"start":"circle-slice-2","file":"70d08c50ec4522dd75d11338db57846588263ee2"},{"start":"cloud-co","file":"141d2bfa55ca4c83f4bae2812a5da59a84fec4ff"},{"start":"cog-s","file":"5a640365f8e47c609005d5e098e0e8104286d120"},{"start":"cookie-l","file":"dd85b8eb8581b176d3acf75d1bd82e61ca1ba2fc"},{"start":"currency-eur-","file":"15362279f4ebfc3620ae55f79d2830ad86d5213e"},{"start":"delete-o","file":"239434ab8df61237277d7599ebe066c55806c274"},{"start":"draw-","file":"5605918a592070803ba2ad05a5aba06263da0d70"},{"start":"emoticon-po","file":"a838cfcec34323946237a9f18e66945f55260f78"},{"start":"fan","file":"effd56103b37a8c7f332e22de8e4d67a69b70db7"},{"start":"file-question-","file":"b2424b50bd465ae192593f1c3d086c5eec893af8"},{"start":"flask-off-","file":"3b76295cde006a18f0301dd98eed8c57e1d5a425"},{"start":"food-s","file":"1c6941474cbeb1755faaaf5771440577f4f1f9c6"},{"start":"gamepad-u","file":"c6efe18db6bc9654ae3540c7dee83218a5450263"},{"start":"google-f","file":"df341afe6ad4437457cf188499cb8d2df8ac7b9e"},{"start":"head-c","file":"282121c9e45ed67f033edcc1eafd279334c00f46"},{"start":"home-pl","file":"27e8e38fc7adcacf2a210802f27d841b49c8c508"},{"start":"inbox-","file":"0f0316ec7b1b7f7ce3eaabce26c9ef619b5a1694"},{"start":"key-v","file":"ea33462be7b953ff1eafc5dac2d166b210685a60"},{"start":"leaf-circle-","file":"33db9bbd66ce48a2db3e987fdbd37fb0482145a4"},{"start":"lock-p","file":"b89e27ed39e9d10c44259362a4b57f3c579d3ec8"},{"start":"message-s","file":"7b5ab5a5cadbe06e3113ec148f044aa701eac53a"},{"start":"moti","file":"01024d78c248d36805b565e343dd98033cc3bcaf"},{"start":"newspaper-variant-o","file":"22a6ec4a4fdd0a7c0acaf805f6127b38723c9189"},{"start":"on","file":"c73d55b412f394e64632e2011a59aa05e5a1f50d"},{"start":"paw-ou","file":"3f669bf26d16752dc4a9ea349492df93a13dcfbf"},{"start":"pigg","file":"0c24edb27eb1c90b6e33fc05f34ef3118fa94256"},{"start":"printer-pos-sy","file":"41a55cda866f90b99a64395c3bb18c14983dcf0a"},{"start":"read","file":"c7ed91552a3a64c9be88c85e807404cf705b7edf"},{"start":"robot-vacuum-variant-o","file":"917d2a35d7268c0ea9ad9ecab2778060e19d90e0"},{"start":"sees","file":"6e82d9861d8fac30102bafa212021b819f303bdb"},{"start":"shoe-f","file":"e2fe7ce02b5472301418cc90a0e631f187b9f238"},{"start":"snowflake-m","file":"a28ba9f5309090c8b49a27ca20ff582a944f6e71"},{"start":"st","file":"7e92d03f095ec27e137b708b879dfd273bd735ab"},{"start":"su","file":"61c74913720f9de59a379bdca37f1d2f0dc1f9db"},{"start":"tag-plus-","file":"8f3184156a4f38549cf4c4fffba73a6a941166ae"},{"start":"timer-a","file":"baab470d11cfb3a3cd3b063ee6503a77d12a80d0"},{"start":"transit-d","file":"8561c0d9b1ac03fab360fd8fe9729c96e8693239"},{"start":"vector-arrange-b","file":"c9a3439257d4bab33d3355f1f2e11842e8171141"},{"start":"water-ou","file":"02dbccfb8ca35f39b99f5a085b095fc1275005a0"},{"start":"webc","file":"57bafd4b97341f4f2ac20a609d023719f23a619c"},{"start":"zip","file":"65ae094e8263236fa50486584a08c03497a38d93"}]}'),f=(0,p.Z)((async()=>{const e=(0,l.MT)("hass-icon-db","mdi-icon-store");{const t=await(0,l.U2)("_version",e);t?t!==h.version&&(await(0,l.ZH)(e),(0,l.t8)("_version",h.version,e)):(0,l.t8)("_version",h.version,e)}return e})),v=["mdi","hass","hassio","hademo"];let b=[];i(37583);let m,y,g,x=e=>e;const w={},k={},_=(0,d.D)((()=>(async e=>{const t=Object.keys(e),i=await Promise.all(Object.values(e));(await f())("readwrite",(a=>{i.forEach(((i,n)=>{Object.entries(i).forEach((([e,t])=>{a.put(t,e)})),delete e[t[n]]}))}))})(k)),2e3),$={};let R=(0,a.Z)([(0,r.Mo)("ha-icon")],(function(e,t){class a extends t{constructor(...t){super(...t),e(this)}}return{F:a,d:[{kind:"field",decorators:[(0,r.Cb)()],key:"icon",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_path",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_secondaryPath",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_viewBox",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_legacy",value(){return!1}},{kind:"method",key:"willUpdate",value:function(e){(0,n.Z)(a,"willUpdate",this,3)([e]),e.has("icon")&&(this._path=void 0,this._secondaryPath=void 0,this._viewBox=void 0,this._loadIcon())}},{kind:"method",key:"render",value:function(){return this.icon?this._legacy?(0,s.dy)(m||(m=x`<!-- @ts-ignore we don't provide the iron-icon element -->
        <iron-icon .icon=${0}></iron-icon>`),this.icon):(0,s.dy)(y||(y=x`<ha-svg-icon .path=${0} .secondaryPath=${0} .viewBox=${0}></ha-svg-icon>`),this._path,this._secondaryPath,this._viewBox):s.Ld}},{kind:"method",key:"_loadIcon",value:async function(){if(!this.icon)return;const e=this.icon,[t,a]=this.icon.split(":",2);let n,s=a;if(!t||!s)return;if(!v.includes(t)){const i=c.g[t];return i?void(i&&"function"==typeof i.getIcon&&this._setCustomPath(i.getIcon(s),e)):void(this._legacy=!0)}if(this._legacy=!1,s in w){const e=w[s];let i;e.newName?(i=`Icon ${t}:${s} was renamed to ${t}:${e.newName}, please change your config, it will be removed in version ${e.removeIn}.`,s=e.newName):i=`Icon ${t}:${s} was removed from MDI, please replace this icon with an other icon in your config, it will be removed in version ${e.removeIn}.`,console.warn(i),(0,o.B)(this,"write_log",{level:"warning",message:i})}if(s in $)return void(this._path=$[s]);if("home-assistant"===s){const t=(await i.e("48348").then(i.bind(i,30511))).mdiHomeAssistant;return this.icon===e&&(this._path=t),void($[s]=t)}try{n=await(e=>new Promise(((t,i)=>{if(b.push([e,t,i]),b.length>1)return;const a=f();(0,u.n)(1e3,(async()=>{(await a)("readonly",(e=>{for(const[t,i,a]of b)(0,l.RV)(e.get(t)).then((e=>i(e))).catch((e=>a(e)));b=[]}))})()).catch((e=>{for(const[,,t]of b)t(e);b=[]}))})))(s)}catch(p){n=void 0}if(n)return this.icon===e&&(this._path=n),void($[s]=n);const r=(e=>{let t;for(const i of h.parts){if(void 0!==i.start&&e<i.start)break;t=i}return t.file})(s);if(r in k)return void this._setPath(k[r],s,e);const d=fetch(`/static/mdi/${r}.json`).then((e=>e.json()));k[r]=d,this._setPath(d,s,e),_()}},{kind:"method",key:"_setCustomPath",value:async function(e,t){const i=await e;this.icon===t&&(this._path=i.path,this._secondaryPath=i.secondaryPath,this._viewBox=i.viewBox)}},{kind:"method",key:"_setPath",value:async function(e,t,i){const a=await e;this.icon===i&&(this._path=a[t]),$[t]=a[t]}},{kind:"field",static:!0,key:"styles",value(){return(0,s.iv)(g||(g=x`:host{fill:currentcolor}`))}}]}}),s.oi)},80654:function(e,t,i){i.d(t,{g:()=>r});const a=window;"customIconsets"in a||(a.customIconsets={});const n=a.customIconsets,s=window;"customIcons"in s||(s.customIcons={});const r=new Proxy(s.customIcons,{get:(e,t)=>{var i;return null!==(i=e[t])&&void 0!==i?i:n[t]?{getIcon:n[t]}:void 0}})},99309:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(61701),n=(i(71695),i(9359),i(31526),i(77439),i(47021),i(57243)),s=i(50778),r=i(27486),o=i(38495),d=i(92057),c=e([d]);d=(c.then?(await c)():c)[0];let l,p,u,h=e=>e;(0,a.Z)([(0,s.Mo)("assist-render-pipeline-events")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"events",value:void 0},{kind:"field",key:"_processEvents",value(){return(0,r.Z)((e=>{let t;return e.forEach((e=>{t=(0,o.eP)(t,e)})),t}))}},{kind:"method",key:"render",value:function(){const e=this._processEvents(this.events);return e?(0,n.dy)(u||(u=h`
      <assist-render-pipeline-run .hass=${0} .pipelineRun=${0}></assist-render-pipeline-run>
    `),this.hass,e):this.events.length?(0,n.dy)(l||(l=h`<ha-alert alert-type="error">Error showing run</ha-alert>
          <ha-card>
            <ha-expansion-panel>
              <span slot="header">Raw</span>
              <pre>${0}</pre>
            </ha-expansion-panel>
          </ha-card>`),JSON.stringify(this.events,null,2)):(0,n.dy)(p||(p=h`<ha-alert alert-type="warning">There were no events in this run.</ha-alert>`))}}]}}),n.oi);t()}catch(l){t(l)}}))},92057:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(61701),n=(i(71695),i(92745),i(9359),i(1331),i(70104),i(47021),i(57243)),s=i(50778),r=(i(54977),i(99426),i(59826),i(17170)),o=(i(41307),i(50602)),d=(i(64889),i(76131)),c=e([r,o]);[r,o]=c.then?(await c)():c;let l,p,u,h,f,v,b,m,y,g,x,w,k,_,$,R,C,N,I,P,L,B,E,F=e=>e;const D={pipeline:"Pipeline",language:"Language"},S={engine:"Engine"},O={engine:"Engine"},T={engine:"Engine",language:"Language",intent_input:"Input"},Z={engine:"Engine",language:"Language",voice:"Voice",tts_input:"Input"},j={ready:0,wake_word:1,stt:2,intent:3,tts:4,done:5,error:6},M=(e,t)=>e.init_options?j[e.init_options.start_stage]<=j[t]&&j[t]<=j[e.init_options.end_stage]:t in e,z=(e,t,i)=>"error"in e&&i===t?(0,n.dy)(l||(l=F`
    <ha-alert alert-type="error">
      ${0} (${0})
    </ha-alert>
  `),e.error.message,e.error.code):"",U=(e,t,i,a="-start")=>{const s=t.events.find((e=>e.type===`${i}`+a)),r=t.events.find((e=>e.type===`${i}-end`));if(!s)return"";if(!r)return"error"in t?(0,n.dy)(p||(p=F`❌`)):(0,n.dy)(u||(u=F` <ha-spinner size="small"></ha-spinner> `));const d=new Date(r.timestamp).getTime()-new Date(s.timestamp).getTime(),c=(0,o.uf)(d/1e3,e.locale,{maximumFractionDigits:2});return(0,n.dy)(h||(h=F`${0}s ✅`),c)},A=(e,t)=>Object.entries(t).map((([t,i])=>(0,n.dy)(f||(f=F`
      <div class="row">
        <div>${0}</div>
        <div>${0}</div>
      </div>
    `),i,e[t]))),H=(e,t)=>{const i={};let a=!1;for(const n in e)n in t||"done"===n||(a=!0,i[n]=e[n]);return a?(0,n.dy)(v||(v=F`<ha-expansion-panel>
        <span slot="header">Raw</span>
        <ha-yaml-editor readOnly=readOnly autoUpdate .value=${0}></ha-yaml-editor>
      </ha-expansion-panel>`),i):""};(0,a.Z)([(0,s.Mo)("assist-render-pipeline-run")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"pipelineRun",value:void 0},{kind:"method",key:"render",value:function(){var e,t,i,a;const s=this.pipelineRun&&["tts","intent","stt","wake_word"].find((e=>e in this.pipelineRun))||"ready",r=[],o=(this.pipelineRun.init_options&&"text"in this.pipelineRun.init_options.input?this.pipelineRun.init_options.input.text:void 0)||(null===(e=this.pipelineRun)||void 0===e||null===(e=e.stt)||void 0===e||null===(e=e.stt_output)||void 0===e?void 0:e.text)||(null===(t=this.pipelineRun)||void 0===t||null===(t=t.intent)||void 0===t?void 0:t.intent_input);return o&&r.push({from:"user",text:o}),null!==(i=this.pipelineRun)&&void 0!==i&&null!==(i=i.intent)&&void 0!==i&&null!==(i=i.intent_output)&&void 0!==i&&null!==(i=i.response)&&void 0!==i&&null!==(i=i.speech)&&void 0!==i&&null!==(i=i.plain)&&void 0!==i&&i.speech&&r.push({from:"hass",text:this.pipelineRun.intent.intent_output.response.speech.plain.speech}),(0,n.dy)(b||(b=F`
      <ha-card>
        <div class="card-content">
          <div class="row heading">
            <div>Run</div>
            <div>${0}</div>
          </div>

          ${0}
          ${0}
        </div>
      </ha-card>

      ${0}
      ${0}
      ${0}
      ${0}
      ${0}
      ${0}
      ${0}
      ${0}
      ${0}
      <ha-card>
        <ha-expansion-panel>
          <span slot="header">Raw</span>
          <ha-yaml-editor read-only auto-update .value=${0}></ha-yaml-editor>
        </ha-expansion-panel>
      </ha-card>
    `),this.pipelineRun.stage,A(this.pipelineRun.run,D),r.length>0?(0,n.dy)(m||(m=F`
                <div class="messages">
                  ${0}
                </div>
                <div style="clear:both"></div>
              `),r.map((({from:e,text:t})=>(0,n.dy)(y||(y=F`
                      <div class=${0}>${0}</div>
                    `),`message ${e}`,t)))):"",z(this.pipelineRun,"ready",s),M(this.pipelineRun,"wake_word")?(0,n.dy)(g||(g=F`
            <ha-card>
              <div class="card-content">
                <div class="row heading">
                  <span>Wake word</span>
                  ${0}
                </div>
                ${0}
              </div>
            </ha-card>
          `),U(this.hass,this.pipelineRun,"wake_word"),this.pipelineRun.wake_word?(0,n.dy)(x||(x=F`
                      <div class="card-content">
                        ${0}
                        ${0}
                        ${0}
                      </div>
                    `),A(this.pipelineRun.wake_word,O),this.pipelineRun.wake_word.wake_word_output?(0,n.dy)(w||(w=F`<div class="row">
                                <div>Model</div>
                                <div>
                                  ${0}
                                </div>
                              </div>
                              <div class="row">
                                <div>Timestamp</div>
                                <div>
                                  ${0}
                                </div>
                              </div>`),this.pipelineRun.wake_word.wake_word_output.ww_id,this.pipelineRun.wake_word.wake_word_output.timestamp):"",H(this.pipelineRun.wake_word,S)):""):"",z(this.pipelineRun,"wake_word",s),M(this.pipelineRun,"stt")?(0,n.dy)(k||(k=F`
            <ha-card>
              <div class="card-content">
                <div class="row heading">
                  <span>Speech-to-text</span>
                  ${0}
                </div>
                ${0}
              </div>
            </ha-card>
          `),U(this.hass,this.pipelineRun,"stt","-vad-end"),this.pipelineRun.stt?(0,n.dy)(_||(_=F`
                      <div class="card-content">
                        ${0}
                        <div class="row">
                          <div>Language</div>
                          <div>${0}</div>
                        </div>
                        ${0}
                        ${0}
                      </div>
                    `),A(this.pipelineRun.stt,O),this.pipelineRun.stt.metadata.language,this.pipelineRun.stt.stt_output?(0,n.dy)($||($=F`<div class="row">
                              <div>Output</div>
                              <div>${0}</div>
                            </div>`),this.pipelineRun.stt.stt_output.text):"",H(this.pipelineRun.stt,O)):""):"",z(this.pipelineRun,"stt",s),M(this.pipelineRun,"intent")?(0,n.dy)(R||(R=F`
            <ha-card>
              <div class="card-content">
                <div class="row heading">
                  <span>Natural Language Processing</span>
                  ${0}
                </div>
                ${0}
              </div>
            </ha-card>
          `),U(this.hass,this.pipelineRun,"intent"),this.pipelineRun.intent?(0,n.dy)(C||(C=F`
                      <div class="card-content">
                        ${0}
                        ${0}
                        <div class="row">
                          <div>Prefer handling locally</div>
                          <div>
                            ${0}
                          </div>
                        </div>
                        <div class="row">
                          <div>Processed locally</div>
                          <div>
                            ${0}
                          </div>
                        </div>
                        ${0}
                      </div>
                    `),A(this.pipelineRun.intent,T),this.pipelineRun.intent.intent_output?(0,n.dy)(N||(N=F`<div class="row">
                                <div>Response type</div>
                                <div>
                                  ${0}
                                </div>
                              </div>
                              ${0}`),this.pipelineRun.intent.intent_output.response.response_type,"error"===this.pipelineRun.intent.intent_output.response.response_type?(0,n.dy)(I||(I=F`<div class="row">
                                    <div>Error code</div>
                                    <div>
                                      ${0}
                                    </div>
                                  </div>`),this.pipelineRun.intent.intent_output.response.data.code):""):"",this.pipelineRun.intent.prefer_local_intents,this.pipelineRun.intent.processed_locally,H(this.pipelineRun.intent,T)):""):"",z(this.pipelineRun,"intent",s),M(this.pipelineRun,"tts")?(0,n.dy)(P||(P=F`
            <ha-card>
              <div class="card-content">
                <div class="row heading">
                  <span>Text-to-speech</span>
                  ${0}
                </div>
                ${0}
              </div>
              ${0}
            </ha-card>
          `),U(this.hass,this.pipelineRun,"tts"),this.pipelineRun.tts?(0,n.dy)(L||(L=F`
                      <div class="card-content">
                        ${0}
                        ${0}
                      </div>
                    `),A(this.pipelineRun.tts,Z),H(this.pipelineRun.tts,Z)):"",null!==(a=this.pipelineRun)&&void 0!==a&&null!==(a=a.tts)&&void 0!==a&&a.tts_output?(0,n.dy)(B||(B=F`
                    <div class="card-actions">
                      <ha-button @click=${0}>
                        Play Audio
                      </ha-button>
                    </div>
                  `),this._playTTS):""):"",z(this.pipelineRun,"tts",s),this.pipelineRun)}},{kind:"method",key:"_playTTS",value:function(){const e=this.pipelineRun.tts.tts_output.url,t=new Audio(e);t.addEventListener("error",(()=>{(0,d.showAlertDialog)(this,{title:"Error",text:"Error playing audio"})})),t.addEventListener("canplaythrough",(()=>{t.play()}))}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(E||(E=F`.message.user,.row>div:last-child{text-align:right}:host{display:block}ha-alert,ha-card{display:block;margin-bottom:16px}.row{display:flex;justify-content:space-between}ha-expansion-panel{padding-left:8px;padding-inline-start:8px;padding-inline-end:initial}.card-content ha-expansion-panel{padding-left:0px;padding-inline-start:0px;padding-inline-end:initial;--expansion-panel-summary-padding:0px;--expansion-panel-content-padding:0px}.heading{font-weight:500;margin-bottom:16px}.messages{margin-top:8px}.message{font-size:18px;margin:8px 0;padding:8px;border-radius:15px;clear:both}.message.user{margin-left:24px;margin-inline-start:24px;margin-inline-end:initial;float:var(--float-end);border-bottom-right-radius:0px;background-color:var(--light-primary-color);color:var(--text-light-primary-color,var(--primary-text-color));direction:var(--direction)}.message.hass{margin-right:24px;margin-inline-end:24px;margin-inline-start:initial;float:var(--float-start);border-bottom-left-radius:0px;background-color:var(--primary-color);color:var(--text-primary-color);direction:var(--direction)}`))}}]}}),n.oi);t()}catch(l){t(l)}}))}}]);
//# sourceMappingURL=26719.e6a92b2db7941a42.js.map