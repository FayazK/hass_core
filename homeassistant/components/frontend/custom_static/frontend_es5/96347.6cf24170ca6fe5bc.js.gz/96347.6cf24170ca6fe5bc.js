"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["96347"],{97937:function(t,i,n){n.a(t,(async function(t,e){try{n.r(i);var s=n(61701),a=(n(52247),n(71695),n(47021),n(57243)),o=n(50778),h=(n(29891),n(96194)),r=n(93331),c=n(8069),d=n(62577),u=t([c]);c=(u.then?(await u)():u)[0];let f,y,l,g,k=t=>t;(0,s.Z)([(0,o.Mo)("hui-valve-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,r.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return a.Ld;const t=this.hass.states[this._config.entity];if(!t)return(0,a.dy)(f||(f=k`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,d.i)(this.hass,this._config.entity));const i="open"===t.state||"closed"===t.state||(0,h.rk)(t.state);return(0,a.dy)(y||(y=k`
      <hui-generic-entity-row .hass=${0} .config=${0} .catchInteraction=${0}>
        ${0}
      </hui-generic-entity-row>
    `),this.hass,this._config,!i,i?(0,a.dy)(l||(l=k`
              <ha-entity-toggle .hass=${0} .stateObj=${0}></ha-entity-toggle>
            `),this.hass,t):(0,a.dy)(g||(g=k`
              <div class="text-content">
                ${0}
              </div>
            `),this.hass.formatEntityState(t)))}}]}}),a.oi);e()}catch(f){e(f)}}))}}]);
//# sourceMappingURL=96347.6cf24170ca6fe5bc.js.map