/*! For license information please see 17898.b61714ba427759cf.js.LICENSE.txt */
"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["17898"],{4918:function(e,t,r){r.d(t,{a:()=>u});r(71695),r(40251),r(47021);var i=r(9065),n=r(80573),o={ROOT:"mdc-form-field"},a={LABEL_SELECTOR:".mdc-form-field > label"};const s=function(e){function t(r){var n=e.call(this,(0,i.__assign)((0,i.__assign)({},t.defaultAdapter),r))||this;return n.click=function(){n.handleClick()},n}return(0,i.__extends)(t,e),Object.defineProperty(t,"cssClasses",{get:function(){return o},enumerable:!1,configurable:!0}),Object.defineProperty(t,"strings",{get:function(){return a},enumerable:!1,configurable:!0}),Object.defineProperty(t,"defaultAdapter",{get:function(){return{activateInputRipple:function(){},deactivateInputRipple:function(){},deregisterInteractionHandler:function(){},registerInteractionHandler:function(){}}},enumerable:!1,configurable:!0}),t.prototype.init=function(){this.adapter.registerInteractionHandler("click",this.click)},t.prototype.destroy=function(){this.adapter.deregisterInteractionHandler("click",this.click)},t.prototype.handleClick=function(){var e=this;this.adapter.activateInputRipple(),requestAnimationFrame((function(){e.adapter.deactivateInputRipple()}))},t}(n.K);var l=r(11911),c=r(88618),d=r(78611),f=r(57243),p=r(50778),m=r(35359);let h,g=e=>e;class u extends l.H{constructor(){super(...arguments),this.alignEnd=!1,this.spaceBetween=!1,this.nowrap=!1,this.label="",this.mdcFoundationClass=s}createAdapter(){return{registerInteractionHandler:(e,t)=>{this.labelEl.addEventListener(e,t)},deregisterInteractionHandler:(e,t)=>{this.labelEl.removeEventListener(e,t)},activateInputRipple:async()=>{const e=this.input;if(e instanceof c.Wg){const t=await e.ripple;t&&t.startPress()}},deactivateInputRipple:async()=>{const e=this.input;if(e instanceof c.Wg){const t=await e.ripple;t&&t.endPress()}}}}get input(){var e,t;return null!==(t=null===(e=this.slottedInputs)||void 0===e?void 0:e[0])&&void 0!==t?t:null}render(){const e={"mdc-form-field--align-end":this.alignEnd,"mdc-form-field--space-between":this.spaceBetween,"mdc-form-field--nowrap":this.nowrap};return(0,f.dy)(h||(h=g`
      <div class="mdc-form-field ${0}">
        <slot></slot>
        <label class="mdc-label" @click="${0}">${0}</label>
      </div>`),(0,m.$)(e),this._labelClick,this.label)}click(){this._labelClick()}_labelClick(){const e=this.input;e&&(e.focus(),e.click())}}(0,i.__decorate)([(0,p.Cb)({type:Boolean})],u.prototype,"alignEnd",void 0),(0,i.__decorate)([(0,p.Cb)({type:Boolean})],u.prototype,"spaceBetween",void 0),(0,i.__decorate)([(0,p.Cb)({type:Boolean})],u.prototype,"nowrap",void 0),(0,i.__decorate)([(0,p.Cb)({type:String}),(0,d.P)((async function(e){var t;null===(t=this.input)||void 0===t||t.setAttribute("aria-label",e)}))],u.prototype,"label",void 0),(0,i.__decorate)([(0,p.IO)(".mdc-form-field")],u.prototype,"mdcRoot",void 0),(0,i.__decorate)([(0,p.vZ)("",!0,"*")],u.prototype,"slottedInputs",void 0),(0,i.__decorate)([(0,p.IO)("label")],u.prototype,"labelEl",void 0)},6394:function(e,t,r){r.d(t,{W:()=>n});let i;const n=(0,r(57243).iv)(i||(i=(e=>e)`.mdc-form-field{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body2-font-family, var(--mdc-typography-font-family, Roboto, sans-serif));font-size:.875rem;font-size:var(--mdc-typography-body2-font-size, .875rem);line-height:1.25rem;line-height:var(--mdc-typography-body2-line-height, 1.25rem);font-weight:400;font-weight:var(--mdc-typography-body2-font-weight,400);letter-spacing:.0178571429em;letter-spacing:var(--mdc-typography-body2-letter-spacing, .0178571429em);text-decoration:inherit;text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body2-text-transform,inherit);color:rgba(0,0,0,.87);color:var(--mdc-theme-text-primary-on-background,rgba(0,0,0,.87));display:inline-flex;align-items:center;vertical-align:middle;width:100%}.mdc-form-field>label{margin-left:0;margin-right:auto;padding-left:4px;padding-right:0;order:0}.mdc-form-field--align-end>label,.mdc-form-field>label[dir=rtl],[dir=rtl] .mdc-form-field>label{margin-left:auto;margin-right:0;padding-left:0;padding-right:4px}.mdc-form-field--nowrap>label{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.mdc-form-field--align-end>label{order:-1}.mdc-form-field--align-end>label[dir=rtl],[dir=rtl] .mdc-form-field--align-end>label{margin-left:0;margin-right:auto;padding-left:4px;padding-right:0}.mdc-form-field--space-between{justify-content:space-between}.mdc-form-field--space-between>label,.mdc-form-field--space-between>label[dir=rtl],[dir=rtl] .mdc-form-field--space-between>label{margin:0}:host{display:inline-flex}::slotted(*){-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font-family:Roboto,sans-serif;font-family:var(--mdc-typography-body2-font-family, var(--mdc-typography-font-family, Roboto, sans-serif));font-size:.875rem;font-size:var(--mdc-typography-body2-font-size, .875rem);line-height:1.25rem;line-height:var(--mdc-typography-body2-line-height, 1.25rem);font-weight:400;font-weight:var(--mdc-typography-body2-font-weight,400);letter-spacing:.0178571429em;letter-spacing:var(--mdc-typography-body2-letter-spacing, .0178571429em);text-decoration:inherit;text-decoration:var(--mdc-typography-body2-text-decoration,inherit);text-transform:inherit;text-transform:var(--mdc-typography-body2-text-transform,inherit);color:rgba(0,0,0,.87);color:var(--mdc-theme-text-primary-on-background,rgba(0,0,0,.87))}::slotted(mwc-switch){margin-right:10px}::slotted(mwc-switch[dir=rtl]),[dir=rtl] ::slotted(mwc-switch){margin-left:10px}`))},99152:function(e,t,r){r.d(t,{V:()=>o});r(63721),r(71695),r(61893),r(92519),r(42179),r(89256),r(24931),r(88463),r(57449),r(19814),r(47021);const i=Symbol("selection controller");class n{constructor(){this.selected=null,this.ordered=null,this.set=new Set}}class o{constructor(e){this.sets={},this.focusedSet=null,this.mouseIsDown=!1,this.updating=!1,e.addEventListener("keydown",(e=>{this.keyDownHandler(e)})),e.addEventListener("mousedown",(()=>{this.mousedownHandler()})),e.addEventListener("mouseup",(()=>{this.mouseupHandler()}))}static getController(e){const t=!("global"in e)||"global"in e&&e.global?document:e.getRootNode();let r=t[i];return void 0===r&&(r=new o(t),t[i]=r),r}keyDownHandler(e){const t=e.target;"checked"in t&&this.has(t)&&("ArrowRight"==e.key||"ArrowDown"==e.key?this.selectNext(t):"ArrowLeft"!=e.key&&"ArrowUp"!=e.key||this.selectPrevious(t))}mousedownHandler(){this.mouseIsDown=!0}mouseupHandler(){this.mouseIsDown=!1}has(e){return this.getSet(e.name).set.has(e)}selectPrevious(e){const t=this.getOrdered(e),r=t.indexOf(e),i=t[r-1]||t[t.length-1];return this.select(i),i}selectNext(e){const t=this.getOrdered(e),r=t.indexOf(e),i=t[r+1]||t[0];return this.select(i),i}select(e){e.click()}focus(e){if(this.mouseIsDown)return;const t=this.getSet(e.name),r=this.focusedSet;this.focusedSet=t,r!=t&&t.selected&&t.selected!=e&&t.selected.focus()}isAnySelected(e){const t=this.getSet(e.name);for(const r of t.set)if(r.checked)return!0;return!1}getOrdered(e){const t=this.getSet(e.name);return t.ordered||(t.ordered=Array.from(t.set),t.ordered.sort(((e,t)=>e.compareDocumentPosition(t)==Node.DOCUMENT_POSITION_PRECEDING?1:0))),t.ordered}getSet(e){return this.sets[e]||(this.sets[e]=new n),this.sets[e]}register(e){const t=e.name||e.getAttribute("name")||"",r=this.getSet(t);r.set.add(e),r.ordered=null}unregister(e){const t=this.getSet(e.name);t.set.delete(e),t.ordered=null,t.selected==e&&(t.selected=null)}update(e){if(this.updating)return;this.updating=!0;const t=this.getSet(e.name);if(e.checked){for(const r of t.set)r!=e&&(r.checked=!1);t.selected=e}if(this.isAnySelected(e))for(const r of t.set){if(void 0===r.formElementTabIndex)break;r.formElementTabIndex=r.checked?0:-1}this.updating=!1}}},68289:function(e,t,r){var i=r(40810),n=r(1569),o=r(27803),a=r(85779),s=TypeError,l=Object.defineProperty,c=n.self!==n;try{if(a){var d=Object.getOwnPropertyDescriptor(n,"self");!c&&d&&d.get&&d.enumerable||o(n,"self",{get:function(){return n},set:function(e){if(this!==n)throw new s("Illegal invocation");l(n,"self",{value:e,writable:!0,configurable:!0,enumerable:!0})},configurable:!0,enumerable:!0})}else i({global:!0,simple:!0,forced:c},{self:n})}catch(f){}},68783:function(e,t,r){r.a(e,(async function(e,i){try{r.d(t,{A:()=>d});r(71695),r(47021);var n=r(64699),o=r(15073),a=r(81048),s=r(31027),l=r(57243),c=e([o]);o=(c.then?(await c)():c)[0];let f,p=e=>e;var d=class extends s.P{constructor(){super(...arguments),this.localize=new o.V(this)}render(){return(0,l.dy)(f||(f=p`
      <svg part="base" class="spinner" role="progressbar" aria-label=${0}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `),this.localize.term("loading"))}};d.styles=[a.N,n.D],i()}catch(f){i(f)}}))},64699:function(e,t,r){r.d(t,{D:()=>n});let i;var n=(0,r(57243).iv)(i||(i=(e=>e)`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`))},97677:function(e,t,r){r.a(e,(async function(e,i){try{r.d(t,{Z:()=>n.A});var n=r(68783),o=(r(64699),r(15073)),a=r(21262),s=(r(81048),r(31027),r(52812),e([o,a,n]));[o,a,n]=s.then?(await s)():s,i()}catch(l){i(l)}}))},43580:function(e,t,r){r.d(t,{Z:()=>i.D});var i=r(64699);r(52812)}}]);
//# sourceMappingURL=17898.b61714ba427759cf.js.map