/*! For license information please see 2600.9fab27613e06ccc3.js.LICENSE.txt */
"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["2600"],{25948:function(t,e,i){var a=i(9065),s=i(50778),r=i(60930),n=i(9714);let d=class extends r.K{};d.styles=[n.W],d=(0,a.__decorate)([(0,s.Mo)("mwc-select")],d)},12763:function(t,e,i){i.a(t,(async function(t,e){try{var a=i(61701),s=(i(22152),i(71695),i(9359),i(56475),i(70104),i(47021),i(57243)),r=i(50778),n=i(25904),d=i(59519),o=i(28008),l=i(59389),u=(i(41307),t([l,d,n]));[l,d,n]=u.then?(await u)():u;let c,h,b,v,y,f=t=>t;(0,a.Z)([(0,r.Mo)("ha-attributes")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"extra-filters"})],key:"extraFilters",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_expanded",value(){return!1}},{kind:"get",key:"_filteredAttributes",value:function(){return this._computeDisplayAttributes(d.wk.concat(this.extraFilters?this.extraFilters.split(","):[]))}},{kind:"method",key:"willUpdate",value:function(t){(t.has("extraFilters")||t.has("stateObj"))&&this.toggleAttribute("empty",0===this._filteredAttributes.length)}},{kind:"method",key:"render",value:function(){if(!this.stateObj)return s.Ld;const t=this._filteredAttributes;return 0===t.length?s.Ld:(0,s.dy)(c||(c=f`
      <ha-expansion-panel .header=${0} outlined @expanded-will-change=${0}>
        <div class="attribute-container">
          ${0}
        </div>
      </ha-expansion-panel>
      ${0}
    `),this.hass.localize("ui.components.attributes.expansion_header"),this._expandedChanged,this._expanded?(0,s.dy)(h||(h=f`
                ${0}
              `),t.map((t=>(0,s.dy)(b||(b=f`
                    <div class="data-entry">
                      <div class="key">
                        ${0}
                      </div>
                      <div class="value">
                        <ha-attribute-value .hass=${0} .attribute=${0} .stateObj=${0}></ha-attribute-value>
                      </div>
                    </div>
                  `),(0,n.computeAttributeNameDisplay)(this.hass.localize,this.stateObj,this.hass.entities,t),this.hass,t,this.stateObj)))):"",this.stateObj.attributes.attribution?(0,s.dy)(v||(v=f`
            <div class="attribution">
              ${0}
            </div>
          `),this.stateObj.attributes.attribution):"")}},{kind:"get",static:!0,key:"styles",value:function(){return[o.Qx,(0,s.iv)(y||(y=f`.attribute-container{margin-bottom:8px;direction:ltr}.data-entry{display:flex;flex-direction:row;justify-content:space-between}.data-entry .value{max-width:60%;overflow-wrap:break-word;text-align:right}.key{flex-grow:1}.attribution{color:var(--secondary-text-color);text-align:center;margin-top:16px}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`))]}},{kind:"method",key:"_computeDisplayAttributes",value:function(t){return this.stateObj?Object.keys(this.stateObj.attributes).filter((e=>-1===t.indexOf(e))):[]}},{kind:"method",key:"_expandedChanged",value:function(t){this._expanded=t.detail.expanded}}]}}),s.oi);e()}catch(c){e(c)}}))},20458:function(t,e,i){i.d(e,{qh:()=>a});const a=4},92081:function(t,e,i){i.a(t,(async function(t,a){try{i.r(e);var s=i(61701),r=(i(71695),i(9359),i(70104),i(47021),i(25948),i(87319),i(57243)),n=i(50778),d=i(49976),o=i(75278),l=i(12763),u=i(20458),c=t([l]);l=(c.then?(await c)():c)[0];let h,b,v,y,f=t=>t;const k="activity_list,current_activity";(0,s.Z)([(0,n.Mo)("more-info-remote")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){var t;if(!this.hass||!this.stateObj)return r.Ld;const e=this.stateObj;return(0,r.dy)(h||(h=f`
      ${0}

      <ha-attributes .hass=${0} .stateObj=${0} .extraFilters=${0}></ha-attributes>
    `),(0,o.e)(e,u.qh)?(0,r.dy)(b||(b=f`
            <mwc-select .label=${0} .value=${0} @selected=${0} fixedMenuPosition naturalMenuWidth @closed=${0}>
              ${0}
            </mwc-select>
          `),this.hass.localize("ui.dialogs.more_info_control.remote.activity"),e.attributes.current_activity||"",this._handleActivityChanged,d.U,null===(t=e.attributes.activity_list)||void 0===t?void 0:t.map((t=>(0,r.dy)(v||(v=f`
                  <mwc-list-item .value=${0}>
                    ${0}
                  </mwc-list-item>
                `),t,this.hass.formatEntityAttributeValue(e,"activity",t))))):r.Ld,this.hass,this.stateObj,k)}},{kind:"method",key:"_handleActivityChanged",value:function(t){const e=this.stateObj.attributes.current_activity,i=t.target.value;i&&e!==i&&this.hass.callService("remote","turn_on",{entity_id:this.stateObj.entity_id,activity:i})}},{kind:"field",static:!0,key:"styles",value(){return(0,r.iv)(y||(y=f`mwc-select{width:100%}`))}}]}}),r.oi);a()}catch(h){a(h)}}))}}]);
//# sourceMappingURL=2600.9fab27613e06ccc3.js.map