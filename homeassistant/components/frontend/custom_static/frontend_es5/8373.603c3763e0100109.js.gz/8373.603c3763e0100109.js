"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["8373"],{55421:function(t,s,i){i.a(t,(async function(t,e){try{i.r(s);var a=i(61701),n=(i(71695),i(9359),i(70104),i(47021),i(57243)),o=i(50778),r=i(33570),l=i(95975),d=t([l,r]);[l,r]=d.then?(await d)():d;let h,c,u,v=t=>t;(0,a.Z)([(0,o.Mo)("more-info-sun")],(function(t,s){return{F:class extends s{constructor(...s){super(...s),t(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass||!this.stateObj)return n.Ld;const t=new Date(this.stateObj.attributes.next_rising),s=new Date(this.stateObj.attributes.next_setting),i=t>s?["set","ris"]:["ris","set"];return(0,n.dy)(h||(h=v`
      <hr/>
      ${0}
      <div class="row">
        <div class="key">
          ${0}
        </div>
        <div class="value">
          ${0}
        </div>
      </div>
      <div class="row">
        <div class="key">
          ${0}
        </div>
        <div class="value">
          ${0}
        </div>
      </div>
    `),i.map((i=>(0,n.dy)(c||(c=v`
          <div class="row">
            <div class="key">
              <span>${0}</span>
              <ha-relative-time .hass=${0} .datetime=${0}></ha-relative-time>
            </div>
            <div class="value">
              ${0}
            </div>
          </div>
        `),"ris"===i?this.hass.localize("ui.dialogs.more_info_control.sun.rising"):this.hass.localize("ui.dialogs.more_info_control.sun.setting"),this.hass,"ris"===i?t:s,(0,r.mr)("ris"===i?t:s,this.hass.locale,this.hass.config)))),this.hass.localize("ui.dialogs.more_info_control.sun.elevation"),this.hass.formatEntityAttributeValue(this.stateObj,"elevation"),this.hass.localize("ui.dialogs.more_info_control.sun.azimuth"),this.hass.formatEntityAttributeValue(this.stateObj,"azimuth"))}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(u||(u=v`.row{margin:0;display:flex;flex-direction:row;justify-content:space-between}ha-relative-time{display:inline-block;white-space:nowrap}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`))}}]}}),n.oi);e()}catch(h){e(h)}}))}}]);
//# sourceMappingURL=8373.603c3763e0100109.js.map