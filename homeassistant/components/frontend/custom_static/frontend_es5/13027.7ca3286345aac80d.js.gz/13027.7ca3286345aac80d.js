"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["13027"],{81698:function(e,i,a){a.a(e,(async function(e,s){try{a.r(i),a.d(i,{CloudRegister:()=>_});var o=a(61701),t=(a(71695),a(40251),a(47021),a(57243)),r=a(50778),l=a(36522),n=a(29095),d=(a(99426),a(54977),a(83166),a(94616)),c=(a(87979),a(28008)),u=(a(98241),a(34326),e([n]));n=(u.then?(await u)():u)[0];let h,f,g,p=e=>e,_=(0,o.Z)([(0,r.Mo)("cloud-register")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({type:Boolean})],key:"narrow",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)()],key:"email",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_requestInProgress",value(){return!1}},{kind:"field",decorators:[(0,r.SB)()],key:"_password",value(){return""}},{kind:"field",decorators:[(0,r.SB)()],key:"_error",value:void 0},{kind:"field",decorators:[(0,r.IO)("#email",!0)],key:"_emailField",value:void 0},{kind:"field",decorators:[(0,r.IO)("#password",!0)],key:"_passwordField",value:void 0},{kind:"method",key:"render",value:function(){var e;return(0,t.dy)(h||(h=p`
      <hass-subpage .hass=${0} .narrow=${0} .header=${0}>
        <div class="content">
          <ha-config-section .isWide=${0}>
            <span slot="header">${0}</span>
            <div slot="introduction">
              <p>
                ${0}
              </p>
              <p>
                ${0}
              </p>
              <ul>
                <li>
                  ${0}
                </li>
                <li>
                  ${0}
                </li>
                <li>
                  ${0}
                </li>
                <li>
                  ${0}
                </li>
              </ul>
              <p>
                ${0}
                <a href="https://www.nabucasa.com" target="_blank">Nabu Casa, Inc</a>
                ${0}
              </p>
              <p>
                ${0}
              </p>
              <ul>
                <li>
                  <a href="https://www.nabucasa.com/tos/" target="_blank" rel="noreferrer">
                    ${0}
                  </a>
                </li>
                <li>
                  <a href="https://www.nabucasa.com/privacy_policy/" target="_blank" rel="noreferrer">
                    ${0}
                  </a>
                </li>
              </ul>
            </div>
            <ha-card outlined .header=${0}><div class="card-content register-form">
                ${0}
                <ha-textfield autofocus id="email" name="email" .label=${0} type="email" autocomplete="email" required .value=${0} @keydown=${0} validationMessage=${0}></ha-textfield>
                <ha-password-field id="password" name="password" .label=${0} .value=${0} autocomplete="new-password" minlength="8" required @keydown=${0} validationMessage=${0}></ha-password-field>
              </div>
              <div class="card-actions">
                <ha-progress-button @click=${0} .progress=${0}>${0}</ha-progress-button>
                <button class="link" .disabled=${0} @click=${0}>
                  ${0}
                </button>
              </div>
            </ha-card>
          </ha-config-section>
        </div>
      </hass-subpage>
    `),this.hass,this.narrow,this.hass.localize("ui.panel.config.cloud.register.title"),this.isWide,this.hass.localize("ui.panel.config.cloud.register.headline"),this.hass.localize("ui.panel.config.cloud.register.information"),this.hass.localize("ui.panel.config.cloud.register.information2"),this.hass.localize("ui.panel.config.cloud.register.feature_remote_control"),this.hass.localize("ui.panel.config.cloud.register.feature_google_home"),this.hass.localize("ui.panel.config.cloud.register.feature_amazon_alexa"),this.hass.localize("ui.panel.config.cloud.register.feature_webhook_apps"),this.hass.localize("ui.panel.config.cloud.register.information3"),this.hass.localize("ui.panel.config.cloud.register.information3a"),this.hass.localize("ui.panel.config.cloud.register.information4"),this.hass.localize("ui.panel.config.cloud.register.link_terms_conditions"),this.hass.localize("ui.panel.config.cloud.register.link_privacy_policy"),this.hass.localize("ui.panel.config.cloud.register.create_account"),this._error?(0,t.dy)(f||(f=p`<ha-alert alert-type="error">${0}</ha-alert>`),this._error):"",this.hass.localize("ui.panel.config.cloud.register.email_address"),null!==(e=this.email)&&void 0!==e?e:"",this._keyDown,this.hass.localize("ui.panel.config.cloud.register.email_error_msg"),this.hass.localize("ui.panel.config.cloud.register.password"),this._password,this._keyDown,this.hass.localize("ui.panel.config.cloud.register.password_error_msg"),this._handleRegister,this._requestInProgress,this.hass.localize("ui.panel.config.cloud.register.start_trial"),this._requestInProgress,this._handleResendVerifyEmail,this.hass.localize("ui.panel.config.cloud.register.resend_confirm_email"))}},{kind:"method",key:"_keyDown",value:function(e){"Enter"===e.key&&this._handleRegister()}},{kind:"method",key:"_handleRegister",value:async function(){const e=this._emailField,i=this._passwordField;if(!e.reportValidity())return i.reportValidity(),void e.focus();if(!i.reportValidity())return void i.focus();const a=e.value.toLowerCase(),s=i.value;this._requestInProgress=!0;try{await(0,d.bi)(this.hass,a,s),this._verificationEmailSent(a)}catch(o){this._password="",this._requestInProgress=!1,this._error=o&&o.body&&o.body.message?o.body.message:"Unknown error"}}},{kind:"method",key:"_handleResendVerifyEmail",value:async function(){const e=this._emailField;if(!e.reportValidity())return void e.focus();const i=e.value,a=async e=>{try{await(0,d._t)(this.hass,e),this._verificationEmailSent(e)}catch(i){"usernotfound"===(i&&i.body&&i.body.code)&&e!==e.toLowerCase()?await a(e.toLowerCase()):this._error=i&&i.body&&i.body.message?i.body.message:"Unknown error"}};await a(i)}},{kind:"method",key:"_verificationEmailSent",value:function(e){this._requestInProgress=!1,this._password="",(0,l.B)(this,"cloud-email-changed",{value:e}),(0,l.B)(this,"cloud-done",{flashMessage:this.hass.localize("ui.panel.config.cloud.register.account_created")})}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,(0,t.iv)(g||(g=p`[slot=introduction]{margin:-1em 0}[slot=introduction] a,a{color:var(--primary-color)}h1{margin:0}.register-form{display:flex;flex-direction:column}.card-actions{display:flex;justify-content:space-between;align-items:center}`))]}}]}}),t.oi);s()}catch(h){s(h)}}))}}]);
//# sourceMappingURL=13027.7ca3286345aac80d.js.map