export const __webpack_ids__=["65430"];export const __webpack_modules__={78244:function(t,i,n){var a=n(44249),e=n(6942),o=n(15093);(0,a.Z)([(0,o.Mo)("ha-fade-in")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,o.Cb)()],key:"name",value:()=>"fadeIn"},{kind:"field",decorators:[(0,o.Cb)()],key:"fill",value:()=>"both"},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"play",value:()=>!0},{kind:"field",decorators:[(0,o.Cb)({type:Number})],key:"iterations",value:()=>1}]}}),e.Z)},48189:function(t,i,n){n.a(t,(async function(t,a){try{n.r(i);var e=n(44249),o=(n(9359),n(1331),n(57243)),c=n(15093),s=(n(99426),n(59826),n(1888),n(34273),n(54977),n(78244),n(17170)),r=(n(23334),n(7285),n(19993),n(74633),n(26779)),l=(n(87979),n(29232),n(12660)),d=n(36522),p=t([s,r,l]);[s,r,l]=p.then?(await p)():p;(0,e.Z)([(0,c.Mo)("ha-config-backup-location")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,c.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,c.Cb)({attribute:"agent-id"})],key:"agentId",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"agents",value:()=>[]},{kind:"field",decorators:[(0,c.SB)()],key:"_agent",value:void 0},{kind:"field",decorators:[(0,c.SB)()],key:"_error",value:void 0},{kind:"method",key:"willUpdate",value:function(t){t.has("agentId")&&(this.agentId?this._fetchAgent():this._error="Agent id not defined")}},{kind:"method",key:"render",value:function(){if(!this.hass)return o.Ld;const t=this._isEncryptionTurnedOn();return o.dy`
      <hass-subpage back-path="/config/backup/settings" .hass=${this.hass} .narrow=${this.narrow} .header=${this._agent&&(0,r.Sw)(this.hass.localize,this.agentId,this.agents)||this.hass.localize("ui.panel.config.backup.location.header")}>
        <div class="content">
          ${this._error&&o.dy`<ha-alert alert-type="error">${this._error}</ha-alert>`}
          ${null===this._agent?o.dy`
                <ha-alert alert-type="warning" .title=${this.hass.localize("ui.panel.config.backup.location.not_found")}>
                  ${this.hass.localize("ui.panel.config.backup.location.not_found_description",{agentId:this.agentId})}
                </ha-alert>
              `:this.agentId?o.dy`
                  ${r.$u===this.agentId?o.dy`
                        <ha-card>
                          <div class="card-header">
                            ${this.hass.localize("ui.panel.config.backup.location.configuration.title")}
                          </div>
                          <div class="card-content">
                            <p>
                              ${this.hass.localize("ui.panel.config.backup.location.configuration.cloud_description")}
                            </p>
                          </div>
                        </ha-card>
                      `:o.Ld}
                  <ha-card>
                    <div class="card-header">
                      ${this.hass.localize("ui.panel.config.backup.location.encryption.title")}
                    </div>
                    <div class="card-content">
                      <p>
                        ${this.hass.localize("ui.panel.config.backup.location.encryption.description")}
                      </p>
                      <ha-md-list>
                        ${r.$u===this.agentId?o.dy`
                              <ha-md-list-item>
                                <span slot="headline">
                                  ${this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted")}
                                </span>
                                <span slot="supporting-text">
                                  ${this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_cloud_description")}
                                </span>
                                <a href="https://www.nabucasa.com/config/backups/" target="_blank" slot="end" rel="noreferrer noopener">
                                  <ha-button>
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_cloud_learn_more")}
                                  </ha-button>
                                </a>
                              </ha-md-list-item>
                            `:t?o.dy`
                                <ha-md-list-item>
                                  <span slot="headline">
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted")}
                                  </span>
                                  <span slot="supporting-text">
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.location_encrypted_description")}
                                  </span>

                                  <ha-button slot="end" @click=${this._turnOffEncryption} destructive>
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off")}
                                  </ha-button>
                                </ha-md-list-item>
                              `:o.dy`
                                <ha-alert alert-type="warning" .title=${this.hass.localize("ui.panel.config.backup.location.encryption.warning_encryption_turn_off")}>
                                  ${this.hass.localize("ui.panel.config.backup.location.encryption.warning_encryption_turn_off_description")}
                                </ha-alert>
                                <ha-md-list-item>
                                  <span slot="headline">
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.location_unencrypted")}
                                  </span>
                                  <span slot="supporting-text">
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.location_unencrypted_description")}
                                  </span>

                                  <ha-button slot="end" @click=${this._turnOnEncryption}>
                                    ${this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_on")}
                                  </ha-button>
                                </ha-md-list-item>
                              `}
                      </ha-md-list>
                    </div>
                  </ha-card>
                `:o.dy`<ha-fade-in .delay=${1e3}><ha-spinner></ha-spinner></ha-fade-in>`}
        </div>
      </hass-subpage>
    `}},{kind:"method",key:"_isEncryptionTurnedOn",value:function(){const t=this.config?.agents[this.agentId];return!t||t.protected}},{kind:"method",key:"_fetchAgent",value:async function(){try{const{agents:t}=await(0,r.xc)(this.hass),i=t.find((t=>t.agent_id===this.agentId));if(!i)throw new Error("Agent not found");this._agent=i}catch(t){this._error=t?.message||this.hass.localize("ui.panel.config.backup.details.error")}}},{kind:"method",key:"_updateAgentEncryption",value:async function(t){const i={...this.config?.agents,[this.agentId]:{...this.config?.agents[this.agentId],protected:t}};await(0,r._r)(this.hass,{agents:i}),(0,d.B)(this,"ha-refresh-backup-config")}},{kind:"method",key:"_turnOnEncryption",value:function(){this._updateAgentEncryption(!0)}},{kind:"method",key:"_turnOffEncryption",value:async function(){await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_title"),text:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_text"),confirmText:this.hass.localize("ui.panel.config.backup.location.encryption.encryption_turn_off_confirm_action"),dismissText:this.hass.localize("ui.common.cancel"),destructive:!0})&&this._updateAgentEncryption(!1)}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}.dot,ha-backup-data-picker{display:block}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item img{width:48px}ha-md-list-item ha-svg-icon[slot=start]{--mdc-icon-size:48px;color:var(--primary-text-color)}ha-md-list.summary ha-md-list-item{--md-list-item-supporting-text-size:1rem;--md-list-item-label-text-size:0.875rem;--md-list-item-label-text-color:var(--secondary-text-color);--md-list-item-supporting-text-color:var(--primary-text-color)}.warning,.warning ha-svg-icon{color:var(--error-color)}ha-button.danger{--mdc-theme-primary:var(--error-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}.dot{position:relative;width:8px;height:8px;background-color:var(--disabled-color);border-radius:50%;flex:none}.dot.success{background-color:var(--success-color)}.dot.error{background-color:var(--error-color)}.card-header{padding-bottom:8px}ha-spinner{margin:24px auto}`}]}}),o.oi);a()}catch(t){a(t)}}))}};
//# sourceMappingURL=65430.3c27049db515ae6d.js.map