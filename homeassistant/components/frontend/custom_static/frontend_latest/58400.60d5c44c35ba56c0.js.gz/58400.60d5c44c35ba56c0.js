export const __webpack_ids__=["58400"];export const __webpack_modules__={97604:function(i,t,n){n.a(i,(async function(i,e){try{n.r(t);var s=n(44249),o=n(57243),r=n(15093),a=n(69919),h=n(93331),c=n(8069),d=n(62577),u=i([c,a]);[c,a]=u.then?(await u)():u;(0,s.Z)([(0,r.Mo)("hui-update-entity-row")],(function(i,t){return{F:class extends t{constructor(...t){super(...t),i(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(i){if(!i)throw new Error("Invalid configuration");this._config=i}},{kind:"method",key:"shouldUpdate",value:function(i){return(0,h.G2)(this,i)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const i=this.hass.states[this._config.entity];return i?o.dy`
      <hui-generic-entity-row .hass=${this.hass} .config=${this._config}>
        ${(0,a.Ym)(i,this.hass)}
      </hui-generic-entity-row>
    `:o.dy`
        <hui-warning>
          ${(0,d.i)(this.hass,this._config.entity)}
        </hui-warning>
      `}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`div{text-align:right}`}]}}),o.oi);e()}catch(i){e(i)}}))}};
//# sourceMappingURL=58400.60d5c44c35ba56c0.js.map