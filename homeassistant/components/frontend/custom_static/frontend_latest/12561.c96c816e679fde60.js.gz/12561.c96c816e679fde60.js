export const __webpack_ids__=["12561"];export const __webpack_modules__={38963:function(a,t,i){i.a(a,(async function(a,s){try{i.r(t);var e=i(44249),n=i(57243),o=i(15093),c=(i(87979),i(87813)),r=a([c]);c=(r.then?(await r)():r)[0];(0,e.Z)([(0,o.Mo)("ha-config-section-analytics")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <hass-subpage back-path="/config/system" .hass=${this.hass} .narrow=${this.narrow} .header=${this.hass.localize("ui.panel.config.analytics.caption")}>
        <div class="content">
          <ha-config-analytics .hass=${this.hass}></ha-config-analytics>
        </div>
      </hass-subpage>
    `}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.content{padding:28px 20px 0;max-width:1040px;margin:0 auto}ha-config-analytics{display:block;max-width:600px;margin:0 auto}`}]}}),n.oi);s()}catch(a){s(a)}}))}};
//# sourceMappingURL=12561.c96c816e679fde60.js.map