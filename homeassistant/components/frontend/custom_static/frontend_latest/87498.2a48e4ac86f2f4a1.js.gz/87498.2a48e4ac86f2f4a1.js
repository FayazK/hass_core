export const __webpack_ids__=["87498"];export const __webpack_modules__={23575:function(e,t,i){i.d(t,{N:()=>s,Z:()=>r});const s=(e,t,i)=>e.subscribeMessage((e=>t(e)),{type:"render_template",...i}),r=(e,t,i,s,r)=>e.connection.subscribeMessage(r,{type:"template/start_preview",flow_id:t,flow_type:i,user_input:s})},20699:function(e,t,i){i.a(e,(async function(e,s){try{i.r(t);var r=i(44249),l=i(72621),a=(i(9359),i(70104),i(57243)),o=i(15093),n=i(22381),d=i(23575),u=i(28820),h=i(36522),_=(i(99426),e([u]));u=(_.then?(await _)():_)[0];(0,r.Z)([(0,o.Mo)("flow-preview-template")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"flowType",value:void 0},{kind:"field",key:"handler",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"stepId",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"flowId",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"stepData",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_preview",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_listeners",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_error",value:void 0},{kind:"field",key:"_unsub",value:void 0},{kind:"method",key:"disconnectedCallback",value:function(){(0,l.Z)(i,"disconnectedCallback",this,3)([]),this._unsub&&(this._unsub.then((e=>e())),this._unsub=void 0)}},{kind:"method",key:"willUpdate",value:function(e){e.has("stepData")&&this._debouncedSubscribePreview()}},{kind:"method",key:"render",value:function(){return this._error?a.dy`<ha-alert alert-type="error">${this._error}</ha-alert>`:a.dy`<entity-preview-row .hass=${this.hass} .stateObj=${this._preview}></entity-preview-row>
      ${this._listeners?.time?a.dy`
            <p>
              ${this.hass.localize("ui.dialogs.helper_settings.template.time")}
            </p>
          `:a.Ld}
      ${this._listeners?this._listeners.all?a.dy`
              <p class="all_listeners">
                ${this.hass.localize("ui.dialogs.helper_settings.template.all_listeners")}
              </p>
            `:this._listeners.domains.length||this._listeners.entities.length?a.dy`
                <p>
                  ${this.hass.localize("ui.dialogs.helper_settings.template.listeners")}
                </p>
                <ul>
                  ${this._listeners.domains.sort().map((e=>a.dy`
                        <li>
                          <b>${this.hass.localize("ui.dialogs.helper_settings.template.domain")}</b>: ${e}
                        </li>
                      `))}
                  ${this._listeners.entities.sort().map((e=>a.dy`
                        <li>
                          <b>${this.hass.localize("ui.dialogs.helper_settings.template.entity")}</b>: ${e}
                        </li>
                      `))}
                </ul>
              `:this._listeners.time?a.Ld:a.dy`<p class="all_listeners">
                  ${this.hass.localize("ui.dialogs.helper_settings.template.no_listeners")}
                </p>`:a.Ld} `}},{kind:"field",key:"_setPreview",value(){return e=>{if("error"in e)return this._error=e.error,void(this._preview=void 0);this._error=void 0,this._listeners=e.listeners;const t=(new Date).toISOString();this._preview={entity_id:`${this.stepId}.___flow_preview___`,last_changed:t,last_updated:t,context:{id:"",parent_id:null,user_id:null},attributes:e.attributes,state:e.state}}}},{kind:"field",key:"_debouncedSubscribePreview",value(){return(0,n.D)((()=>{this._subscribePreview()}),250)}},{kind:"method",key:"_subscribePreview",value:async function(){if(this._unsub&&((await this._unsub)(),this._unsub=void 0),"config_flow"===this.flowType||"options_flow"===this.flowType)try{this._unsub=(0,d.Z)(this.hass,this.flowId,this.flowType,this.stepData,this._setPreview),await this._unsub,(0,h.B)(this,"set-flow-errors",{errors:{}})}catch(e){"string"==typeof e.message?this._error=e.message:(this._error=void 0,(0,h.B)(this,"set-flow-errors",e.message)),this._unsub=void 0,this._preview=void 0}}}]}}),a.oi);s()}catch(e){s(e)}}))}};
//# sourceMappingURL=87498.2a48e4ac86f2f4a1.js.map