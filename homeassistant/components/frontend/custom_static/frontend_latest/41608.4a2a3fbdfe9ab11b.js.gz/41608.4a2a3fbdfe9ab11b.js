export const __webpack_ids__=["41608"];export const __webpack_modules__={99426:function(e,t,i){i.r(t);var a=i(44249),n=i(57243),o=i(15093),s=i(35359),r=i(36522);i(23334),i(37583);const c={info:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",warning:"M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16",error:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",success:"M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"};(0,a.Z)([(0,o.Mo)("ha-alert")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)()],key:"title",value:()=>""},{kind:"field",decorators:[(0,o.Cb)({attribute:"alert-type"})],key:"alertType",value:()=>"info"},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"dismissable",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <div class="issue-type ${(0,s.$)({[this.alertType]:!0})}" role="alert">
        <div class="icon ${this.title?"":"no-title"}">
          <slot name="icon">
            <ha-svg-icon .path=${c[this.alertType]}></ha-svg-icon>
          </slot>
        </div>
        <div class=${(0,s.$)({content:!0,narrow:this.narrow})}>
          <div class="main-content">
            ${this.title?n.dy`<div class="title">${this.title}</div>`:n.Ld}
            <slot></slot>
          </div>
          <div class="action">
            <slot name="action">
              ${this.dismissable?n.dy`<ha-icon-button @click=${this._dismissClicked} label="Dismiss alert" .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}></ha-icon-button>`:n.Ld}
            </slot>
          </div>
        </div>
      </div>
    `}},{kind:"method",key:"_dismissClicked",value:function(){(0,r.B)(this,"alert-dismissed-clicked")}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.action,.icon{z-index:1}.issue-type{position:relative;padding:8px;display:flex}.issue-type::after{position:absolute;top:0;right:0;bottom:0;left:0;opacity:.12;pointer-events:none;content:"";border-radius:4px}.icon.no-title{align-self:center}.content{display:flex;justify-content:space-between;align-items:center;width:100%;text-align:var(--float-start)}.content.narrow{flex-direction:column;align-items:flex-end}.action{width:min-content;--mdc-theme-primary:var(--primary-text-color)}.main-content{overflow-wrap:anywhere;word-break:break-word;margin-left:8px;margin-right:0;margin-inline-start:8px;margin-inline-end:0}.title{margin-top:2px;font-weight:700}.action ha-icon-button,.action mwc-button{--mdc-theme-primary:var(--primary-text-color);--mdc-icon-button-size:36px}.issue-type.info>.icon{color:var(--info-color)}.issue-type.info::after{background-color:var(--info-color)}.issue-type.warning>.icon{color:var(--warning-color)}.issue-type.warning::after{background-color:var(--warning-color)}.issue-type.error>.icon{color:var(--error-color)}.issue-type.error::after{background-color:var(--error-color)}.issue-type.success>.icon{color:var(--success-color)}.issue-type.success::after{background-color:var(--success-color)}:host ::slotted(ul){margin:0;padding-inline-start:20px}`}]}}),n.oi)},54977:function(e,t,i){var a=i(44249),n=i(57243),o=i(15093);(0,a.Z)([(0,o.Mo)("ha-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)()],key:"header",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,reflect:!0})],key:"raised",value:()=>!1},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{background:var(--custom-background-color,var(--card-background-color,#fff));-webkit-backdrop-filter:var(--ha-card-backdrop-filter,none);backdrop-filter:var(--ha-card-backdrop-filter,none);box-shadow:var(--ha-card-box-shadow,none);box-sizing:border-box;border-radius:var(--ha-card-border-radius,16px);color:var(--primary-text-color);display:block;transition:.3s ease-out;position:relative}:host([raised]){border:none;box-shadow:var(--ha-card-box-shadow,0px 2px 1px -1px rgba(0,0,0,.2),0px 1px 1px 0px rgba(0,0,0,.14),0px 1px 3px 0px rgba(0,0,0,.12))}.card-header,:host ::slotted(.card-header){color:var(--ha-card-header-color,var(--primary-text-color));font-family:var(--ha-card-header-font-family, inherit);font-size:var(--ha-card-header-font-size, 24px);letter-spacing:-.012em;line-height:48px;padding:12px 16px 16px;display:block;margin-block-start:0px;margin-block-end:0px;font-weight:400}:host ::slotted(.card-content:not(:first-child)),slot:not(:first-child)::slotted(.card-content){padding-top:0px;margin-top:-8px}:host ::slotted(.card-content){padding:16px}:host ::slotted(.card-actions){border-top:1px solid var(--divider-color,#e8e8e8);padding:5px 16px}`},{kind:"method",key:"render",value:function(){return n.dy`
      ${this.header?n.dy`<h1 class="card-header">${this.header}</h1>`:n.Ld}
      <slot></slot>
    `}}]}}),n.oi)},30509:function(e,t,i){var a=i(44249),n=i(57243),o=i(15093);(0,a.Z)([(0,o.Mo)("ha-settings-row")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({type:Boolean,reflect:!0})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,reflect:!0})],key:"slim",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"three-line"})],key:"threeLine",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"wrap-heading",reflect:!0})],key:"wrapHeading",value:()=>!1},{kind:"method",key:"render",value:function(){return n.dy`
      <div class="prefix-wrap">
        <slot name="prefix"></slot>
        <div class="body" ?two-line=${!this.threeLine} ?three-line=${this.threeLine}>
          <slot name="heading"></slot>
          <div class="secondary"><slot name="description"></slot></div>
        </div>
      </div>
      <div class="content"><slot></slot></div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{display:flex;padding:0 16px;align-content:normal;align-self:auto;align-items:center}.body{padding-inline-start:0;padding:8px 16px 8px 0;padding-inline-end:16px;overflow:hidden;display:var(--layout-vertical_-_display,flex);flex-direction:var(--layout-vertical_-_flex-direction,column);justify-content:var(--layout-center-justified_-_justify-content,center);flex:var(--layout-flex_-_flex,1);flex-basis:var(--layout-flex_-_flex-basis,0.000000001px)}.body[three-line]{min-height:var(--paper-item-body-three-line-min-height,88px)}:host(:not([wrap-heading])) body>*{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.body>.secondary{display:block;padding-top:4px;font-family:var(
        --mdc-typography-body2-font-family,
        var(--mdc-typography-font-family, Roboto, sans-serif)
      );-webkit-font-smoothing:antialiased;font-size:var(--mdc-typography-body2-font-size, .875rem);font-weight:var(--mdc-typography-body2-font-weight,400);line-height:normal;color:var(--secondary-text-color)}.body[two-line]{min-height:calc(var(--paper-item-body-two-line-min-height,72px) - 16px);flex:1}.content{display:contents}:host(:not([narrow])) .content{display:var(--settings-row-content-display,flex);justify-content:flex-end;flex:1;padding:16px 0}.content ::slotted(*){width:var(--settings-row-content-width)}:host([narrow]){align-items:normal;flex-direction:column;border-top:1px solid var(--divider-color);padding-bottom:8px}::slotted(ha-switch){padding:16px 0}.secondary{white-space:normal}.prefix-wrap{display:var(--settings-row-prefix-display)}:host([narrow]) .prefix-wrap{display:flex;align-items:center}:host([slim]),:host([slim]) .content,:host([slim]) ::slotted(ha-switch){padding:0}:host([slim]) .body{min-height:0}`}]}}),n.oi)},62801:function(e,t,i){var a=i(44249),n=i(72621),o=(i(9359),i(56475),i(22139),i(57243)),s=i(15093),r=i(36522);(0,a.Z)([(0,s.Mo)("ha-sortable")],(function(e,t){class a extends t{constructor(...t){super(...t),e(this)}}return{F:a,d:[{kind:"field",key:"_sortable",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,attribute:"no-style"})],key:"noStyle",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:String,attribute:"draggable-selector"})],key:"draggableSelector",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:String,attribute:"handle-selector"})],key:"handleSelector",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:String,attribute:"filter"})],key:"filter",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:String})],key:"group",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean,attribute:"invert-swap"})],key:"invertSwap",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"options",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"rollback",value:()=>!0},{kind:"method",key:"updated",value:function(e){e.has("disabled")&&(this.disabled?this._destroySortable():this._createSortable())}},{kind:"field",key:"_shouldBeDestroy",value:()=>!1},{kind:"method",key:"disconnectedCallback",value:function(){(0,n.Z)(a,"disconnectedCallback",this,3)([]),this._shouldBeDestroy=!0,setTimeout((()=>{this._shouldBeDestroy&&(this._destroySortable(),this._shouldBeDestroy=!1)}),1)}},{kind:"method",key:"connectedCallback",value:function(){(0,n.Z)(a,"connectedCallback",this,3)([]),this._shouldBeDestroy=!1,this.hasUpdated&&!this.disabled&&this._createSortable()}},{kind:"method",key:"createRenderRoot",value:function(){return this}},{kind:"method",key:"render",value:function(){return this.noStyle?o.Ld:o.dy`
      <style>.sortable-fallback{display:none!important}.sortable-ghost{box-shadow:0 0 0 2px var(--primary-color);background:rgba(var(--rgb-primary-color),.25);border-radius:4px;opacity:.4}.sortable-drag{border-radius:4px;opacity:1;background:var(--card-background-color);box-shadow:0px 4px 8px 3px #00000026;cursor:grabbing}</style>
    `}},{kind:"method",key:"_createSortable",value:async function(){if(this._sortable)return;const e=this.children[0];if(!e)return;const t=(await Promise.all([i.e("34153"),i.e("467")]).then(i.bind(i,59807))).default,a={scroll:!0,forceAutoScrollFallback:!0,scrollSpeed:20,animation:150,...this.options,onChoose:this._handleChoose,onStart:this._handleStart,onEnd:this._handleEnd,onUpdate:this._handleUpdate,onAdd:this._handleAdd,onRemove:this._handleRemove};this.draggableSelector&&(a.draggable=this.draggableSelector),this.handleSelector&&(a.handle=this.handleSelector),void 0!==this.invertSwap&&(a.invertSwap=this.invertSwap),this.group&&(a.group=this.group),this.filter&&(a.filter=this.filter),this._sortable=new t(e,a)}},{kind:"field",key:"_handleUpdate",value(){return e=>{(0,r.B)(this,"item-moved",{newIndex:e.newIndex,oldIndex:e.oldIndex})}}},{kind:"field",key:"_handleAdd",value(){return e=>{(0,r.B)(this,"item-added",{index:e.newIndex,data:e.item.sortableData})}}},{kind:"field",key:"_handleRemove",value(){return e=>{(0,r.B)(this,"item-removed",{index:e.oldIndex})}}},{kind:"field",key:"_handleEnd",value(){return async e=>{(0,r.B)(this,"drag-end"),this.rollback&&e.item.placeholder&&(e.item.placeholder.replaceWith(e.item),delete e.item.placeholder)}}},{kind:"field",key:"_handleStart",value(){return()=>{(0,r.B)(this,"drag-start")}}},{kind:"field",key:"_handleChoose",value(){return e=>{this.rollback&&(e.item.placeholder=document.createComment("sort-placeholder"),e.item.after(e.item.placeholder))}}},{kind:"method",key:"_destroySortable",value:function(){this._sortable&&(this._sortable.destroy(),this._sortable=void 0)}}]}}),o.oi)},75101:function(e,t,i){i.d(t,{$H:()=>a,DJ:()=>r,LZ:()=>o,Nn:()=>u,Ny:()=>p,Pk:()=>f,Q4:()=>s,RQ:()=>l,SO:()=>d,T0:()=>g,aR:()=>n,iJ:()=>h,pB:()=>c});i(9359),i(56475),i(1331);const a=(e,t)=>e.callWS({type:"config_entries/subentries/list",entry_id:t}),n=(e,t,i)=>e.callWS({type:"config_entries/subentries/delete",entry_id:t,subentry_id:i}),o=["migration_error","setup_error","setup_retry"],s=["not_loaded","loaded","setup_error","setup_retry"],r=(e,t,i)=>{const a={type:"config_entries/subscribe"};return i&&i.type&&(a.type_filter=i.type),e.connection.subscribeMessage((e=>t(e)),a)},c=(e,t)=>{const i={};return t&&(t.type&&(i.type_filter=t.type),t.domain&&(i.domain=t.domain)),e.callWS({type:"config_entries/get",...i})},l=(e,t)=>e.callWS({type:"config_entries/get_single",entry_id:t}),d=(e,t,i)=>e.callWS({type:"config_entries/update",entry_id:t,...i}),h=(e,t)=>e.callApi("DELETE",`config/config_entries/entry/${t}`),u=(e,t)=>e.callApi("POST",`config/config_entries/entry/${t}/reload`),p=(e,t)=>e.callWS({type:"config_entries/disable",entry_id:t,disabled_by:"user"}),g=(e,t)=>e.callWS({type:"config_entries/disable",entry_id:t,disabled_by:null}),f=(e,t)=>{if(!t)return e;const i=e.find((e=>e.entry_id===t));if(!i)return e;return[i,...e.filter((e=>e.entry_id!==t))]}},15681:function(e,t,i){i.d(t,{D4:()=>d,D7:()=>f,Ky:()=>l,P3:()=>r,V3:()=>_,WW:()=>m,XO:()=>h,ZJ:()=>v,d4:()=>g,oi:()=>p,pV:()=>s,zO:()=>u});var a=i(62212),n=i(22381),o=i(57816);const s=["bluetooth","dhcp","discovery","hardware","hassio","homekit","integration_discovery","mqtt","ssdp","unignore","usb","zeroconf"],r=["reauth"],c={"HA-Frontend-Base":`${location.protocol}//${location.host}`},l=(e,t,i)=>e.callApi("POST","config/config_entries/flow",{handler:t,show_advanced_options:Boolean(e.userData?.showAdvanced),entry_id:i},c),d=(e,t)=>e.callApi("GET",`config/config_entries/flow/${t}`,void 0,c),h=(e,t,i)=>e.callApi("POST",`config/config_entries/flow/${t}`,i,c),u=(e,t,i)=>e.callWS({type:"config_entries/ignore_flow",flow_id:t,title:i}),p=(e,t)=>e.callApi("DELETE",`config/config_entries/flow/${t}`),g=(e,t)=>e.callApi("GET","config/config_entries/flow_handlers"+(t?`?type=${t}`:"")),f=e=>e.sendMessagePromise({type:"config_entries/flow/progress"}),y=(e,t)=>e.subscribeEvents((0,n.D)((()=>f(e).then((e=>t.setState(e,!0)))),500,!0),"config_entry_discovered"),v=e=>(0,a._)(e,"_configFlowProgress",f,y),_=(e,t)=>v(e.connection).subscribe(t),m=(e,t)=>t.context.title_placeholders&&0!==Object.keys(t.context.title_placeholders).length?e(`component.${t.handler}.config.flow_title`,t.context.title_placeholders)||("name"in t.context.title_placeholders?t.context.title_placeholders.name:(0,o.Lh)(e,t.handler)):(0,o.Lh)(e,t.handler)},38572:function(e,t,i){i.d(t,{t:()=>r});var a=i(57243),n=i(15681),o=i(57816),s=i(7956);const r=(e,t)=>(0,s.w)(e,t,{flowType:"config_flow",showDevices:!0,createFlow:async(e,i)=>{const[a]=await Promise.all([(0,n.Ky)(e,i,t.entryId),e.loadFragmentTranslation("config"),e.loadBackendTranslation("config",i),e.loadBackendTranslation("selector",i),e.loadBackendTranslation("title",i)]);return a},fetchFlow:async(e,t)=>{const i=await(0,n.D4)(e,t);return await e.loadFragmentTranslation("config"),await e.loadBackendTranslation("config",i.handler),await e.loadBackendTranslation("selector",i.handler),i},handleFlowStep:n.XO,deleteFlow:n.oi,renderAbortDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.abort.${t.reason}`,t.description_placeholders);return i?a.dy`
            <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
          `:t.reason},renderShowFormStepHeader:(e,t)=>e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.title`,t.description_placeholders)||e.localize(`component.${t.handler}.title`),renderShowFormStepDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.description`,t.description_placeholders);return i?a.dy`
            <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
          `:""},renderShowFormStepFieldLabel(e,t,i,a){if("expandable"===i.type)return e.localize(`component.${t.handler}.config.step.${t.step_id}.sections.${i.name}.name`);const n=a?.path?.[0]?`sections.${a.path[0]}.`:"";return e.localize(`component.${t.handler}.config.step.${t.step_id}.${n}data.${i.name}`)||i.name},renderShowFormStepFieldHelper(e,t,i,n){if("expandable"===i.type)return e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.sections.${i.name}.description`);const o=n?.path?.[0]?`sections.${n.path[0]}.`:"",s=e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.${o}data_description.${i.name}`,t.description_placeholders);return s?a.dy`<ha-markdown breaks .content=${s}></ha-markdown>`:""},renderShowFormStepFieldError:(e,t,i)=>e.localize(`component.${t.translation_domain||t.translation_domain||t.handler}.config.error.${i}`,t.description_placeholders)||i,renderShowFormStepFieldLocalizeValue:(e,t,i)=>e.localize(`component.${t.handler}.selector.${i}`),renderShowFormStepSubmitButton:(e,t)=>e.localize(`component.${t.handler}.config.step.${t.step_id}.submit`)||e.localize("ui.panel.config.integrations.config_flow."+(!1===t.last_step?"next":"submit")),renderExternalStepHeader:(e,t)=>e.localize(`component.${t.handler}.config.step.${t.step_id}.title`)||e.localize("ui.panel.config.integrations.config_flow.external_step.open_site"),renderExternalStepDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.${t.step_id}.description`,t.description_placeholders);return a.dy`
        <p>
          ${e.localize("ui.panel.config.integrations.config_flow.external_step.description")}
        </p>
        ${i?a.dy`
              <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
            `:""}
      `},renderCreateEntryDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.create_entry.${t.description||"default"}`,t.description_placeholders);return a.dy`
        ${i?a.dy`
              <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
            `:""}
        <p>
          ${e.localize("ui.panel.config.integrations.config_flow.created_config",{name:t.title})}
        </p>
      `},renderShowFormProgressHeader:(e,t)=>e.localize(`component.${t.handler}.config.step.${t.step_id}.title`)||e.localize(`component.${t.handler}.title`),renderShowFormProgressDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.progress.${t.progress_action}`,t.description_placeholders);return i?a.dy`
            <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
          `:""},renderMenuHeader:(e,t)=>e.localize(`component.${t.handler}.config.step.${t.step_id}.title`)||e.localize(`component.${t.handler}.title`),renderMenuDescription(e,t){const i=e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.description`,t.description_placeholders);return i?a.dy`
            <ha-markdown allow-svg breaks .content=${i}></ha-markdown>
          `:""},renderMenuOption:(e,t,i)=>e.localize(`component.${t.translation_domain||t.handler}.config.step.${t.step_id}.menu_options.${i}`,t.description_placeholders),renderLoadingDescription(e,t,i,a){if("loading_flow"!==t&&"loading_step"!==t)return"";const n=a?.handler||i;return e.localize(`ui.panel.config.integrations.config_flow.loading.${t}`,{integration:n?(0,o.Lh)(e.localize,n):e.localize("ui.panel.config.integrations.config_flow.loading.fallback_title")})}})},7956:function(e,t,i){i.d(t,{w:()=>o});var a=i(36522);const n=()=>Promise.all([i.e("46379"),i.e("66031"),i.e("72206"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("83895"),i.e("7764"),i.e("2981"),i.e("58640"),i.e("1562"),i.e("84503"),i.e("27090"),i.e("19882")]).then(i.bind(i,12656)),o=(e,t,i)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-data-entry-flow",dialogImport:n,dialogParams:{...t,flowConfig:i,dialogParentElement:e}})}},3409:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(31526),i(70104),i(31622),i(57243)),o=i(15093),s=i(36522),r=(i(54977),i(23334),i(30509),i(1118)),c=i(17705),l=i(76131),d=i(28008),h=i(73192),u=i(58605),p=(i(34234),i(39418)),g=e([r]);r=(g.then?(await g)():g)[0];const f="M16 20H8V6H16M16.67 4H15V2H9V4H7.33C6.6 4 6 4.6 6 5.33V20.67C6 21.4 6.6 22 7.33 22H16.67C17.41 22 18 21.41 18 20.67V5.33C18 4.6 17.4 4 16.67 4M15 16H9V19H15V16M15 7H9V10H15V7M15 11.5H9V14.5H15V11.5Z",y="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",v="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z";(0,a.Z)([(0,o.Mo)("ha-energy-battery-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"method",key:"render",value:function(){const e=[],t=[];return this.preferences.energy_sources.forEach(((i,a)=>{"battery"===i.type&&(e.push(i),this.validationResult&&t.push(this.validationResult.energy_sources[a]))})),n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${f}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.battery.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.battery.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,h.R)(this.hass,"/docs/energy/battery/")}>${this.hass.localize("ui.panel.config.energy.battery.learn_more")}</a>
          </p>
          ${t.map((e=>n.dy`
              <ha-energy-validation-result .hass=${this.hass} .issues=${e}></ha-energy-validation-result>
            `))}

          <h3>
            ${this.hass.localize("ui.panel.config.energy.battery.battery_systems")}
          </h3>
          ${e.map((e=>{const t=this.hass.states[e.stat_energy_to];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${f}></ha-svg-icon>`}
                <div class="content">
                  <span class="label">${(0,c.Kd)(this.hass,e.stat_energy_from,this.statsMetadata?.[e.stat_energy_from])}</span>
                  <span class="label">${(0,c.Kd)(this.hass,e.stat_energy_to,this.statsMetadata?.[e.stat_energy_to])}</span>
                </div>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.battery.edit_battery_system")} @click=${this._editSource} .path=${v}></ha-icon-button>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.battery.delete_battery_system")} @click=${this._deleteSource} .path=${y}></ha-icon-button>
              </div>
            `}))}
          <div class="row border-bottom">
            <ha-svg-icon .path=${f}></ha-svg-icon>
            <mwc-button @click=${this._addSource}>${this.hass.localize("ui.panel.config.energy.battery.add_battery_system")}</mwc-button>
          </div>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_addSource",value:function(){(0,u.Q6)(this,{battery_sources:this.preferences.energy_sources.filter((e=>"battery"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.concat(e)})}})}},{kind:"method",key:"_editSource",value:function(e){const t=e.currentTarget.closest(".row").source;(0,u.Q6)(this,{source:{...t},battery_sources:this.preferences.energy_sources.filter((e=>"battery"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>i===t?e:i))})}})}},{kind:"method",key:"_deleteSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))try{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.filter((e=>e!==t))})}catch(e){(0,l.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"method",key:"_savePreferences",value:async function(e){const t=await(0,r._Z)(this.hass,e);(0,s.B)(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,p.L,n.iv`.row{height:58px}.content{display:flex;flex-direction:column}.label{overflow:hidden;text-overflow:ellipsis}`]}}]}}),n.oi);t()}catch(e){t(e)}}))},98445:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(9359),i(56475),i(31526),i(70104),i(31622),i(57243)),o=i(91583),s=i(15093),r=i(36522),c=(i(54977),i(23334),i(62801),i(37583),i(1118)),l=i(17705),d=i(76131),h=i(28008),u=i(73192),p=i(58605),g=(i(34234),i(39418)),f=e([c]);c=(f.then?(await f)():f)[0];const y="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",v="M3 6H21V4H3C1.9 4 1 4.9 1 6V18C1 19.1 1.9 20 3 20H7V18H3V6M13 12H9V13.78C8.39 14.33 8 15.11 8 16C8 16.89 8.39 17.67 9 18.22V20H13V18.22C13.61 17.67 14 16.88 14 16S13.61 14.33 13 13.78V12M11 17.5C10.17 17.5 9.5 16.83 9.5 16S10.17 14.5 11 14.5 12.5 15.17 12.5 16 11.83 17.5 11 17.5M22 8H16C15.5 8 15 8.5 15 9V19C15 19.5 15.5 20 16 20H22C22.5 20 23 19.5 23 19V9C23 8.5 22.5 8 22 8M21 18H17V10H21V18Z",_="M7,19V17H9V19H7M11,19V17H13V19H11M15,19V17H17V19H15M7,15V13H9V15H7M11,15V13H13V15H11M15,15V13H17V15H15M7,11V9H9V11H7M11,11V9H13V11H11M15,11V9H17V11H15M7,7V5H9V7H7M11,7V5H13V7H11M15,7V5H17V7H15Z",m="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z";(0,a.Z)([(0,s.Mo)("ha-energy-device-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"method",key:"render",value:function(){return n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${v}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.device_consumption.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.device_consumption.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,u.R)(this.hass,"/docs/energy/individual-devices/")}>${this.hass.localize("ui.panel.config.energy.device_consumption.learn_more")}</a>
          </p>
          ${this.validationResult?.device_consumption.map((e=>n.dy`
              <ha-energy-validation-result .hass=${this.hass} .issues=${e}></ha-energy-validation-result>
            `))}
          <h3>
            ${this.hass.localize("ui.panel.config.energy.device_consumption.devices")}
          </h3>
          <ha-sortable handle-selector=".handle" @item-moved=${this._itemMoved}>
            <div class="devices">
              ${(0,o.r)(this.preferences.device_consumption,(e=>e.stat_consumption),(e=>n.dy`
                  <div class="row" .device=${e}>
                    <div class="handle">
                      <ha-svg-icon .path=${_}></ha-svg-icon>
                    </div>
                    <span class="content">${e.name||(0,l.Kd)(this.hass,e.stat_consumption,this.statsMetadata?.[e.stat_consumption])}</span>
                    <ha-icon-button .label=${this.hass.localize("ui.common.edit")} @click=${this._editDevice} .path=${m}></ha-icon-button>
                    <ha-icon-button .label=${this.hass.localize("ui.common.delete")} @click=${this._deleteDevice} .device=${e} .path=${y}></ha-icon-button>
                  </div>
                `))}
            </div>
          </ha-sortable>
          <div class="row">
            <ha-svg-icon .path=${v}></ha-svg-icon>
            <mwc-button @click=${this._addDevice}>${this.hass.localize("ui.panel.config.energy.device_consumption.add_device")}</mwc-button>
          </div>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_itemMoved",value:function(e){e.stopPropagation();const{oldIndex:t,newIndex:i}=e.detail,a=this.preferences.device_consumption.concat(),n=a.splice(t,1)[0];a.splice(i,0,n);const o={...this.preferences,device_consumption:a};(0,r.B)(this,"value-changed",{value:o}),this._savePreferences(o)}},{kind:"method",key:"_editDevice",value:function(e){const t=e.currentTarget.closest(".row").device;(0,p.Qh)(this,{statsMetadata:this.statsMetadata,device:{...t},device_consumptions:this.preferences.device_consumption,saveCallback:async e=>{await this._savePreferences({...this.preferences,device_consumption:this.preferences.device_consumption.map((i=>i===t?e:i))})}})}},{kind:"method",key:"_addDevice",value:function(){(0,p.Qh)(this,{statsMetadata:this.statsMetadata,device_consumptions:this.preferences.device_consumption,saveCallback:async e=>{await this._savePreferences({...this.preferences,device_consumption:this.preferences.device_consumption.concat(e)})}})}},{kind:"method",key:"_deleteDevice",value:async function(e){const t=e.currentTarget.device;if(await(0,d.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))try{const e={...this.preferences,device_consumption:this.preferences.device_consumption.filter((e=>e!==t))};e.device_consumption.forEach(((i,a)=>{i.included_in_stat===t.stat_consumption&&(e.device_consumption[a]={...e.device_consumption[a]},delete e.device_consumption[a].included_in_stat)})),await this._savePreferences(e)}catch(e){(0,d.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"method",key:"_savePreferences",value:async function(e){const t=await(0,c._Z)(this.hass,e);(0,r.B)(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return[h.Qx,g.L,n.iv`.handle{cursor:move;cursor:grab}`]}}]}}),n.oi);t()}catch(e){t(e)}}))},68646:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(31526),i(70104),i(31622),i(57243)),o=i(15093),s=i(36522),r=(i(54977),i(23334),i(1118)),c=i(17705),l=i(76131),d=i(28008),h=i(73192),u=i(58605),p=(i(34234),i(39418)),g=e([r]);r=(g.then?(await g)():g)[0];const f="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",y="M17.66 11.2C17.43 10.9 17.15 10.64 16.89 10.38C16.22 9.78 15.46 9.35 14.82 8.72C13.33 7.26 13 4.85 13.95 3C13 3.23 12.17 3.75 11.46 4.32C8.87 6.4 7.85 10.07 9.07 13.22C9.11 13.32 9.15 13.42 9.15 13.55C9.15 13.77 9 13.97 8.8 14.05C8.57 14.15 8.33 14.09 8.14 13.93C8.08 13.88 8.04 13.83 8 13.76C6.87 12.33 6.69 10.28 7.45 8.64C5.78 10 4.87 12.3 5 14.47C5.06 14.97 5.12 15.47 5.29 15.97C5.43 16.57 5.7 17.17 6 17.7C7.08 19.43 8.95 20.67 10.96 20.92C13.1 21.19 15.39 20.8 17.03 19.32C18.86 17.66 19.5 15 18.56 12.72L18.43 12.46C18.22 12 17.66 11.2 17.66 11.2M14.5 17.5C14.22 17.74 13.76 18 13.4 18.1C12.28 18.5 11.16 17.94 10.5 17.28C11.69 17 12.4 16.12 12.61 15.23C12.78 14.43 12.46 13.77 12.33 13C12.21 12.26 12.23 11.63 12.5 10.94C12.69 11.32 12.89 11.7 13.13 12C13.9 13 15.11 13.44 15.37 14.8C15.41 14.94 15.43 15.08 15.43 15.23C15.46 16.05 15.1 16.95 14.5 17.5H14.5Z",v="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z";(0,a.Z)([(0,o.Mo)("ha-energy-gas-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"method",key:"render",value:function(){const e=[],t=[];return this.preferences.energy_sources.forEach(((i,a)=>{"gas"===i.type&&(e.push(i),this.validationResult&&t.push(this.validationResult.energy_sources[a]))})),n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${y}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.gas.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.gas.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,h.R)(this.hass,"/docs/energy/gas/")}>${this.hass.localize("ui.panel.config.energy.gas.learn_more")}</a>
          </p>
          ${t.map((e=>n.dy`
              <ha-energy-validation-result .hass=${this.hass} .issues=${e}></ha-energy-validation-result>
            `))}
          <h3>
            ${this.hass.localize("ui.panel.config.energy.gas.gas_consumption")}
          </h3>
          ${e.map((e=>{const t=this.hass.states[e.stat_energy_from];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${y}></ha-svg-icon>`}
                <span class="content">${(0,c.Kd)(this.hass,e.stat_energy_from,this.statsMetadata?.[e.stat_energy_from])}</span>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.gas.edit_gas_source")} @click=${this._editSource} .path=${v}></ha-icon-button>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.gas.delete_gas_source")} @click=${this._deleteSource} .path=${f}></ha-icon-button>
              </div>
            `}))}
          <div class="row border-bottom">
            <ha-svg-icon .path=${y}></ha-svg-icon>
            <mwc-button @click=${this._addSource}>${this.hass.localize("ui.panel.config.energy.gas.add_gas_source")}</mwc-button>
          </div>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_addSource",value:function(){(0,u.vp)(this,{allowedGasUnitClass:(0,r.G9)(this.preferences,void 0,this.statsMetadata),gas_sources:this.preferences.energy_sources.filter((e=>"gas"===e.type)),saveCallback:async e=>{delete e.unit_of_measurement,await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.concat(e)})}})}},{kind:"method",key:"_editSource",value:function(e){const t=e.currentTarget.closest(".row").source;(0,u.vp)(this,{source:{...t},allowedGasUnitClass:(0,r.G9)(this.preferences,t.stat_energy_from,this.statsMetadata),metadata:this.statsMetadata?.[t.stat_energy_from],gas_sources:this.preferences.energy_sources.filter((e=>"gas"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>i===t?e:i))})}})}},{kind:"method",key:"_deleteSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))try{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.filter((e=>e!==t))})}catch(e){(0,l.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"method",key:"_savePreferences",value:async function(e){const t=await(0,r._Z)(this.hass,e);(0,s.B)(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,p.L]}}]}}),n.oi);t()}catch(e){t(e)}}))},98237:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(1331),i(70104),i(48136),i(31622),i(57243)),o=i(15093),s=i(36522),r=(i(54977),i(23334),i(75101)),c=i(1118),l=i(17705),d=i(38572),h=i(76131),u=i(28008),p=i(88238),g=i(73192),f=i(58605),y=(i(34234),i(39418)),v=e([c]);c=(v.then?(await v)():v)[0];const _="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",m="M24 13L20 17V14H11V12H20V9L24 13M4 20V12H1L11 3L18 9.3V10H15.79L11 5.69L6 10.19V18H16V16H18V20H4Z",b="M15 13L11 17V14H2V12H11V9L15 13M5 20V16H7V18H17V10.19L12 5.69L7.21 10H4.22L12 3L22 12H19V20H5Z",k="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",w="M8.28,5.45L6.5,4.55L7.76,2H16.23L17.5,4.55L15.72,5.44L15,4H9L8.28,5.45M18.62,8H14.09L13.3,5H10.7L9.91,8H5.38L4.1,10.55L5.89,11.44L6.62,10H17.38L18.1,11.45L19.89,10.56L18.62,8M17.77,22H15.7L15.46,21.1L12,15.9L8.53,21.1L8.3,22H6.23L9.12,11H11.19L10.83,12.35L12,14.1L13.16,12.35L12.81,11H14.88L17.77,22M11.4,15L10.5,13.65L9.32,18.13L11.4,15M14.68,18.12L13.5,13.64L12.6,15L14.68,18.12Z";(0,a.Z)([(0,o.Mo)("ha-energy-grid-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_co2ConfigEntry",value:void 0},{kind:"method",key:"firstUpdated",value:function(){this._fetchCO2SignalConfigEntries()}},{kind:"method",key:"render",value:function(){const e=this.preferences.energy_sources.findIndex((e=>"grid"===e.type));let t,i;return-1===e?t=(0,c.iK)():(t=this.preferences.energy_sources[e],this.validationResult&&(i=this.validationResult.energy_sources[e])),n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${w}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.grid.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.grid.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,g.R)(this.hass,"/docs/energy/electricity-grid/")}>${this.hass.localize("ui.panel.config.energy.grid.learn_more")}</a>
          </p>
          ${i?n.dy`
                <ha-energy-validation-result .hass=${this.hass} .issues=${i}></ha-energy-validation-result>
              `:""}

          <h3>
            ${this.hass.localize("ui.panel.config.energy.grid.grid_consumption")}
          </h3>
          ${t.flow_from.map((e=>{const t=this.hass.states[e.stat_energy_from];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t?.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${b}></ha-svg-icon>`}
                <span class="content">${(0,l.Kd)(this.hass,e.stat_energy_from,this.statsMetadata?.[e.stat_energy_from])}</span>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.grid.edit_consumption")} @click=${this._editFromSource} .path=${k}></ha-icon-button>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.grid.delete_consumption")} @click=${this._deleteFromSource} .path=${_}></ha-icon-button>
              </div>
            `}))}
          <div class="row border-bottom">
            <ha-svg-icon .path=${b}></ha-svg-icon>
            <mwc-button @click=${this._addFromSource}>${this.hass.localize("ui.panel.config.energy.grid.add_consumption")}</mwc-button>
          </div>

          <h3>
            ${this.hass.localize("ui.panel.config.energy.grid.return_to_grid")}
          </h3>
          ${t.flow_to.map((e=>{const t=this.hass.states[e.stat_energy_to];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${m}></ha-svg-icon>`}
                <span class="content">${(0,l.Kd)(this.hass,e.stat_energy_to,this.statsMetadata?.[e.stat_energy_to])}</span>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.grid.edit_return")} @click=${this._editToSource} .path=${k}></ha-icon-button>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.grid.delete_return")} @click=${this._deleteToSource} .path=${_}></ha-icon-button>
              </div>
            `}))}
          <div class="row border-bottom">
            <ha-svg-icon .path=${m}></ha-svg-icon>
            <mwc-button @click=${this._addToSource}>${this.hass.localize("ui.panel.config.energy.grid.add_return")}</mwc-button>
          </div>

          <h3>
            ${this.hass.localize("ui.panel.config.energy.grid.grid_carbon_footprint")}
          </h3>
          ${this._co2ConfigEntry?n.dy`<div class="row" .entry=${this._co2ConfigEntry}>
                <img alt="" crossorigin="anonymous" referrerpolicy="no-referrer" src=${(0,p.X1)({domain:"co2signal",type:"icon",darkOptimized:this.hass.themes?.darkMode})}/>
                <span class="content">${this._co2ConfigEntry.title}</span>
                <a href=${`/config/integrations/integration/${this._co2ConfigEntry?.domain}`}>
                  <ha-icon-button .path=${k}></ha-icon-button>
                </a>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.grid.remove_co2_signal")} @click=${this._removeCO2Sensor} .path=${_}></ha-icon-button>
              </div>`:n.dy`
                <div class="row border-bottom">
                  <img alt="" crossorigin="anonymous" referrerpolicy="no-referrer" src=${(0,p.X1)({domain:"co2signal",type:"icon",darkOptimized:this.hass.themes?.darkMode})}/>
                  <mwc-button @click=${this._addCO2Sensor}>
                    ${this.hass.localize("ui.panel.config.energy.grid.add_co2_signal")}
                  </mwc-button>
                </div>
              `}
        </div>
      </ha-card>
    `}},{kind:"method",key:"_fetchCO2SignalConfigEntries",value:async function(){const e=await(0,r.pB)(this.hass,{domain:"co2signal"});this._co2ConfigEntry=e.length?e[0]:void 0}},{kind:"method",key:"_addCO2Sensor",value:function(){(0,d.t)(this,{startFlowHandler:"co2signal",dialogClosedCallback:()=>{this._fetchCO2SignalConfigEntries()}})}},{kind:"method",key:"_removeCO2Sensor",value:async function(e){const t=e.currentTarget.closest(".row").entry.entry_id;await(0,h.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_integration")})&&(await(0,r.iJ)(this.hass,t),this._fetchCO2SignalConfigEntries())}},{kind:"method",key:"_addFromSource",value:function(){const e=this.preferences.energy_sources.find((e=>"grid"===e.type));(0,f.a0)(this,{grid_source:e,saveCallback:async t=>{let i;i=e?{...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>"grid"===i.type?{...i,flow_from:[...e.flow_from,t]}:i))}:{...this.preferences,energy_sources:[...this.preferences.energy_sources,{...(0,c.iK)(),flow_from:[t]}]},await this._savePreferences(i)}})}},{kind:"method",key:"_addToSource",value:function(){const e=this.preferences.energy_sources.find((e=>"grid"===e.type));(0,f.u_)(this,{grid_source:e,saveCallback:async t=>{let i;i=e?{...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>"grid"===i.type?{...i,flow_to:[...e.flow_to,t]}:i))}:{...this.preferences,energy_sources:[...this.preferences.energy_sources,{...(0,c.iK)(),flow_to:[t]}]},await this._savePreferences(i)}})}},{kind:"method",key:"_editFromSource",value:function(e){const t=e.currentTarget.closest(".row").source,i=this.preferences.energy_sources.find((e=>"grid"===e.type));(0,f.a0)(this,{source:{...t},grid_source:i,metadata:this.statsMetadata?.[t.stat_energy_from],saveCallback:async e=>{const i=(0,c.Jj)(this.preferences).grid[0].flow_from,a={...this.preferences,energy_sources:this.preferences.energy_sources.map((a=>"grid"===a.type?{...a,flow_from:i.map((i=>i===t?e:i))}:a))};await this._savePreferences(a)}})}},{kind:"method",key:"_editToSource",value:function(e){const t=e.currentTarget.closest(".row").source,i=this.preferences.energy_sources.find((e=>"grid"===e.type));(0,f.u_)(this,{source:{...t},grid_source:i,metadata:this.statsMetadata?.[t.stat_energy_to],saveCallback:async e=>{const i=(0,c.Jj)(this.preferences).grid[0].flow_to,a={...this.preferences,energy_sources:this.preferences.energy_sources.map((a=>"grid"===a.type?{...a,flow_to:i.map((i=>i===t?e:i))}:a))};await this._savePreferences(a)}})}},{kind:"method",key:"_deleteFromSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(!await(0,h.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))return;const i=(0,c.Jj)(this.preferences).grid[0].flow_from.filter((e=>e!==t)),a={...this.preferences,energy_sources:this.preferences.energy_sources.map((e=>"grid"===e.type?{...e,flow_from:i}:e))},n=this._removeEmptySources(a);await this._savePreferences(n)}},{kind:"method",key:"_deleteToSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(!await(0,h.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))return;const i=(0,c.Jj)(this.preferences).grid[0].flow_to.filter((e=>e!==t)),a={...this.preferences,energy_sources:this.preferences.energy_sources.map((e=>"grid"===e.type?{...e,flow_to:i}:e))},n=this._removeEmptySources(a);await this._savePreferences(n)}},{kind:"method",key:"_removeEmptySources",value:function(e){return e.energy_sources=e.energy_sources.reduce(((e,t)=>(("grid"!==t.type||t.flow_from.length>0||t.flow_to.length>0)&&e.push(t),e)),[]),e}},{kind:"method",key:"_savePreferences",value:async function(e){try{const t=await(0,c._Z)(this.hass,e);(0,s.B)(this,"value-changed",{value:t})}catch(e){(0,h.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"get",static:!0,key:"styles",value:function(){return[u.Qx,y.L]}}]}}),n.oi);t()}catch(e){t(e)}}))},76539:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(31526),i(70104),i(31622),i(57243)),o=i(15093),s=i(36522),r=(i(54977),i(23334),i(1118)),c=i(17705),l=i(76131),d=i(28008),h=i(73192),u=i(58605),p=(i(34234),i(39418)),g=e([r]);r=(g.then?(await g)():g)[0];const f="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",y="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",v="M11.45,2V5.55L15,3.77L11.45,2M10.45,8L8,10.46L11.75,11.71L10.45,8M2,11.45L3.77,15L5.55,11.45H2M10,2H2V10C2.57,10.17 3.17,10.25 3.77,10.25C7.35,10.26 10.26,7.35 10.27,3.75C10.26,3.16 10.17,2.57 10,2M17,22V16H14L19,7V13H22L17,22Z";(0,a.Z)([(0,o.Mo)("ha-energy-solar-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"info",value:void 0},{kind:"method",key:"render",value:function(){const e=[],t=[];return this.preferences.energy_sources.forEach(((i,a)=>{"solar"===i.type&&(e.push(i),this.validationResult&&t.push(this.validationResult.energy_sources[a]))})),n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${v}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.solar.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.solar.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,h.R)(this.hass,"/docs/energy/solar-panels/")}>${this.hass.localize("ui.panel.config.energy.solar.learn_more")}</a>
          </p>
          ${t.map((e=>n.dy`
              <ha-energy-validation-result .hass=${this.hass} .issues=${e}></ha-energy-validation-result>
            `))}

          <h3>
            ${this.hass.localize("ui.panel.config.energy.solar.solar_production")}
          </h3>
          ${e.map((e=>{const t=this.hass.states[e.stat_energy_from];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${v}></ha-svg-icon>`}
                <span class="content">${(0,c.Kd)(this.hass,e.stat_energy_from,this.statsMetadata?.[e.stat_energy_from])}</span>
                ${this.info?n.dy`
                      <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.solar.edit_solar_production")} @click=${this._editSource} .path=${y}></ha-icon-button>
                    `:""}
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.solar.delete_solar_production")} @click=${this._deleteSource} .path=${f}></ha-icon-button>
              </div>
            `}))}
          ${this.info?n.dy`
                <div class="row border-bottom">
                  <ha-svg-icon .path=${v}></ha-svg-icon>
                  <mwc-button @click=${this._addSource}>
                    ${this.hass.localize("ui.panel.config.energy.solar.add_solar_production")}
                  </mwc-button>
                </div>
              `:""}
        </div>
      </ha-card>
    `}},{kind:"method",key:"_addSource",value:function(){(0,u.v3)(this,{info:this.info,solar_sources:this.preferences.energy_sources.filter((e=>"solar"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.concat(e)})}})}},{kind:"method",key:"_editSource",value:function(e){const t=e.currentTarget.closest(".row").source;(0,u.v3)(this,{info:this.info,source:{...t},solar_sources:this.preferences.energy_sources.filter((e=>"solar"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>i===t?e:i))})}})}},{kind:"method",key:"_deleteSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))try{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.filter((e=>e!==t))})}catch(e){(0,l.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"method",key:"_savePreferences",value:async function(e){const t=await(0,r._Z)(this.hass,e);(0,s.B)(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,p.L]}}]}}),n.oi);t()}catch(e){t(e)}}))},34234:function(e,t,i){var a=i(44249),n=(i(9359),i(70104),i(57243)),o=i(15093);i(99426);(0,a.Z)([(0,o.Mo)("ha-energy-validation-result")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"issues",value:void 0},{kind:"method",key:"render",value:function(){return 0===this.issues.length?n.Ld:this.issues.map((e=>n.dy`
        <ha-alert alert-type="warning" .title=${this.hass.localize(`component.energy.issues.${e.type}.title`)||e.type}>
          ${this.hass.localize(`component.energy.issues.${e.type}.description`,e.translation_placeholders)}
          ${"recorder_untracked"===e.type?n.dy`(<a href="https://www.home-assistant.io/integrations/recorder#configure-filter" target="_blank" rel="noopener noreferrer">${this.hass.localize("ui.panel.config.common.learn_more")}</a>)`:""}
          <ul>
            ${e.affected_entities.map((([e,t])=>n.dy`<li>${e}${t?n.dy` (${t})`:""}</li>`))}
          </ul>
        </ha-alert>
      `))}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`ul{padding-left:24px;padding-inline-start:24px padding-inline-end: initial;margin:4px 0}a{color:var(--primary-color)}`}]}}),n.oi)},43672:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),n=(i(92745),i(9359),i(56475),i(31526),i(70104),i(31622),i(57243)),o=i(15093),s=i(36522),r=(i(54977),i(23334),i(1118)),c=i(17705),l=i(76131),d=i(28008),h=i(73192),u=i(58605),p=(i(34234),i(39418)),g=e([r]);r=(g.then?(await g)():g)[0];const f="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",y="M12,20A6,6 0 0,1 6,14C6,10 12,3.25 12,3.25C12,3.25 18,10 18,14A6,6 0 0,1 12,20Z",v="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z";(0,a.Z)([(0,o.Mo)("ha-energy-water-settings")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"preferences",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"statsMetadata",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"validationResult",value:void 0},{kind:"method",key:"render",value:function(){const e=[],t=[];return this.preferences.energy_sources.forEach(((i,a)=>{"water"===i.type&&(e.push(i),this.validationResult&&t.push(this.validationResult.energy_sources[a]))})),n.dy`
      <ha-card outlined>
        <h1 class="card-header">
          <ha-svg-icon .path=${y}></ha-svg-icon>
          ${this.hass.localize("ui.panel.config.energy.water.title")}
        </h1>

        <div class="card-content">
          <p>
            ${this.hass.localize("ui.panel.config.energy.water.sub")}
            <a target="_blank" rel="noopener noreferrer" href=${(0,h.R)(this.hass,"/docs/energy/water/")}>${this.hass.localize("ui.panel.config.energy.water.learn_more")}</a>
          </p>
          ${t.map((e=>n.dy`
              <ha-energy-validation-result .hass=${this.hass} .issues=${e}></ha-energy-validation-result>
            `))}
          <h3>
            ${this.hass.localize("ui.panel.config.energy.water.water_consumption")}
          </h3>
          ${e.map((e=>{const t=this.hass.states[e.stat_energy_from];return n.dy`
              <div class="row" .source=${e}>
                ${t?.attributes.icon?n.dy`<ha-icon .icon=${t.attributes.icon}></ha-icon>`:n.dy`<ha-svg-icon .path=${y}></ha-svg-icon>`}
                <span class="content">${(0,c.Kd)(this.hass,e.stat_energy_from,this.statsMetadata?.[e.stat_energy_from])}</span>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.water.edit_water_source")} @click=${this._editSource} .path=${v}></ha-icon-button>
                <ha-icon-button .label=${this.hass.localize("ui.panel.config.energy.water.delete_water_source")} @click=${this._deleteSource} .path=${f}></ha-icon-button>
              </div>
            `}))}
          <div class="row border-bottom">
            <ha-svg-icon .path=${y}></ha-svg-icon>
            <mwc-button @click=${this._addSource}>${this.hass.localize("ui.panel.config.energy.water.add_water_source")}</mwc-button>
          </div>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_addSource",value:function(){(0,u.lS)(this,{water_sources:this.preferences.energy_sources.filter((e=>"water"===e.type)),saveCallback:async e=>{delete e.unit_of_measurement,await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.concat(e)})}})}},{kind:"method",key:"_editSource",value:function(e){const t=e.currentTarget.closest(".row").source;(0,u.lS)(this,{source:{...t},metadata:this.statsMetadata?.[t.stat_energy_from],water_sources:this.preferences.energy_sources.filter((e=>"water"===e.type)),saveCallback:async e=>{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.map((i=>i===t?e:i))})}})}},{kind:"method",key:"_deleteSource",value:async function(e){const t=e.currentTarget.closest(".row").source;if(await(0,l.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.energy.delete_source")}))try{await this._savePreferences({...this.preferences,energy_sources:this.preferences.energy_sources.filter((e=>e!==t))})}catch(e){(0,l.showAlertDialog)(this,{title:`Failed to save config: ${e.message}`})}}},{kind:"method",key:"_savePreferences",value:async function(e){const t=await(0,r._Z)(this.hass,e);(0,s.B)(this,"value-changed",{value:t})}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,p.L]}}]}}),n.oi);t()}catch(e){t(e)}}))},39418:function(e,t,i){i.d(t,{L:()=>a});const a=i(57243).iv`ha-card{height:100%}.card-header ha-svg-icon{height:32px;width:32px;margin-right:8px;margin-inline-end:8px;margin-inline-start:initial;direction:var(--direction)}h3{margin-top:24px;margin-bottom:4px}.row{display:flex;align-items:center;border-top:1px solid var(--divider-color);height:48px;box-sizing:border-box}.row ha-icon,.row ha-svg-icon,.row img{margin-right:16px;margin-inline-end:16px;margin-inline-start:initial;direction:var(--direction)}.row img{height:24px}.row .content{flex-grow:1;overflow:hidden;text-overflow:ellipsis}ha-icon-button{color:var(--secondary-text-color)}`},58605:function(e,t,i){i.d(t,{Q6:()=>o,Qh:()=>n,a0:()=>l,lS:()=>c,u_:()=>d,v3:()=>s,vp:()=>r});var a=i(36522);const n=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-device-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("91552"),i.e("78456"),i.e("24199"),i.e("27506"),i.e("41258"),i.e("56898"),i.e("97983"),i.e("35671"),i.e("7010"),i.e("79988"),i.e("18865"),i.e("27090"),i.e("3049"),i.e("55033")]).then(i.bind(i,29001)),dialogParams:t})},o=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-battery-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("7565"),i.e("18865"),i.e("27090"),i.e("21588")]).then(i.bind(i,97154)),dialogParams:t})},s=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-solar-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("29570"),i.e("7010"),i.e("46337"),i.e("18865"),i.e("27090"),i.e("79085")]).then(i.bind(i,30413)),dialogParams:t})},r=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-gas-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("7010"),i.e("36616"),i.e("18865"),i.e("27090"),i.e("3049"),i.e("92190")]).then(i.bind(i,49546)),dialogParams:t})},c=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-water-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("7010"),i.e("18233"),i.e("18865"),i.e("27090"),i.e("3049"),i.e("10014")]).then(i.bind(i,46765)),dialogParams:t})},l=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-grid-flow-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("7010"),i.e("80806"),i.e("18865"),i.e("27090"),i.e("3049"),i.e("96754")]).then(i.bind(i,61116)),dialogParams:{...t,direction:"from"}})},d=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-energy-grid-flow-settings",dialogImport:()=>Promise.all([i.e("46379"),i.e("66031"),i.e("24199"),i.e("27506"),i.e("97983"),i.e("7010"),i.e("80806"),i.e("18865"),i.e("27090"),i.e("3049"),i.e("96754")]).then(i.bind(i,61116)),dialogParams:{...t,direction:"to"}})}},88238:function(e,t,i){i.d(t,{RU:()=>n,X1:()=>a,u4:()=>o,zC:()=>s});const a=e=>`https://brands.home-assistant.io/${e.brand?"brands/":""}${e.useFallback?"_/":""}${e.domain}/${e.darkOptimized?"dark_":""}${e.type}.png`,n=e=>`https://brands.home-assistant.io/hardware/${e.category}/${e.darkOptimized?"dark_":""}${e.manufacturer}${e.model?`_${e.model}`:""}.png`,o=e=>e.split("/")[4],s=e=>e.startsWith("https://brands.home-assistant.io/")},73192:function(e,t,i){i.d(t,{R:()=>a});const a=(e,t)=>`https://${e.config.version.includes("b")?"rc":e.config.version.includes("dev")?"next":"www"}.home-assistant.io${t}`}};
//# sourceMappingURL=41608.4a2a3fbdfe9ab11b.js.map