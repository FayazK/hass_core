export const __webpack_ids__=["30543"];export const __webpack_modules__={28506:function(e,o,t){t.r(o);var n=t(44249),a=t(57243),i=t(15093),r=(t(59826),t(54202),t(36522)),c=t(83523),l=t(58776),s=t(17409);(0,n.Z)([(0,i.Mo)("onboarding-restore-backup-no-cloud-backup")],(function(e,o){return{F:class extends o{constructor(...o){super(...o),e(this)}},d:[{kind:"field",decorators:[(0,i.Cb)({attribute:!1})],key:"localize",value:void 0},{kind:"method",key:"render",value:function(){return a.dy`
      <ha-icon-button-arrow-prev .label=${this.localize("ui.panel.page-onboarding.restore.back")} @click=${this._back}></ha-icon-button-arrow-prev>
      <h1>
        ${this.localize("ui.panel.page-onboarding.restore.ha-cloud.no_cloud_backup")}
      </h1>
      <div class="description">
        ${this.localize("ui.panel.page-onboarding.restore.ha-cloud.no_cloud_backup_description")}
      </div>
      <div class="actions">
        <ha-button @click=${this._signOut}>
          ${this.localize("ui.panel.page-onboarding.restore.ha-cloud.sign_out")}
        </ha-button>
        <a href="https://www.nabucasa.com/config/backups/" target="_blank" rel="noreferrer noopener">
          <ha-button>
            ${this.localize("ui.panel.page-onboarding.restore.ha-cloud.learn_more")}
          </ha-button>
        </a>
      </div>
    `}},{kind:"method",key:"_back",value:function(){(0,c.c)(`${location.pathname}?${(0,l.pc)("page")}`)}},{kind:"method",key:"_signOut",value:function(){(0,r.B)(this,"sign-out")}},{kind:"get",static:!0,key:"styles",value:function(){return[s.I,a.iv`h1,p{text-align:left}.description{font-size:1rem;line-height:1.5rem;margin-top:24px;margin-bottom:32px}.actions{display:flex;justify-content:space-between}`]}}]}}),a.oi)}};
//# sourceMappingURL=30543.984685a882b7affa.js.map