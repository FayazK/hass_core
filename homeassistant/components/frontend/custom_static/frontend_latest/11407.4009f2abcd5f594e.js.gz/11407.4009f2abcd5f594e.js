export const __webpack_ids__=["11407"];export const __webpack_modules__={87865:function(t,e,a){a.d(e,{v:()=>o});const o=async(t,e)=>{if(navigator.clipboard)try{return void await navigator.clipboard.writeText(t)}catch{}const a=e??document.body,o=document.createElement("textarea");o.value=t,a.appendChild(o),o.select(),document.execCommand("copy"),a.removeChild(o)}},59826:function(t,e,a){var o=a(44249),i=a(31622),s=a(57243),n=a(15093),r=a(22344);(0,o.Z)([(0,n.Mo)("ha-button")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",static:!0,key:"styles",value:()=>[r.W,s.iv`::slotted([slot=icon]){margin-inline-start:0px;margin-inline-end:8px;direction:var(--direction);display:block}.mdc-button{height:var(--button-height,36px)}.trailing-icon{display:flex}.slot-container{overflow:var(--button-slot-container-overflow,visible)}:host([destructive]){--mdc-theme-primary:var(--error-color)}`]}]}}),i.Button)},30274:function(t,e,a){a.r(e);var o=a(44249),i=(a(9359),a(70104),a(57243)),s=a(15093),n=a(36522),r=a(73729),d=(a(59826),a(72473)),l=a(87865);(0,o.Z)([(0,s.Mo)("dialog-bluetooth-device-info")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"method",key:"showDialog",value:async function(t){this._params=t}},{kind:"method",key:"closeDialog",value:function(){return this._params=void 0,(0,n.B)(this,"dialog-closed",{dialog:this.localName}),!0}},{kind:"method",key:"showDataAsHex",value:function(t){return Array.from((new TextEncoder).encode(t)).map((t=>t.toString(16).toUpperCase().padStart(2,"0"))).join(" ")}},{kind:"method",key:"_copyToClipboard",value:async function(){this._params&&(await(0,l.v)(JSON.stringify(this._params.entry)),(0,d.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")}))}},{kind:"method",key:"render",value:function(){return this._params?i.dy`
      <ha-dialog open @closed=${this.closeDialog} .heading=${(0,r.i)(this.hass,this.hass.localize("ui.panel.config.bluetooth.device_information"))}>
        <p>
          <b>${this.hass.localize("ui.panel.config.bluetooth.address")}</b>:
          ${this._params.entry.address}
          <br/>
          <b>${this.hass.localize("ui.panel.config.bluetooth.name")}</b>:
          ${this._params.entry.name}
          <br/>
          <b>${this.hass.localize("ui.panel.config.bluetooth.source")}</b>:
          ${this._params.entry.source}
        </p>

        <h3>
          ${this.hass.localize("ui.panel.config.bluetooth.advertisement_data")}
        </h3>
        <h4>
          ${this.hass.localize("ui.panel.config.bluetooth.manufacturer_data")}
        </h4>
        <table width="100%">
          <tbody>
            ${Object.entries(this._params.entry.manufacturer_data).map((([t,e])=>i.dy`
                <tr>
                  <td><b>${t}</b></td>
                  <td>${this.showDataAsHex(e)}</td>
                </tr>
              `))}
          </tbody>
        </table>

        <h4>${this.hass.localize("ui.panel.config.bluetooth.service_data")}</h4>
        <table width="100%">
          <tbody>
            ${Object.entries(this._params.entry.service_data).map((([t,e])=>i.dy`
                <tr>
                  <td><b>${t}</b></td>
                  <td>${this.showDataAsHex(e)}</td>
                </tr>
              `))}
          </tbody>
        </table>

        <h4>
          ${this.hass.localize("ui.panel.config.bluetooth.service_uuids")}
        </h4>
        <table width="100%">
          <tbody>
            ${this._params.entry.service_uuids.map((t=>i.dy`
                <tr>
                  <td>${t}</td>
                </tr>
              `))}
          </tbody>
        </table>

        <ha-button slot="secondaryAction" @click=${this._copyToClipboard}>${this.hass.localize("ui.panel.config.bluetooth.copy_to_clipboard")}</ha-button>
      </ha-dialog>
    `:i.Ld}}]}}),i.oi)}};
//# sourceMappingURL=11407.4009f2abcd5f594e.js.map