export const __webpack_ids__=["59086"];export const __webpack_modules__={95612:function(e,t,a){a.a(e,(async function(e,i){try{a.r(t),a.d(t,{CloudForgotPasswordCard:()=>y});var s=a(44249),r=a(57243),o=a(15093),n=a(36522),l=a(29095),d=(a(99426),a(54977),a(83166),a(28008)),c=a(94616),h=a(37013),u=e([l]);l=(u.then?(await u)():u)[0];let y=(0,s.Z)([(0,o.Mo)("cloud-forgot-password-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"localize",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:"translation-key-panel"})],key:"translationKeyPanel",value:()=>"config.cloud.forgot_password"},{kind:"field",decorators:[(0,o.Cb)()],key:"email",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"card-less"})],key:"cardLess",value:()=>!1},{kind:"field",decorators:[(0,o.SB)()],key:"_inProgress",value:()=>!1},{kind:"field",decorators:[(0,o.SB)()],key:"_error",value:void 0},{kind:"field",decorators:[(0,o.IO)("#email",!0)],key:"emailField",value:void 0},{kind:"method",key:"render",value:function(){return this.cardLess?this._renderContent():r.dy`
      <ha-card outlined .header=${this.localize(`ui.panel.${this.translationKeyPanel}.subtitle`)}>
        ${this._renderContent()}
      </ha-card>
    `}},{kind:"method",key:"_renderContent",value:function(){return r.dy`
      <div class="card-content">
        <p>
          ${this.localize(`ui.panel.${this.translationKeyPanel}.instructions`)}
        </p>
        ${this._error?r.dy`<ha-alert alert-type="error">${this._error}</ha-alert>`:r.Ld}
        <ha-textfield autofocus id="email" label=${this.localize(`ui.panel.${this.translationKeyPanel}.email`)} .value=${this.email??""} type="email" required .disabled=${this._inProgress} @keydown=${this._keyDown} .validationMessage=${this.localize(`ui.panel.${this.translationKeyPanel}.email_error_msg`)}></ha-textfield>
      </div>
      <div class="card-actions">
        <ha-progress-button @click=${this._handleEmailPasswordReset} .progress=${this._inProgress}>
          ${this.localize(`ui.panel.${this.translationKeyPanel}.send_reset_email`)}
        </ha-progress-button>
      </div>
    `}},{kind:"method",key:"_keyDown",value:function(e){"Enter"===e.key&&this._handleEmailPasswordReset()}},{kind:"field",key:"_resetPassword",value(){return async e=>{this._inProgress=!0;try{this.hass?await(0,c.u_)(this.hass,e):await(0,h.cG)(e),(0,n.B)(this,"cloud-email-changed",{value:e}),this._inProgress=!1,(0,n.B)(this,"cloud-done",{flashMessage:this.localize(`ui.panel.${this.translationKeyPanel}.check_your_email`)})}catch(t){this._inProgress=!1;"usernotfound"===(t&&t.body&&t.body.code)&&e!==e.toLowerCase()?await this._resetPassword(e.toLowerCase()):this._error=t&&t.body&&t.body.message?t.body.message:"Unknown error"}}}},{kind:"method",key:"_handleEmailPasswordReset",value:async function(){const e=this.emailField,t=e.value;e.reportValidity()?(this._inProgress=!0,this._resetPassword(t)):e.focus()}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,r.iv`ha-card{max-width:600px;margin:24px auto 0}h1{margin:0}ha-textfield{width:100%}.card-actions{display:flex;justify-content:flex-end;align-items:center}`]}}]}}),r.oi);i()}catch(e){i(e)}}))}};
//# sourceMappingURL=59086.57e8b09c0a5147d4.js.map