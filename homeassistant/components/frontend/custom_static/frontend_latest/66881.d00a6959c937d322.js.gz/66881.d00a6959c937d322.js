export const __webpack_ids__=["66881"];export const __webpack_modules__={44732:function(t,e,i){var s=i(44249),n=i(57243),a=i(15093),r=i(35359);(0,s.Z)([(0,a.Mo)("ha-more-info-control-select-container")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"method",key:"render",value:function(){const t=`items-${this.childElementCount}`;return n.dy`
      <div class="controls">
        <div class="controls-scroll ${(0,r.$)({[t]:!0,multiline:this.childElementCount>=4})}">
          <slot></slot>
        </div>
      </div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.controls{display:flex;flex-direction:row;justify-content:center}.controls-scroll{display:flex;flex-direction:row;justify-content:flex-start;gap:12px;margin:-2px -24px;overflow:auto;-ms-overflow-style:none;scrollbar-width:none;padding:2px 24px}.controls-scroll::-webkit-scrollbar{display:none}::slotted(*){min-width:120px;max-width:160px;flex:none}@media all and (hover:hover),all and (min-width:600px) and (min-height:501px){.controls-scroll{justify-content:center;flex-wrap:wrap;width:100%;max-width:450px}.controls-scroll.items-4{max-width:300px}.controls-scroll.items-3 ::slotted(*){max-width:140px}.multiline ::slotted(*){width:140px}}`}]}}),n.oi)},12173:function(t,e,i){i.d(e,{b:()=>s});const s=i(57243).iv`:host{display:flex;flex-direction:column;flex:1;justify-content:space-between}.controls{display:flex;flex-direction:column;align-items:center}.controls:not(:last-child),.controls>:not(:last-child){margin-bottom:24px}.buttons{display:flex;align-items:center;justify-content:center;margin-bottom:12px}.buttons>*{margin:8px}ha-attributes{display:block;width:100%}ha-more-info-control-select-container+ha-attributes:not([empty]){margin-top:16px}`},9198:function(t,e,i){i.a(t,(async function(t,s){try{i.r(e);var n=i(44249),a=i(72621),r=(i(9359),i(70104),i(57243)),o=i(15093),l=i(49976),d=i(75278),u=(i(34058),i(7285),i(13642)),h=i(96194),c=i(97419),m=i(12243),y=(i(44732),i(12173)),b=t([u,m]);[u,m]=b.then?(await b)():b;const v="M16.56,5.44L15.11,6.89C16.84,7.94 18,9.83 18,12A6,6 0 0,1 12,18A6,6 0 0,1 6,12C6,9.83 7.16,7.94 8.88,6.88L7.44,5.44C5.36,6.88 4,9.28 4,12A8,8 0 0,0 12,20A8,8 0 0,0 20,12C20,9.28 18.64,6.88 16.56,5.44M13,3H11V13H13",f="M8 13C6.14 13 4.59 14.28 4.14 16H2V18H4.14C4.59 19.72 6.14 21 8 21S11.41 19.72 11.86 18H22V16H11.86C11.41 14.28 9.86 13 8 13M8 19C6.9 19 6 18.1 6 17C6 15.9 6.9 15 8 15S10 15.9 10 17C10 18.1 9.1 19 8 19M19.86 6C19.41 4.28 17.86 3 16 3S12.59 4.28 12.14 6H2V8H12.14C12.59 9.72 14.14 11 16 11S19.41 9.72 19.86 8H22V6H19.86M16 9C14.9 9 14 8.1 14 7C14 5.9 14.9 5 16 5S18 5.9 18 7C18 8.1 17.1 9 16 9Z";let p=(0,n.Z)(null,(function(t,e){class i extends e{constructor(...e){super(...e),t(this)}}return{F:i,d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_mode",value:void 0},{kind:"method",key:"willUpdate",value:function(t){(0,a.Z)(i,"willUpdate",this,3)([t]),t.has("stateObj")&&(this._mode=this.stateObj?.attributes.mode)}},{kind:"method",key:"render",value:function(){if(!this.stateObj)return r.Ld;const t=this.hass,e=this.stateObj,i=(0,d.e)(e,c.lN.MODES);return r.dy`
      <div class="current">
        ${null!=this.stateObj.attributes.current_humidity?r.dy`
              <div>
                <p class="label">
                  ${this.hass.formatEntityAttributeName(this.stateObj,"current_humidity")}
                </p>
                <p class="value">
                  ${this.hass.formatEntityAttributeValue(this.stateObj,"current_humidity")}
                </p>
              </div>
            `:r.Ld}
      </div>

      <div class="controls">
        <ha-state-control-humidifier-humidity .hass=${this.hass} .stateObj=${this.stateObj}></ha-state-control-humidifier-humidity>
      </div>

      <ha-more-info-control-select-container>
        <ha-control-select-menu .label=${this.hass.localize("ui.card.humidifier.state")} .value=${this.stateObj.state} .disabled=${this.stateObj.state===h.nZ} fixedMenuPosition naturalMenuWidth @selected=${this._handleStateChanged} @closed=${l.U}>
          <ha-svg-icon slot="icon" .path=${v}></ha-svg-icon>
          <ha-list-item value="off">
            ${this.hass.formatEntityState(this.stateObj,"off")}
          </ha-list-item>
          <ha-list-item value="on">
            ${this.hass.formatEntityState(this.stateObj,"on")}
          </ha-list-item>
        </ha-control-select-menu>

        ${i?r.dy`
              <ha-control-select-menu .label=${t.localize("ui.card.humidifier.mode")} .value=${e.attributes.mode} .disabled=${this.stateObj.state===h.nZ} fixedMenuPosition naturalMenuWidth @selected=${this._handleModeChanged} @closed=${l.U}>
                ${e.attributes.mode?r.dy`
                      <ha-attribute-icon slot="icon" .hass=${this.hass} .stateObj=${e} attribute="mode" .attributeValue=${e.attributes.mode}></ha-attribute-icon>
                    `:r.dy`
                      <ha-svg-icon slot="icon" .path=${f}></ha-svg-icon>
                    `}
                ${e.attributes.available_modes.map((t=>r.dy`
                    <ha-list-item .value=${t} graphic="icon">
                      <ha-attribute-icon slot="graphic" .hass=${this.hass} .stateObj=${e} attribute="mode" .attributeValue=${t}></ha-attribute-icon>
                      ${this.hass.formatEntityAttributeValue(e,"mode",t)}
                    </ha-list-item>
                  `))}
              </ha-control-select-menu>
            `:r.Ld}
      </ha-more-info-control-select-container>
    `}},{kind:"method",key:"_handleStateChanged",value:function(t){const e=t.target.value||null;this._callServiceHelper(this.stateObj.state,e,"on"===e?"turn_on":"turn_off",{})}},{kind:"method",key:"_handleModeChanged",value:function(t){const e=t.target.value||null;this._mode=e,this._callServiceHelper(this.stateObj.attributes.mode,e,"set_mode",{mode:e})}},{kind:"method",key:"_callServiceHelper",value:async function(t,e,i,s){if(t===e)return;s.entity_id=this.stateObj.entity_id;const n=this.stateObj;await this.hass.callService("humidifier",i,s),await new Promise((t=>{setTimeout(t,2e3)})),this.stateObj===n&&(this.stateObj=void 0,await this.updateComplete,void 0===this.stateObj&&(this.stateObj=n))}},{kind:"get",static:!0,key:"styles",value:function(){return[y.b,r.iv`.current,.current div{display:flex;text-align:center}.current,.current div,.current p{text-align:center}:host{color:var(--primary-text-color)}.current{flex-direction:row;align-items:center;justify-content:center;margin-bottom:40px}.current div{flex-direction:column;align-items:center;justify-content:center;flex:1}.current p{margin:0;color:var(--primary-text-color)}.current .label{opacity:.8;font-size:14px;line-height:16px;letter-spacing:.4px;margin-bottom:4px}.current .value{font-size:22px;font-weight:500;line-height:28px;direction:ltr}`]}}]}}),r.oi);customElements.define("more-info-humidifier",p),s()}catch(t){s(t)}}))},12243:function(t,e,i){i.a(t,(async function(t,e){try{var s=i(44249),n=i(72621),a=i(57243),r=i(15093),o=i(69634),l=i(5839),d=i(42818),u=i(34593),h=i(22381),c=i(1703),m=(i(5906),i(75138),i(37583),i(96194)),y=i(59519),b=i(97419),v=i(3015),f=t([c,y]);[c,y]=f.then?(await f)():f;const p="M19,13H5V11H19V13Z",_="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",$="M16.95,16.95L14.83,14.83C15.55,14.1 16,13.1 16,12C16,11.26 15.79,10.57 15.43,10L17.6,7.81C18.5,9 19,10.43 19,12C19,13.93 18.22,15.68 16.95,16.95M12,5C13.57,5 15,5.5 16.19,6.4L14,8.56C13.43,8.21 12.74,8 12,8A4,4 0 0,0 8,12C8,13.1 8.45,14.1 9.17,14.83L7.05,16.95C5.78,15.68 5,13.93 5,12A7,7 0 0,1 12,5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z",g="M12,3.25C12,3.25 6,10 6,14C6,17.32 8.69,20 12,20A6,6 0 0,0 18,14C18,10 12,3.25 12,3.25M14.47,9.97L15.53,11.03L9.53,17.03L8.47,15.97M9.75,10A1.25,1.25 0 0,1 11,11.25A1.25,1.25 0 0,1 9.75,12.5A1.25,1.25 0 0,1 8.5,11.25A1.25,1.25 0 0,1 9.75,10M14.25,14.5A1.25,1.25 0 0,1 15.5,15.75A1.25,1.25 0 0,1 14.25,17A1.25,1.25 0 0,1 13,15.75A1.25,1.25 0 0,1 14.25,14.5Z";(0,s.Z)([(0,r.Mo)("ha-state-control-humidifier-humidity")],(function(t,e){class i extends e{constructor(...e){super(...e),t(this)}}return{F:i,d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"show-secondary",type:Boolean})],key:"showSecondary",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)({attribute:"use-current-as-primary",type:Boolean})],key:"showCurrentAsPrimary",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)({type:Boolean,attribute:"prevent-interaction-on-scroll"})],key:"preventInteractionOnScroll",value:()=>!1},{kind:"field",decorators:[(0,r.SB)()],key:"_targetHumidity",value:void 0},{kind:"field",key:"_sizeController",value(){return(0,v.$)(this)}},{kind:"method",key:"willUpdate",value:function(t){(0,n.Z)(i,"willUpdate",this,3)([t]),t.has("stateObj")&&(this._targetHumidity=this.stateObj.attributes.humidity)}},{kind:"field",key:"_step",value:()=>1},{kind:"get",key:"_min",value:function(){return this.stateObj.attributes.min_humidity??0}},{kind:"get",key:"_max",value:function(){return this.stateObj.attributes.max_humidity??100}},{kind:"method",key:"_valueChanged",value:function(t){const e=t.detail.value;isNaN(e)||(this._targetHumidity=e,this._callService())}},{kind:"method",key:"_valueChanging",value:function(t){const e=t.detail.value;isNaN(e)||(this._targetHumidity=e)}},{kind:"field",key:"_debouncedCallService",value(){return(0,h.D)((()=>this._callService()),1e3)}},{kind:"method",key:"_callService",value:function(){this.hass.callService("humidifier","set_humidity",{entity_id:this.stateObj.entity_id,humidity:this._targetHumidity})}},{kind:"method",key:"_handleButton",value:function(t){const e=t.currentTarget.step;let i=this._targetHumidity??this._min;i+=e,i=(0,u.u)(i,this._min,this._max),this._targetHumidity=i,this._debouncedCallService()}},{kind:"method",key:"_renderLabel",value:function(){if(this.stateObj.state===m.nZ)return a.dy`
        <p class="label disabled">
          ${this.hass.formatEntityState(this.stateObj,m.nZ)}
        </p>
      `;const t=this.stateObj.attributes.action,e=null!=this.stateObj.attributes.current_humidity&&this.showCurrentAsPrimary||null!=this._targetHumidity&&!this.showCurrentAsPrimary;return a.dy`
      <p class="label">
        ${t&&"off"!==t?this.hass.formatEntityAttributeValue(this.stateObj,"action"):e?this.hass.formatEntityState(this.stateObj):a.Ld}
      </p>
    `}},{kind:"method",key:"_renderButtons",value:function(){return a.dy`
      <div class="buttons">
        <ha-outlined-icon-button .step=${-this._step} @click=${this._handleButton}>
          <ha-svg-icon .path=${p}></ha-svg-icon>
        </ha-outlined-icon-button>
        <ha-outlined-icon-button .step=${this._step} @click=${this._handleButton}>
          <ha-svg-icon .path=${_}></ha-svg-icon>
        </ha-outlined-icon-button>
      </div>
    `}},{kind:"method",key:"_renderPrimary",value:function(){const t=this.stateObj.attributes.current_humidity;return null!=t&&this.showCurrentAsPrimary?this._renderCurrent(t,"big"):null==this._targetHumidity||this.showCurrentAsPrimary?this.stateObj.state!==m.nZ?a.dy`
        <p class="primary-state">
          ${this.hass.formatEntityState(this.stateObj)}
        </p>
      `:a.Ld:this._renderTarget(this._targetHumidity,"big")}},{kind:"method",key:"_renderSecondary",value:function(){if(!this.showSecondary)return a.dy`<p class="label"></p>`;const t=this.stateObj.attributes.current_humidity;return null==t||this.showCurrentAsPrimary?null!=this._targetHumidity&&this.showCurrentAsPrimary?a.dy`
        <p class="label">
          <ha-svg-icon .path=${$}></ha-svg-icon>
          ${this._renderCurrent(this._targetHumidity,"normal")}
        </p>
      `:a.dy`<p class="label"></p>`:a.dy`
        <p class="label">
          <ha-svg-icon .path=${g}></ha-svg-icon>
          ${this._renderCurrent(t,"normal")}
        </p>
      `}},{kind:"method",key:"_renderTarget",value:function(t,e){const i={maximumFractionDigits:0};return"big"===e?a.dy`
        <ha-big-number .value=${t} .unit=${y.F_.humidifier.current_humidity} .hass=${this.hass} .formatOptions=${i} unit-position="bottom"></ha-big-number>
      `:a.dy`
      ${this.hass.formatEntityAttributeValue(this.stateObj,"humidity",t)}
    `}},{kind:"method",key:"_renderCurrent",value:function(t,e){const i={maximumFractionDigits:1};return"big"===e?a.dy`
        <ha-big-number .value=${t} .unit=${y.F_.humidifier.current_humidity} .hass=${this.hass} .formatOptions=${i} unit-position="bottom"></ha-big-number>
      `:a.dy`
      ${this.hass.formatEntityAttributeValue(this.stateObj,"current_humidity",t)}
    `}},{kind:"method",key:"_renderInfo",value:function(){return a.dy`
      <div class="info">
        ${this._renderLabel()}${this._renderPrimary()}${this._renderSecondary()}
      </div>
    `}},{kind:"method",key:"render",value:function(){const t=(0,d.Hh)(this.stateObj),e=(0,l.v)(this.stateObj),i=this.stateObj.attributes.action;let s;i&&"idle"!==i&&"off"!==i&&e&&(s=(0,d.Hh)(this.stateObj,b.Sp[i]));const n=this._targetHumidity,r=this.stateObj.attributes.current_humidity,u=this._sizeController.value?` ${this._sizeController.value}`:"";if(null!=n&&this.stateObj.state!==m.nZ){const i=this.stateObj.attributes.device_class===b.Qr.DEHUMIDIFIER;return a.dy`
        <div class="container${u}" style=${(0,o.V)({"--state-color":t,"--action-color":s})}>
          <ha-control-circular-slider .preventInteractionOnScroll=${this.preventInteractionOnScroll} .inactive=${!e} .mode=${i?"end":"start"} .value=${n} .min=${this._min} .max=${this._max} .step=${this._step} .current=${r} @value-changed=${this._valueChanged} @value-changing=${this._valueChanging}>
          </ha-control-circular-slider>
          ${this._renderInfo()} ${this._renderButtons()}
        </div>
      `}return a.dy`
      <div class="container${u}" style=${(0,o.V)({"--state-color":t,"--action-color":s})}>
        <ha-control-circular-slider .preventInteractionOnScroll=${this.preventInteractionOnScroll} .current=${r} .min=${this._min} .max=${this._max} .step=${this._step} disabled=disabled>
        </ha-control-circular-slider>
        ${this._renderInfo()}
      </div>
    `}},{kind:"get",static:!0,key:"styles",value:function(){return v.r}}]}}),a.oi);e()}catch(t){e(t)}}))}};
//# sourceMappingURL=66881.d00a6959c937d322.js.map