export const __webpack_ids__=["25643"];export const __webpack_modules__={73729:function(o,i,e){e.d(i,{i:()=>h});var t=e(44249),a=e(72621),n=e(74966),l=e(51408),d=e(57243),s=e(15093),c=e(76525);e(23334);const r=["button","ha-list-item"],h=(o,i)=>d.dy`
  <div class="header_title">
    <ha-icon-button .label=${o?.localize("ui.common.close")??"Close"} .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"} dialogAction="close" class="header_button"></ha-icon-button>
    <span>${i}</span>
  </div>
`;(0,t.Z)([(0,s.Mo)("ha-dialog")],(function(o,i){class e extends i{constructor(...i){super(...i),o(this)}}return{F:e,d:[{kind:"field",key:c.gA,value:void 0},{kind:"method",key:"scrollToPos",value:function(o,i){this.contentElement?.scrollTo(o,i)}},{kind:"method",key:"renderHeading",value:function(){return d.dy`<slot name="heading"> ${(0,a.Z)(e,"renderHeading",this,3)([])} </slot>`}},{kind:"method",key:"firstUpdated",value:function(){(0,a.Z)(e,"firstUpdated",this,3)([]),this.suppressDefaultPressSelector=[this.suppressDefaultPressSelector,r].join(", "),this._updateScrolledAttribute(),this.contentElement?.addEventListener("scroll",this._onScroll,{passive:!0})}},{kind:"method",key:"disconnectedCallback",value:function(){(0,a.Z)(e,"disconnectedCallback",this,3)([]),this.contentElement.removeEventListener("scroll",this._onScroll)}},{kind:"field",key:"_onScroll",value(){return()=>{this._updateScrolledAttribute()}}},{kind:"method",key:"_updateScrolledAttribute",value:function(){this.contentElement&&this.toggleAttribute("scrolled",0!==this.contentElement.scrollTop)}},{kind:"field",static:!0,key:"styles",value:()=>[l.W,d.iv`.dialog-actions,.header_button,.header_title{direction:var(--direction)}:host([scrolled]) ::slotted(ha-dialog-header){border-bottom:1px solid var(--mdc-dialog-scroll-divider-color,rgba(0,0,0,.12))}.mdc-dialog{--mdc-dialog-scroll-divider-color:var(
          --dialog-scroll-divider-color,
          var(--divider-color)
        );z-index:var(--dialog-z-index,8);-webkit-backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));backdrop-filter:var(--ha-dialog-scrim-backdrop-filter,var(--dialog-backdrop-filter,none));--mdc-dialog-box-shadow:var(--dialog-box-shadow, none);--mdc-typography-headline6-font-weight:400;--mdc-typography-headline6-font-size:1.574rem}.mdc-dialog__actions{justify-content:var(--justify-action-buttons,flex-end)}.mdc-dialog__actions span:first-child{flex:var(--secondary-action-button-flex,unset)}.mdc-dialog__actions span:nth-child(2){flex:var(--primary-action-button-flex,unset)}.mdc-dialog__container{align-items:var(--vertical-align-dialog,center)}.mdc-dialog__title{padding:24px 24px 0}.mdc-dialog__title:has(span){padding:12px 12px 0}.mdc-dialog__actions{padding:12px 24px}.mdc-dialog__title::before{content:unset}.mdc-dialog .mdc-dialog__content{position:var(--dialog-content-position,relative);padding:var(--dialog-content-padding,24px)}:host([hideactions]) .mdc-dialog .mdc-dialog__content{padding-bottom:max(var(--dialog-content-padding,24px),env(safe-area-inset-bottom))}.mdc-dialog .mdc-dialog__surface{position:var(--dialog-surface-position,relative);top:var(--dialog-surface-top);margin-top:var(--dialog-surface-margin-top);min-height:var(--mdc-dialog-min-height,auto);border-radius:var(--ha-dialog-border-radius,28px);-webkit-backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);backdrop-filter:var(--ha-dialog-surface-backdrop-filter,none);background:var(--ha-dialog-surface-background,var(--mdc-theme-surface,#fff))}:host([flexContent]) .mdc-dialog .mdc-dialog__content{display:flex;flex-direction:column}.header_title{display:flex;align-items:center}.header_title span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;padding-left:4px}.header_button{text-decoration:none;color:inherit;inset-inline-start:initial;inset-inline-end:-12px}.dialog-actions{inset-inline-start:initial!important;inset-inline-end:0px!important}`]}]}}),n.M)},92213:function(o,i,e){e.r(i),e.d(i,{DialogManageCloudhook:()=>h});var t=e(44249),a=(e(31622),e(57243)),n=e(15093),l=e(36522),d=e(73729),s=e(76131),c=e(28008),r=e(73192);e(75930);let h=(0,t.Z)(null,(function(o,i){return{F:class extends i{constructor(...i){super(...i),o(this)}},d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_params",value:void 0},{kind:"method",key:"showDialog",value:function(o){this._params=o}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,(0,l.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){if(!this._params)return a.Ld;const{webhook:o,cloudhook:i}=this._params,e="automation"===o.domain?(0,r.R)(this.hass,"/docs/automation/trigger/#webhook-trigger"):(0,r.R)(this.hass,`/integrations/${o.domain}/`);return a.dy`
      <ha-dialog open hideActions @closed=${this.closeDialog} .heading=${(0,d.i)(this.hass,this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.webhook_for",{name:o.name}))}>
        <div>
          <p>
            ${i.managed?a.dy`
                  ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.info_disable_webhook")}
                  <button class="link" @click=${this._disableWebhook}>
                    ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.link_disable_webhook")}</button>.
                `:a.dy`
                  ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.managed_by_integration")}
                `}
            <br/>
            <a href=${e} target="_blank" rel="noreferrer">
              ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.view_documentation")}
              <ha-svg-icon .path=${"M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z"}></ha-svg-icon>
            </a>
          </p>

          <ha-copy-textfield .hass=${this.hass} .value=${i.cloudhook_url} .label=${this.hass.localize("ui.panel.config.common.copy_link")}></ha-copy-textfield>
        </div>

        <a href=${e} target="_blank" rel="noreferrer" slot="secondaryAction">
          <mwc-button>
            ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.view_documentation")}
          </mwc-button>
        </a>
        <mwc-button @click=${this.closeDialog} slot="primaryAction">
          ${this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.close")}
        </mwc-button>
      </ha-dialog>
    `}},{kind:"method",key:"_disableWebhook",value:async function(){await(0,s.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.confirm_disable_title"),text:this.hass.localize("ui.panel.config.cloud.dialog_cloudhook.confirm_disable_text",{name:this._params.webhook.name}),dismissText:this.hass.localize("ui.common.cancel"),confirmText:this.hass.localize("ui.common.disable"),destructive:!0})&&(this._params.disableHook(),this.closeDialog())}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,c.yu,a.iv`a,button.link{text-decoration:none}ha-dialog{width:650px}button.link{color:var(--primary-color)}a ha-svg-icon{--mdc-icon-size:16px}p{margin-top:0;margin-bottom:16px}`]}}]}}),a.oi);customElements.define("dialog-manage-cloudhook",h)},73192:function(o,i,e){e.d(i,{R:()=>t});const t=(o,i)=>`https://${o.config.version.includes("b")?"rc":o.config.version.includes("dev")?"next":"www"}.home-assistant.io${i}`}};
//# sourceMappingURL=25643.d66a4fd34fcfb966.js.map