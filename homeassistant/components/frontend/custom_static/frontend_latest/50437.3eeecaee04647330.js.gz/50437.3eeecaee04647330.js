export const __webpack_ids__=["50437"];export const __webpack_modules__={5828:function(e,t,i){i.r(t),i.d(t,{HaIconButtonPrev:()=>l});var n=i(44249),a=i(57243),o=i(15093),s=i(5111);i(23334);let l=(0,n.Z)([(0,o.Mo)("ha-icon-button-prev")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)()],key:"label",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_icon",value:()=>"rtl"===s.E.document.dir?"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z":"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"},{kind:"method",key:"render",value:function(){return a.dy`
      <ha-icon-button .disabled=${this.disabled} .label=${this.label||this.hass?.localize("ui.common.back")||"Back"} .path=${this._icon}></ha-icon-button>
    `}}]}}),a.oi)},51784:function(e,t,i){i.d(t,{dJ:()=>p,zB:()=>u});var n=i(44249),a=i(72621),o=i(67840),s=i(88854),l=i(57243),d=i(15093);let c;o.A.addInitializer((async e=>{await e.updateComplete;const t=e;t.dialog.prepend(t.scrim),t.scrim.style.inset=0,t.scrim.style.zIndex=0;const{getOpenAnimation:i,getCloseAnimation:n}=t;t.getOpenAnimation=()=>{const e=i.call(void 0);return e.container=[...e.container??[],...e.dialog??[]],e.dialog=[],e},t.getCloseAnimation=()=>{const e=n.call(void 0);return e.container=[...e.container??[],...e.dialog??[]],e.dialog=[],e}}));(0,n.Z)([(0,d.Mo)("ha-md-dialog")],(function(e,t){class n extends t{constructor(){super(),e(this),this.addEventListener("cancel",this._handleCancel),"function"!=typeof HTMLDialogElement&&(this.addEventListener("open",this._handleOpen),c||(c=i.e("73854").then(i.bind(i,85893)))),void 0===this.animate&&(this.quick=!0),void 0===this.animate&&(this.quick=!0)}}return{F:n,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:"disable-cancel-action",type:Boolean})],key:"disableCancelAction",value:()=>!1},{kind:"field",key:"_polyfillDialogRegistered",value:()=>!1},{kind:"method",key:"_handleOpen",value:async function(e){if(e.preventDefault(),this._polyfillDialogRegistered)return;this._polyfillDialogRegistered=!0,this._loadPolyfillStylesheet("/static/polyfills/dialog-polyfill.css");const t=this.shadowRoot?.querySelector("dialog");(await c).default.registerDialog(t),this.removeEventListener("open",this._handleOpen),this.show()}},{kind:"method",key:"_loadPolyfillStylesheet",value:async function(e){const t=document.createElement("link");return t.rel="stylesheet",t.href=e,new Promise(((i,n)=>{t.onload=()=>i(),t.onerror=()=>n(new Error(`Stylesheet failed to load: ${e}`)),this.shadowRoot?.appendChild(t)}))}},{kind:"method",key:"_handleCancel",value:function(e){if(this.disableCancelAction){e.preventDefault();const t=this.shadowRoot?.querySelector("dialog .container");void 0!==this.animate&&t?.animate([{transform:"rotate(-1deg)","animation-timing-function":"ease-in"},{transform:"rotate(1.5deg)","animation-timing-function":"ease-out"},{transform:"rotate(0deg)","animation-timing-function":"ease-in"}],{duration:200,iterations:2})}}},{kind:"field",static:!0,key:"styles",value(){return[...(0,a.Z)(n,"styles",this),l.iv`:host{--md-dialog-container-color:var(--card-background-color);--md-dialog-headline-color:var(--primary-text-color);--md-dialog-supporting-text-color:var(--primary-text-color);--md-sys-color-scrim:#000000;--md-dialog-headline-weight:400;--md-dialog-headline-size:1.574rem;--md-dialog-supporting-text-size:1rem;--md-dialog-supporting-text-line-height:1.5rem}:host([type=alert]){min-width:320px}@media all and (max-width:450px),all and (max-height:500px){:host(:not([type=alert])){min-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));max-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));min-height:100%;max-height:100%;--md-dialog-container-shape:0}}::slotted(ha-dialog-header[slot=headline]){display:contents}.scroller{overflow:var(--dialog-content-overflow,auto)}slot[name=content]::slotted(*){padding:var(--dialog-content-padding,24px)}.scrim{z-index:10}`]}}]}}),o.A);const r={...s.I,dialog:[[[{transform:"translateY(50px)"},{transform:"translateY(0)"}],{duration:500,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:0},{opacity:1}],{duration:50,easing:"linear",pseudoElement:"::before"}]]},h={...s.G,dialog:[[[{transform:"translateY(0)"},{transform:"translateY(50px)"}],{duration:150,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:"1"},{opacity:"0"}],{delay:100,duration:50,easing:"linear",pseudoElement:"::before"}]]},p=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?r:s.I,u=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?h:s.G},36943:function(e,t,i){i.a(e,(async function(e,n){try{i.r(t);var a=i(44249),o=i(57243),s=i(15093),l=i(36522),d=i(87865),c=(i(59826),i(95198),i(23334),i(5828),i(51784),i(19993),i(74633),i(34326),i(26779)),r=i(28008),h=i(72473),p=e([c]);c=(p.then?(await p)():p)[0];const u="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",y="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",m="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",g=["current","new","done"];(0,a.Z)([(0,s.Mo)("ha-dialog-change-backup-encryption-key")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_opened",value:()=>!1},{kind:"field",decorators:[(0,s.SB)()],key:"_step",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,s.IO)("ha-md-dialog")],key:"_dialog",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_newEncryptionKey",value:void 0},{kind:"method",key:"showDialog",value:function(e){this._params=e,this._step=g[0],this._opened=!0,this._newEncryptionKey=(0,c.Ty)()}},{kind:"method",key:"closeDialog",value:function(){return this._params.cancel&&this._params.cancel(),this._opened&&(0,l.B)(this,"dialog-closed",{dialog:this.localName}),this._opened=!1,this._step=void 0,this._params=void 0,this._newEncryptionKey=void 0,!0}},{kind:"method",key:"_done",value:function(){this._params?.submit(!0),this._dialog.close()}},{kind:"method",key:"_previousStep",value:function(){const e=g.indexOf(this._step);0!==e&&(this._step=g[e-1])}},{kind:"method",key:"_nextStep",value:function(){const e=g.indexOf(this._step);e!==g.length-1&&(this._step=g[e+1])}},{kind:"method",key:"render",value:function(){if(!this._opened||!this._params)return o.Ld;const e="current"===this._step||"new"===this._step?this.hass.localize(`ui.panel.config.backup.dialogs.change_encryption_key.${this._step}.title`):"";return o.dy`
      <ha-md-dialog disable-cancel-action open @closed=${this.closeDialog}>
        <ha-dialog-header slot="headline">
          ${"new"===this._step?o.dy`
                <ha-icon-button-prev slot="navigationIcon" @click=${this._previousStep}></ha-icon-button-prev>
              `:o.dy`
                <ha-icon-button slot="navigationIcon" .label=${this.hass.localize("ui.common.close")} .path=${u} @click=${this.closeDialog}></ha-icon-button>
              `}
          <span slot="title">${e}</span>
        </ha-dialog-header>
        <div slot="content">${this._renderStepContent()}</div>
        <div slot="actions">
          ${"current"===this._step?o.dy`
                <ha-button @click=${this._nextStep}>
                  ${this.hass.localize("ui.common.next")}
                </ha-button>
              `:"new"===this._step?o.dy`
                  <ha-button @click=${this._submit} .disabled=${!this._newEncryptionKey} class="danger">
                    ${this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.actions.change")}
                  </ha-button>
                `:o.dy`
                  <ha-button @click=${this._done}>
                    ${this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.actions.done")}
                  </ha-button>
                `}
        </div>
      </ha-md-dialog>
    `}},{kind:"method",key:"_renderStepContent",value:function(){switch(this._step){case"current":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.current.description")}
          </p>
          <div class="encryption-key">
            <p>${this._params?.currentKey}</p>
            <ha-icon-button .path=${y} @click=${this._copyOldKeyToClipboard}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit_description")}
              </span>
              <ha-button slot="end" @click=${this._downloadOld}>
                <ha-svg-icon .path=${m} slot="icon"></ha-svg-icon>
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit_action")}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `;case"new":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.new.description")}
          </p>
          <div class="encryption-key">
            <p>${this._newEncryptionKey}</p>
            <ha-icon-button .path=${y} @click=${this._copyKeyToClipboard}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description")}
              </span>
              <ha-button slot="end" @click=${this._downloadNew}>
                <ha-svg-icon .path=${m} slot="icon"></ha-svg-icon>
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action")}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `;case"done":return o.dy`
          <div class="done">
            <img src="/static/images/voice-assistant/hi.png" alt="Casita ASCIA logo"/>
            <h1>
              ${this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.done.title")}
            </h1>
          </div>
        `}return o.Ld}},{kind:"method",key:"_copyKeyToClipboard",value:async function(){await(0,d.v)(this._newEncryptionKey,this.renderRoot.querySelector("div")),(0,h.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}},{kind:"method",key:"_copyOldKeyToClipboard",value:async function(){this._params?.currentKey&&(await(0,d.v)(this._params.currentKey,this.renderRoot.querySelector("div")),(0,h.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")}))}},{kind:"method",key:"_downloadOld",value:function(){this._params?.currentKey&&(0,c.VY)(this.hass,this._params.currentKey,"old")}},{kind:"method",key:"_downloadNew",value:function(){this._newEncryptionKey&&(0,c.VY)(this.hass,this._newEncryptionKey)}},{kind:"method",key:"_submit",value:async function(){this._newEncryptionKey&&(this._params.saveKey(this._newEncryptionKey),this._nextStep())}},{kind:"get",static:!0,key:"styles",value:function(){return[r.Qx,r.yu,o.iv`.done,.encryption-key p{text-align:center}ha-md-dialog{width:90vw;max-width:560px;--dialog-content-padding:8px 24px}ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-button.danger{--mdc-theme-primary:var(--error-color)}.encryption-key{border:1px solid var(--divider-color);background-color:var(--primary-background-color);border-radius:8px;padding:16px;display:flex;flex-direction:row;align-items:center;gap:24px}.encryption-key p{margin:0;flex:1;font-family:"Roboto Mono",Consolas,Menlo,monospace;font-size:20px;font-style:normal;font-weight:400;line-height:28px}.encryption-key ha-icon-button{flex:none;margin:-16px}@media all and (max-width:450px),all and (max-height:500px){ha-md-dialog{max-width:none}div[slot=content]{margin-top:0}}p{margin-top:0}`]}}]}}),o.oi);n()}catch(e){n(e)}}))}};
//# sourceMappingURL=50437.3eeecaee04647330.js.map