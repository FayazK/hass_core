export const __webpack_ids__=["8889"];export const __webpack_modules__={78244:function(a,t,e){var i=e(44249),s=e(6942),n=e(15093);(0,i.Z)([(0,n.Mo)("ha-fade-in")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,n.Cb)()],key:"name",value:()=>"fadeIn"},{kind:"field",decorators:[(0,n.Cb)()],key:"fill",value:()=>"both"},{kind:"field",decorators:[(0,n.Cb)({type:Boolean})],key:"play",value:()=>!0},{kind:"field",decorators:[(0,n.Cb)({type:Number})],key:"iterations",value:()=>1}]}}),s.Z)},55195:function(a,t,e){var i=e(44249),s=e(27486),n=e(57243),o=e(15093),d=(e(54977),e(19993),e(74633),e(59826),e(29232),e(36522));(0,i.Z)([(0,o.Mo)("ha-backup-details-restore")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"localize",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Object})],key:"backup",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean,attribute:"ha-required"})],key:"haRequired",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({attribute:"translation-key-panel"})],key:"translationKeyPanel",value:()=>"config.backup"},{kind:"field",decorators:[(0,o.SB)()],key:"_selectedData",value:void 0},{kind:"method",key:"willUpdate",value:function(){!this.hasUpdated&&this.haRequired&&(this._selectedData={homeassistant_included:!0,folders:[],addons:[],homeassistant_version:this.backup.homeassistant_version,database_included:this.backup.database_included})}},{kind:"method",key:"render",value:function(){return n.dy`
      <ha-card>
        <div class="card-header">
          ${this.localize(`ui.panel.${this.translationKeyPanel}.details.restore.title`)}
        </div>
        <div class="card-content">
          <ha-backup-data-picker .translationKeyPanel=${this.translationKeyPanel} .localize=${this.localize} .hass=${this.hass} .data=${this.backup} .value=${this._selectedData} @value-changed=${this._selectedBackupChanged} .requiredItems=${this._isHomeAssistantRequired(this.haRequired)}>
          </ha-backup-data-picker>
        </div>
        <div class="card-actions">
          <ha-button @click=${this._restore} .disabled=${this._isRestoreDisabled} destructive>
            ${this.localize(`ui.panel.${this.translationKeyPanel}.details.restore.action`)}
          </ha-button>
        </div>
      </ha-card>
    `}},{kind:"method",key:"_restore",value:function(){(0,d.B)(this,"backup-restore",{selectedData:this._selectedData})}},{kind:"method",key:"_selectedBackupChanged",value:function(a){a.stopPropagation(),this._selectedData=a.detail.value}},{kind:"field",key:"_isHomeAssistantRequired",value:()=>(0,s.Z)((a=>a?["config"]:[]))},{kind:"get",key:"_isRestoreDisabled",value:function(){return!this._selectedData||this.haRequired&&!this._selectedData.homeassistant_included||!(this._selectedData?.database_included||this._selectedData?.homeassistant_included||this._selectedData.addons.length||this._selectedData.folders.length)}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{max-width:690px;width:100%;margin:0 auto;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}`}]}}),n.oi)},83457:function(a,t,e){e.a(a,(async function(a,t){try{var i=e(44249),s=e(57243),n=e(15093),o=(e(54977),e(19993),e(74633),e(64214)),d=e(26779),l=e(90698),c=a([o,d]);[o,d]=c.then?(await c)():c;(0,i.Z)([(0,n.Mo)("ha-backup-details-summary")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({type:Object})],key:"backup",value:void 0},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"hassio"})],key:"isHassio",value:()=>!1},{kind:"method",key:"render",value:function(){const a=new Date(this.backup.date),t=(0,o.o0)(a,this.hass.locale,this.hass.config);return s.dy`
      <ha-card>
        <div class="card-header">
          ${this.hass.localize("ui.panel.config.backup.details.summary.title")}
        </div>
        <div class="card-content">
          <ha-md-list class="summary">
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.backup_type")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize(`ui.panel.config.backup.type.${(0,d.Vn)(this.backup,this.isHassio)}`)}
              </span>
            </ha-md-list-item>
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.details.summary.size")}
              </span>
              <span slot="supporting-text">
                ${(0,l.d)((0,d.En)(this.backup))}
              </span>
            </ha-md-list-item>
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.details.summary.created")}
              </span>
              <span slot="supporting-text">${t}</span>
            </ha-md-list-item>
          </ha-md-list>
        </div>
      </ha-card>
    `}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`:host{max-width:690px;width:100%;margin:0 auto;gap:24px;display:grid}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list.summary ha-md-list-item{--md-list-item-supporting-text-size:1rem;--md-list-item-label-text-size:0.875rem;--md-list-item-label-text-color:var(--secondary-text-color);--md-list-item-supporting-text-color:var(--primary-text-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}`}]}}),s.oi);t()}catch(a){t(a)}}))},96804:function(a,t,e){e.d(t,{U:()=>n});var i=e(36522);const s=()=>Promise.all([e.e("7442"),e.e("51747")]).then(e.bind(e,60906)),n=(a,t)=>{(0,i.B)(a,"show-dialog",{dialogTag:"ha-dialog-restore-backup",dialogImport:s,dialogParams:t})}},13526:function(a,t,e){e.a(a,(async function(a,i){try{e.r(t);var s=e(44249),n=e(72621),o=(e(9359),e(56475),e(70104),e(57243)),d=e(15093),l=e(73850),c=e(83523),r=(e(99426),e(59826),e(34273),e(54977),e(78244),e(17170)),h=(e(23334),e(7285),e(19993),e(74633),e(83457)),u=(e(55195),e(26779)),p=(e(87979),e(88238)),k=e(96804),m=e(36522),g=e(76131),b=e(9807),f=e(72344),y=a([r,h,b,u]);[r,h,b,u]=y.then?(await y)():y;const v="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",_="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",x="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",$="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M12,4A6,6 0 0,0 6,10C6,13.31 8.69,16 12.1,16L11.22,13.77C10.95,13.29 11.11,12.68 11.59,12.4L12.45,11.9C12.93,11.63 13.54,11.79 13.82,12.27L15.74,14.69C17.12,13.59 18,11.9 18,10A6,6 0 0,0 12,4M12,9A1,1 0 0,1 13,10A1,1 0 0,1 12,11A1,1 0 0,1 11,10A1,1 0 0,1 12,9M7,18A1,1 0 0,0 6,19A1,1 0 0,0 7,20A1,1 0 0,0 8,19A1,1 0 0,0 7,18M12.09,13.27L14.58,19.58L17.17,18.08L12.95,12.77L12.09,13.27Z",w="M4,5C2.89,5 2,5.89 2,7V17C2,18.11 2.89,19 4,19H20C21.11,19 22,18.11 22,17V7C22,5.89 21.11,5 20,5H4M4.5,7A1,1 0 0,1 5.5,8A1,1 0 0,1 4.5,9A1,1 0 0,1 3.5,8A1,1 0 0,1 4.5,7M7,7H20V17H7V7M8,8V16H11V8H8M12,8V16H15V8H12M16,8V16H19V8H16M9,9H10V10H9V9M13,9H14V10H13V9M17,9H18V10H17V9Z",A=a=>{const t=Object.keys(a.agents),e=a.failed_agent_ids??[];return[...t.filter((a=>!e.includes(a))),...e].map((t=>({...a.agents[t]??{protected:!1,size:0},id:t,success:!e.includes(t)}))).sort(((a,t)=>(0,u.Ef)(a.id,t.id)))};(0,s.Z)([(0,d.Mo)("ha-config-backup-details")],(function(a,t){class e extends t{constructor(...t){super(...t),a(this)}}return{F:e,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,d.Cb)({attribute:"backup-id"})],key:"backupId",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"agents",value:()=>[]},{kind:"field",decorators:[(0,d.SB)()],key:"_backup",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_agents",value:()=>[]},{kind:"field",decorators:[(0,d.SB)()],key:"_error",value:void 0},{kind:"method",key:"firstUpdated",value:function(a){(0,n.Z)(e,"firstUpdated",this,3)([a]),this.backupId?this._fetchBackup():this._error="Backup id not defined"}},{kind:"method",key:"render",value:function(){if(!this.hass)return o.Ld;const a=(0,f.p)(this.hass,"hassio");return o.dy`
      <hass-subpage back-path="/config/backup/backups" .hass=${this.hass} .narrow=${this.narrow} .header=${this._backup?.name||this.hass.localize("ui.panel.config.backup.details.header")}>
        <ha-button-menu slot="toolbar-icon" @action=${this._handleAction}>
          <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.common.menu")} .path=${_}></ha-icon-button>
          <ha-list-item graphic="icon">
            <ha-svg-icon slot="graphic" .path=${x}></ha-svg-icon>
            ${this.hass.localize("ui.common.download")}
          </ha-list-item>
          <ha-list-item graphic="icon" class="warning">
            <ha-svg-icon slot="graphic" .path=${v}></ha-svg-icon>
            ${this.hass.localize("ui.common.delete")}
          </ha-list-item>
        </ha-button-menu>
        <div class="content">
          ${this._error&&o.dy`<ha-alert alert-type="error">${this._error}</ha-alert>`}
          ${null===this._backup?o.dy`
                <ha-alert alert-type="warning" .title=${this.hass.localize("ui.panel.config.backup.details.not_found")}>
                  ${this.hass.localize("ui.panel.config.backup.details.not_found_description",{backupId:this.backupId})}
                </ha-alert>
              `:this._backup?o.dy`
                  <ha-backup-details-summary .backup=${this._backup} .hass=${this.hass} .localize=${this.hass.localize} .isHassio=${a}></ha-backup-details-summary>
                  <ha-backup-details-restore .backup=${this._backup} @backup-restore=${this._restore} .hass=${this.hass} .localize=${this.hass.localize}></ha-backup-details-restore>
                  <ha-card>
                    <div class="card-header">
                      ${this.hass.localize("ui.panel.config.backup.details.locations.title")}
                    </div>
                    <div class="card-content">
                      <ha-md-list>
                        ${this._agents.map((a=>{const t=a.id,e=(0,l.M)(t),i=(0,u.Sw)(this.hass.localize,t,this.agents),s=a.success,n=!a.success,d=!a.protected;return o.dy`
                            <ha-md-list-item>
                              ${(0,u.V1)(t)?o.dy`
                                      <ha-svg-icon .path=${$} slot="start">
                                      </ha-svg-icon>
                                    `:(0,u.BR)(t)?o.dy`
                                        <ha-svg-icon .path=${w} slot="start"></ha-svg-icon>
                                      `:o.dy`
                                        <img .src=${(0,p.X1)({domain:e,type:"icon",useFallback:!0,darkOptimized:this.hass.themes?.darkMode})} crossorigin="anonymous" referrerpolicy="no-referrer" alt=${`${e} logo`} slot="start"/>
                                      `}
                              <div slot="headline">${i}</div>
                                <div slot="supporting-text">
                                   ${n?o.dy`
                                           <span class="dot error"></span>
                                           <span>
                                             ${this.hass.localize("ui.panel.config.backup.details.locations.backup_failed")}
                                           </span>
                                         `:d?o.dy`
                                             <span class="dot warning"></span>
                                             <span>
                                               ${this.hass.localize("ui.panel.config.backup.details.locations.unencrypted")}</span>
                                           `:o.dy`
                                             <span class="dot success"></span>
                                             <span>${this.hass.localize("ui.panel.config.backup.details.locations.encrypted")}</span>
                                           `}
                                </div>
                              
                              ${s?o.dy`
                                      <ha-button-menu slot="end" @action=${this._handleAgentAction} .agent=${t} fixed>
                                        <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.common.menu")} .path=${_}></ha-icon-button>
                                        <ha-list-item graphic="icon">
                                          <ha-svg-icon slot="graphic" .path=${x}></ha-svg-icon>
                                          ${this.hass.localize("ui.panel.config.backup.details.locations.download")}
                                        </ha-list-item>
                                      </ha-button-menu>
                                    `:o.Ld}
                            </ha-md-list-item>
                          `}))}
                      </ha-md-list>
                    </div>
                  </ha-card>
                `:o.dy`<ha-fade-in .delay=${1e3}><ha-spinner></ha-spinner></ha-fade-in>`}
        </div>
      </hass-subpage>
    `}},{kind:"method",key:"_restore",value:function(a){this._backup&&a.detail.selectedData&&(0,k.U)(this,{backup:this._backup,selectedData:a.detail.selectedData})}},{kind:"method",key:"_fetchBackup",value:async function(){try{const a=await(0,u.Ye)(this.hass,this.backupId);this._backup=a.backup,this._agents=A(a.backup)}catch(a){this._error=a?.message||this.hass.localize("ui.panel.config.backup.details.error")}}},{kind:"method",key:"_handleAction",value:function(a){switch(a.detail.index){case 0:this._downloadBackup();break;case 1:this._deleteBackup()}}},{kind:"method",key:"_handleAgentAction",value:function(a){const t=a.currentTarget.agent;this._downloadBackup(t)}},{kind:"method",key:"_downloadBackup",value:async function(a){await(0,b.w)(this.hass,this,this._backup,this.config,a)}},{kind:"method",key:"_deleteBackup",value:async function(){await(0,g.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.backup.dialogs.delete.title"),text:this.hass.localize("ui.panel.config.backup.dialogs.delete.text"),confirmText:this.hass.localize("ui.common.delete"),destructive:!0})&&(await(0,u.Ug)(this.hass,this._backup.backup_id),(0,m.B)(this,"ha-refresh-backup-info"),(0,c.c)("/config/backup"))}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:grid}ha-spinner{margin:24px auto}.card-content{padding:0 20px}.card-actions{display:flex;justify-content:flex-end}ha-md-list{background:0 0;padding:0}ha-md-list-item{--md-list-item-leading-space:0;--md-list-item-trailing-space:0;--md-list-item-two-line-container-height:64px}ha-md-list-item img{width:48px}ha-md-list-item ha-svg-icon[slot=start]{--mdc-icon-size:48px;color:var(--primary-text-color)}.warning,.warning ha-svg-icon{color:var(--error-color)}ha-button.danger{--mdc-theme-primary:var(--error-color)}ha-md-list-item [slot=supporting-text]{display:flex;align-items:center;flex-direction:row;gap:8px;line-height:normal}.dot{display:block;position:relative;width:8px;height:8px;background-color:var(--disabled-color);border-radius:50%;flex:none}.dot.success{background-color:var(--success-color)}.dot.warning{background-color:var(--warning-color)}.dot.error{background-color:var(--error-color)}.card-header{padding-bottom:8px}`}]}}),o.oi);i()}catch(a){i(a)}}))}};
//# sourceMappingURL=8889.7bd62329c68e5396.js.map