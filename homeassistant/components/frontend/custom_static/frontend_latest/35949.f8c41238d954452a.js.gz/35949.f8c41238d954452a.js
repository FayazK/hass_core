export const __webpack_ids__=["35949"];export const __webpack_modules__={88935:function(e,t,a){a.d(t,{Cu:()=>g,Ex:()=>r,R9:()=>l,_T:()=>p,fC:()=>c,gK:()=>_,lN:()=>f,nJ:()=>y,tB:()=>h,td:()=>o,uV:()=>u,xO:()=>m,xr:()=>v});a(9359),a(56475),a(1331),a(70104),a(92519),a(42179),a(89256),a(24931),a(88463),a(57449),a(19814);var i=a(83523),s=a(46329),n=a(72344),d=a(22274);let o=function(e){return e.THREAD="thread",e.WIFI="wifi",e.ETHERNET="ethernet",e.UNKNOWN="unknown",e}({});const r=e=>e.auth.external?.config.canCommissionMatter,c=async e=>{if((0,n.p)(e,"thread")){const t=(await(0,d.r9)(e)).datasets.find((e=>e.preferred));if(t)return e.auth.external.fireMessage({type:"matter/commission",payload:{active_operational_dataset:(await(0,d.EM)(e,t.dataset_id)).tlv,border_agent_id:t.preferred_border_agent_id,mac_extended_address:t.preferred_extended_address,extended_pan_id:t.extended_pan_id}})}return e.auth.external.fireMessage({type:"matter/commission"})},l=(e,t)=>{let a;const n=(0,s.q4)(e.connection,(e=>{if(!a)return void(a=new Set(Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0])))).map((e=>e.id))));const s=Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0]))&&!a.has(e.id)));s.length&&(n(),a=void 0,t?.(),(0,i.c)(`/config/devices/device/${s[0].id}`))}));return()=>{n(),a=void 0}},p=(e,t)=>e.callWS({type:"matter/commission",code:t}),_=(e,t)=>e.callWS({type:"matter/commission_on_network",pin:t}),v=(e,t,a)=>e.callWS({type:"matter/set_wifi_credentials",network_name:t,password:a}),h=(e,t)=>e.callWS({type:"matter/set_thread",thread_operation_dataset:t}),u=(e,t)=>e.callWS({type:"matter/node_diagnostics",device_id:t}),m=(e,t)=>e.callWS({type:"matter/ping_node",device_id:t}),f=(e,t)=>e.callWS({type:"matter/open_commissioning_window",device_id:t}),y=(e,t,a)=>e.callWS({type:"matter/remove_matter_fabric",device_id:t,fabric_index:a}),g=(e,t)=>e.callWS({type:"matter/interview_node",device_id:t})},22274:function(e,t,a){a.d(t,{EM:()=>d,NO:()=>l,Xt:()=>r,h:()=>s,jK:()=>o,lR:()=>c,r9:()=>n});class i{constructor(){this.routers=void 0,this.routers={}}processEvent(e){return"router_discovered"===e.type?this.routers[e.key]=e.data:"router_removed"===e.type&&delete this.routers[e.key],Object.values(this.routers)}}const s=(e,t)=>{const a=new i;return e.connection.subscribeMessage((e=>t(a.processEvent(e))),{type:"thread/discover_routers"})},n=e=>e.callWS({type:"thread/list_datasets"}),d=(e,t)=>e.callWS({type:"thread/get_dataset_tlv",dataset_id:t}),o=(e,t,a)=>e.callWS({type:"thread/add_dataset_tlv",source:t,tlv:a}),r=(e,t)=>e.callWS({type:"thread/delete_dataset",dataset_id:t}),c=(e,t)=>e.callWS({type:"thread/set_preferred_dataset",dataset_id:t}),l=(e,t,a,i)=>e.callWS({type:"thread/set_preferred_border_agent",dataset_id:t,border_agent_id:a,extended_address:i})},17547:function(e,t,a){a.r(t),a.d(t,{HaDeviceInfoMatter:()=>l});var i=a(44249),s=a(72621),n=(a(9359),a(70104),a(57243)),d=a(15093),o=(a(41307),a(88935)),r=(a(2060),a(7285),a(6736)),c=a(28008);let l=(0,i.Z)([(0,d.Mo)("ha-device-info-matter")],(function(e,t){class a extends t{constructor(...t){super(...t),e(this)}}return{F:a,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"device",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_nodeDiagnostics",value:void 0},{kind:"method",key:"willUpdate",value:function(e){(0,s.Z)(a,"willUpdate",this,3)([e]),e.has("device")&&this._fetchNodeDetails()}},{kind:"method",key:"_fetchNodeDetails",value:async function(){if(this.device&&null===this.device.via_device_id)try{this._nodeDiagnostics=await(0,o.uV)(this.hass,this.device.id)}catch(e){this._nodeDiagnostics=void 0}}},{kind:"method",key:"render",value:function(){return this._nodeDiagnostics?n.dy`
      <ha-expansion-panel .header=${this.hass.localize("ui.panel.config.matter.device_info.device_info")}>
        <div class="row">
          <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.node_id")}:</span>
          <span class="value">${this._nodeDiagnostics.node_id}</span>
        </div>
        <div class="row">
          <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.network_type")}:</span>
          <span class="value">${this.hass.localize(`ui.panel.config.matter.network_type.${this._nodeDiagnostics.network_type}`)}</span>
        </div>
        <div class="row">
          <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.node_type")}:</span>
          <span class="value">${this.hass.localize(`ui.panel.config.matter.node_type.${this._nodeDiagnostics.node_type}`)}</span>
        </div>
        ${this._nodeDiagnostics.network_name?n.dy`
              <div class="row">
                <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.network_name")}:</span>
                <span class="value">${this._nodeDiagnostics.network_name}</span>
              </div>
            `:n.Ld}
        ${this._nodeDiagnostics.mac_address?n.dy`
              <div class="row">
                <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.mac_address")}:</span>
                <span class="value">${this._nodeDiagnostics.mac_address}</span>
              </div>
            `:n.Ld}

        <div class="row">
          <span class="name">${this.hass.localize("ui.panel.config.matter.device_info.ip_adresses")}:</span>
          <span class="value">${this._nodeDiagnostics.ip_adresses.map((e=>n.dy`${e}<br/>`))}</span>
        </div>
      </ha-expansion-panel>
    `:n.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,n.iv`h4{margin-bottom:4px}div{word-break:break-all;margin-top:2px}.row{display:flex;justify-content:space-between;padding-bottom:4px}.value{text-align:right}ha-expansion-panel{margin:8px -16px 0;--expansion-panel-summary-padding:0 16px;--expansion-panel-content-padding:0 16px;--ha-card-border-radius:0px}`]}}]}}),(0,r.f)(n.oi))}};
//# sourceMappingURL=35949.f8c41238d954452a.js.map