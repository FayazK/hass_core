export const __webpack_ids__=["16160"];export const __webpack_modules__={17705:function(e,t,i){i.d(t,{Cj:()=>h,Hs:()=>$,Kd:()=>b,Kj:()=>u,Nw:()=>p,PA:()=>r,Py:()=>n,Qm:()=>w,Z0:()=>m,_Y:()=>l,_m:()=>s,dL:()=>c,dO:()=>k,hN:()=>g,h_:()=>d,j2:()=>_,q6:()=>v,uR:()=>o});i(9359),i(52924);var a=i(47194);const r=99387==i.j?["entity_not_recorded","entity_no_longer_recorded","state_class_removed","units_changed","no_state"]:null,s=e=>e.sendMessagePromise({type:"recorder/info"}),o=(e,t)=>e.callWS({type:"recorder/list_statistic_ids",statistic_type:t}),n=(e,t)=>e.callWS({type:"recorder/get_statistics_metadata",statistic_ids:t}),c=(e,t,i,a,r="hour",s,o)=>e.callWS({type:"recorder/statistics_during_period",start_time:t.toISOString(),end_time:i?.toISOString(),statistic_ids:a,period:r,units:s,types:o}),l=(e,t,i,a)=>e.callWS({type:"recorder/statistic_during_period",statistic_id:t,units:a,fixed_period:i.fixed_period?{start_time:i.fixed_period.start instanceof Date?i.fixed_period.start.toISOString():i.fixed_period.start,end_time:i.fixed_period.end instanceof Date?i.fixed_period.end.toISOString():i.fixed_period.end}:void 0,calendar:i.calendar,rolling_window:i.rolling_window}),d=e=>e.callWS({type:"recorder/validate_statistics"}),h=(e,t,i)=>e.callWS({type:"recorder/update_statistics_metadata",statistic_id:t,unit_of_measurement:i}),g=(e,t)=>e.callWS({type:"recorder/clear_statistics",statistic_ids:t}),u=e=>{let t=null;if(!e)return null;for(const i of e)null!==i.change&&void 0!==i.change&&(null===t?t=i.change:t+=i.change);return t},v=(e,t)=>{let i=null;for(const a of t){if(!(a in e))continue;const t=u(e[a]);null!==t&&(null===i?i=t:i+=t)}return i},p=(e,t)=>e.some((e=>void 0!==e[t]&&null!==e[t])),y=["mean","min","max"],f=["sum","state","change"],m=(e,t)=>!(!y.includes(t)||!e.has_mean)||!(!f.includes(t)||!e.has_sum),_=(e,t,i,a,r)=>{const s=new Date(i).toISOString();return e.callWS({type:"recorder/adjust_sum_statistics",statistic_id:t,start_time:s,adjustment:a,adjustment_unit_of_measurement:r})},b=(e,t,i)=>{const r=e.states[t];return r?(0,a.C)(r):i?.name||t},k=(e,t,i)=>{let a;return t&&(a=e.states[t]?.attributes.unit_of_measurement),void 0===a?i?.statistics_unit_of_measurement:a},$=e=>e.includes(":"),w=e=>e.callWS({type:"recorder/update_statistics_issues"})},6736:function(e,t,i){i.d(t,{f:()=>o});var a=i(44249),r=i(72621),s=(i(9359),i(52924),i(15093));const o=e=>(0,a.Z)(null,(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:void 0},{kind:"field",key:"__unsubs",value:void 0},{kind:"method",key:"connectedCallback",value:function(){(0,r.Z)(i,"connectedCallback",this,3)([]),this._checkSubscribed()}},{kind:"method",key:"disconnectedCallback",value:function(){if((0,r.Z)(i,"disconnectedCallback",this,3)([]),this.__unsubs){for(;this.__unsubs.length;){const e=this.__unsubs.pop();e instanceof Promise?e.then((e=>e())):e()}this.__unsubs=void 0}}},{kind:"method",key:"updated",value:function(e){if((0,r.Z)(i,"updated",this,3)([e]),e.has("hass"))this._checkSubscribed();else if(this.hassSubscribeRequiredHostProps)for(const t of e.keys())if(this.hassSubscribeRequiredHostProps.includes(t))return void this._checkSubscribed()}},{kind:"method",key:"hassSubscribe",value:function(){return[]}},{kind:"method",key:"_checkSubscribed",value:function(){void 0===this.__unsubs&&this.isConnected&&void 0!==this.hass&&!this.hassSubscribeRequiredHostProps?.some((e=>void 0===this[e]))&&(this.__unsubs=this.hassSubscribe())}}]}}),e)},93892:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t);var r=i(44249),s=(i(9359),i(70104),i(48136),i(31622),i(57243)),o=i(15093),n=i(35359),c=(i(54977),i(37583),i(1118)),l=i(17705),d=i(6736),h=i(93331),g=e([c]);c=(g.then?(await g)():g)[0];const u="M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",v="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",p="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z",y="M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",f="M16 20H8V6H16M16.67 4H15V2H9V4H7.33C6.6 4 6 4.6 6 5.33V20.67C6 21.4 6.6 22 7.33 22H16.67C17.41 22 18 21.41 18 20.67V5.33C18 4.6 17.4 4 16.67 4M15 16H9V19H15V16M15 7H9V10H15V7M15 11.5H9V14.5H15V11.5Z",m="M17.66 11.2C17.43 10.9 17.15 10.64 16.89 10.38C16.22 9.78 15.46 9.35 14.82 8.72C13.33 7.26 13 4.85 13.95 3C13 3.23 12.17 3.75 11.46 4.32C8.87 6.4 7.85 10.07 9.07 13.22C9.11 13.32 9.15 13.42 9.15 13.55C9.15 13.77 9 13.97 8.8 14.05C8.57 14.15 8.33 14.09 8.14 13.93C8.08 13.88 8.04 13.83 8 13.76C6.87 12.33 6.69 10.28 7.45 8.64C5.78 10 4.87 12.3 5 14.47C5.06 14.97 5.12 15.47 5.29 15.97C5.43 16.57 5.7 17.17 6 17.7C7.08 19.43 8.95 20.67 10.96 20.92C13.1 21.19 15.39 20.8 17.03 19.32C18.86 17.66 19.5 15 18.56 12.72L18.43 12.46C18.22 12 17.66 11.2 17.66 11.2M14.5 17.5C14.22 17.74 13.76 18 13.4 18.1C12.28 18.5 11.16 17.94 10.5 17.28C11.69 17 12.4 16.12 12.61 15.23C12.78 14.43 12.46 13.77 12.33 13C12.21 12.26 12.23 11.63 12.5 10.94C12.69 11.32 12.89 11.7 13.13 12C13.9 13 15.11 13.44 15.37 14.8C15.41 14.94 15.43 15.08 15.43 15.23C15.46 16.05 15.1 16.95 14.5 17.5H14.5Z",_="M10,20V14H14V20H19V12H22L12,3L2,12H5V20H10Z",b="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z",k="M11.45,2V5.55L15,3.77L11.45,2M10.45,8L8,10.46L11.75,11.71L10.45,8M2,11.45L3.77,15L5.55,11.45H2M10,2H2V10C2.57,10.17 3.17,10.25 3.77,10.25C7.35,10.26 10.26,7.35 10.27,3.75C10.26,3.16 10.17,2.57 10,2M17,22V16H14L19,7V13H22L17,22Z",$="M8.28,5.45L6.5,4.55L7.76,2H16.23L17.5,4.55L15.72,5.44L15,4H9L8.28,5.45M18.62,8H14.09L13.3,5H10.7L9.91,8H5.38L4.1,10.55L5.89,11.44L6.62,10H17.38L18.1,11.45L19.89,10.56L18.62,8M17.77,22H15.7L15.46,21.1L12,15.9L8.53,21.1L8.3,22H6.23L9.12,11H11.19L10.83,12.35L12,14.1L13.16,12.35L12.81,11H14.88L17.77,22M11.4,15L10.5,13.65L9.32,18.13L11.4,15M14.68,18.12L13.5,13.64L12.6,15L14.68,18.12Z",w="M12,20A6,6 0 0,1 6,14C6,10 12,3.25 12,3.25C12,3.25 18,10 18,14A6,6 0 0,1 12,20Z",x=238.76104;(0,r.Z)([(0,o.Mo)("hui-energy-distribution-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_data",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_animate",value:()=>!0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:()=>["_config"]},{kind:"method",key:"setConfig",value:function(e){this._config=e}},{kind:"method",key:"hassSubscribe",value:function(){return[(0,c.UB)(this.hass,{key:this._config?.collection_key}).subscribe((e=>{this._data=e}))]}},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"shouldUpdate",value:function(e){return(0,h.SN)(this,e)||e.size>1||!e.has("hass")||!!this._data?.co2SignalEntity&&this.hass.states[this._data.co2SignalEntity]!==e.get("hass").states[this._data.co2SignalEntity]}},{kind:"method",key:"willUpdate",value:function(){!this.hasUpdated&&matchMedia("(prefers-reduced-motion)").matches&&(this._animate=!1)}},{kind:"method",key:"render",value:function(){if(!this._config)return s.Ld;if(!this._data)return s.dy`${this.hass.localize("ui.panel.lovelace.cards.energy.loading")}`;const e=this._data.prefs,t=(0,c.Jj)(e),i=void 0!==t.solar,a=void 0!==t.battery,r=void 0!==t.gas,o=void 0!==t.water,d=t.grid[0].flow_to.length>0,h=(0,l.q6)(this._data.stats,t.grid[0].flow_from.map((e=>e.stat_energy_from)))??0;let g=null;o&&(g=(0,l.q6)(this._data.stats,t.water.map((e=>e.stat_energy_from)))??0);let M=null;r&&(M=(0,l.q6)(this._data.stats,t.gas.map((e=>e.stat_energy_from)))??0);let L=null;i&&(L=(0,l.q6)(this._data.stats,t.solar.map((e=>e.stat_energy_from)))||0);let C=null,S=null;a&&(C=(0,l.q6)(this._data.stats,t.battery.map((e=>e.stat_energy_to)))||0,S=(0,l.q6)(this._data.stats,t.battery.map((e=>e.stat_energy_from)))||0);let H=null;d&&(H=(0,l.q6)(this._data.stats,t.grid[0].flow_to.map((e=>e.stat_energy_to)))||0);let P=null;i&&(P=(L||0)-(H||0)-(C||0));let V=null,Y=null;null!==P&&P<0&&(a&&(V=-1*P,V>h&&(Y=V-h,V=h)),P=0);let z=null;i&&a?(Y||(Y=Math.max(0,(H||0)-(L||0)-(C||0)-(V||0))),z=C-(V||0)):!i&&a&&(Y=H);let Z=null;a&&(Z=(S||0)-(Y||0));const W=Math.max(0,h-(V||0)),j=Math.max(0,W+(P||0)+(Z||0));let q,T,E,B,O;i&&(q=x*(P/j)),Z&&(T=x*(Z/j));let R="https://app.electricitymap.org";if(this._data.co2SignalEntity&&this._data.fossilEnergyConsumption){const e=Object.values(this._data.fossilEnergyConsumption).reduce(((e,t)=>e+t),0),t=this.hass.states[this._data.co2SignalEntity];if(t?.attributes.country_code&&(R+=`/zone/${t.attributes.country_code}`),null!==e){let t;E=h-e,t=W!==h?e*(W/h):e,O=x*(t/j),B=x-(q||0)-(T||0)-O}}const I=W+(P||0)+(H?H-(Y||0):0)+(z||0)+(Z||0)+(V||0)+(Y||0);return s.dy`
      <ha-card .header=${this._config.title}>
        <div class="card-content">
          ${void 0!==E||i||r||o?s.dy`<div class="row">
                ${void 0===E?s.dy`<div class="spacer"></div>`:s.dy`<div class="circle-container low-carbon">
                      <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.low_carbon")}</span>
                      <a class="circle" href=${R} target="_blank" rel="noopener no referrer">
                        <ha-svg-icon .path=${b}></ha-svg-icon>
                        ${(0,c.ST)(this.hass,E,"kWh")}
                      </a>
                      <svg width="80" height="30">
                        <line x1="40" y1="0" x2="40" y2="30"></line>
                      </svg>
                    </div>`}
                ${i?s.dy`<div class="circle-container solar">
                      <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.solar")}</span>
                      <div class="circle">
                        <ha-svg-icon .path=${k}></ha-svg-icon>
                        ${(0,c.ST)(this.hass,L,"kWh")}
                      </div>
                    </div>`:r||o?s.dy`<div class="spacer"></div>`:""}
                ${r?s.dy`<div class="circle-container gas">
                      <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.gas")}</span>
                      <div class="circle">
                        <ha-svg-icon .path=${m}></ha-svg-icon>
                        ${(0,c.ST)(this.hass,M,(0,c.vE)(this.hass,e,this._data.statsMetadata))}
                      </div>
                      <svg width="80" height="30">
                        <path d="M40 0 v30" id="gas"/>
                        ${M&&this._animate?s.YP`<circle r="1" class="gas" vector-effect="non-scaling-stroke">
                    <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#gas"/>
                    </animateMotion>
                  </circle>`:""}
                      </svg>
                    </div>`:o?s.dy`<div class="circle-container water">
                        <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.water")}</span>
                        <div class="circle">
                          <ha-svg-icon .path=${w}></ha-svg-icon>
                          ${(0,c.ST)(this.hass,g,(0,c.b)(this.hass))}
                        </div>
                        <svg width="80" height="30">
                          <path d="M40 0 v30" id="water"/>
                          ${g&&this._animate?s.YP`<circle r="1" class="water" vector-effect="non-scaling-stroke">
                <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                  <mpath xlink:href="#water"/>
                </animateMotion>
              </circle>`:""}
                        </svg>
                      </div>`:s.dy`<div class="spacer"></div>`}
              </div>`:""}
          <div class="row">
            <div class="circle-container grid">
              <div class="circle">
                <ha-svg-icon .path=${$}></ha-svg-icon>
                ${null!==H?s.dy`<span class="return">
                      <ha-svg-icon class="small" .path=${v}></ha-svg-icon>${(0,c.ST)(this.hass,H,"kWh")}
                    </span>`:""}
                <span class="consumption">
                  ${d?s.dy`<ha-svg-icon class="small" .path=${p}></ha-svg-icon>`:""}${(0,c.ST)(this.hass,h,"kWh")}
                </span>
              </div>
              <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.grid")}</span>
            </div>
            <div class="circle-container home">
              <div class="circle ${(0,n.$)({border:void 0===q&&void 0===B})}">
                <ha-svg-icon .path=${_}></ha-svg-icon>
                ${(0,c.ST)(this.hass,j,"kWh")}
                ${void 0!==q||void 0!==B?s.dy`<svg>
                      ${void 0!==q?s.YP`<circle class="solar" cx="40" cy="40" r="38" stroke-dasharray="${q} ${x-q}" shape-rendering="geometricPrecision" stroke-dashoffset="-${x-q}"/>`:""}
                      ${T?s.YP`<circle class="battery" cx="40" cy="40" r="38" stroke-dasharray="${T} ${x-T}" stroke-dashoffset="-${x-T-(q||0)}" shape-rendering="geometricPrecision"/>`:""}
                      ${B?s.YP`<circle class="low-carbon" cx="40" cy="40" r="38" stroke-dasharray="${B} ${x-B}" stroke-dashoffset="-${x-B-(T||0)-(q||0)}" shape-rendering="geometricPrecision"/>`:""}
                      <circle class="grid" cx="40" cy="40" r="38" stroke-dasharray="${O??x-q-(T||0)} ${void 0!==O?x-O:q+(T||0)}" stroke-dashoffset="0" shape-rendering="geometricPrecision"/>
                    </svg>`:""}
              </div>
              ${r&&o?"":s.dy`<span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.home")}</span>`}
            </div>
          </div>
          ${a||r&&o?s.dy`<div class="row">
                <div class="spacer"></div>
                ${a?s.dy` <div class="circle-container battery">
                      <div class="circle">
                        <ha-svg-icon .path=${f}></ha-svg-icon>
                        <span class="battery-in">
                          <ha-svg-icon class="small" .path=${u}></ha-svg-icon>${(0,c.ST)(this.hass,C,"kWh")}
                        </span>
                        <span class="battery-out">
                          <ha-svg-icon class="small" .path=${y}></ha-svg-icon>${(0,c.ST)(this.hass,S,"kWh")}
                        </span>
                      </div>
                      <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.battery")}</span>
                    </div>`:s.dy`<div class="spacer"></div>`}
                ${r&&o?s.dy`<div class="circle-container water bottom">
                      <svg width="80" height="30">
                        <path d="M40 30 v-30" id="water"/>
                        ${g&&this._animate?s.YP`<circle r="1" class="water" vector-effect="non-scaling-stroke">
                    <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#water"/>
                    </animateMotion>
                  </circle>`:""}
                      </svg>
                      <div class="circle">
                        <ha-svg-icon .path=${w}></ha-svg-icon>
                        ${(0,c.ST)(this.hass,g,(0,c.b)(this.hass))}
                      </div>
                      <span class="label">${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.water")}</span>
                    </div>`:s.dy`<div class="spacer"></div>`}
              </div>`:""}
          <div class="lines ${(0,n.$)({high:a||r&&o})}">
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
              ${d&&i?s.YP`<path id="return" class="return" d="M${a?45:47},0 v15 c0,${a?"35 -10,30 -30,30":"40 -10,35 -30,35"} h-20" vector-effect="non-scaling-stroke"></path> `:""}
              ${i?s.YP`<path id="solar" class="solar" d="M${a?55:53},0 v15 c0,${a?"35 10,30 30,30":"40 10,35 30,35"} h20" vector-effect="non-scaling-stroke"></path>`:""}
              ${a?s.YP`<path id="battery-house" class="battery-house" d="M55,100 v-15 c0,-35 10,-30 30,-30 h20" vector-effect="non-scaling-stroke"></path>
                  <path id="battery-grid" class=${(0,n.$)({"battery-from-grid":Boolean(V),"battery-to-grid":Boolean(Y)})} d="M45,100 v-15 c0,-35 -10,-30 -30,-30 h-20" vector-effect="non-scaling-stroke"></path>
                  `:""}
              ${a&&i?s.YP`<path id="battery-solar" class="battery-solar" d="M50,0 V100" vector-effect="non-scaling-stroke"></path>`:""}
              <path class="grid" id="grid" d="M0,${a?50:i?56:53} H100" vector-effect="non-scaling-stroke"></path>
              ${H&&i&&this._animate?s.YP`<circle r="1" class="return" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-(H-(Y||0))/I*6}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#return"/>
                    </animateMotion>
                  </circle>`:""}
              ${P&&this._animate?s.YP`<circle r="1" class="solar" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-P/I*5}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#solar"/>
                    </animateMotion>
                  </circle>`:""}
              ${W&&this._animate?s.YP`<circle r="1" class="grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-W/I*5}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#grid"/>
                    </animateMotion>
                  </circle>`:""}
              ${z&&this._animate?s.YP`<circle r="1" class="battery-solar" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-z/I*5}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-solar"/>
                    </animateMotion>
                  </circle>`:""}
              ${Z&&this._animate?s.YP`<circle r="1" class="battery-house" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-Z/I*5}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-house"/>
                    </animateMotion>
                  </circle>`:""}
              ${V&&this._animate?s.YP`<circle r="1" class="battery-from-grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-V/I*5}s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                      <mpath xlink:href="#battery-grid"/>
                    </animateMotion>
                  </circle>`:""}
              ${Y&&this._animate?s.YP`<circle r="1" class="battery-to-grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${6-Y/I*5}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-grid"/>
                    </animateMotion>
                  </circle>`:""}
            </svg>
          </div>
        </div>
        ${this._config.link_dashboard?s.dy`
              <div class="card-actions">
                <a href="/energy"><mwc-button>
                    ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.go_to_energy_dashboard")}
                  </mwc-button></a>
              </div>
            `:""}
      </ha-card>
    `}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`.circle,.lines{box-sizing:border-box;display:flex}.circle,.lines,.row{display:flex}.circle,.label{font-size:12px}.circle svg circle,line,path{fill:none}.card-actions a,.circle{text-decoration:none}:host{--mdc-icon-size:24px}ha-card{min-width:210px}.card-content{position:relative;direction:ltr}.circle svg,.lines{position:absolute;left:0}.lines{bottom:0;width:100%;height:146px;justify-content:center;padding:0 16px 16px}.lines.high{bottom:100px;height:156px}.lines svg{width:calc(100% - 160px);height:100%;max-width:340px}.row{justify-content:space-between;max-width:500px;margin:0 auto}.circle-container{display:flex;flex-direction:column;align-items:center}.circle-container.low-carbon{margin-right:4px}.circle-container.solar{margin:0 4px;height:130px}.circle-container.gas,.circle-container.water{margin-left:4px;height:130px}.circle-container.water.bottom{position:relative;top:-20px;margin-bottom:-20px}.circle-container.battery{height:110px;justify-content:flex-end}.spacer{width:84px}.circle{width:80px;height:80px;border-radius:50%;border:2px solid;flex-direction:column;align-items:center;justify-content:center;text-align:center;line-height:12px;position:relative;color:var(--primary-text-color)}ha-svg-icon{padding-bottom:2px}ha-svg-icon.small{--mdc-icon-size:12px}.label{color:var(--secondary-text-color);opacity:1;height:20px;overflow:hidden;text-overflow:ellipsis;max-width:80px;white-space:nowrap}line,path{stroke:var(--primary-text-color);stroke-width:1}.circle svg{fill:none;stroke-width:4px;width:100%;height:100%;top:0}.gas circle,.gas path{stroke:var(--energy-gas-color)}circle.gas{stroke-width:4;fill:var(--energy-gas-color)}.gas .circle{border-color:var(--energy-gas-color)}.water circle,.water path{stroke:var(--energy-water-color)}circle.water{stroke-width:4;fill:var(--energy-water-color)}.low-carbon line,circle.low-carbon{stroke:var(--energy-non-fossil-color)}.water .circle{border-color:var(--energy-water-color)}.low-carbon .circle{border-color:var(--energy-non-fossil-color)}.low-carbon ha-svg-icon{color:var(--energy-non-fossil-color)}circle.low-carbon{fill:var(--energy-non-fossil-color)}.solar .circle{border-color:var(--energy-solar-color)}circle.solar,path.solar{stroke:var(--energy-solar-color)}circle.solar{stroke-width:4;fill:var(--energy-solar-color)}.battery .circle{border-color:var(--energy-battery-in-color)}circle.battery,circle.battery-house,path.battery,path.battery-house{stroke:var(--energy-battery-out-color)}circle.battery-house{stroke-width:4;fill:var(--energy-battery-out-color)}circle.battery-solar,path.battery-solar{stroke:var(--energy-battery-in-color)}circle.battery-solar{stroke-width:4;fill:var(--energy-battery-in-color)}.battery-in{color:var(--energy-battery-in-color)}.battery-out{color:var(--energy-battery-out-color)}circle.battery-from-grid,circle.grid,path.battery-from-grid,path.grid{stroke:var(--energy-grid-consumption-color)}circle.battery-to-grid,circle.return,path.battery-to-grid,path.return{stroke:var(--energy-grid-return-color)}circle.battery-to-grid,circle.return{stroke-width:4;fill:var(--energy-grid-return-color)}.return{color:var(--energy-grid-return-color)}.grid .circle{border-color:var(--energy-grid-consumption-color)}.consumption{color:var(--energy-grid-consumption-color)}circle.battery-from-grid,circle.grid{stroke-width:4;fill:var(--energy-grid-consumption-color)}.home .circle{border-width:0;border-color:var(--primary-color)}.home .circle.border{border-width:2px}@media not (prefers-reduced-motion){.circle svg circle{animation:.6s ease-in rotate-in;transition:stroke-dashoffset .4s,stroke-dasharray .4s}@keyframes rotate-in{from{stroke-dashoffset:238.76104;stroke-dasharray:238.76104}}}`}]}}),(0,d.f)(s.oi));a()}catch(e){a(e)}}))}};
//# sourceMappingURL=16160.6926896b1509afcc.js.map