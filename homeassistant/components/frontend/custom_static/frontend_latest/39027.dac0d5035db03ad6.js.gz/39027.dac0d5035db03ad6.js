export const __webpack_ids__=["39027"];export const __webpack_modules__={46467:function(e,t,a){a.a(e,(async function(e,n){try{a.d(t,{D_:()=>w,NC:()=>y,Nh:()=>z,U8:()=>b,WB:()=>h,mn:()=>d,p6:()=>m,ud:()=>_,yQ:()=>Z});a(9359),a(1331);var i=a(16485),o=a(27486),l=a(20382),c=a(11104),s=e([i,c]);[i,c]=s.then?(await s)():s;(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{weekday:"long",month:"long",day:"numeric",timeZone:(0,c.f)(e.time_zone,t)})));const m=(e,t,a)=>r(t,a.time_zone).format(e),r=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"long",day:"numeric",timeZone:(0,c.f)(e.time_zone,t)}))),d=(e,t,a)=>u(t,a.time_zone).format(e),u=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"short",day:"numeric",timeZone:(0,c.f)(e.time_zone,t)}))),h=(e,t,a)=>{const n=g(t,a.time_zone);if(t.date_format===l.t6.language||t.date_format===l.t6.system)return n.format(e);const i=n.formatToParts(e),o=i.find((e=>"literal"===e.type))?.value,c=i.find((e=>"day"===e.type))?.value,s=i.find((e=>"month"===e.type))?.value,m=i.find((e=>"year"===e.type))?.value,r=i.at(i.length-1);let d="literal"===r?.type?r?.value:"";"bg"===t.language&&t.date_format===l.t6.YMD&&(d="");return{[l.t6.DMY]:`${c}${o}${s}${o}${m}${d}`,[l.t6.MDY]:`${s}${o}${c}${o}${m}${d}`,[l.t6.YMD]:`${m}${o}${s}${o}${c}${d}`}[t.date_format]},g=(0,o.Z)(((e,t)=>{const a=e.date_format===l.t6.system?void 0:e.language;return e.date_format===l.t6.language||(e.date_format,l.t6.system),new Intl.DateTimeFormat(a,{year:"numeric",month:"numeric",day:"numeric",timeZone:(0,c.f)(e.time_zone,t)})})),_=(e,t,a)=>f(t,a.time_zone).format(e),f=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{day:"numeric",month:"short",timeZone:(0,c.f)(e.time_zone,t)}))),y=(e,t,a)=>p(t,a.time_zone).format(e),p=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{month:"long",year:"numeric",timeZone:(0,c.f)(e.time_zone,t)}))),z=(e,t,a)=>v(t,a.time_zone).format(e),v=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{month:"long",timeZone:(0,c.f)(e.time_zone,t)}))),Z=(e,t,a)=>$(t,a.time_zone).format(e),$=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",timeZone:(0,c.f)(e.time_zone,t)}))),w=(e,t,a)=>D(t,a.time_zone).format(e),D=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{weekday:"long",timeZone:(0,c.f)(e.time_zone,t)}))),b=(e,t,a)=>I(t,a.time_zone).format(e),I=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{weekday:"short",timeZone:(0,c.f)(e.time_zone,t)})));n()}catch(e){n(e)}}))},64214:function(e,t,a){a.a(e,(async function(e,n){try{a.d(t,{DG:()=>_,E8:()=>v,Fu:()=>z,NR:()=>$,W0:()=>h,o0:()=>d,yD:()=>y});var i=a(16485),o=a(27486),l=a(46467),c=a(33570),s=a(11104),m=a(16922),r=e([i,s,l,c]);[i,s,l,c]=r.then?(await r)():r;const d=(e,t,a)=>u(t,a.time_zone).format(e),u=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"long",day:"numeric",hour:(0,m.y)(e)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,m.y)(e)?"h12":"h23",timeZone:(0,s.f)(e.time_zone,t)}))),h=e=>g().format(e),g=(0,o.Z)((()=>new Intl.DateTimeFormat(void 0,{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"}))),_=(e,t,a)=>f(t,a.time_zone).format(e),f=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"short",day:"numeric",hour:(0,m.y)(e)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,m.y)(e)?"h12":"h23",timeZone:(0,s.f)(e.time_zone,t)}))),y=(e,t,a)=>p(t,a.time_zone).format(e),p=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{month:"short",day:"numeric",hour:(0,m.y)(e)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,m.y)(e)?"h12":"h23",timeZone:(0,s.f)(e.time_zone,t)}))),z=(e,t,a)=>(new Date).getFullYear()===e.getFullYear()?y(e,t,a):_(e,t,a),v=(e,t,a)=>Z(t,a.time_zone).format(e),Z=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{year:"numeric",month:"long",day:"numeric",hour:(0,m.y)(e)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,m.y)(e)?"h12":"h23",timeZone:(0,s.f)(e.time_zone,t)}))),$=(e,t,a)=>`${(0,l.WB)(e,t,a)}, ${(0,c.mr)(e,t,a)}`;n()}catch(e){n(e)}}))},33570:function(e,t,a){a.a(e,(async function(e,n){try{a.d(t,{Vu:()=>d,Zs:()=>_,mr:()=>m,xO:()=>h});var i=a(16485),o=a(27486),l=a(11104),c=a(16922),s=e([i,l]);[i,l]=s.then?(await s)():s;const m=(e,t,a)=>r(t,a.time_zone).format(e),r=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{hour:"numeric",minute:"2-digit",hourCycle:(0,c.y)(e)?"h12":"h23",timeZone:(0,l.f)(e.time_zone,t)}))),d=(e,t,a)=>u(t,a.time_zone).format(e),u=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{hour:(0,c.y)(e)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,c.y)(e)?"h12":"h23",timeZone:(0,l.f)(e.time_zone,t)}))),h=(e,t,a)=>g(t,a.time_zone).format(e),g=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat(e.language,{weekday:"long",hour:(0,c.y)(e)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,c.y)(e)?"h12":"h23",timeZone:(0,l.f)(e.time_zone,t)}))),_=(e,t,a)=>f(t,a.time_zone).format(e),f=(0,o.Z)(((e,t)=>new Intl.DateTimeFormat("en-GB",{hour:"numeric",minute:"2-digit",hour12:!1,timeZone:(0,l.f)(e.time_zone,t)})));n()}catch(e){n(e)}}))},11104:function(e,t,a){a.a(e,(async function(e,n){try{a.d(t,{Q:()=>s,f:()=>m});var i=a(16485),o=a(20382),l=e([i]);i=(l.then?(await l)():l)[0];const c=Intl.DateTimeFormat?.().resolvedOptions?.().timeZone,s=c??"UTC",m=(e,t)=>e===o.c_.local&&c?s:t;n()}catch(e){n(e)}}))},16922:function(e,t,a){a.d(t,{y:()=>o});var n=a(27486),i=a(20382);const o=(0,n.Z)((e=>{if(e.time_format===i.zt.language||e.time_format===i.zt.system){const t=e.time_format===i.zt.language?e.language:void 0;return new Date("January 1, 2023 22:00:00").toLocaleString(t).includes("10")}return e.time_format===i.zt.am_pm}))},94223:function(e,t,a){a.a(e,(async function(e,n){try{a.r(t);var i=a(44249),o=a(57243),l=a(15093),c=a(64214),s=a(36522),m=(a(99426),a(59826),a(23334),a(73729)),r=a(28008),d=a(11225),u=e([c]);c=(u.then?(await u)():u)[0];const h="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z",g="M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z";(0,i.Z)([(0,l.Mo)("dialog-cloud-already-connected")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_obfuscateIp",value:()=>!0},{kind:"method",key:"showDialog",value:function(e){this._params=e}},{kind:"method",key:"closeDialog",value:function(){this._params?.closeDialog?.(),this._params=void 0,this._obfuscateIp=!0,(0,s.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){if(!this._params)return o.Ld;const{details:e}=this._params;return o.dy`
      <ha-dialog open @closed=${this.closeDialog} .heading=${(0,m.i)(this.hass,this.hass.localize("ui.panel.config.cloud.dialog_already_connected.heading"))}>
        <div class="intro">
          <span>
            ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.description")}
          </span>
          <b>
            ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.other_home_assistant")}
          </b>
        </div>
        <div class="instance-details">
          ${e.name?o.dy`<div class="instance-detail">
                <span>
                  ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.instance_name")}:
                </span>
                <span>${e.name}</span>
              </div>`:o.Ld}
          ${e.version?o.dy`<div class="instance-detail">
                <span>
                  ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.instance_version")}:
                </span>
                <span>${e.version}</span>
              </div>`:o.Ld}
          <div class="instance-detail">
            <span>
              ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.ip_address")}:
            </span>
            <div class="obfuscated">
              <span>
                ${this._obfuscateIp?(0,d.t)(e.remote_ip_address):e.remote_ip_address}
              </span>

              <ha-icon-button class="toggle-unmasked-url" .label=${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.obfuscated_ip."+(this._obfuscateIp?"hide":"show"))} @click=${this._toggleObfuscateIp} .path=${this._obfuscateIp?h:g}></ha-icon-button>
            </div>
          </div>
          <div class="instance-detail">
            <span>
              ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.connected_at")}:
            </span>
            <span>
              ${(0,c.o0)(new Date(e.connected_at),this.hass.locale,this.hass.config)}
            </span>
          </div>
        </div>
        <ha-alert alert-type="info" .title=${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.info_backups.title")}>
          ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.info_backups.description")}
        </ha-alert>

        <ha-button @click=${this.closeDialog} slot="secondaryAction">
          ${this.hass.localize("ui.common.cancel")}
        </ha-button>
        <ha-button @click=${this._logInHere} slot="primaryAction">
          ${this.hass.localize("ui.panel.config.cloud.dialog_already_connected.login_here")}
        </ha-button>
      </ha-dialog>
    `}},{kind:"method",key:"_toggleObfuscateIp",value:function(){this._obfuscateIp=!this._obfuscateIp}},{kind:"method",key:"_logInHere",value:function(){this._params?.logInHereAction?.(),this.closeDialog()}},{kind:"get",static:!0,key:"styles",value:function(){return[r.yu,o.iv`ha-dialog{--mdc-dialog-max-width:535px}.intro b{display:block;margin-top:16px}.instance-details{display:flex;flex-direction:column;margin-bottom:16px}.instance-detail{display:flex;flex-direction:row;justify-content:space-between;align-items:center}.obfuscated{align-items:center;display:flex;flex-direction:row}`]}}]}}),o.oi);n()}catch(e){n(e)}}))},11225:function(e,t,a){function n(e){return e.endsWith(".ui.nabu.casa")?"https://•••••••••••••••••.ui.nabu.casa":e.replace(/(?<=:\/\/)[\w-]+|(?<=\.)[\w-]+/g,(e=>"•".repeat(e.length)))}a.d(t,{t:()=>n})}};
//# sourceMappingURL=39027.dac0d5035db03ad6.js.map