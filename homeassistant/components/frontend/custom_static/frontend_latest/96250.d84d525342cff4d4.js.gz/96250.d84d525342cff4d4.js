export const __webpack_ids__=["96250"];export const __webpack_modules__={96814:function(e,i,t){t(9359),t(31526),e.exports=function e(i){return Object.freeze(i),Object.getOwnPropertyNames(i).forEach((function(t){!i.hasOwnProperty(t)||null===i[t]||"object"!=typeof i[t]&&"function"!=typeof i[t]||Object.isFrozen(i[t])||e(i[t])})),i}},37284:function(e,i,t){t.a(e,(async function(e,o){try{t.r(i),t.d(i,{HuiDialogDeleteCard:()=>f});var a=t(44249),n=t(96814),s=t.n(n),c=t(57243),d=t(15093),l=t(36522),r=t(28008),h=t(11734),u=e([h]);h=(u.then?(await u)():u)[0];let f=(0,a.Z)([(0,d.Mo)("hui-dialog-delete-card")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_cardConfig",value:void 0},{kind:"method",key:"showDialog",value:async function(e){this._params=e,this._cardConfig=e.cardConfig,Object.isFrozen(this._cardConfig)||(this._cardConfig=s()(this._cardConfig))}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,this._cardConfig=void 0,(0,l.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"render",value:function(){return this._params?c.dy`
      <ha-dialog open @closed=${this.closeDialog} .heading=${this.hass.localize("ui.panel.lovelace.cards.confirm_delete")}>
        <div>
          ${this._cardConfig?c.dy`
                <div class="element-preview">
                  <hui-card .hass=${this.hass} .config=${this._cardConfig} preview></hui-card>
                </div>
              `:""}
        </div>
        <mwc-button slot="secondaryAction" @click=${this.closeDialog} dialogInitialFocus>
          ${this.hass.localize("ui.common.cancel")}
        </mwc-button>
        <mwc-button slot="primaryAction" class="warning" @click=${this._delete}>
          ${this.hass.localize("ui.common.delete")}
        </mwc-button>
      </ha-dialog>
    `:c.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[r.yu,c.iv`.element-preview{position:relative}hui-card{margin:4px auto;max-width:500px;display:block;width:100%}`]}},{kind:"method",key:"_delete",value:function(){this._params?.deleteCard&&(this._params.deleteCard(),this.closeDialog())}}]}}),c.oi);o()}catch(e){o(e)}}))}};
//# sourceMappingURL=96250.d84d525342cff4d4.js.map