export const __webpack_ids__=["98368"];export const __webpack_modules__={13592:function(t,e,i){i.a(t,(async function(t,a){try{i.r(e);var s=i(44249),r=(i(31622),i(57243)),o=i(15093),n=i(95975),d=i(14473),c=i(96194),l=t([n]);n=(l.then?(await l)():l)[0];(0,s.Z)([(0,o.Mo)("more-info-automation")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){return this.hass&&this.stateObj?r.dy`
      <hr/>
      <div class="flex">
        <div>${this.hass.localize("ui.card.automation.last_triggered")}:</div>
        <ha-relative-time .hass=${this.hass} .datetime=${this.stateObj.attributes.last_triggered} capitalize></ha-relative-time>
      </div>

      <div class="actions">
        <mwc-button @click=${this._runActions} .disabled=${(0,c.rk)(this.stateObj.state)}>
          ${this.hass.localize("ui.card.automation.trigger")}
        </mwc-button>
      </div>
    `:r.Ld}},{kind:"method",key:"_runActions",value:function(){(0,d.Es)(this.hass,this.stateObj.entity_id)}},{kind:"field",static:!0,key:"styles",value:()=>r.iv`.flex{display:flex;justify-content:space-between}.actions{margin:8px 0;display:flex;flex-wrap:wrap;justify-content:center}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`}]}}),r.oi);a()}catch(t){a(t)}}))}};
//# sourceMappingURL=98368.7fbac13ae6af064a.js.map