export const __webpack_ids__=["39124"];export const __webpack_modules__={34713:function(e,r,a){a.a(e,(async function(e,o){try{a.r(r),a.d(r,{HuiRecoveryModeCard:()=>n});var d=a(44249),c=(a(31622),a(57243)),t=a(15093),i=(a(54977),a(74713)),s=e([i]);i=(s.then?(await s)():s)[0];let n=(0,d.Z)([(0,t.Mo)("hui-recovery-mode-card")],(function(e,r){return{F:class extends r{constructor(...r){super(...r),e(this)}},d:[{kind:"field",decorators:[(0,t.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"setConfig",value:function(e){}},{kind:"method",key:"render",value:function(){return c.dy`
      <ha-card .header=${this.hass.localize("ui.panel.lovelace.cards.recovery-mode.header")}>
        <div class="card-content">
          ${this.hass.localize("ui.panel.lovelace.cards.recovery-mode.description")}
        </div>
        <error-log-card .hass=${this.hass} provider="core"></error-log-card>
      </ha-card>
    `}},{kind:"field",static:!0,key:"styles",value:()=>c.iv`ha-card{--ha-card-header-color:var(--primary-color)}error-log-card{display:block;padding-bottom:16px}`}]}}),c.oi);o()}catch(e){o(e)}}))}};
//# sourceMappingURL=39124.e7c67c995c399292.js.map