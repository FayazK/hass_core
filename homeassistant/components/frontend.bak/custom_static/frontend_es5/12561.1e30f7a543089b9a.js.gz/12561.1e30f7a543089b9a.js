"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["12561"],{38963:function(a,t,s){s.a(a,(async function(a,n){try{s.r(t);var e=s(61701),i=(s(71695),s(47021),s(57243)),o=s(50778),r=(s(87979),s(87813)),c=a([r]);r=(c.then?(await c)():c)[0];let d,h,u=a=>a;(0,e.Z)([(0,o.Mo)("ha-config-section-analytics")],(function(a,t){return{F:class extends t{constructor(...t){super(...t),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value(){return!1}},{kind:"method",key:"render",value:function(){return(0,i.dy)(d||(d=u`
      <hass-subpage back-path="/config/system" .hass=${0} .narrow=${0} .header=${0}>
        <div class="content">
          <ha-config-analytics .hass=${0}></ha-config-analytics>
        </div>
      </hass-subpage>
    `),this.hass,this.narrow,this.hass.localize("ui.panel.config.analytics.caption"),this.hass)}},{kind:"field",static:!0,key:"styles",value(){return(0,i.iv)(h||(h=u`.content{padding:28px 20px 0;max-width:1040px;margin:0 auto}ha-config-analytics{display:block;max-width:600px;margin:0 auto}`))}}]}}),i.oi);n()}catch(d){n(d)}}))}}]);
//# sourceMappingURL=12561.1e30f7a543089b9a.js.map