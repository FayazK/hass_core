"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["25510"],{32441:function(t,e,i){i.r(e);var s=i(61701),n=(i(71695),i(47021),i(31622),i(57243)),a=i(50778),c=i(96194);let o,r,u=t=>t;(0,s.Z)([(0,a.Mo)("more-info-counter")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass||!this.stateObj)return n.Ld;const t=(0,c.rk)(this.stateObj.state);return(0,n.dy)(o||(o=u`
      <div class="actions">
        <mwc-button .action=${0} @click=${0} .disabled=${0}>
          ${0}
        </mwc-button>
        <mwc-button .action=${0} @click=${0} .disabled=${0}>
          ${0}
        </mwc-button>
        <mwc-button .action=${0} @click=${0} .disabled=${0}>
          ${0}
        </mwc-button>
      </div>
    `),"increment",this._handleActionClick,t||Number(this.stateObj.state)===this.stateObj.attributes.maximum,this.hass.localize("ui.card.counter.actions.increment"),"decrement",this._handleActionClick,t||Number(this.stateObj.state)===this.stateObj.attributes.minimum,this.hass.localize("ui.card.counter.actions.decrement"),"reset",this._handleActionClick,t,this.hass.localize("ui.card.counter.actions.reset"))}},{kind:"method",key:"_handleActionClick",value:function(t){const e=t.currentTarget.action;this.hass.callService("counter",e,{entity_id:this.stateObj.entity_id})}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(r||(r=u`.actions{margin:8px 0;display:flex;flex-wrap:wrap;justify-content:center}`))}}]}}),n.oi)}}]);
//# sourceMappingURL=25510.c8d1389bcb35dd77.js.map