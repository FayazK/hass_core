"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["87126"],{18049:function(a,s,e){var i=e(61701),t=e(72621),o=(e(71695),e(47021),e(68245)),n=e(57243),d=e(50778);let l,c=a=>a;(0,i.Z)([(0,d.Mo)("ha-md-select-option")],(function(a,s){class e extends s{constructor(...s){super(...s),a(this)}}return{F:e,d:[{kind:"field",static:!0,key:"styles",value(){return[...(0,t.Z)(e,"styles",this),(0,n.iv)(l||(l=c`:host{--ha-icon-display:block;--md-sys-color-primary:var(--primary-text-color);--md-sys-color-secondary:var(--secondary-text-color);--md-sys-color-surface:var(--card-background-color);--md-sys-color-on-surface:var(--primary-text-color);--md-sys-color-on-surface-variant:var(--secondary-text-color)}`))]}}]}}),o.y)},67846:function(a,s,e){var i=e(61701),t=e(72621),o=(e(71695),e(47021),e(84626)),n=e(57243),d=e(50778);let l,c=a=>a;(0,i.Z)([(0,d.Mo)("ha-md-select")],(function(a,s){class e extends s{constructor(...s){super(...s),a(this)}}return{F:e,d:[{kind:"field",static:!0,key:"styles",value(){return[...(0,t.Z)(e,"styles",this),(0,n.iv)(l||(l=c`:host{--ha-icon-display:block;--md-sys-color-primary:var(--primary-text-color);--md-sys-color-secondary:var(--secondary-text-color);--md-sys-color-surface:var(--card-background-color);--md-sys-color-on-surface-variant:var(--secondary-text-color);--md-sys-color-surface-container-highest:var(--input-fill-color);--md-sys-color-on-surface:var(--input-ink-color);--md-sys-color-surface-container:var(--input-fill-color);--md-sys-color-on-secondary-container:var(--primary-text-color);--md-sys-color-secondary-container:var(--input-fill-color);--md-menu-container-color:var(--card-background-color)}`))]}}]}}),o.K)},33544:function(a,s,e){e.d(s,{yt:()=>o,fU:()=>d,kP:()=>n});e(52247),e(9359),e(1331),e(40251);var i=e(17803),t=e(56785);const o=async a=>(0,i.I)(a.config.version,2021,2,4)?a.callWS({type:"supervisor/api",endpoint:"/addons",method:"get"}):(0,t.rY)(await a.callApi("GET","hassio/addons")),n=async(a,s)=>(0,i.I)(a.config.version,2021,2,4)?a.callWS({type:"supervisor/api",endpoint:`/addons/${s}/start`,method:"post",timeout:null}):a.callApi("POST",`hassio/addons/${s}/start`),d=async(a,s)=>{(0,i.I)(a.config.version,2021,2,4)?await a.callWS({type:"supervisor/api",endpoint:`/addons/${s}/install`,method:"post",timeout:null}):await a.callApi("POST",`hassio/addons/${s}/install`)}},5131:function(a,s,e){var i=e(61701),t=e(72621),o=(e(19083),e(71695),e(9359),e(52924),e(19423),e(40251),e(61006),e(47021),e(57243)),n=e(50778),d=e(27486),l=e(72344),c=e(36522),h=(e(59826),e(41307),e(19993),e(74633),e(67846),e(18049),e(1888),e(33544)),r=(e(92712),e(17705));let u,p,v,m,k,f,g,y=a=>a;const _="M10,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V8C22,6.89 21.1,6 20,6H12L10,4Z",b={homeassistant:!1,database:!1,media:!1,share:!1,local_addons:!1,addons_mode:"all",addons:[]};(0,i.Z)([(0,n.Mo)("ha-backup-config-data")],(function(a,s){class e extends s{constructor(...s){super(...s),a(this)}}return{F:e,d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"force-home-assistant"})],key:"forceHomeAssistant",value(){return!1}},{kind:"field",decorators:[(0,n.Cb)({attribute:"hide-addon-version",type:Boolean})],key:"hideAddonVersion",value(){return!1}},{kind:"field",decorators:[(0,n.SB)()],key:"value",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_addons",value(){return[]}},{kind:"field",decorators:[(0,n.SB)()],key:"_showAddons",value(){return!1}},{kind:"field",decorators:[(0,n.SB)()],key:"_showDbOption",value(){return!0}},{kind:"method",key:"firstUpdated",value:function(a){(0,t.Z)(e,"firstUpdated",this,3)([a]),this._checkDbOption(),(0,l.p)(this.hass,"hassio")&&this._fetchAddons()}},{kind:"method",key:"updated",value:function(a){var s;a.has("value")&&((0,l.p)(this.hass,"hassio")&&null!==(s=this.value)&&void 0!==s&&null!==(s=s.include_addons)&&void 0!==s&&s.length&&(this._showAddons=!0))}},{kind:"method",key:"_fetchAddons",value:async function(){const{addons:a}=await(0,h.yt)(this.hass);this._addons=a,(0,c.B)(this,"backup-addons-fetched")}},{kind:"method",key:"_checkDbOption",value:async function(){if((0,l.p)(this.hass,"recorder")){var a;const s=await(0,r._m)(this.hass.connection);this._showDbOption=s.db_in_default_location,!this._showDbOption&&null!==(a=this.value)&&void 0!==a&&a.include_database&&(this.value.include_database=!1)}else this._showDbOption=!1}},{kind:"method",key:"_hasLocalAddons",value:function(a){return a.some((a=>"local"===a.slug))}},{kind:"field",key:"_getData",value(){return(0,d.Z)(((a,s)=>{var e,i,t,o,n;if(!a)return b;const d=a,l=null!==(e=null===(i=d.include_addons)||void 0===i?void 0:i.slice())&&void 0!==e?e:[];return{homeassistant:d.include_homeassistant||this.forceHomeAssistant,database:d.include_database,media:(null===(t=d.include_folders)||void 0===t?void 0:t.includes("media"))||!1,share:(null===(o=d.include_folders)||void 0===o?void 0:o.includes("share"))||!1,local_addons:(null===(n=d.include_folders)||void 0===n?void 0:n.includes("addons/local"))||!1,addons_mode:d.include_all_addons?"all":l.length>0||s?"custom":"none",addons:l}}))}},{kind:"method",key:"_setData",value:function(a){const s=[...a.media?["media"]:[],...a.share?["share"]:[],...a.local_addons?["addons/local"]:[]],e="custom"===a.addons_mode?a.addons:[];this.value={include_homeassistant:a.homeassistant||a.database||this.forceHomeAssistant,include_addons:e.length?e:void 0,include_all_addons:"all"===a.addons_mode,include_database:a.database,include_folders:s.length?s:void 0},(0,c.B)(this,"value-changed",{value:this.value})}},{kind:"method",key:"render",value:function(){const a=this._getData(this.value,this._showAddons),s=(0,l.p)(this.hass,"hassio");return(0,o.dy)(u||(u=y`
      <ha-md-list>
        <ha-md-list-item>
          <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
          <span slot="headline">
            ${0}
          </span>
          <span slot="supporting-text">
            ${0}
          </span>
          <ha-switch id="homeassistant" slot="end" @change=${0} .checked=${0} .disabled=${0}></ha-switch>
        </ha-md-list-item>

        ${0}
        ${0}
      </ha-md-list>
      ${0}
    `),"M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",this.hass.localize("ui.panel.config.backup.data.ha_settings"),this.forceHomeAssistant?this.hass.localize("ui.panel.config.backup.data.ha_settings_included_description"):this.hass.localize("ui.panel.config.backup.data.ha_settings_description"),this._switchChanged,a.homeassistant,this.forceHomeAssistant||a.database,this._showDbOption?(0,o.dy)(p||(p=y`<ha-md-list-item>
              <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-switch id="database" slot="end" @change=${0} .checked=${0}></ha-switch>
            </ha-md-list-item>`),"M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3M9 17H7V10H9V17M13 17H11V7H13V17M17 17H15V13H17V17Z",this.hass.localize("ui.panel.config.backup.data.history"),this.hass.localize("ui.panel.config.backup.data.history_description"),this._switchChanged,a.database):o.Ld,s?(0,o.dy)(v||(v=y`
              <ha-md-list-item>
                <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
                <span slot="headline">
                  ${0}
                </span>
                <span slot="supporting-text">
                  ${0}
                </span>
                <ha-switch id="media" slot="end" @change=${0} .checked=${0}></ha-switch>
              </ha-md-list-item>

              <ha-md-list-item>
                <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
                <span slot="headline">
                  ${0}
                </span>
                <span slot="supporting-text">
                  ${0}
                </span>
                <ha-switch id="share" slot="end" @change=${0} .checked=${0}></ha-switch>
              </ha-md-list-item>

              ${0}
              ${0}
            `),"M4,6H2V20A2,2 0 0,0 4,22H18V20H4V6M20,2H8A2,2 0 0,0 6,4V16A2,2 0 0,0 8,18H20A2,2 0 0,0 22,16V4A2,2 0 0,0 20,2M12,14.5V5.5L18,10L12,14.5Z",this.hass.localize("ui.panel.config.backup.data.media"),this.hass.localize("ui.panel.config.backup.data.media_description"),this._switchChanged,a.media,_,this.hass.localize("ui.panel.config.backup.data.share_folder"),this.hass.localize("ui.panel.config.backup.data.share_folder_description"),this._switchChanged,a.share,this._hasLocalAddons(this._addons)?(0,o.dy)(m||(m=y`
                    <ha-md-list-item>
                      <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
                      <span slot="headline">
                        ${0}
                      </span>
                      <span slot="supporting-text">
                        ${0}
                      </span>
                      <ha-switch id="local_addons" slot="end" @change=${0} .checked=${0}></ha-switch>
                    </ha-md-list-item>
                  `),_,this.hass.localize("ui.panel.config.backup.data.local_addons"),this.hass.localize("ui.panel.config.backup.data.local_addons_description"),this._switchChanged,a.local_addons):o.Ld,this._addons.length?(0,o.dy)(k||(k=y`
                    <ha-md-list-item>
                      <ha-svg-icon slot="start" .path=${0}></ha-svg-icon>
                      <span slot="headline">
                        ${0}
                      </span>
                      <span slot="supporting-text">
                        ${0}
                      </span>
                      <ha-md-select slot="end" id="addons_mode" @change=${0} .value=${0}>
                        <ha-md-select-option value="all">
                          <div slot="headline">
                            ${0}
                          </div>
                        </ha-md-select-option>
                        <ha-md-select-option value="none">
                          <div slot="headline">
                            ${0}
                          </div>
                        </ha-md-select-option>
                        <ha-md-select-option value="custom">
                          <div slot="headline">
                            ${0}
                          </div>
                        </ha-md-select-option>
                      </ha-md-select>
                    </ha-md-list-item>
                  `),"M20.5,11H19V7C19,5.89 18.1,5 17,5H13V3.5A2.5,2.5 0 0,0 10.5,1A2.5,2.5 0 0,0 8,3.5V5H4A2,2 0 0,0 2,7V10.8H3.5C5,10.8 6.2,12 6.2,13.5C6.2,15 5,16.2 3.5,16.2H2V20A2,2 0 0,0 4,22H7.8V20.5C7.8,19 9,17.8 10.5,17.8C12,17.8 13.2,19 13.2,20.5V22H17A2,2 0 0,0 19,20V16H20.5A2.5,2.5 0 0,0 23,13.5A2.5,2.5 0 0,0 20.5,11Z",this.hass.localize("ui.panel.config.backup.data.addons"),this.hass.localize("ui.panel.config.backup.data.addons_description"),this._selectChanged,a.addons_mode,this.hass.localize("ui.panel.config.backup.data.addons_all"),this.hass.localize("ui.panel.config.backup.data.addons_none"),this.hass.localize("ui.panel.config.backup.data.addons_custom")):o.Ld):o.Ld,s&&this._showAddons&&this._addons.length?(0,o.dy)(f||(f=y`
            <ha-expansion-panel .header=${0} outlined expanded>
              <ha-backup-addons-picker .hass=${0} .value=${0} @value-changed=${0} .addons=${0} .hideVersion=${0}></ha-backup-addons-picker>
            </ha-expansion-panel>
          `),"Add-ons",this.hass,a.addons,this._addonsChanged,this._addons,this.hideAddonVersion):o.Ld)}},{kind:"method",key:"_switchChanged",value:function(a){const s=a.currentTarget,e=this._getData(this.value,this._showAddons);this._setData(Object.assign(Object.assign({},e),{},{[s.id]:s.checked}))}},{kind:"method",key:"_selectChanged",value:function(a){const s=a.currentTarget,e=this._getData(this.value,this._showAddons);this._setData(Object.assign(Object.assign({},e),{},{[s.id]:s.value})),"addons_mode"===s.id&&(this._showAddons="custom"===s.value)}},{kind:"method",key:"_addonsChanged",value:function(a){a.stopPropagation();const s=a.detail.value,e=this._getData(this.value,this._showAddons);this._setData(Object.assign(Object.assign({},e),{},{addons:s}))}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(g||(g=y`ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-md-list-item{--md-item-overflow:visible}ha-md-select{min-width:210px}@media all and (max-width:450px){ha-md-select{min-width:140px;width:140px;--md-filled-field-content-space:0}}`))}}]}}),o.oi)},92712:function(a,s,e){var i=e(61701),t=(e(19083),e(71695),e(92745),e(61893),e(9359),e(56475),e(1331),e(70104),e(61006),e(47021),e(57243)),o=e(50778),n=e(27486),d=e(36522),l=e(1416);e(83456),e(55486),e(15369);let c,h,r,u=a=>a;(0,i.Z)([(0,o.Mo)("ha-backup-addons-picker")],(function(a,s){return{F:class extends s{constructor(...s){super(...s),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"addons",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"value",value:void 0},{kind:"field",decorators:[(0,o.Cb)({attribute:"hide-version",type:Boolean})],key:"hideVersion",value(){return!1}},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"disabled",value(){return!1}},{kind:"field",key:"_addons",value(){return(0,n.Z)((a=>a.sort(((a,s)=>{var e;return(0,l.$K)(a.name,s.name,null===(e=this.hass)||void 0===e||null===(e=e.locale)||void 0===e?void 0:e.language)}))))}},{kind:"method",key:"render",value:function(){return(0,t.dy)(c||(c=u`
      <div class="items">
        ${0}
      </div>
    `),this._addons(this.addons).map((a=>{var s,e;return(0,t.dy)(h||(h=u`
            <ha-formfield>
              <ha-backup-formfield-label slot="label" .label=${0} .version=${0} .iconPath=${0} .imageUrl=${0}>
              </ha-backup-formfield-label>
              <ha-checkbox .id=${0} .checked=${0} @change=${0} .disabled=${0}></ha-checkbox>
            </ha-formfield>
          `),a.name,this.hideVersion?void 0:a.version,a.iconPath||"M20.5,11H19V7C19,5.89 18.1,5 17,5H13V3.5A2.5,2.5 0 0,0 10.5,1A2.5,2.5 0 0,0 8,3.5V5H4A2,2 0 0,0 2,7V10.8H3.5C5,10.8 6.2,12 6.2,13.5C6.2,15 5,16.2 3.5,16.2H2V20A2,2 0 0,0 4,22H7.8V20.5C7.8,19 9,17.8 10.5,17.8C12,17.8 13.2,19 13.2,20.5V22H17A2,2 0 0,0 19,20V16H20.5A2.5,2.5 0 0,0 23,13.5A2.5,2.5 0 0,0 20.5,11Z",null!==(s=this.addons)&&void 0!==s&&null!==(s=s.find((s=>s.slug===a.slug)))&&void 0!==s&&s.icon?`/api/hassio/addons/${a.slug}/icon`:void 0,a.slug,(null===(e=this.value)||void 0===e?void 0:e.includes(a.slug))||!1,this._checkboxChanged,this.disabled)})))}},{kind:"method",key:"_checkboxChanged",value:function(a){var s;a.stopPropagation();let e=null!==(s=this.value)&&void 0!==s?s:[];const i=a.currentTarget;i.checked?e.push(i.id):e=e.filter((a=>a!==i.id)),(0,d.B)(this,"value-changed",{value:e})}},{kind:"field",static:!0,key:"styles",value(){return(0,t.iv)(r||(r=u`.items{display:flex;flex-direction:column}`))}}]}}),t.oi)},15369:function(a,s,e){var i=e(61701),t=(e(71695),e(47021),e(57243)),o=e(50778);e(37583);let n,d,l,c,h,r=a=>a;(0,i.Z)([(0,o.Mo)("ha-backup-formfield-label")],(function(a,s){return{F:class extends s{constructor(...s){super(...s),a(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({type:String})],key:"label",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:String,attribute:"image-url"})],key:"imageUrl",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:String,attribute:"icon-path"})],key:"iconPath",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:String})],key:"version",value:void 0},{kind:"method",key:"render",value:function(){return(0,t.dy)(n||(n=r`
      ${0}
      <span class="label">
        ${0}
        ${0}
      </span>
    `),this.imageUrl?(0,t.dy)(d||(d=r`<img loading="lazy" alt="" src=${0} class="icon"/>`),this.imageUrl):this.iconPath?(0,t.dy)(l||(l=r`
              <ha-svg-icon .path=${0} class="icon"></ha-svg-icon>
            `),this.iconPath):t.Ld,this.label,this.version?(0,t.dy)(c||(c=r`<span class="version">(${0})</span>`),this.version):t.Ld)}},{kind:"field",static:!0,key:"styles",value(){return(0,t.iv)(h||(h=r`:host{display:flex;flex-direction:row;gap:16px;align-items:center}.label{margin-right:4px;margin-inline-end:4px;margin-inline-start:initial;font-size:14px;font-weight:400;line-height:24px;letter-spacing:.5px}.version{color:var(--secondary-text-color)}.icon{--mdi-icon-size:24px;width:24px;height:24px}`))}}]}}),t.oi)}}]);
//# sourceMappingURL=87126.65ef27c1c94bdf4f.js.map