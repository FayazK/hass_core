"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["35949"],{88935:function(e,t,a){a.d(t,{Cu:()=>g,Ex:()=>o,R9:()=>l,_T:()=>p,fC:()=>c,gK:()=>_,lN:()=>f,nJ:()=>y,tB:()=>v,td:()=>r,uV:()=>u,xO:()=>m,xr:()=>h});a(71695),a(9359),a(56475),a(1331),a(70104),a(40251),a(92519),a(42179),a(89256),a(24931),a(88463),a(57449),a(19814),a(47021);var i=a(83523),s=a(71857),n=a(72344),d=a(22274);let r=function(e){return e.THREAD="thread",e.WIFI="wifi",e.ETHERNET="ethernet",e.UNKNOWN="unknown",e}({});const o=e=>{var t;return null===(t=e.auth.external)||void 0===t?void 0:t.config.canCommissionMatter},c=async e=>{if((0,n.p)(e,"thread")){const t=(await(0,d.r9)(e)).datasets.find((e=>e.preferred));if(t)return e.auth.external.fireMessage({type:"matter/commission",payload:{active_operational_dataset:(await(0,d.EM)(e,t.dataset_id)).tlv,border_agent_id:t.preferred_border_agent_id,mac_extended_address:t.preferred_extended_address,extended_pan_id:t.extended_pan_id}})}return e.auth.external.fireMessage({type:"matter/commission"})},l=(e,t)=>{let a;const n=(0,s.q4)(e.connection,(e=>{if(!a)return void(a=new Set(Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0])))).map((e=>e.id))));const s=Object.values(e).filter((e=>e.identifiers.find((e=>"matter"===e[0]))&&!a.has(e.id)));s.length&&(n(),a=void 0,null==t||t(),(0,i.c)(`/config/devices/device/${s[0].id}`))}));return()=>{n(),a=void 0}},p=(e,t)=>e.callWS({type:"matter/commission",code:t}),_=(e,t)=>e.callWS({type:"matter/commission_on_network",pin:t}),h=(e,t,a)=>e.callWS({type:"matter/set_wifi_credentials",network_name:t,password:a}),v=(e,t)=>e.callWS({type:"matter/set_thread",thread_operation_dataset:t}),u=(e,t)=>e.callWS({type:"matter/node_diagnostics",device_id:t}),m=(e,t)=>e.callWS({type:"matter/ping_node",device_id:t}),f=(e,t)=>e.callWS({type:"matter/open_commissioning_window",device_id:t}),y=(e,t,a)=>e.callWS({type:"matter/remove_matter_fabric",device_id:t,fabric_index:a}),g=(e,t)=>e.callWS({type:"matter/interview_node",device_id:t})},22274:function(e,t,a){a.d(t,{EM:()=>d,NO:()=>l,Xt:()=>o,h:()=>s,jK:()=>r,lR:()=>c,r9:()=>n});class i{constructor(){this.routers=void 0,this.routers={}}processEvent(e){return"router_discovered"===e.type?this.routers[e.key]=e.data:"router_removed"===e.type&&delete this.routers[e.key],Object.values(this.routers)}}const s=(e,t)=>{const a=new i;return e.connection.subscribeMessage((e=>t(a.processEvent(e))),{type:"thread/discover_routers"})},n=e=>e.callWS({type:"thread/list_datasets"}),d=(e,t)=>e.callWS({type:"thread/get_dataset_tlv",dataset_id:t}),r=(e,t,a)=>e.callWS({type:"thread/add_dataset_tlv",source:t,tlv:a}),o=(e,t)=>e.callWS({type:"thread/delete_dataset",dataset_id:t}),c=(e,t)=>e.callWS({type:"thread/set_preferred_dataset",dataset_id:t}),l=(e,t,a,i)=>e.callWS({type:"thread/set_preferred_border_agent",dataset_id:t,border_agent_id:a,extended_address:i})},17547:function(e,t,a){a.r(t),a.d(t,{HaDeviceInfoMatter:()=>m});var i=a(61701),s=a(72621),n=(a(71695),a(9359),a(70104),a(40251),a(47021),a(57243)),d=a(50778),r=(a(41307),a(88935)),o=(a(2060),a(7285),a(6736)),c=a(28008);let l,p,_,h,v,u=e=>e,m=(0,i.Z)([(0,d.Mo)("ha-device-info-matter")],(function(e,t){class a extends t{constructor(...t){super(...t),e(this)}}return{F:a,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"device",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_nodeDiagnostics",value:void 0},{kind:"method",key:"willUpdate",value:function(e){(0,s.Z)(a,"willUpdate",this,3)([e]),e.has("device")&&this._fetchNodeDetails()}},{kind:"method",key:"_fetchNodeDetails",value:async function(){if(this.device&&null===this.device.via_device_id)try{this._nodeDiagnostics=await(0,r.uV)(this.hass,this.device.id)}catch(e){this._nodeDiagnostics=void 0}}},{kind:"method",key:"render",value:function(){return this._nodeDiagnostics?(0,n.dy)(l||(l=u`
      <ha-expansion-panel .header=${0}>
        <div class="row">
          <span class="name">${0}:</span>
          <span class="value">${0}</span>
        </div>
        <div class="row">
          <span class="name">${0}:</span>
          <span class="value">${0}</span>
        </div>
        <div class="row">
          <span class="name">${0}:</span>
          <span class="value">${0}</span>
        </div>
        ${0}
        ${0}

        <div class="row">
          <span class="name">${0}:</span>
          <span class="value">${0}</span>
        </div>
      </ha-expansion-panel>
    `),this.hass.localize("ui.panel.config.matter.device_info.device_info"),this.hass.localize("ui.panel.config.matter.device_info.node_id"),this._nodeDiagnostics.node_id,this.hass.localize("ui.panel.config.matter.device_info.network_type"),this.hass.localize(`ui.panel.config.matter.network_type.${this._nodeDiagnostics.network_type}`),this.hass.localize("ui.panel.config.matter.device_info.node_type"),this.hass.localize(`ui.panel.config.matter.node_type.${this._nodeDiagnostics.node_type}`),this._nodeDiagnostics.network_name?(0,n.dy)(p||(p=u`
              <div class="row">
                <span class="name">${0}:</span>
                <span class="value">${0}</span>
              </div>
            `),this.hass.localize("ui.panel.config.matter.device_info.network_name"),this._nodeDiagnostics.network_name):n.Ld,this._nodeDiagnostics.mac_address?(0,n.dy)(_||(_=u`
              <div class="row">
                <span class="name">${0}:</span>
                <span class="value">${0}</span>
              </div>
            `),this.hass.localize("ui.panel.config.matter.device_info.mac_address"),this._nodeDiagnostics.mac_address):n.Ld,this.hass.localize("ui.panel.config.matter.device_info.ip_adresses"),this._nodeDiagnostics.ip_adresses.map((e=>(0,n.dy)(h||(h=u`${0}<br/>`),e)))):n.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,(0,n.iv)(v||(v=u`h4{margin-bottom:4px}div{word-break:break-all;margin-top:2px}.row{display:flex;justify-content:space-between;padding-bottom:4px}.value{text-align:right}ha-expansion-panel{margin:8px -16px 0;--expansion-panel-summary-padding:0 16px;--expansion-panel-content-padding:0 16px;--ha-card-border-radius:0px}`))]}}]}}),(0,o.f)(n.oi))}}]);
//# sourceMappingURL=35949.66d24201c0dedfd2.js.map