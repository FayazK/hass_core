"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["11407"],{87865:function(t,e,a){a.d(e,{v:()=>i});a(40251);const i=async(t,e)=>{if(navigator.clipboard)try{return void(await navigator.clipboard.writeText(t))}catch(o){}const a=null!=e?e:document.body,i=document.createElement("textarea");i.value=t,a.appendChild(i),i.select(),document.execCommand("copy"),a.removeChild(i)}},59826:function(t,e,a){var i=a(61701),o=(a(71695),a(47021),a(31622)),s=a(57243),n=a(50778),r=a(22344);let l,d=t=>t;(0,i.Z)([(0,n.Mo)("ha-button")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",static:!0,key:"styles",value(){return[r.W,(0,s.iv)(l||(l=d`::slotted([slot=icon]){margin-inline-start:0px;margin-inline-end:8px;direction:var(--direction);display:block}.mdc-button{height:var(--button-height,36px)}.trailing-icon{display:flex}.slot-container{overflow:var(--button-slot-container-overflow,visible)}:host([destructive]){--mdc-theme-primary:var(--error-color)}`))]}}]}}),o.Button)},30274:function(t,e,a){a.r(e);var i=a(61701),o=(a(71695),a(9359),a(70104),a(77439),a(40251),a(11740),a(47021),a(57243)),s=a(50778),n=a(36522),r=a(73729),l=(a(59826),a(72473)),d=a(87865);let c,h,u,b,p=t=>t;(0,i.Z)([(0,s.Mo)("dialog-bluetooth-device-info")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"method",key:"showDialog",value:async function(t){this._params=t}},{kind:"method",key:"closeDialog",value:function(){return this._params=void 0,(0,n.B)(this,"dialog-closed",{dialog:this.localName}),!0}},{kind:"method",key:"showDataAsHex",value:function(t){return Array.from((new TextEncoder).encode(t)).map((t=>t.toString(16).toUpperCase().padStart(2,"0"))).join(" ")}},{kind:"method",key:"_copyToClipboard",value:async function(){this._params&&(await(0,d.v)(JSON.stringify(this._params.entry)),(0,l.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")}))}},{kind:"method",key:"render",value:function(){return this._params?(0,o.dy)(c||(c=p`
      <ha-dialog open @closed=${0} .heading=${0}>
        <p>
          <b>${0}</b>:
          ${0}
          <br/>
          <b>${0}</b>:
          ${0}
          <br/>
          <b>${0}</b>:
          ${0}
        </p>

        <h3>
          ${0}
        </h3>
        <h4>
          ${0}
        </h4>
        <table width="100%">
          <tbody>
            ${0}
          </tbody>
        </table>

        <h4>${0}</h4>
        <table width="100%">
          <tbody>
            ${0}
          </tbody>
        </table>

        <h4>
          ${0}
        </h4>
        <table width="100%">
          <tbody>
            ${0}
          </tbody>
        </table>

        <ha-button slot="secondaryAction" @click=${0}>${0}</ha-button>
      </ha-dialog>
    `),this.closeDialog,(0,r.i)(this.hass,this.hass.localize("ui.panel.config.bluetooth.device_information")),this.hass.localize("ui.panel.config.bluetooth.address"),this._params.entry.address,this.hass.localize("ui.panel.config.bluetooth.name"),this._params.entry.name,this.hass.localize("ui.panel.config.bluetooth.source"),this._params.entry.source,this.hass.localize("ui.panel.config.bluetooth.advertisement_data"),this.hass.localize("ui.panel.config.bluetooth.manufacturer_data"),Object.entries(this._params.entry.manufacturer_data).map((([t,e])=>(0,o.dy)(h||(h=p`
                <tr>
                  <td><b>${0}</b></td>
                  <td>${0}</td>
                </tr>
              `),t,this.showDataAsHex(e)))),this.hass.localize("ui.panel.config.bluetooth.service_data"),Object.entries(this._params.entry.service_data).map((([t,e])=>(0,o.dy)(u||(u=p`
                <tr>
                  <td><b>${0}</b></td>
                  <td>${0}</td>
                </tr>
              `),t,this.showDataAsHex(e)))),this.hass.localize("ui.panel.config.bluetooth.service_uuids"),this._params.entry.service_uuids.map((t=>(0,o.dy)(b||(b=p`
                <tr>
                  <td>${0}</td>
                </tr>
              `),t))),this._copyToClipboard,this.hass.localize("ui.panel.config.bluetooth.copy_to_clipboard")):o.Ld}}]}}),o.oi)}}]);
//# sourceMappingURL=11407.e2c9d4d4920c8caf.js.map