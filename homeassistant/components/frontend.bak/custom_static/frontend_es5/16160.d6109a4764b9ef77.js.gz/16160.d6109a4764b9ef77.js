"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["16160"],{17705:function(e,t,i){i.d(t,{Cj:()=>h,Hs:()=>$,Kd:()=>b,Kj:()=>g,Nw:()=>p,PA:()=>r,Py:()=>n,Qm:()=>w,Z0:()=>m,_Y:()=>l,_m:()=>s,dL:()=>c,dO:()=>k,hN:()=>u,h_:()=>d,j2:()=>_,q6:()=>v,uR:()=>o});i(19083),i(71695),i(9359),i(52924),i(61006),i(47021);var a=i(47194);const r=99387==i.j?["entity_not_recorded","entity_no_longer_recorded","state_class_removed","units_changed","no_state"]:null,s=e=>e.sendMessagePromise({type:"recorder/info"}),o=(e,t)=>e.callWS({type:"recorder/list_statistic_ids",statistic_type:t}),n=(e,t)=>e.callWS({type:"recorder/get_statistics_metadata",statistic_ids:t}),c=(e,t,i,a,r="hour",s,o)=>e.callWS({type:"recorder/statistics_during_period",start_time:t.toISOString(),end_time:null==i?void 0:i.toISOString(),statistic_ids:a,period:r,units:s,types:o}),l=(e,t,i,a)=>e.callWS({type:"recorder/statistic_during_period",statistic_id:t,units:a,fixed_period:i.fixed_period?{start_time:i.fixed_period.start instanceof Date?i.fixed_period.start.toISOString():i.fixed_period.start,end_time:i.fixed_period.end instanceof Date?i.fixed_period.end.toISOString():i.fixed_period.end}:void 0,calendar:i.calendar,rolling_window:i.rolling_window}),d=e=>e.callWS({type:"recorder/validate_statistics"}),h=(e,t,i)=>e.callWS({type:"recorder/update_statistics_metadata",statistic_id:t,unit_of_measurement:i}),u=(e,t)=>e.callWS({type:"recorder/clear_statistics",statistic_ids:t}),g=e=>{let t=null;if(!e)return null;for(const i of e)null!==i.change&&void 0!==i.change&&(null===t?t=i.change:t+=i.change);return t},v=(e,t)=>{let i=null;for(const a of t){if(!(a in e))continue;const t=g(e[a]);null!==t&&(null===i?i=t:i+=t)}return i},p=(e,t)=>e.some((e=>void 0!==e[t]&&null!==e[t])),y=["mean","min","max"],f=["sum","state","change"],m=(e,t)=>!(!y.includes(t)||!e.has_mean)||!(!f.includes(t)||!e.has_sum),_=(e,t,i,a,r)=>{const s=new Date(i).toISOString();return e.callWS({type:"recorder/adjust_sum_statistics",statistic_id:t,start_time:s,adjustment:a,adjustment_unit_of_measurement:r})},b=(e,t,i)=>{const r=e.states[t];return r?(0,a.C)(r):(null==i?void 0:i.name)||t},k=(e,t,i)=>{let a;var r;t&&(a=null===(r=e.states[t])||void 0===r?void 0:r.attributes.unit_of_measurement);return void 0===a?null==i?void 0:i.statistics_unit_of_measurement:a},$=e=>e.includes(":"),w=e=>e.callWS({type:"recorder/update_statistics_issues"})},6736:function(e,t,i){i.d(t,{f:()=>o});var a=i(61701),r=i(72621),s=(i(19083),i(71695),i(9359),i(52924),i(40251),i(61006),i(47021),i(50778));const o=e=>(0,a.Z)(null,(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:void 0},{kind:"field",key:"__unsubs",value:void 0},{kind:"method",key:"connectedCallback",value:function(){(0,r.Z)(i,"connectedCallback",this,3)([]),this._checkSubscribed()}},{kind:"method",key:"disconnectedCallback",value:function(){if((0,r.Z)(i,"disconnectedCallback",this,3)([]),this.__unsubs){for(;this.__unsubs.length;){const e=this.__unsubs.pop();e instanceof Promise?e.then((e=>e())):e()}this.__unsubs=void 0}}},{kind:"method",key:"updated",value:function(e){if((0,r.Z)(i,"updated",this,3)([e]),e.has("hass"))this._checkSubscribed();else if(this.hassSubscribeRequiredHostProps)for(const t of e.keys())if(this.hassSubscribeRequiredHostProps.includes(t))return void this._checkSubscribed()}},{kind:"method",key:"hassSubscribe",value:function(){return[]}},{kind:"method",key:"_checkSubscribed",value:function(){var e;void 0!==this.__unsubs||!this.isConnected||void 0===this.hass||null!==(e=this.hassSubscribeRequiredHostProps)&&void 0!==e&&e.some((e=>void 0===this[e]))||(this.__unsubs=this.hassSubscribe())}}]}}),e)},93892:function(e,t,i){i.a(e,(async function(e,a){try{i.r(t);var r=i(61701),s=(i(71695),i(52805),i(9359),i(70104),i(48136),i(47021),i(31622),i(57243)),o=i(50778),n=i(35359),c=(i(54977),i(37583),i(1118)),l=i(17705),d=i(6736),h=i(93331),u=e([c]);c=(u.then?(await u)():u)[0];let g,v,p,y,f,m,_,b,k,$,w,x,M,L,C,S,H,P,V,Y,z,Z,W,j,q,T,E,B,O,R,I,A,U,D,N,F,K,J,Q=e=>e;const G="M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",X="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",ee="M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z",te="M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",ie="M16 20H8V6H16M16.67 4H15V2H9V4H7.33C6.6 4 6 4.6 6 5.33V20.67C6 21.4 6.6 22 7.33 22H16.67C17.41 22 18 21.41 18 20.67V5.33C18 4.6 17.4 4 16.67 4M15 16H9V19H15V16M15 7H9V10H15V7M15 11.5H9V14.5H15V11.5Z",ae="M17.66 11.2C17.43 10.9 17.15 10.64 16.89 10.38C16.22 9.78 15.46 9.35 14.82 8.72C13.33 7.26 13 4.85 13.95 3C13 3.23 12.17 3.75 11.46 4.32C8.87 6.4 7.85 10.07 9.07 13.22C9.11 13.32 9.15 13.42 9.15 13.55C9.15 13.77 9 13.97 8.8 14.05C8.57 14.15 8.33 14.09 8.14 13.93C8.08 13.88 8.04 13.83 8 13.76C6.87 12.33 6.69 10.28 7.45 8.64C5.78 10 4.87 12.3 5 14.47C5.06 14.97 5.12 15.47 5.29 15.97C5.43 16.57 5.7 17.17 6 17.7C7.08 19.43 8.95 20.67 10.96 20.92C13.1 21.19 15.39 20.8 17.03 19.32C18.86 17.66 19.5 15 18.56 12.72L18.43 12.46C18.22 12 17.66 11.2 17.66 11.2M14.5 17.5C14.22 17.74 13.76 18 13.4 18.1C12.28 18.5 11.16 17.94 10.5 17.28C11.69 17 12.4 16.12 12.61 15.23C12.78 14.43 12.46 13.77 12.33 13C12.21 12.26 12.23 11.63 12.5 10.94C12.69 11.32 12.89 11.7 13.13 12C13.9 13 15.11 13.44 15.37 14.8C15.41 14.94 15.43 15.08 15.43 15.23C15.46 16.05 15.1 16.95 14.5 17.5H14.5Z",re="M10,20V14H14V20H19V12H22L12,3L2,12H5V20H10Z",se="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z",oe="M11.45,2V5.55L15,3.77L11.45,2M10.45,8L8,10.46L11.75,11.71L10.45,8M2,11.45L3.77,15L5.55,11.45H2M10,2H2V10C2.57,10.17 3.17,10.25 3.77,10.25C7.35,10.26 10.26,7.35 10.27,3.75C10.26,3.16 10.17,2.57 10,2M17,22V16H14L19,7V13H22L17,22Z",ne="M8.28,5.45L6.5,4.55L7.76,2H16.23L17.5,4.55L15.72,5.44L15,4H9L8.28,5.45M18.62,8H14.09L13.3,5H10.7L9.91,8H5.38L4.1,10.55L5.89,11.44L6.62,10H17.38L18.1,11.45L19.89,10.56L18.62,8M17.77,22H15.7L15.46,21.1L12,15.9L8.53,21.1L8.3,22H6.23L9.12,11H11.19L10.83,12.35L12,14.1L13.16,12.35L12.81,11H14.88L17.77,22M11.4,15L10.5,13.65L9.32,18.13L11.4,15M14.68,18.12L13.5,13.64L12.6,15L14.68,18.12Z",ce="M12,20A6,6 0 0,1 6,14C6,10 12,3.25 12,3.25C12,3.25 18,10 18,14A6,6 0 0,1 12,20Z",le=238.76104;(0,r.Z)([(0,o.Mo)("hui-energy-distribution-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_data",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_animate",value(){return!0}},{kind:"field",key:"hassSubscribeRequiredHostProps",value(){return["_config"]}},{kind:"method",key:"setConfig",value:function(e){this._config=e}},{kind:"method",key:"hassSubscribe",value:function(){var e;return[(0,c.UB)(this.hass,{key:null===(e=this._config)||void 0===e?void 0:e.collection_key}).subscribe((e=>{this._data=e}))]}},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"shouldUpdate",value:function(e){var t;return(0,h.SN)(this,e)||e.size>1||!e.has("hass")||!(null===(t=this._data)||void 0===t||!t.co2SignalEntity)&&this.hass.states[this._data.co2SignalEntity]!==e.get("hass").states[this._data.co2SignalEntity]}},{kind:"method",key:"willUpdate",value:function(){!this.hasUpdated&&matchMedia("(prefers-reduced-motion)").matches&&(this._animate=!1)}},{kind:"method",key:"render",value:function(){var e;if(!this._config)return s.Ld;if(!this._data)return(0,s.dy)(g||(g=Q`${0}`),this.hass.localize("ui.panel.lovelace.cards.energy.loading"));const t=this._data.prefs,i=(0,c.Jj)(t),a=void 0!==i.solar,r=void 0!==i.battery,o=void 0!==i.gas,d=void 0!==i.water,h=i.grid[0].flow_to.length>0,u=null!==(e=(0,l.q6)(this._data.stats,i.grid[0].flow_from.map((e=>e.stat_energy_from))))&&void 0!==e?e:0;let J=null;var de;d&&(J=null!==(de=(0,l.q6)(this._data.stats,i.water.map((e=>e.stat_energy_from))))&&void 0!==de?de:0);let he=null;var ue;o&&(he=null!==(ue=(0,l.q6)(this._data.stats,i.gas.map((e=>e.stat_energy_from))))&&void 0!==ue?ue:0);let ge=null;a&&(ge=(0,l.q6)(this._data.stats,i.solar.map((e=>e.stat_energy_from)))||0);let ve=null,pe=null;r&&(ve=(0,l.q6)(this._data.stats,i.battery.map((e=>e.stat_energy_to)))||0,pe=(0,l.q6)(this._data.stats,i.battery.map((e=>e.stat_energy_from)))||0);let ye=null;h&&(ye=(0,l.q6)(this._data.stats,i.grid[0].flow_to.map((e=>e.stat_energy_to)))||0);let fe=null;a&&(fe=(ge||0)-(ye||0)-(ve||0));let me=null,_e=null;null!==fe&&fe<0&&(r&&(me=-1*fe,me>u&&(_e=me-u,me=u)),fe=0);let be=null;a&&r?(_e||(_e=Math.max(0,(ye||0)-(ge||0)-(ve||0)-(me||0))),be=ve-(me||0)):!a&&r&&(_e=ye);let ke=null;r&&(ke=(pe||0)-(_e||0));const $e=Math.max(0,u-(me||0)),we=Math.max(0,$e+(fe||0)+(ke||0));let xe,Me,Le,Ce,Se;a&&(xe=le*(fe/we)),ke&&(Me=le*(ke/we));let He="https://app.electricitymap.org";if(this._data.co2SignalEntity&&this._data.fossilEnergyConsumption){const e=Object.values(this._data.fossilEnergyConsumption).reduce(((e,t)=>e+t),0),t=this.hass.states[this._data.co2SignalEntity];if(null!=t&&t.attributes.country_code&&(He+=`/zone/${t.attributes.country_code}`),null!==e){let t;Le=u-e,t=$e!==u?e*($e/u):e,Se=le*(t/we),Ce=le-(xe||0)-(Me||0)-Se}}const Pe=$e+(fe||0)+(ye?ye-(_e||0):0)+(be||0)+(ke||0)+(me||0)+(_e||0);return(0,s.dy)(v||(v=Q`
      <ha-card .header=${0}>
        <div class="card-content">
          ${0}
          <div class="row">
            <div class="circle-container grid">
              <div class="circle">
                <ha-svg-icon .path=${0}></ha-svg-icon>
                ${0}
                <span class="consumption">
                  ${0}${0}
                </span>
              </div>
              <span class="label">${0}</span>
            </div>
            <div class="circle-container home">
              <div class="circle ${0}">
                <ha-svg-icon .path=${0}></ha-svg-icon>
                ${0}
                ${0}
              </div>
              ${0}
            </div>
          </div>
          ${0}
          <div class="lines ${0}">
            <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
              ${0}
              ${0}
              ${0}
              ${0}
              <path class="grid" id="grid" d="M0,${0} H100" vector-effect="non-scaling-stroke"></path>
              ${0}
              ${0}
              ${0}
              ${0}
              ${0}
              ${0}
              ${0}
            </svg>
          </div>
        </div>
        ${0}
      </ha-card>
    `),this._config.title,void 0!==Le||a||o||d?(0,s.dy)(p||(p=Q`<div class="row">
                ${0}
                ${0}
                ${0}
              </div>`),void 0===Le?(0,s.dy)(y||(y=Q`<div class="spacer"></div>`)):(0,s.dy)(f||(f=Q`<div class="circle-container low-carbon">
                      <span class="label">${0}</span>
                      <a class="circle" href=${0} target="_blank" rel="noopener no referrer">
                        <ha-svg-icon .path=${0}></ha-svg-icon>
                        ${0}
                      </a>
                      <svg width="80" height="30">
                        <line x1="40" y1="0" x2="40" y2="30"></line>
                      </svg>
                    </div>`),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.low_carbon"),He,se,(0,c.ST)(this.hass,Le,"kWh")),a?(0,s.dy)(m||(m=Q`<div class="circle-container solar">
                      <span class="label">${0}</span>
                      <div class="circle">
                        <ha-svg-icon .path=${0}></ha-svg-icon>
                        ${0}
                      </div>
                    </div>`),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.solar"),oe,(0,c.ST)(this.hass,ge,"kWh")):o||d?(0,s.dy)(_||(_=Q`<div class="spacer"></div>`)):"",o?(0,s.dy)(b||(b=Q`<div class="circle-container gas">
                      <span class="label">${0}</span>
                      <div class="circle">
                        <ha-svg-icon .path=${0}></ha-svg-icon>
                        ${0}
                      </div>
                      <svg width="80" height="30">
                        <path d="M40 0 v30" id="gas"/>
                        ${0}
                      </svg>
                    </div>`),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.gas"),ae,(0,c.ST)(this.hass,he,(0,c.vE)(this.hass,t,this._data.statsMetadata)),he&&this._animate?(0,s.YP)(k||(k=Q`<circle r="1" class="gas" vector-effect="non-scaling-stroke">
                    <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#gas"/>
                    </animateMotion>
                  </circle>`)):""):d?(0,s.dy)($||($=Q`<div class="circle-container water">
                        <span class="label">${0}</span>
                        <div class="circle">
                          <ha-svg-icon .path=${0}></ha-svg-icon>
                          ${0}
                        </div>
                        <svg width="80" height="30">
                          <path d="M40 0 v30" id="water"/>
                          ${0}
                        </svg>
                      </div>`),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.water"),ce,(0,c.ST)(this.hass,J,(0,c.b)(this.hass)),J&&this._animate?(0,s.YP)(w||(w=Q`<circle r="1" class="water" vector-effect="non-scaling-stroke">
                <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                  <mpath xlink:href="#water"/>
                </animateMotion>
              </circle>`)):""):(0,s.dy)(x||(x=Q`<div class="spacer"></div>`))):"",ne,null!==ye?(0,s.dy)(M||(M=Q`<span class="return">
                      <ha-svg-icon class="small" .path=${0}></ha-svg-icon>${0}
                    </span>`),X,(0,c.ST)(this.hass,ye,"kWh")):"",h?(0,s.dy)(L||(L=Q`<ha-svg-icon class="small" .path=${0}></ha-svg-icon>`),ee):"",(0,c.ST)(this.hass,u,"kWh"),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.grid"),(0,n.$)({border:void 0===xe&&void 0===Ce}),re,(0,c.ST)(this.hass,we,"kWh"),void 0!==xe||void 0!==Ce?(0,s.dy)(C||(C=Q`<svg>
                      ${0}
                      ${0}
                      ${0}
                      <circle class="grid" cx="40" cy="40" r="38" stroke-dasharray="${0} ${0}" stroke-dashoffset="0" shape-rendering="geometricPrecision"/>
                    </svg>`),void 0!==xe?(0,s.YP)(S||(S=Q`<circle class="solar" cx="40" cy="40" r="38" stroke-dasharray="${0} ${0}" shape-rendering="geometricPrecision" stroke-dashoffset="-${0}"/>`),xe,le-xe,le-xe):"",Me?(0,s.YP)(H||(H=Q`<circle class="battery" cx="40" cy="40" r="38" stroke-dasharray="${0} ${0}" stroke-dashoffset="-${0}" shape-rendering="geometricPrecision"/>`),Me,le-Me,le-Me-(xe||0)):"",Ce?(0,s.YP)(P||(P=Q`<circle class="low-carbon" cx="40" cy="40" r="38" stroke-dasharray="${0} ${0}" stroke-dashoffset="-${0}" shape-rendering="geometricPrecision"/>`),Ce,le-Ce,le-Ce-(Me||0)-(xe||0)):"",null!=Se?Se:le-xe-(Me||0),void 0!==Se?le-Se:xe+(Me||0)):"",o&&d?"":(0,s.dy)(V||(V=Q`<span class="label">${0}</span>`),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.home")),r||o&&d?(0,s.dy)(Y||(Y=Q`<div class="row">
                <div class="spacer"></div>
                ${0}
                ${0}
              </div>`),r?(0,s.dy)(z||(z=Q` <div class="circle-container battery">
                      <div class="circle">
                        <ha-svg-icon .path=${0}></ha-svg-icon>
                        <span class="battery-in">
                          <ha-svg-icon class="small" .path=${0}></ha-svg-icon>${0}
                        </span>
                        <span class="battery-out">
                          <ha-svg-icon class="small" .path=${0}></ha-svg-icon>${0}
                        </span>
                      </div>
                      <span class="label">${0}</span>
                    </div>`),ie,G,(0,c.ST)(this.hass,ve,"kWh"),te,(0,c.ST)(this.hass,pe,"kWh"),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.battery")):(0,s.dy)(Z||(Z=Q`<div class="spacer"></div>`)),o&&d?(0,s.dy)(W||(W=Q`<div class="circle-container water bottom">
                      <svg width="80" height="30">
                        <path d="M40 30 v-30" id="water"/>
                        ${0}
                      </svg>
                      <div class="circle">
                        <ha-svg-icon .path=${0}></ha-svg-icon>
                        ${0}
                      </div>
                      <span class="label">${0}</span>
                    </div>`),J&&this._animate?(0,s.YP)(j||(j=Q`<circle r="1" class="water" vector-effect="non-scaling-stroke">
                    <animateMotion dur="2s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#water"/>
                    </animateMotion>
                  </circle>`)):"",ce,(0,c.ST)(this.hass,J,(0,c.b)(this.hass)),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.water")):(0,s.dy)(q||(q=Q`<div class="spacer"></div>`))):"",(0,n.$)({high:r||o&&d}),h&&a?(0,s.YP)(T||(T=Q`<path id="return" class="return" d="M${0},0 v15 c0,${0} h-20" vector-effect="non-scaling-stroke"></path> `),r?45:47,r?"35 -10,30 -30,30":"40 -10,35 -30,35"):"",a?(0,s.YP)(E||(E=Q`<path id="solar" class="solar" d="M${0},0 v15 c0,${0} h20" vector-effect="non-scaling-stroke"></path>`),r?55:53,r?"35 10,30 30,30":"40 10,35 30,35"):"",r?(0,s.YP)(B||(B=Q`<path id="battery-house" class="battery-house" d="M55,100 v-15 c0,-35 10,-30 30,-30 h20" vector-effect="non-scaling-stroke"></path>
                  <path id="battery-grid" class=${0} d="M45,100 v-15 c0,-35 -10,-30 -30,-30 h-20" vector-effect="non-scaling-stroke"></path>
                  `),(0,n.$)({"battery-from-grid":Boolean(me),"battery-to-grid":Boolean(_e)})):"",r&&a?(0,s.YP)(O||(O=Q`<path id="battery-solar" class="battery-solar" d="M50,0 V100" vector-effect="non-scaling-stroke"></path>`)):"",r?50:a?56:53,ye&&a&&this._animate?(0,s.YP)(R||(R=Q`<circle r="1" class="return" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#return"/>
                    </animateMotion>
                  </circle>`),6-(ye-(_e||0))/Pe*6):"",fe&&this._animate?(0,s.YP)(I||(I=Q`<circle r="1" class="solar" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#solar"/>
                    </animateMotion>
                  </circle>`),6-fe/Pe*5):"",$e&&this._animate?(0,s.YP)(A||(A=Q`<circle r="1" class="grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#grid"/>
                    </animateMotion>
                  </circle>`),6-$e/Pe*5):"",be&&this._animate?(0,s.YP)(U||(U=Q`<circle r="1" class="battery-solar" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-solar"/>
                    </animateMotion>
                  </circle>`),6-be/Pe*5):"",ke&&this._animate?(0,s.YP)(D||(D=Q`<circle r="1" class="battery-house" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-house"/>
                    </animateMotion>
                  </circle>`),6-ke/Pe*5):"",me&&this._animate?(0,s.YP)(N||(N=Q`<circle r="1" class="battery-from-grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                      <mpath xlink:href="#battery-grid"/>
                    </animateMotion>
                  </circle>`),6-me/Pe*5):"",_e&&this._animate?(0,s.YP)(F||(F=Q`<circle r="1" class="battery-to-grid" vector-effect="non-scaling-stroke">
                    <animateMotion dur="${0}s" repeatCount="indefinite" calcMode="linear">
                      <mpath xlink:href="#battery-grid"/>
                    </animateMotion>
                  </circle>`),6-_e/Pe*5):"",this._config.link_dashboard?(0,s.dy)(K||(K=Q`
              <div class="card-actions">
                <a href="/energy"><mwc-button>
                    ${0}
                  </mwc-button></a>
              </div>
            `),this.hass.localize("ui.panel.lovelace.cards.energy.energy_distribution.go_to_energy_dashboard")):"")}},{kind:"field",static:!0,key:"styles",value(){return(0,s.iv)(J||(J=Q`.circle,.lines{box-sizing:border-box;display:flex}.circle,.lines,.row{display:flex}.circle,.label{font-size:12px}.circle svg circle,line,path{fill:none}.card-actions a,.circle{text-decoration:none}:host{--mdc-icon-size:24px}ha-card{min-width:210px}.card-content{position:relative;direction:ltr}.circle svg,.lines{position:absolute;left:0}.lines{bottom:0;width:100%;height:146px;justify-content:center;padding:0 16px 16px}.lines.high{bottom:100px;height:156px}.lines svg{width:calc(100% - 160px);height:100%;max-width:340px}.row{justify-content:space-between;max-width:500px;margin:0 auto}.circle-container{display:flex;flex-direction:column;align-items:center}.circle-container.low-carbon{margin-right:4px}.circle-container.solar{margin:0 4px;height:130px}.circle-container.gas,.circle-container.water{margin-left:4px;height:130px}.circle-container.water.bottom{position:relative;top:-20px;margin-bottom:-20px}.circle-container.battery{height:110px;justify-content:flex-end}.spacer{width:84px}.circle{width:80px;height:80px;border-radius:50%;border:2px solid;flex-direction:column;align-items:center;justify-content:center;text-align:center;line-height:12px;position:relative;color:var(--primary-text-color)}ha-svg-icon{padding-bottom:2px}ha-svg-icon.small{--mdc-icon-size:12px}.label{color:var(--secondary-text-color);opacity:1;height:20px;overflow:hidden;text-overflow:ellipsis;max-width:80px;white-space:nowrap}line,path{stroke:var(--primary-text-color);stroke-width:1}.circle svg{fill:none;stroke-width:4px;width:100%;height:100%;top:0}.gas circle,.gas path{stroke:var(--energy-gas-color)}circle.gas{stroke-width:4;fill:var(--energy-gas-color)}.gas .circle{border-color:var(--energy-gas-color)}.water circle,.water path{stroke:var(--energy-water-color)}circle.water{stroke-width:4;fill:var(--energy-water-color)}.low-carbon line,circle.low-carbon{stroke:var(--energy-non-fossil-color)}.water .circle{border-color:var(--energy-water-color)}.low-carbon .circle{border-color:var(--energy-non-fossil-color)}.low-carbon ha-svg-icon{color:var(--energy-non-fossil-color)}circle.low-carbon{fill:var(--energy-non-fossil-color)}.solar .circle{border-color:var(--energy-solar-color)}circle.solar,path.solar{stroke:var(--energy-solar-color)}circle.solar{stroke-width:4;fill:var(--energy-solar-color)}.battery .circle{border-color:var(--energy-battery-in-color)}circle.battery,circle.battery-house,path.battery,path.battery-house{stroke:var(--energy-battery-out-color)}circle.battery-house{stroke-width:4;fill:var(--energy-battery-out-color)}circle.battery-solar,path.battery-solar{stroke:var(--energy-battery-in-color)}circle.battery-solar{stroke-width:4;fill:var(--energy-battery-in-color)}.battery-in{color:var(--energy-battery-in-color)}.battery-out{color:var(--energy-battery-out-color)}circle.battery-from-grid,circle.grid,path.battery-from-grid,path.grid{stroke:var(--energy-grid-consumption-color)}circle.battery-to-grid,circle.return,path.battery-to-grid,path.return{stroke:var(--energy-grid-return-color)}circle.battery-to-grid,circle.return{stroke-width:4;fill:var(--energy-grid-return-color)}.return{color:var(--energy-grid-return-color)}.grid .circle{border-color:var(--energy-grid-consumption-color)}.consumption{color:var(--energy-grid-consumption-color)}circle.battery-from-grid,circle.grid{stroke-width:4;fill:var(--energy-grid-consumption-color)}.home .circle{border-width:0;border-color:var(--primary-color)}.home .circle.border{border-width:2px}@media not (prefers-reduced-motion){.circle svg circle{animation:.6s ease-in rotate-in;transition:stroke-dashoffset .4s,stroke-dasharray .4s}@keyframes rotate-in{from{stroke-dashoffset:238.76104;stroke-dasharray:238.76104}}}`))}}]}}),(0,d.f)(s.oi));a()}catch(g){a(g)}}))}}]);
//# sourceMappingURL=16160.d6109a4764b9ef77.js.map