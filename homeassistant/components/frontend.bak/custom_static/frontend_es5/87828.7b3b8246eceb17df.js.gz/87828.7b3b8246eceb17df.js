"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["87828"],{17170:function(e,t,i){i.a(e,(async function(e,r){try{i.r(t),i.d(t,{HaSpinner:()=>f});var n=i(61701),o=i(72621),s=(i(71695),i(47021),i(97677)),a=i(43580),c=i(57243),l=i(50778),d=e([s]);s=(d.then?(await d)():d)[0];let h,u=e=>e,f=(0,n.Z)([(0,l.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,o.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value(){return[a.Z,(0,c.iv)(h||(h=u`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`))]}}]}}),s.Z);r()}catch(h){r(h)}}))},77348:function(e,t,i){i.d(t,{H:()=>r});const r=5},54372:function(e,t,i){i.d(t,{g:()=>a});i(71695),i(92745),i(52805),i(9359),i(56475),i(31526),i(70104),i(48136),i(95078),i(11740),i(47021);var r=i(77348);const n=e=>e.reduce(((e,t)=>e+parseFloat(t.state)),0)/e.length,o=e=>parseFloat(e[e.length-1].state)||0,s=(e,t,i,s,a)=>{e.forEach((e=>{e.state=Number(e.state)})),e=e.filter((e=>!Number.isNaN(e.state)));const c=void 0!==(null==a?void 0:a.min)?a.min:Math.min(...e.map((e=>e.state))),l=void 0!==(null==a?void 0:a.max)?a.max:Math.max(...e.map((e=>e.state))),d=(new Date).getTime(),h=(e,i,r)=>{const n=d-new Date(i.last_changed).getTime();let o=Math.abs(n/36e5-t);return r?(o=60*(o-Math.floor(o)),o=Number((10*Math.round(o/10)).toString()[0])):o=Math.floor(o),e[o]||(e[o]=[]),e[o].push(i),e};if(e=e.reduce(((e,t)=>h(e,t,!1)),[]),s>1&&(e=e.map((e=>e.reduce(((e,t)=>h(e,t,!0)),[])))),e.length)return((e,t,i,s,a,c)=>{const l=[];let d=(c-a)/80;d=0!==d?d:80;let h=i/(t-(1===s?1:0));h=isFinite(h)?h:i;let u=e.filter(Boolean)[0];s>1&&(u=u.filter(Boolean)[0]);let f=[n(u),o(u)];const p=e=>80+r.H/2-(e-a)/d,v=(e,t,i=0,r=1)=>{if(r>1&&e)return e.forEach(((e,i)=>v(e,t,i,r-1)));const s=h*(t+i/6);e&&(f=[n(e),o(e)]);const a=p(e?f[0]:f[1]);return l.push([s,a])};for(let r=0;r<e.length;r+=1)v(e[r],r,0,s);return l.push([i,p(f[1])]),l})(e,t,i,s,c,l)},a=(e,t,i,r,n)=>{if(!e)return;const o=e.map((e=>({state:Number(e.s),last_changed:1e3*e.lu})));return s(o,t,i,r,n)}},33325:function(e,t,i){var r=i(61701),n=(i(71695),i(47021),i(57243)),o=i(50778),s=i(77348);i(9359),i(56475);let a,c,l,d,h=e=>e;(0,r.Z)([(0,o.Mo)("hui-graph-base")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)()],key:"coordinates",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_path",value:void 0},{kind:"method",key:"render",value:function(){return(0,n.dy)(a||(a=h`
      ${0}
    `),this._path?(0,n.YP)(c||(c=h`<svg width="100%" height="100%" viewBox="0 0 500 100">
          <g>
            <mask id="fill">
              <path class='fill' fill='white' d="${0} L 500, 100 L 0, 100 z"/>
            </mask>
            <rect height="100%" width="100%" id="fill-rect" fill="var(--accent-color)" mask="url(#fill)"></rect>
            <mask id="line">
              <path fill="none" stroke="var(--accent-color)" stroke-width="${0}" stroke-linecap="round" stroke-linejoin="round" d=${0}></path>
            </mask>
            <rect height="100%" width="100%" id="rect" fill="var(--accent-color)" mask="url(#line)"></rect>
          </g>
        </svg>`),this._path,s.H,this._path):(0,n.YP)(l||(l=h`<svg width="100%" height="100%" viewBox="0 0 500 100"></svg>`)))}},{kind:"method",key:"willUpdate",value:function(e){this.coordinates&&e.has("coordinates")&&(this._path=(e=>{if(!e.length)return"";let t,i,r="",n=e.filter(Boolean)[0];r+=`M ${n[0]},${n[1]}`;for(const l of e)t=l,o=n[0],s=n[1],a=t[0],c=t[1],i=[(o-a)/2+a,(s-c)/2+c],r+=` ${i[0]},${i[1]}`,r+=` Q${t[0]},${t[1]}`,n=t;var o,s,a,c;return r+=` ${t[0]},${t[1]}`,r})(this.coordinates))}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(d||(d=h`:host{display:flex;width:100%}.fill{opacity:.1}`))}}]}}),n.oi)},43403:function(e,t,i){i.a(e,(async function(e,r){try{i.r(t),i.d(t,{HuiGraphHeaderFooter:()=>x});var n=i(61701),o=i(72621),s=(i(52247),i(19083),i(71695),i(19423),i(40251),i(47021),i(57243)),a=i(50778),c=i(72344),l=i(73850),d=i(17170),h=i(6280),u=i(69223),f=i(54372),p=(i(33325),e([d,h]));[d,h]=p.then?(await p)():p;let v,m,g,y,b,k=e=>e;const _=6e4,w=60*_,C=["counter","input_number","number","sensor"];let x=(0,n.Z)([(0,a.Mo)("hui-graph-header-footer")],(function(e,t){class r extends t{constructor(...t){super(...t),e(this)}}return{F:r,d:[{kind:"method",static:!0,key:"getConfigElement",value:async function(){return await Promise.all([i.e("46379"),i.e("24199"),i.e("78943"),i.e("27090"),i.e("3049"),i.e("67983")]).then(i.bind(i,84476)),document.createElement("hui-graph-footer-editor")}},{kind:"method",static:!0,key:"getStubConfig",value:function(e,t,i){return{type:"graph",entity:(0,u.j)(e,1,t,i,C,(e=>!isNaN(Number(e.state))&&!!e.attributes.unit_of_measurement))[0]||""}}},{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.Cb)()],key:"type",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_coordinates",value:void 0},{kind:"field",key:"_error",value:void 0},{kind:"field",key:"_interval",value:void 0},{kind:"field",key:"_subscribed",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"setConfig",value:function(e){if(null==e||!e.entity||!C.includes((0,l.M)(e.entity)))throw new Error("Specify an entity from within the sensor domain");const t=Object.assign({detail:1,hours_to_show:24},e);t.hours_to_show=Number(t.hours_to_show),t.detail=1===t.detail||2===t.detail?t.detail:1,this._config=t}},{kind:"method",key:"render",value:function(){return this._config&&this.hass?this._error?(0,s.dy)(v||(v=k`<div class="errors">${0}</div>`),this._error):this._coordinates?this._coordinates.length?(0,s.dy)(y||(y=k`
      <hui-graph-base .coordinates=${0}></hui-graph-base>
    `),this._coordinates):(0,s.dy)(g||(g=k`
        <div class="container">
          <div class="info">No state history found.</div>
        </div>
      `)):(0,s.dy)(m||(m=k`
        <div class="container">
          <ha-spinner size="small"></ha-spinner>
        </div>
      `)):s.Ld}},{kind:"method",key:"connectedCallback",value:function(){(0,o.Z)(r,"connectedCallback",this,3)([]),this.hasUpdated&&this._config&&this._subscribeHistory()}},{kind:"method",key:"disconnectedCallback",value:function(){(0,o.Z)(r,"disconnectedCallback",this,3)([]),this._unsubscribeHistory()}},{kind:"method",key:"_subscribeHistory",value:function(){(0,c.p)(this.hass,"history")&&!this._subscribed&&this._config&&(this._subscribed=(0,h.xS)(this.hass,(e=>{this._subscribed&&this._config&&(this._coordinates=(0,f.g)(e[this._config.entity],this._config.hours_to_show,500,this._config.detail,this._config.limits)||[])}),this._config.hours_to_show,[this._config.entity]).catch((e=>{this._subscribed=void 0,this._error=e})),this._setRedrawTimer())}},{kind:"method",key:"_redrawGraph",value:function(){this._coordinates&&(this._coordinates=[...this._coordinates])}},{kind:"method",key:"_setRedrawTimer",value:function(){clearInterval(this._interval),this._interval=window.setInterval((()=>this._redrawGraph()),this._config.hours_to_show>24?w:_)}},{kind:"method",key:"_unsubscribeHistory",value:function(){clearInterval(this._interval),this._subscribed&&(this._subscribed.then((e=>null==e?void 0:e())),this._subscribed=void 0)}},{kind:"method",key:"updated",value:function(e){if(!this._config||!this.hass||!e.has("_config"))return;const t=e.get("_config");t&&this._subscribed&&t.entity===this._config.entity||(this._unsubscribeHistory(),this._subscribeHistory())}},{kind:"field",static:!0,key:"styles",value(){return(0,s.iv)(b||(b=k`ha-spinner{position:absolute;top:calc(50% - 14px)}.container{display:flex;justify-content:center;position:relative;padding-bottom:20%}.info{position:absolute;top:calc(50% - 16px);color:var(--secondary-text-color)}`))}}]}}),s.oi);r()}catch(v){r(v)}}))},48734:function(e,t,i){i.a(e,(async function(e,r){try{i.d(t,{P5:()=>f,Ve:()=>v});var n=i(16485),o=(i(71695),i(9359),i(70104),i(19423),i(19134),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),i(97003),i(47021),e([n]));n=(o.then?(await o)():o)[0];const a=new Set,c=new Map;let l,d="ltr",h="en";const u="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(u){const m=new MutationObserver(p);d=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language,m.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function f(...e){e.map((e=>{const t=e.$code.toLowerCase();c.has(t)?c.set(t,Object.assign(Object.assign({},c.get(t)),e)):c.set(t,e),l||(l=e)})),p()}function p(){u&&(d=document.documentElement.dir||"ltr",h=document.documentElement.lang||navigator.language),[...a.keys()].map((e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()}))}class v{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){a.add(this.host)}hostDisconnected(){a.delete(this.host)}dir(){return`${this.host.dir||d}`.toLowerCase()}lang(){return`${this.host.lang||h}`.toLowerCase()}getTranslationData(e){var t,i;const r=new Intl.Locale(e.replace(/_/g,"-")),n=null==r?void 0:r.language.toLowerCase(),o=null!==(i=null===(t=null==r?void 0:r.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==i?i:"";return{locale:r,language:n,region:o,primary:c.get(`${n}-${o}`),secondary:c.get(n)}}exists(e,t){var i;const{primary:r,secondary:n}=this.getTranslationData(null!==(i=t.lang)&&void 0!==i?i:this.lang());return t=Object.assign({includeFallback:!1},t),!!(r&&r[e]||n&&n[e]||t.includeFallback&&l&&l[e])}term(e,...t){const{primary:i,secondary:r}=this.getTranslationData(this.lang());let n;if(i&&i[e])n=i[e];else if(r&&r[e])n=r[e];else{if(!l||!l[e])return console.error(`No translation found for: ${String(e)}`),String(e);n=l[e]}return"function"==typeof n?n(...t):n}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,i){return new Intl.RelativeTimeFormat(this.lang(),i).format(e,t)}}r()}catch(s){r(s)}}))},68783:function(e,t,i){i.a(e,(async function(e,r){try{i.d(t,{A:()=>d});i(71695),i(47021);var n=i(64699),o=i(15073),s=i(81048),a=i(31027),c=i(57243),l=e([o]);o=(l.then?(await l)():l)[0];let h,u=e=>e;var d=class extends a.P{constructor(){super(...arguments),this.localize=new o.V(this)}render(){return(0,c.dy)(h||(h=u`
      <svg part="base" class="spinner" role="progressbar" aria-label=${0}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `),this.localize.term("loading"))}};d.styles=[s.N,n.D],r()}catch(h){r(h)}}))},31027:function(e,t,i){i.d(t,{P:()=>a});i(71695),i(9359),i(31526),i(46692),i(47021);var r,n=i(52812),o=i(57243),s=i(50778),a=class extends o.oi{constructor(){super(),(0,n.Ko)(this,r,!1),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach((([e,t])=>{this.constructor.define(e,t)}))}emit(e,t){const i=new CustomEvent(e,(0,n.ih)({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(i),i}static define(e,t=this,i={}){const r=customElements.get(e);if(!r){try{customElements.define(e,t,i)}catch(s){customElements.define(e,class extends t{},i)}return}let n=" (unknown version)",o=n;"version"in t&&t.version&&(n=" v"+t.version),"version"in r&&r.version&&(o=" v"+r.version),n&&o&&n===o||console.warn(`Attempted to register <${e}>${n}, but <${e}>${o} has already been registered.`)}attributeChangedCallback(e,t,i){(0,n.ac)(this,r)||(this.constructor.elementProperties.forEach(((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])})),(0,n.qx)(this,r,!0)),super.attributeChangedCallback(e,t,i)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach(((t,i)=>{e.has(i)&&null==this[i]&&(this[i]=t)}))}};r=new WeakMap,a.version="2.20.1",a.dependencies={},(0,n.u2)([(0,s.Cb)()],a.prototype,"dir",2),(0,n.u2)([(0,s.Cb)()],a.prototype,"lang",2)},15073:function(e,t,i){i.a(e,(async function(e,r){try{i.d(t,{V:()=>a});var n=i(21262),o=i(48734),s=e([o,n]);[o,n]=s.then?(await s)():s;var a=class extends o.Ve{};(0,o.P5)(n.K),r()}catch(c){r(c)}}))},21262:function(e,t,i){i.a(e,(async function(e,r){try{i.d(t,{K:()=>a});var n=i(48734),o=e([n]);n=(o.then?(await o)():o)[0];var s={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};(0,n.P5)(s);var a=s;r()}catch(c){r(c)}}))},64699:function(e,t,i){i.d(t,{D:()=>n});let r;var n=(0,i(57243).iv)(r||(r=(e=>e)`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`))},52812:function(e,t,i){i.d(t,{EZ:()=>f,Ko:()=>g,ac:()=>m,ih:()=>u,qx:()=>y,u2:()=>p});i(63721),i(52247),i(71695),i(40251),i(47021);var r=Object.defineProperty,n=Object.defineProperties,o=Object.getOwnPropertyDescriptor,s=Object.getOwnPropertyDescriptors,a=Object.getOwnPropertySymbols,c=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=e=>{throw TypeError(e)},h=(e,t,i)=>t in e?r(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i,u=(e,t)=>{for(var i in t||(t={}))c.call(t,i)&&h(e,i,t[i]);if(a)for(var i of a(t))l.call(t,i)&&h(e,i,t[i]);return e},f=(e,t)=>n(e,s(t)),p=(e,t,i,n)=>{for(var s,a=n>1?void 0:n?o(t,i):t,c=e.length-1;c>=0;c--)(s=e[c])&&(a=(n?s(t,i,a):s(a))||a);return n&&a&&r(t,i,a),a},v=(e,t,i)=>t.has(e)||d("Cannot "+i),m=(e,t,i)=>(v(e,t,"read from private field"),i?i.call(e):t.get(e)),g=(e,t,i)=>t.has(e)?d("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,i),y=(e,t,i,r)=>(v(e,t,"write to private field"),r?r.call(e,i):t.set(e,i),i)},81048:function(e,t,i){i.d(t,{N:()=>n});let r;var n=(0,i(57243).iv)(r||(r=(e=>e)`:host{box-sizing:border-box}:host *,:host ::after,:host ::before{box-sizing:inherit}[hidden]{display:none!important}`))},97677:function(e,t,i){i.a(e,(async function(e,r){try{i.d(t,{Z:()=>n.A});var n=i(68783),o=(i(64699),i(15073)),s=i(21262),a=(i(81048),i(31027),i(52812),e([o,s,n]));[o,s,n]=a.then?(await a)():a,r()}catch(c){r(c)}}))},43580:function(e,t,i){i.d(t,{Z:()=>r.D});var r=i(64699);i(52812)}}]);
//# sourceMappingURL=87828.7b3b8246eceb17df.js.map