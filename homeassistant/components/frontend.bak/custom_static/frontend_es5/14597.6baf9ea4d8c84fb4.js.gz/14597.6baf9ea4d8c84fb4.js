"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["14597"],{12763:function(t,e,i){i.a(t,(async function(t,e){try{var a=i(61701),s=(i(22152),i(71695),i(9359),i(56475),i(70104),i(47021),i(57243)),n=i(50778),r=i(25904),o=i(59519),c=i(28008),d=i(59389),l=(i(41307),t([d,o,r]));[d,o,r]=l.then?(await l)():l;let u,h,b,k,v,y=t=>t;(0,a.Z)([(0,n.Mo)("ha-attributes")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:"extra-filters"})],key:"extraFilters",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_expanded",value(){return!1}},{kind:"get",key:"_filteredAttributes",value:function(){return this._computeDisplayAttributes(o.wk.concat(this.extraFilters?this.extraFilters.split(","):[]))}},{kind:"method",key:"willUpdate",value:function(t){(t.has("extraFilters")||t.has("stateObj"))&&this.toggleAttribute("empty",0===this._filteredAttributes.length)}},{kind:"method",key:"render",value:function(){if(!this.stateObj)return s.Ld;const t=this._filteredAttributes;return 0===t.length?s.Ld:(0,s.dy)(u||(u=y`
      <ha-expansion-panel .header=${0} outlined @expanded-will-change=${0}>
        <div class="attribute-container">
          ${0}
        </div>
      </ha-expansion-panel>
      ${0}
    `),this.hass.localize("ui.components.attributes.expansion_header"),this._expandedChanged,this._expanded?(0,s.dy)(h||(h=y`
                ${0}
              `),t.map((t=>(0,s.dy)(b||(b=y`
                    <div class="data-entry">
                      <div class="key">
                        ${0}
                      </div>
                      <div class="value">
                        <ha-attribute-value .hass=${0} .attribute=${0} .stateObj=${0}></ha-attribute-value>
                      </div>
                    </div>
                  `),(0,r.computeAttributeNameDisplay)(this.hass.localize,this.stateObj,this.hass.entities,t),this.hass,t,this.stateObj)))):"",this.stateObj.attributes.attribution?(0,s.dy)(k||(k=y`
            <div class="attribution">
              ${0}
            </div>
          `),this.stateObj.attributes.attribution):"")}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,(0,s.iv)(v||(v=y`.attribute-container{margin-bottom:8px;direction:ltr}.data-entry{display:flex;flex-direction:row;justify-content:space-between}.data-entry .value{max-width:60%;overflow-wrap:break-word;text-align:right}.key{flex-grow:1}.attribution{color:var(--secondary-text-color);text-align:center;margin-top:16px}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`))]}},{kind:"method",key:"_computeDisplayAttributes",value:function(t){return this.stateObj?Object.keys(this.stateObj.attributes).filter((e=>-1===t.indexOf(e))):[]}},{kind:"method",key:"_expandedChanged",value:function(t){this._expanded=t.detail.expanded}}]}}),s.oi);e()}catch(u){e(u)}}))},42971:function(t,e,i){i.a(t,(async function(t,a){try{i.r(e);var s=i(61701),n=(i(71695),i(47021),i(31622),i(57243)),r=i(50778),o=i(12763),c=t([o]);o=(c.then?(await c)():c)[0];let d,l,u,h,b,k=t=>t;(0,s.Z)([(0,r.Mo)("more-info-timer")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){return this.hass&&this.stateObj?(0,n.dy)(d||(d=k`
      <div class="actions">
        ${0}
        ${0}
        ${0}
      </div>
      <ha-attributes .hass=${0} .stateObj=${0} extra-filters="remaining,restore"></ha-attributes>
    `),"idle"===this.stateObj.state||"paused"===this.stateObj.state?(0,n.dy)(l||(l=k`
              <mwc-button .action=${0} @click=${0}>
                ${0}
              </mwc-button>
            `),"start",this._handleActionClick,this.hass.localize("ui.card.timer.actions.start")):"","active"===this.stateObj.state?(0,n.dy)(u||(u=k`
              <mwc-button .action=${0} @click=${0}>
                ${0}
              </mwc-button>
            `),"pause",this._handleActionClick,this.hass.localize("ui.card.timer.actions.pause")):"","active"===this.stateObj.state||"paused"===this.stateObj.state?(0,n.dy)(h||(h=k`
              <mwc-button .action=${0} @click=${0}>
                ${0}
              </mwc-button>
              <mwc-button .action=${0} @click=${0}>
                ${0}
              </mwc-button>
            `),"cancel",this._handleActionClick,this.hass.localize("ui.card.timer.actions.cancel"),"finish",this._handleActionClick,this.hass.localize("ui.card.timer.actions.finish")):"",this.hass,this.stateObj):n.Ld}},{kind:"method",key:"_handleActionClick",value:function(t){const e=t.currentTarget.action;this.hass.callService("timer",e,{entity_id:this.stateObj.entity_id})}},{kind:"field",static:!0,key:"styles",value(){return(0,n.iv)(b||(b=k`.actions{margin:8px 0;display:flex;flex-wrap:wrap;justify-content:center}`))}}]}}),n.oi);a()}catch(d){a(d)}}))}}]);
//# sourceMappingURL=14597.6baf9ea4d8c84fb4.js.map