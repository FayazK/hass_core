"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["58400"],{97604:function(t,i,n){n.a(t,(async function(t,e){try{n.r(i);var s=n(61701),o=(n(52247),n(71695),n(47021),n(57243)),r=n(50778),a=n(69919),h=n(93331),u=n(8069),c=n(62577),d=t([u,a]);[u,a]=d.then?(await d)():d;let f,l,k,y=t=>t;(0,s.Z)([(0,r.Mo)("hui-update-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,h.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const t=this.hass.states[this._config.entity];return t?(0,o.dy)(l||(l=y`
      <hui-generic-entity-row .hass=${0} .config=${0}>
        ${0}
      </hui-generic-entity-row>
    `),this.hass,this._config,(0,a.Ym)(t,this.hass)):(0,o.dy)(f||(f=y`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,c.i)(this.hass,this._config.entity))}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(k||(k=y`div{text-align:right}`))}}]}}),o.oi);e()}catch(f){e(f)}}))}}]);
//# sourceMappingURL=58400.0c67cfa41a1be2b6.js.map