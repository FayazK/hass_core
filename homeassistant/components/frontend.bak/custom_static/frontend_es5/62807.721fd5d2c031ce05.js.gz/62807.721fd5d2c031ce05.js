"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["62807"],{4322:function(a,e,i){i.a(a,(async function(a,e){try{var n=i(61701),t=(i(71695),i(47021),i(57243)),s=i(50778),o=i(36522),c=(i(19993),i(74633),i(42603)),l=i(7111),d=i(26779),h=i(93913),u=a([d]);d=(u.then?(await u)():u)[0];let r,g,p,_=a=>a;const k="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z";(0,n.Z)([(0,s.Mo)("ha-backup-config-encryption-key")],(function(a,e){return{F:class extends e{constructor(...e){super(...e),a(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"value",value:void 0},{kind:"get",key:"_value",value:function(){var a;return null!==(a=this.value)&&void 0!==a?a:""}},{kind:"method",key:"render",value:function(){return this._value?(0,t.dy)(r||(r=_`
        <ha-md-list>
          <ha-md-list-item>
            <span slot="headline">
              ${0}
            </span>
            <span slot="supporting-text">
              ${0}
            </span>
            <ha-button slot="end" @click=${0}>
              <ha-svg-icon .path=${0} slot="icon"></ha-svg-icon>
              ${0}
            </ha-button>
          </ha-md-list-item>
          <ha-md-list-item>
            <span slot="headline">
              ${0}
            </span>
            <span slot="supporting-text">
              ${0}
            </span>
            <ha-button slot="end" @click=${0}>
              ${0}
            </ha-button>
          </ha-md-list-item>
          <ha-md-list-item>
            <span slot="headline">
              ${0}
            </span>
            <span slot="supporting-text">
              ${0}
            </span>
            <ha-button class="danger" slot="end" @click=${0}>
              ${0}
            </ha-button>
          </ha-md-list-item>
        </ha-md-list>
      `),this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit"),this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description"),this._download,k,this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action"),this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key"),this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key_description"),this._show,this.hass.localize("ui.panel.config.backup.encryption_key.show_encryption_key_action"),this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key"),this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key_description"),this._change,this.hass.localize("ui.panel.config.backup.encryption_key.change_encryption_key_action")):(0,t.dy)(g||(g=_`
      <ha-md-list>
        <ha-md-list-item>
          <span slot="headline">
            ${0}</span>
          <span slot="supporting-text">
            ${0}
          </span>
          <ha-button slot="end" @click=${0}>
            ${0}</ha-button>
        </ha-md-list-item>
      </ha-md-list>
    `),this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key"),this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key_description"),this._set,this.hass.localize("ui.panel.config.backup.encryption_key.set_encryption_key_action"))}},{kind:"method",key:"_download",value:function(){this._value&&(0,d.VY)(this.hass,this._value)}},{kind:"method",key:"_show",value:function(){(0,h.i)(this,{currentKey:this._value})}},{kind:"method",key:"_change",value:function(){(0,c.k)(this,{currentKey:this._value,saveKey:a=>{(0,o.B)(this,"value-changed",{value:a})}})}},{kind:"method",key:"_set",value:function(){(0,l.S)(this,{saveKey:a=>{(0,o.B)(this,"value-changed",{value:a})}})}},{kind:"field",static:!0,key:"styles",value(){return(0,t.iv)(p||(p=_`ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-md-list-item{--md-item-overflow:visible}.danger{--mdc-theme-primary:var(--error-color)}`))}}]}}),t.oi);e()}catch(r){e(r)}}))},42603:function(a,e,i){i.d(e,{k:()=>s});i(71695),i(19423),i(40251),i(47021);var n=i(36522);const t=()=>Promise.all([i.e("7442"),i.e("50437")]).then(i.bind(i,36943)),s=(a,e)=>new Promise((i=>{const s=null==e?void 0:e.cancel,o=null==e?void 0:e.submit;(0,n.B)(a,"show-dialog",{dialogTag:"ha-dialog-change-backup-encryption-key",dialogImport:t,dialogParams:Object.assign(Object.assign({},e),{},{cancel:()=>{i(!1),s&&s()},submit:a=>{i(a),o&&o(a)}})})}))},84941:function(a,e,i){i.d(e,{s:()=>t});i(71695),i(40251),i(47021);var n=i(36522);const t=(a,e)=>{(0,n.B)(a,"show-dialog",{dialogTag:"dialog-local-backup-location",dialogImport:()=>i.e("33602").then(i.bind(i,74136)),dialogParams:e})}},7111:function(a,e,i){i.d(e,{S:()=>s});i(71695),i(19423),i(40251),i(47021);var n=i(36522);const t=()=>Promise.all([i.e("7442"),i.e("28501")]).then(i.bind(i,82023)),s=(a,e)=>new Promise((i=>{const s=null==e?void 0:e.cancel,o=null==e?void 0:e.submit;(0,n.B)(a,"show-dialog",{dialogTag:"ha-dialog-set-backup-encryption-key",dialogImport:t,dialogParams:Object.assign(Object.assign({},e),{},{cancel:()=>{i(!1),s&&s()},submit:a=>{i(a),o&&o(a)}})})}))},93913:function(a,e,i){i.d(e,{i:()=>s});i(71695),i(40251),i(47021);var n=i(36522);const t=()=>Promise.all([i.e("7442"),i.e("99091")]).then(i.bind(i,70697)),s=(a,e)=>(0,n.B)(a,"show-dialog",{dialogTag:"ha-dialog-show-backup-encryption-key",dialogImport:t,dialogParams:e})},13310:function(a,e,i){i.a(a,(async function(a,n){try{i.r(e);var t=i(61701),s=i(72621),o=(i(71695),i(19423),i(40251),i(47021),i(57243)),c=i(50778),l=i(72344),d=i(36522),h=i(87707),u=i(22381),r=i(76320),g=(i(59826),i(34273),i(54977),i(23334),i(13928),i(7285),i(99426),i(34326),i(37583),i(26779)),p=(i(87979),i(68545)),_=(i(5131),i(4322)),k=i(6384),f=i(84941),b=i(73192),v=a([p,_,k,g]);[p,_,k,g]=v.then?(await v)():v;let y,m,$,w,C,A=a=>a;const z="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",L="M6,2H18A2,2 0 0,1 20,4V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V4A2,2 0 0,1 6,2M12,4A6,6 0 0,0 6,10C6,13.31 8.69,16 12.1,16L11.22,13.77C10.95,13.29 11.11,12.68 11.59,12.4L12.45,11.9C12.93,11.63 13.54,11.79 13.82,12.27L15.74,14.69C17.12,13.59 18,11.9 18,10A6,6 0 0,0 12,4M12,9A1,1 0 0,1 13,10A1,1 0 0,1 12,11A1,1 0 0,1 11,10A1,1 0 0,1 12,9M7,18A1,1 0 0,0 6,19A1,1 0 0,0 7,20A1,1 0 0,0 8,19A1,1 0 0,0 7,18M12.09,13.27L14.58,19.58L17.17,18.08L12.95,12.77L12.09,13.27Z",H="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z";(0,t.Z)([(0,c.Mo)("ha-config-backup-settings")],(function(a,e){class i extends e{constructor(...e){super(...e),a(this)}}return{F:i,d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"cloudStatus",value:void 0},{kind:"field",decorators:[(0,c.Cb)({type:Boolean})],key:"narrow",value(){return!1}},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"agents",value(){return[]}},{kind:"field",decorators:[(0,c.SB)()],key:"_config",value:void 0},{kind:"method",key:"willUpdate",value:function(a){(0,s.Z)(i,"willUpdate",this,3)([a]),a.has("config")&&!this._config&&(this._config=this.config)}},{kind:"method",key:"connectedCallback",value:function(){(0,s.Z)(i,"connectedCallback",this,3)([]),this._scrollToSection(),this._config=this.config}},{kind:"method",key:"_scrollToSection",value:async function(){var a,e;if("locations"===window.location.hash.substring(1)&&(0,l.p)(this.hass,"hassio")&&(null===(a=this._config)||void 0===a||!a.create_backup.include_all_addons)&&null!==(e=this._config)&&void 0!==e&&null!==(e=e.create_backup.include_addons)&&void 0!==e&&e.length)return this.addEventListener("backup-addons-fetched",(async()=>{await(0,r.y)(),this._scrolltoHash()})),void setTimeout((()=>{this._clearHash()}),500);await(0,r.y)(),this._scrolltoHash()}},{kind:"method",key:"_scrolltoHash",value:function(){const a=window.location.hash.substring(1);if(a){const e=this.shadowRoot.getElementById(a);null==e||e.scrollIntoView(),this._clearHash()}}},{kind:"method",key:"_clearHash",value:function(){history.replaceState(null,"",window.location.pathname)}},{kind:"method",key:"render",value:function(){if(!this._config)return o.Ld;const a=(0,l.p)(this.hass,"hassio");return(0,o.dy)(y||(y=A`
      <hass-subpage back-path="/config/backup" .hass=${0} .narrow=${0} .header=${0}>
        ${0}

        <div class="content">
          <ha-card id="schedule">
            <div class="card-header">
              ${0}
            </div>
            <div class="card-content">
              <p>
                ${0}
              </p>
              <ha-backup-config-schedule .hass=${0} .value=${0} @value-changed=${0}></ha-backup-config-schedule>
            </div>
          </ha-card>
          <ha-card id="data">
            <div class="card-header">
              ${0}
            </div>
            <div class="card-content">
              <ha-backup-config-data .hass=${0} .value=${0} @value-changed=${0} force-home-assistant hide-addon-version></ha-backup-config-data>
            </div>
          </ha-card>

          <ha-card class="agents" id="locations">
            <div class="card-header">
              ${0}
            </div>
            <div class="card-content">
              <p>
                ${0}
              </p>
              <ha-backup-config-agents .hass=${0} .value=${0} .agentsConfig=${0} .cloudStatus=${0} .agents=${0} @value-changed=${0} show-settings></ha-backup-config-agents>
              ${0}
            </div>
            <div class="card-actions">
              <a href=${0} target="_blank" rel="noreferrer">
                <ha-button>
                  <ha-svg-icon slot="icon" .path=${0}></ha-svg-icon>
                  ${0}
                </ha-button>
              </a>
              ${0}
            </div>
          </ha-card>
          <ha-card>
            <div class="card-header">
              ${0}
            </div>
            <div class="card-content">
              <p>
                ${0}
              </p>
              <ha-backup-config-encryption-key .hass=${0} .value=${0} @value-changed=${0}></ha-backup-config-encryption-key>
            </div>
          </ha-card>
        </div>
      </hass-subpage>
    `),this.hass,this.narrow,this.hass.localize("ui.panel.config.backup.settings.header"),a?(0,o.dy)(m||(m=A`
              <ha-button-menu slot="toolbar-icon">
                <ha-icon-button slot="trigger" .label=${0} .path=${0}></ha-icon-button>
                <ha-list-item graphic="icon" @request-selected=${0}>
                  <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
                  ${0}
                </ha-list-item>
              </ha-button-menu>
            `),this.hass.localize("ui.common.menu"),z,this._changeLocalLocation,L,this.hass.localize("ui.panel.config.backup.settings.menu.change_default_location")):o.Ld,this.hass.localize("ui.panel.config.backup.settings.schedule.title"),this.hass.localize("ui.panel.config.backup.settings.schedule.description"),this.hass,this._config,this._scheduleConfigChanged,this.hass.localize("ui.panel.config.backup.settings.data.title"),this.hass,this._dataConfig,this._dataConfigChanged,this.hass.localize("ui.panel.config.backup.settings.locations.title"),this.hass.localize("ui.panel.config.backup.settings.locations.description"),this.hass,this._config.create_backup.agent_ids,this._config.agents,this.cloudStatus,this.agents,this._agentsConfigChanged,this._config.create_backup.agent_ids.length?o.Ld:(0,o.dy)($||($=A`
                    <ha-alert alert-type="warning" .title=${0}>
                      ${0}
                    </ha-alert>
                    <br/>
                  `),this.hass.localize("ui.panel.config.backup.settings.locations.no_location"),this.hass.localize("ui.panel.config.backup.settings.locations.no_location_description")),(0,b.R)(this.hass,"/integrations/#backup"),H,this.hass.localize("ui.panel.config.backup.settings.locations.more_locations"),a?(0,o.dy)(w||(w=A`<a href="/config/storage">
                    <ha-button>
                      ${0}
                    </ha-button>
                  </a>`),this.hass.localize("ui.panel.config.backup.settings.locations.manage_network_storage")):o.Ld,this.hass.localize("ui.panel.config.backup.settings.encryption_key.title"),this.hass.localize("ui.panel.config.backup.settings.encryption_key.description"),this.hass,this._config.create_backup.password,this._encryptionKeyChanged)}},{kind:"method",key:"_changeLocalLocation",value:async function(a){(0,h.Q)(a)&&(0,f.s)(this,{})}},{kind:"method",key:"_scheduleConfigChanged",value:function(a){const e=a.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{schedule:e.schedule,retention:e.retention}),this._debounceSave()}},{kind:"get",key:"_dataConfig",value:function(){const{include_addons:a,include_all_addons:e,include_database:i,include_folders:n}=this._config.create_backup;return{include_homeassistant:!0,include_database:i,include_folders:n||void 0,include_all_addons:e,include_addons:a||void 0}}},{kind:"method",key:"_dataConfigChanged",value:function(a){const e=a.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{create_backup:Object.assign(Object.assign({},this.config.create_backup),{},{include_database:e.include_database,include_folders:e.include_folders||null,include_all_addons:e.include_all_addons,include_addons:e.include_addons||null})}),this._debounceSave()}},{kind:"method",key:"_agentsConfigChanged",value:function(a){const e=a.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{create_backup:Object.assign(Object.assign({},this._config.create_backup),{},{agent_ids:e})}),this._debounceSave()}},{kind:"method",key:"_encryptionKeyChanged",value:function(a){const e=a.detail.value;this._config=Object.assign(Object.assign({},this._config),{},{create_backup:Object.assign(Object.assign({},this._config.create_backup),{},{password:e})}),this._debounceSave()}},{kind:"field",key:"_debounceSave",value(){return(0,u.D)((()=>this._save()),500)}},{kind:"method",key:"_save",value:async function(){var a,e;await(0,g._r)(this.hass,{create_backup:{agent_ids:this._config.create_backup.agent_ids,include_folders:null!==(a=this._config.create_backup.include_folders)&&void 0!==a?a:[],include_database:this._config.create_backup.include_database,include_addons:null!==(e=this._config.create_backup.include_addons)&&void 0!==e?e:[],include_all_addons:this._config.create_backup.include_all_addons,password:this._config.create_backup.password},retention:this._config.retention,schedule:this._config.schedule}),(0,d.B)(this,"ha-refresh-backup-config")}},{kind:"field",static:!0,key:"styles",value(){return(0,o.iv)(C||(C=A`ha-card{scroll-margin-top:16px}.content{padding:28px 20px 0;max-width:690px;margin:0 auto 24px;gap:24px;display:flex;flex-direction:column}.alert{--mdc-theme-primary:var(--error-color)}.card-header{padding-bottom:8px}.card-content{padding-bottom:0}a{text-decoration:none}`))}}]}}),o.oi);n()}catch(y){n(y)}}))}}]);
//# sourceMappingURL=62807.721fd5d2c031ce05.js.map