"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["84933"],{79601:function(t,i,e){e.a(t,(async function(t,a){try{e.r(i),e.d(i,{HaAutomationTrace:()=>q});var o=e(61701),s=e(72621),n=(e(71695),e(61495),e(9359),e(1331),e(52924),e(77439),e(40251),e(19134),e(11740),e(47706),e(88972),e(47021),e(71513),e(75656),e(50100),e(18084),e(87319),e(57243)),r=e(50778),c=e(35359),d=e(91583),h=e(72344),l=e(64214),u=e(36522),_=(e(34273),e(23334),e(81025),e(79315),e(5327)),v=e(81097),k=e(57119),m=e(28639),g=e(43770),p=e(25433),f=e(75244),b=e(76131),$=(e(87979),e(28008)),y=e(20172),w=t([_,v,k,m,l]);[_,v,k,m,l]=w.then?(await w)():w;let I,A,T,x,C,L,E,H,S,z,M,V,N,B,Z,U,P=t=>t;const j="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",O="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",R="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",D="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",J="M1,12L5,16V13H17.17C17.58,14.17 18.69,15 20,15A3,3 0 0,0 23,12A3,3 0 0,0 20,9C18.69,9 17.58,9.83 17.17,11H5V8L1,12Z",F="M23,12L19,16V13H6.83C6.42,14.17 5.31,15 4,15A3,3 0 0,1 1,12A3,3 0 0,1 4,9C5.31,9 6.42,9.83 6.83,11H19V8L23,12Z",Q="M17.65,6.35C16.2,4.9 14.21,4 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20C15.73,20 18.84,17.45 19.73,14H17.65C16.83,16.33 14.61,18 12,18A6,6 0 0,1 6,12A6,6 0 0,1 12,6C13.66,6 15.14,6.69 16.22,7.78L13,11H20V4L17.65,6.35Z",W=["details","automation_config","timeline","logbook"];let q=(0,o.Z)([(0,r.Mo)("ha-automation-trace")],(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"automationId",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"automations",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({type:Boolean,reflect:!0})],key:"narrow",value(){return!1}},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_entityId",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_traces",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_runId",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_selected",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_trace",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_logbookEntries",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_view",value(){return"details"}},{kind:"field",decorators:[(0,r.IO)("hat-script-graph")],key:"_graph",value:void 0},{kind:"method",key:"render",value:function(){var t;const i=this._entityId?this.hass.states[this._entityId]:void 0,e=this._graph,a=null==e?void 0:e.trackedNodes,o=null==e?void 0:e.renderedNodes,s=(null==i?void 0:i.attributes.friendly_name)||this._entityId;return(0,n.dy)(I||(I=P`
      ${0}
      <hass-subpage .hass=${0} .narrow=${0} .header=${0}>
        ${0}
        <ha-button-menu slot="toolbar-icon">
          <ha-icon-button slot="trigger" .label=${0} .path=${0}></ha-icon-button>

          <mwc-list-item graphic="icon" .disabled=${0} @click=${0}>
            ${0}
            <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
          </mwc-list-item>

          ${0}

          <li divider role="separator"></li>

          <mwc-list-item graphic="icon" @click=${0}>
            ${0}
            <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
          </mwc-list-item>

          <mwc-list-item graphic="icon" .disabled=${0} @click=${0}>
            ${0}
            <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
          </mwc-list-item>
        </ha-button-menu>

        <div class="toolbar">
          ${0}
        </div>

        ${0}
      </hass-subpage>
    `),"",this.hass,this.narrow,s,!this.narrow&&null!=i&&i.attributes.id?(0,n.dy)(A||(A=P`
              <a class="trace-link" href="/config/automation/edit/${0}" slot="toolbar-icon">
                <mwc-button>
                  ${0}
                </mwc-button>
              </a>
            `),encodeURIComponent(i.attributes.id),this.hass.localize("ui.panel.config.automation.trace.edit_automation")):"",this.hass.localize("ui.common.menu"),j,!i,this._showInfo,this.hass.localize("ui.panel.config.automation.editor.show_info"),R,null!=i&&i.attributes.id&&this.narrow?(0,n.dy)(T||(T=P`
                <a class="trace-link" href="/config/automation/edit/${0}">
                  <mwc-list-item graphic="icon">
                    ${0}
                    <ha-svg-icon slot="graphic" .path=${0}></ha-svg-icon>
                  </mwc-list-item>
                </a>
              `),encodeURIComponent(i.attributes.id),this.hass.localize("ui.panel.config.automation.trace.edit_automation"),D):"",this._refreshTraces,this.hass.localize("ui.panel.config.automation.trace.refresh"),Q,!this._trace,this._downloadTrace,this.hass.localize("ui.panel.config.automation.trace.download_trace"),O,this._traces&&this._traces.length>0?(0,n.dy)(x||(x=P`
                <ha-icon-button .label=${0} .path=${0} .disabled=${0} @click=${0}></ha-icon-button>
                <select .value=${0} @change=${0}>
                  ${0}
                </select>
                <ha-icon-button .label=${0} .path=${0} .disabled=${0} @click=${0}></ha-icon-button>
              `),this.hass.localize("ui.panel.config.automation.trace.older_trace"),(0,y.HE)(this.hass)?F:J,this._traces[this._traces.length-1].run_id===this._runId,this._pickOlderTrace,this._runId,this._pickTrace,(0,d.r)(this._traces,(t=>t.run_id),(t=>(0,n.dy)(C||(C=P`<option value=${0}>
                        ${0}
                      </option>`),t.run_id,(0,l.E8)(new Date(t.timestamp.start),this.hass.locale,this.hass.config)))),this.hass.localize("ui.panel.config.automation.trace.newer_trace"),(0,y.HE)(this.hass)?J:F,this._traces[0].run_id===this._runId,this._pickNewerTrace):"",void 0===this._traces?(0,n.dy)(L||(L=P`<div class="container">
              ${0}
            </div>`),this.hass.localize("ui.common.loading")):0===this._traces.length?(0,n.dy)(E||(E=P`<div class="container">
                ${0}
              </div>`),this.hass.localize("ui.panel.config.automation.trace.no_traces_found")):void 0===this._trace?"":(0,n.dy)(H||(H=P`
                  <div class="main">
                    <div class="graph">
                      <hat-script-graph .hass=${0} .trace=${0} .selected=${0} @graph-node-selected=${0}></hat-script-graph>
                    </div>

                    <div class="info">
                      <div class="tabs top">
                        ${0}
                        ${0}
                      </div>
                      ${0}
                    </div>
                  </div>
                `),this.hass,this._trace,null===(t=this._selected)||void 0===t?void 0:t.path,this._pickNode,W.map((t=>(0,n.dy)(S||(S=P`
                            <button tabindex="0" .view=${0} class=${0} @click=${0}>
                              ${0}
                            </button>
                          `),t,(0,c.$)({active:this._view===t}),this._showTab,this.hass.localize(`ui.panel.config.automation.trace.tabs.${t}`)))),this._trace.blueprint_inputs?(0,n.dy)(z||(z=P`
                              <button tabindex="0" .view=${0} class=${0} @click=${0}>
                                ${0}
                              </button>
                            `),"blueprint",(0,c.$)({active:"blueprint"===this._view}),this._showTab,this.hass.localize("ui.panel.config.automation.trace.tabs.blueprint_config")):"",void 0===this._selected||void 0===this._logbookEntries||void 0===a?n.Ld:"details"===this._view?(0,n.dy)(M||(M=P`
                              <ha-trace-path-details .hass=${0} .narrow=${0} .trace=${0} .selected=${0} .logbookEntries=${0} .trackedNodes=${0} .renderedNodes=${0}></ha-trace-path-details>
                            `),this.hass,this.narrow,this._trace,this._selected,this._logbookEntries,a,o):"automation_config"===this._view?(0,n.dy)(V||(V=P`
                                <ha-trace-config .hass=${0} .trace=${0}></ha-trace-config>
                              `),this.hass,this._trace):"logbook"===this._view?(0,n.dy)(N||(N=P`
                                  <ha-trace-logbook .hass=${0} .narrow=${0} .trace=${0} .logbookEntries=${0}></ha-trace-logbook>
                                `),this.hass,this.narrow,this._trace,this._logbookEntries):"blueprint"===this._view?(0,n.dy)(B||(B=P`
                                    <ha-trace-blueprint-config .hass=${0} .trace=${0}></ha-trace-blueprint-config>
                                  `),this.hass,this._trace):(0,n.dy)(Z||(Z=P`
                                    <ha-trace-timeline .hass=${0} .trace=${0} .logbookEntries=${0} .selected=${0} @value-changed=${0}></ha-trace-timeline>
                                  `),this.hass,this._trace,this._logbookEntries,this._selected,this._timelinePathPicked)))}},{kind:"method",key:"firstUpdated",value:function(t){if((0,s.Z)(e,"firstUpdated",this,3)([t]),!this.automationId)return;const i=new URLSearchParams(location.search);this._loadTraces(i.get("run_id")||void 0)}},{kind:"method",key:"updated",value:function(t){if((0,s.Z)(e,"updated",this,3)([t]),t.get("automationId")&&(this._traces=void 0,this._entityId=void 0,this._runId=void 0,this._trace=void 0,this._logbookEntries=void 0,this.automationId&&this._loadTraces()),t.has("_runId")&&this._runId&&(this._trace=void 0,this._logbookEntries=void 0,this._loadTrace()),t.has("automations")&&this.automationId&&!this._entityId){const t=this.automations.find((t=>t.attributes.id===this.automationId));this._entityId=null==t?void 0:t.entity_id}}},{kind:"method",key:"_pickOlderTrace",value:function(){const t=this._traces.findIndex((t=>t.run_id===this._runId));this._runId=this._traces[t+1].run_id,this._selected=void 0}},{kind:"method",key:"_pickNewerTrace",value:function(){const t=this._traces.findIndex((t=>t.run_id===this._runId));this._runId=this._traces[t-1].run_id,this._selected=void 0}},{kind:"method",key:"_pickTrace",value:function(t){this._runId=t.target.value,this._selected=void 0}},{kind:"method",key:"_pickNode",value:function(t){this._selected=t.detail}},{kind:"method",key:"_refreshTraces",value:function(){this._loadTraces()}},{kind:"method",key:"_loadTraces",value:async function(t){if(this._traces=await(0,f.lj)(this.hass,"automation",this.automationId),this._traces.reverse(),t&&(this._runId=t),this._runId&&!this._traces.some((t=>t.run_id===this._runId))){if(this._runId=void 0,this._selected=void 0,t){const t=new URLSearchParams(location.search);t.delete("run_id"),history.replaceState(null,"",`${location.pathname}?${t.toString()}`)}await(0,b.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.automation.trace.trace_no_longer_available")})}!this._runId&&this._traces.length>0&&(this._runId=this._traces[0].run_id)}},{kind:"method",key:"_loadTrace",value:async function(){const t=await(0,f.mA)(this.hass,"automation",this.automationId,this._runId);this._logbookEntries=(0,h.p)(this.hass,"logbook")?await(0,p.sS)(this.hass,t.timestamp.start,t.context.id):[],this._trace=t}},{kind:"method",key:"_downloadTrace",value:function(){const t=document.createElement("a");t.download=`trace ${this._entityId} ${this._trace.timestamp.start}.json`,t.href=`data:application/json;charset=utf-8,${encodeURI(JSON.stringify({trace:this._trace,logbookEntries:this._logbookEntries},void 0,2))}`,t.click()}},{kind:"method",key:"_importTrace",value:function(){const t=prompt(this.hass.localize("ui.panel.config.automation.trace.enter_downloaded_trace"));t&&(window.localStorage.setItem("devTrace",t),this._loadLocalTrace(t))}},{kind:"method",key:"_loadLocalStorageTrace",value:function(){const t=window.localStorage.getItem("devTrace");t&&this._loadLocalTrace(t)}},{kind:"method",key:"_loadLocalTrace",value:function(t){const i=JSON.parse(t);this._trace=i.trace,this._logbookEntries=i.logbookEntries}},{kind:"method",key:"_showTab",value:function(t){this._view=t.target.view}},{kind:"method",key:"_timelinePathPicked",value:function(t){const i=t.detail.value,e=this._graph.trackedNodes;e[i]&&(this._selected=e[i])}},{kind:"method",key:"_showInfo",value:function(){this.hass&&this._entityId&&(0,u.B)(this,"hass-more-info",{entityId:this._entityId})}},{kind:"get",static:!0,key:"styles",value:function(){return[$.Qx,g.b,(0,n.iv)(U||(U=P`.toolbar{display:flex;align-items:center;justify-content:center;font-size:20px;height:var(--header-height);padding:4px;background-color:var(--primary-background-color);font-weight:400;color:var(--app-header-text-color,#fff);border-bottom:var(--app-header-border-bottom,none);box-sizing:border-box}.info,.main{background-color:var(--card-background-color)}.main{min-height:calc(100% - var(--header-height));display:flex;direction:ltr}:host([narrow]) .main{height:auto;flex-direction:column}.container{padding:16px}.graph{border-right:1px solid var(--divider-color);overflow-x:auto;max-width:50%;padding-bottom:16px}:host([narrow]) .graph{max-width:100%;justify-content:center;display:flex}.info{flex:1}.trace-link{text-decoration:none}ha-trace-logbook{direction:var(--direction)}`))]}}]}}),n.oi);a()}catch(I){a(I)}}))}}]);
//# sourceMappingURL=84933.8a8144ef0d4b632a.js.map