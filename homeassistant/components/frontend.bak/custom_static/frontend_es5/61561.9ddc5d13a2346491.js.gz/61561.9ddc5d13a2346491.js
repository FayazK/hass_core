"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["61561"],{70251:function(i,s,e){e.a(i,(async function(i,t){try{e.r(s);var a=e(61701),n=e(72621),o=(e(71695),e(40251),e(47021),e(31622),e(57243)),d=e(50778),c=e(36522),l=e(17170),h=e(73729),r=e(79011),u=e(28008),v=i([l]);l=(v.then?(await v)():v)[0];let _,f,L,m,k,g,p,b=i=>i;const y="M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41 10.59L10 14.17L17.59 6.58L19 8L10 17Z",C="M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",$="M22 14H21C21 10.13 17.87 7 14 7H13V5.73C13.6 5.39 14 4.74 14 4C14 2.9 13.11 2 12 2S10 2.9 10 4C10 4.74 10.4 5.39 11 5.73V7H10C6.13 7 3 10.13 3 14H2C1.45 14 1 14.45 1 15V18C1 18.55 1.45 19 2 19H3V20C3 21.11 3.9 22 5 22H19C20.11 22 21 21.11 21 20V19H22C22.55 19 23 18.55 23 18V15C23 14.45 22.55 14 22 14M9.86 16.68L8.68 17.86L7.5 16.68L6.32 17.86L5.14 16.68L6.32 15.5L5.14 14.32L6.32 13.14L7.5 14.32L8.68 13.14L9.86 14.32L8.68 15.5L9.86 16.68M18.86 16.68L17.68 17.86L16.5 16.68L15.32 17.86L14.14 16.68L15.32 15.5L14.14 14.32L15.32 13.14L16.5 14.32L17.68 13.14L18.86 14.32L17.68 15.5L18.86 16.68Z";(0,a.Z)([(0,d.Mo)("dialog-zwave_js-remove-failed-node")],(function(i,s){class e extends s{constructor(...s){super(...s),i(this)}}return{F:e,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"device_id",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_status",value(){return""}},{kind:"field",decorators:[(0,d.SB)()],key:"_error",value:void 0},{kind:"field",decorators:[(0,d.SB)()],key:"_node",value:void 0},{kind:"field",key:"_subscribed",value:void 0},{kind:"method",key:"disconnectedCallback",value:function(){(0,n.Z)(e,"disconnectedCallback",this,3)([]),this._unsubscribe()}},{kind:"method",key:"showDialog",value:async function(i){this.device_id=i.device_id}},{kind:"method",key:"closeDialog",value:function(){this._unsubscribe(),this.device_id=void 0,this._status="",(0,c.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"closeDialogFinished",value:function(){history.back(),this.closeDialog()}},{kind:"method",key:"render",value:function(){return this.device_id?(0,o.dy)(_||(_=b`
      <ha-dialog open @closed=${0} .heading=${0}>
        ${0}
        ${0}
        ${0}
        ${0}
      </ha-dialog>
    `),this.closeDialog,(0,h.i)(this.hass,this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.title")),""===this._status?(0,o.dy)(f||(f=b`
              <div class="flex-container">
                <ha-svg-icon .path=${0} class="introduction"></ha-svg-icon>
                <div class="status">
                  ${0}
                </div>
              </div>
              <mwc-button slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),$,this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.introduction"),this._startExclusion,this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.remove_device")):"","started"===this._status?(0,o.dy)(L||(L=b`
              <div class="flex-container">
                <ha-spinner></ha-spinner>
                <div class="status">
                  <p>
                    <b>
                      ${0}
                    </b>
                  </p>
                </div>
              </div>
            `),this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.in_progress")):"","failed"===this._status?(0,o.dy)(m||(m=b`
              <div class="flex-container">
                <ha-svg-icon .path=${0} class="error"></ha-svg-icon>
                <div class="status">
                  <p>
                    ${0}
                  </p>
                  ${0}
                </div>
              </div>
              <mwc-button slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),C,this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.removal_failed"),this._error?(0,o.dy)(k||(k=b` <p><em> ${0} </em></p> `),this._error.message):"",this.closeDialog,this.hass.localize("ui.common.close")):"","finished"===this._status?(0,o.dy)(g||(g=b`
              <div class="flex-container">
                <ha-svg-icon .path=${0} class="success"></ha-svg-icon>
                <div class="status">
                  <p>
                    ${0}
                  </p>
                </div>
              </div>
              <mwc-button slot="primaryAction" @click=${0}>
                ${0}
              </mwc-button>
            `),y,this.hass.localize("ui.panel.config.zwave_js.remove_failed_node.removal_finished",{id:this._node.node_id}),this.closeDialogFinished,this.hass.localize("ui.common.close")):""):o.Ld}},{kind:"method",key:"_startExclusion",value:function(){this.hass&&(this._status="started",this._subscribed=(0,r.Hr)(this.hass,this.device_id,(i=>this._handleMessage(i))).catch((i=>{this._status="failed",this._error=i})))}},{kind:"method",key:"_handleMessage",value:function(i){"exclusion started"===i.event&&(this._status="started"),"node removed"===i.event&&(this._status="finished",this._node=i.node,this._unsubscribe())}},{kind:"method",key:"_unsubscribe",value:async function(){if(this._subscribed){const i=await this._subscribed;i instanceof Function&&i(),this._subscribed=void 0}"finished"!==this._status&&(this._status="")}},{kind:"get",static:!0,key:"styles",value:function(){return[u.yu,(0,o.iv)(p||(p=b`.success{color:var(--success-color)}.failed{color:var(--warning-color)}.flex-container{display:flex;align-items:center}ha-svg-icon{width:68px;height:48px}.flex-container ha-spinner,.flex-container ha-svg-icon{margin-right:20px;margin-inline-end:20px;margin-inline-start:initial}`))]}}]}}),o.oi);t()}catch(_){t(_)}}))}}]);
//# sourceMappingURL=61561.9ddc5d13a2346491.js.map