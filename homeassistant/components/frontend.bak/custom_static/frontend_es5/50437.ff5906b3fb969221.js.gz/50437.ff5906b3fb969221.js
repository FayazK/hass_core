"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["50437"],{5828:function(e,t,i){i.r(t),i.d(t,{HaIconButtonPrev:()=>r});var n=i(61701),a=(i(71695),i(47021),i(57243)),o=i(50778),s=i(5111);i(23334);let l,d=e=>e;let r=(0,n.Z)([(0,o.Mo)("ha-icon-button-prev")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"disabled",value(){return!1}},{kind:"field",decorators:[(0,o.Cb)()],key:"label",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_icon",value(){return"rtl"===s.E.document.dir?"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z":"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"}},{kind:"method",key:"render",value:function(){var e;return(0,a.dy)(l||(l=d`
      <ha-icon-button .disabled=${0} .label=${0} .path=${0}></ha-icon-button>
    `),this.disabled,this.label||(null===(e=this.hass)||void 0===e?void 0:e.localize("ui.common.back"))||"Back",this._icon)}}]}}),a.oi)},51784:function(e,t,i){i.d(t,{dJ:()=>y,zB:()=>m});var n=i(61701),a=i(72621),o=(i(52247),i(71695),i(19423),i(40251),i(47021),i(67840)),s=i(88854),l=i(57243),d=i(50778);let r,c,h=e=>e;o.A.addInitializer((async e=>{await e.updateComplete;const t=e;t.dialog.prepend(t.scrim),t.scrim.style.inset=0,t.scrim.style.zIndex=0;const{getOpenAnimation:i,getCloseAnimation:n}=t;t.getOpenAnimation=()=>{var e,t;const n=i.call(void 0);return n.container=[...null!==(e=n.container)&&void 0!==e?e:[],...null!==(t=n.dialog)&&void 0!==t?t:[]],n.dialog=[],n},t.getCloseAnimation=()=>{var e,t;const i=n.call(void 0);return i.container=[...null!==(e=i.container)&&void 0!==e?e:[],...null!==(t=i.dialog)&&void 0!==t?t:[]],i.dialog=[],i}}));(0,n.Z)([(0,d.Mo)("ha-md-dialog")],(function(e,t){class n extends t{constructor(){super(),e(this),this.addEventListener("cancel",this._handleCancel),"function"!=typeof HTMLDialogElement&&(this.addEventListener("open",this._handleOpen),c||(c=i.e("73854").then(i.bind(i,85893)))),void 0===this.animate&&(this.quick=!0),void 0===this.animate&&(this.quick=!0)}}return{F:n,d:[{kind:"field",decorators:[(0,d.Cb)({attribute:"disable-cancel-action",type:Boolean})],key:"disableCancelAction",value(){return!1}},{kind:"field",key:"_polyfillDialogRegistered",value(){return!1}},{kind:"method",key:"_handleOpen",value:async function(e){var t;if(e.preventDefault(),this._polyfillDialogRegistered)return;this._polyfillDialogRegistered=!0,this._loadPolyfillStylesheet("/static/polyfills/dialog-polyfill.css");const i=null===(t=this.shadowRoot)||void 0===t?void 0:t.querySelector("dialog");(await c).default.registerDialog(i),this.removeEventListener("open",this._handleOpen),this.show()}},{kind:"method",key:"_loadPolyfillStylesheet",value:async function(e){const t=document.createElement("link");return t.rel="stylesheet",t.href=e,new Promise(((i,n)=>{var a;t.onload=()=>i(),t.onerror=()=>n(new Error(`Stylesheet failed to load: ${e}`)),null===(a=this.shadowRoot)||void 0===a||a.appendChild(t)}))}},{kind:"method",key:"_handleCancel",value:function(e){if(this.disableCancelAction){var t;e.preventDefault();const i=null===(t=this.shadowRoot)||void 0===t?void 0:t.querySelector("dialog .container");void 0!==this.animate&&(null==i||i.animate([{transform:"rotate(-1deg)","animation-timing-function":"ease-in"},{transform:"rotate(1.5deg)","animation-timing-function":"ease-out"},{transform:"rotate(0deg)","animation-timing-function":"ease-in"}],{duration:200,iterations:2}))}}},{kind:"field",static:!0,key:"styles",value(){return[...(0,a.Z)(n,"styles",this),(0,l.iv)(r||(r=h`:host{--md-dialog-container-color:var(--card-background-color);--md-dialog-headline-color:var(--primary-text-color);--md-dialog-supporting-text-color:var(--primary-text-color);--md-sys-color-scrim:#000000;--md-dialog-headline-weight:400;--md-dialog-headline-size:1.574rem;--md-dialog-supporting-text-size:1rem;--md-dialog-supporting-text-line-height:1.5rem}:host([type=alert]){min-width:320px}@media all and (max-width:450px),all and (max-height:500px){:host(:not([type=alert])){min-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));max-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));min-height:100%;max-height:100%;--md-dialog-container-shape:0}}::slotted(ha-dialog-header[slot=headline]){display:contents}.scroller{overflow:var(--dialog-content-overflow,auto)}slot[name=content]::slotted(*){padding:var(--dialog-content-padding,24px)}.scrim{z-index:10}`))]}}]}}),o.A);const p=Object.assign(Object.assign({},s.I),{},{dialog:[[[{transform:"translateY(50px)"},{transform:"translateY(0)"}],{duration:500,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:0},{opacity:1}],{duration:50,easing:"linear",pseudoElement:"::before"}]]}),u=Object.assign(Object.assign({},s.G),{},{dialog:[[[{transform:"translateY(0)"},{transform:"translateY(50px)"}],{duration:150,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:"1"},{opacity:"0"}],{delay:100,duration:50,easing:"linear",pseudoElement:"::before"}]]}),y=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?p:s.I,m=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?u:s.G},36943:function(e,t,i){i.a(e,(async function(e,n){try{i.r(t);var a=i(61701),o=(i(71695),i(40251),i(47021),i(57243)),s=i(50778),l=i(36522),d=i(87865),r=(i(59826),i(95198),i(23334),i(5828),i(51784),i(19993),i(74633),i(34326),i(26779)),c=i(28008),h=i(72473),p=e([r]);r=(p.then?(await p)():p)[0];let u,y,m,g,v,k,_,f,b,w,x=e=>e;const $="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",L="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",z="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",C=["current","new","done"];(0,a.Z)([(0,s.Mo)("ha-dialog-change-backup-encryption-key")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_opened",value(){return!1}},{kind:"field",decorators:[(0,s.SB)()],key:"_step",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,s.IO)("ha-md-dialog")],key:"_dialog",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_newEncryptionKey",value:void 0},{kind:"method",key:"showDialog",value:function(e){this._params=e,this._step=C[0],this._opened=!0,this._newEncryptionKey=(0,r.Ty)()}},{kind:"method",key:"closeDialog",value:function(){return this._params.cancel&&this._params.cancel(),this._opened&&(0,l.B)(this,"dialog-closed",{dialog:this.localName}),this._opened=!1,this._step=void 0,this._params=void 0,this._newEncryptionKey=void 0,!0}},{kind:"method",key:"_done",value:function(){var e;null===(e=this._params)||void 0===e||e.submit(!0),this._dialog.close()}},{kind:"method",key:"_previousStep",value:function(){const e=C.indexOf(this._step);0!==e&&(this._step=C[e-1])}},{kind:"method",key:"_nextStep",value:function(){const e=C.indexOf(this._step);e!==C.length-1&&(this._step=C[e+1])}},{kind:"method",key:"render",value:function(){if(!this._opened||!this._params)return o.Ld;const e="current"===this._step||"new"===this._step?this.hass.localize(`ui.panel.config.backup.dialogs.change_encryption_key.${this._step}.title`):"";return(0,o.dy)(u||(u=x`
      <ha-md-dialog disable-cancel-action open @closed=${0}>
        <ha-dialog-header slot="headline">
          ${0}
          <span slot="title">${0}</span>
        </ha-dialog-header>
        <div slot="content">${0}</div>
        <div slot="actions">
          ${0}
        </div>
      </ha-md-dialog>
    `),this.closeDialog,"new"===this._step?(0,o.dy)(y||(y=x`
                <ha-icon-button-prev slot="navigationIcon" @click=${0}></ha-icon-button-prev>
              `),this._previousStep):(0,o.dy)(m||(m=x`
                <ha-icon-button slot="navigationIcon" .label=${0} .path=${0} @click=${0}></ha-icon-button>
              `),this.hass.localize("ui.common.close"),$,this.closeDialog),e,this._renderStepContent(),"current"===this._step?(0,o.dy)(g||(g=x`
                <ha-button @click=${0}>
                  ${0}
                </ha-button>
              `),this._nextStep,this.hass.localize("ui.common.next")):"new"===this._step?(0,o.dy)(v||(v=x`
                  <ha-button @click=${0} .disabled=${0} class="danger">
                    ${0}
                  </ha-button>
                `),this._submit,!this._newEncryptionKey,this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.actions.change")):(0,o.dy)(k||(k=x`
                  <ha-button @click=${0}>
                    ${0}
                  </ha-button>
                `),this._done,this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.actions.done")))}},{kind:"method",key:"_renderStepContent",value:function(){var e;switch(this._step){case"current":return(0,o.dy)(_||(_=x`
          <p>
            ${0}
          </p>
          <div class="encryption-key">
            <p>${0}</p>
            <ha-icon-button .path=${0} @click=${0}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-button slot="end" @click=${0}>
                <ha-svg-icon .path=${0} slot="icon"></ha-svg-icon>
                ${0}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `),this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.current.description"),null===(e=this._params)||void 0===e?void 0:e.currentKey,L,this._copyOldKeyToClipboard,this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit"),this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit_description"),this._downloadOld,z,this.hass.localize("ui.panel.config.backup.encryption_key.download_old_emergency_kit_action"));case"new":return(0,o.dy)(f||(f=x`
          <p>
            ${0}
          </p>
          <div class="encryption-key">
            <p>${0}</p>
            <ha-icon-button .path=${0} @click=${0}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${0}
              </span>
              <span slot="supporting-text">
                ${0}
              </span>
              <ha-button slot="end" @click=${0}>
                <ha-svg-icon .path=${0} slot="icon"></ha-svg-icon>
                ${0}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `),this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.new.description"),this._newEncryptionKey,L,this._copyKeyToClipboard,this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit"),this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description"),this._downloadNew,z,this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action"));case"done":return(0,o.dy)(b||(b=x`
          <div class="done">
            <img src="/static/images/voice-assistant/hi.png" alt="Casita ASCIA logo"/>
            <h1>
              ${0}
            </h1>
          </div>
        `),this.hass.localize("ui.panel.config.backup.dialogs.change_encryption_key.done.title"))}return o.Ld}},{kind:"method",key:"_copyKeyToClipboard",value:async function(){await(0,d.v)(this._newEncryptionKey,this.renderRoot.querySelector("div")),(0,h.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}},{kind:"method",key:"_copyOldKeyToClipboard",value:async function(){var e;null!==(e=this._params)&&void 0!==e&&e.currentKey&&(await(0,d.v)(this._params.currentKey,this.renderRoot.querySelector("div")),(0,h.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")}))}},{kind:"method",key:"_downloadOld",value:function(){var e;null!==(e=this._params)&&void 0!==e&&e.currentKey&&(0,r.VY)(this.hass,this._params.currentKey,"old")}},{kind:"method",key:"_downloadNew",value:function(){this._newEncryptionKey&&(0,r.VY)(this.hass,this._newEncryptionKey)}},{kind:"method",key:"_submit",value:async function(){this._newEncryptionKey&&(this._params.saveKey(this._newEncryptionKey),this._nextStep())}},{kind:"get",static:!0,key:"styles",value:function(){return[c.Qx,c.yu,(0,o.iv)(w||(w=x`.done,.encryption-key p{text-align:center}ha-md-dialog{width:90vw;max-width:560px;--dialog-content-padding:8px 24px}ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-button.danger{--mdc-theme-primary:var(--error-color)}.encryption-key{border:1px solid var(--divider-color);background-color:var(--primary-background-color);border-radius:8px;padding:16px;display:flex;flex-direction:row;align-items:center;gap:24px}.encryption-key p{margin:0;flex:1;font-family:"Roboto Mono",Consolas,Menlo,monospace;font-size:20px;font-style:normal;font-weight:400;line-height:28px}.encryption-key ha-icon-button{flex:none;margin:-16px}@media all and (max-width:450px),all and (max-height:500px){ha-md-dialog{max-width:none}div[slot=content]{margin-top:0}}p{margin-top:0}`))]}}]}}),o.oi);n()}catch(u){n(u)}}))}}]);
//# sourceMappingURL=50437.ff5906b3fb969221.js.map