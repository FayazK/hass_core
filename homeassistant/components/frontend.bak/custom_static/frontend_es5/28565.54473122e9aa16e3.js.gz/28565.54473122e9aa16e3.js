"use strict";(self.webpackChunkhome_assistant_frontend=self.webpackChunkhome_assistant_frontend||[]).push([["28565"],{51973:function(t,i,e){e.a(t,(async function(t,s){try{e.r(i);var n=e(61701),a=e(72621),o=(e(52247),e(71695),e(40251),e(47021),e(57243)),c=e(50778),d=e(35359),r=e(20552),h=e(47194),l=e(96194),u=e(49319),f=e(3967),_=e(1617),v=e(5684),b=e(93331),y=e(8069),g=e(62577),k=t([y]);y=(k.then?(await k)():k)[0];let p,m,$,x,w,C,E,F=t=>t;(0,n.Z)([(0,c.Mo)("hui-weather-entity-row")],(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,c.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,c.SB)()],key:"_forecastEvent",value:void 0},{kind:"field",decorators:[(0,c.SB)()],key:"_subscribed",value:void 0},{kind:"method",key:"_unsubscribeForecastEvents",value:function(){this._subscribed&&(this._subscribed.then((t=>t())),this._subscribed=void 0)}},{kind:"method",key:"_subscribeForecastEvents",value:async function(){if(this._unsubscribeForecastEvents(),!this.hass||!this._config||!this.isConnected)return;const t=this.hass.states[this._config.entity],i=(0,u.k5)(t);i&&(this._subscribed=(0,u.MC)(this.hass,t.entity_id,i,(t=>{this._forecastEvent=t})))}},{kind:"method",key:"connectedCallback",value:function(){(0,a.Z)(e,"connectedCallback",this,3)([]),this.hasUpdated&&this._subscribeForecastEvents()}},{kind:"method",key:"disconnectedCallback",value:function(){(0,a.Z)(e,"disconnectedCallback",this,3)([]),this._unsubscribeForecastEvents()}},{kind:"method",key:"setConfig",value:function(t){if(null==t||!t.entity)throw new Error("Entity must be specified");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,b.G2)(this,t)||t.size>1||!t.has("hass")}},{kind:"method",key:"updated",value:function(t){(0,a.Z)(e,"updated",this,3)([t]),!t.has("_config")&&this._subscribed||this._subscribeForecastEvents()}},{kind:"method",key:"render",value:function(){if(!this.hass||!this._config)return o.Ld;const t=this.hass.states[this._config.entity];if(!t)return(0,o.dy)(p||(p=F`
        <hui-warning>
          ${0}
        </hui-warning>
      `),(0,g.i)(this.hass,this._config.entity));const i=(0,v.q)(this._config),e=this._config.secondary_info,s=(0,u.Cq)(t.state,this),n=(0,u.Rt)(t.attributes,this._forecastEvent),a=null==n?void 0:n.forecast;return(0,o.dy)(m||(m=F`
      <div class="icon-image ${0}" @action=${0} .actionHandler=${0} tabindex=${0}>
        ${0}
      </div>
      <div class="info ${0}" @action=${0} .actionHandler=${0}>
        ${0}
        ${0}
      </div>
      <div class="attributes ${0}" @action=${0} .actionHandler=${0}>
        <div>
          ${0}
        </div>
        <div class="secondary">
          ${0}
        </div>
      </div>
    `),(0,d.$)({pointer:i}),this._handleAction,(0,f.K)({hasHold:(0,v._)(this._config.hold_action),hasDoubleClick:(0,v._)(this._config.double_tap_action)}),(0,r.o)(!this._config.tap_action||(0,v._)(this._config.tap_action)?"0":void 0),s||(0,o.dy)($||($=F`
          <ha-state-icon class="weather-icon" .stateObj=${0} .hass=${0}></ha-state-icon>
        `),t,this.hass),(0,d.$)({pointer:i,"text-content":!e}),this._handleAction,(0,f.K)({hasHold:(0,v._)(this._config.hold_action),hasDoubleClick:(0,v._)(this._config.double_tap_action)}),this._config.name||(0,h.C)(t),e?(0,o.dy)(x||(x=F`
              <div class="secondary">
                ${0}
              </div>
            `),"entity-id"===this._config.secondary_info?t.entity_id:"last-changed"===this._config.secondary_info?(0,o.dy)(w||(w=F`
                        <ha-relative-time .hass=${0} .datetime=${0} capitalize></ha-relative-time>
                      `),this.hass,t.last_changed):"last-updated"===this._config.secondary_info?(0,o.dy)(C||(C=F`
                          <ha-relative-time .hass=${0} .datetime=${0} capitalize></ha-relative-time>
                        `),this.hass,t.last_updated):""):"",(0,d.$)({pointer:i}),this._handleAction,(0,f.K)({hasHold:(0,v._)(this._config.hold_action),hasDoubleClick:(0,v._)(this._config.double_tap_action)}),(0,l.rk)(t.state)||void 0===t.attributes.temperature||null===t.attributes.temperature?this.hass.formatEntityState(t):this.hass.formatEntityAttributeValue(t,"temperature"),(0,u.k2)(this.hass,t,a))}},{kind:"method",key:"_handleAction",value:function(t){(0,_.G)(this,this.hass,this._config,t.detail.action)}},{kind:"get",static:!0,key:"styles",value:function(){return[u.A$,(0,o.iv)(E||(E=F`.attributes,.info{margin-inline-end:initial}:host{display:flex;align-items:center;flex-direction:row}.info{margin-left:16px;margin-inline-start:16px;flex:1 0 60px}.info,.info>*{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.icon-image{display:flex;align-items:center;min-width:40px}.icon-image>*{flex:0 0 40px;height:40px}.icon-image:focus{outline:0;background-color:var(--divider-color);border-radius:50%}.weather-icon{--mdc-icon-size:40px}.pointer{cursor:pointer}.attributes{display:flex;flex-direction:column;justify-content:center;text-align:right;margin-left:8px;margin-inline-start:8px}.secondary{color:var(--secondary-text-color)}`))]}}]}}),o.oi);s()}catch(p){s(p)}}))}}]);
//# sourceMappingURL=28565.54473122e9aa16e3.js.map