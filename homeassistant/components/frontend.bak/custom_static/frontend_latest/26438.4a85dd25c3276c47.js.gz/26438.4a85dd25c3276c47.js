export const __webpack_ids__=["26438"];export const __webpack_modules__={93665:function(i,e,n){n.r(e);var t=n(44249),r=n(57243),o=n(15093);(0,t.Z)([(0,o.Mo)("hui-section-row")],(function(i,e){return{F:class extends e{constructor(...e){super(...e),i(this)}},d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(i){if(!i)throw new Error("Invalid configuration");this._config=i}},{kind:"method",key:"render",value:function(){return this._config?r.dy`
      <div class="divider"></div>
      ${this._config.label?r.dy`
            <div class="label" .title=${this._config.label}>
              ${this._config.label}
            </div>
          `:r.Ld}
    `:r.Ld}},{kind:"field",static:!0,key:"styles",value:()=>r.iv`.label{color:var(--section-header-text-color,var(--primary-text-color));margin-left:8px;margin-inline-start:8px;margin-inline-end:initial;margin-bottom:8px;margin-top:16px;font-weight:500}.divider{height:1px;background-color:var(--entities-divider-color,var(--divider-color));margin-left:-16px;margin-right:-16px;margin-inline-start:-16px;margin-inline-end:-16px;margin-top:8px}`}]}}),r.oi)}};
//# sourceMappingURL=26438.4a85dd25c3276c47.js.map