export const __webpack_ids__=["53403"];export const __webpack_modules__={279:function(e,t,i){i.d(t,{Qc:()=>c,Xr:()=>o,zJ:()=>d});i(9359),i(31526),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814);const a=["zone","persistent_notification"],s=(e,t)=>{if("call-service"!==t.action||!t.target?.entity_id&&!t.service_data?.entity_id&&!t.data?.entity_id)return;let i=t.service_data?.entity_id??t.data?.entity_id??t.target?.entity_id;Array.isArray(i)||(i=[i]);for(const t of i)e.add(t)},r=(e,t)=>{t&&("string"!=typeof t?(t.entity&&e.add(t.entity),t.camera_image&&e.add(t.camera_image),t.tap_action&&s(e,t.tap_action),t.hold_action&&s(e,t.hold_action)):e.add(t))},n=(e,t)=>{t.entity&&r(e,t.entity),t.entities&&Array.isArray(t.entities)&&t.entities.forEach((t=>r(e,t))),t.card&&n(e,t.card),t.cards&&Array.isArray(t.cards)&&t.cards.forEach((t=>n(e,t))),t.elements&&Array.isArray(t.elements)&&t.elements.forEach((t=>n(e,t))),t.badges&&Array.isArray(t.badges)&&t.badges.forEach((t=>r(e,t))),t.sections&&Array.isArray(t.sections)&&t.sections.forEach((t=>n(e,t)))},d=e=>{const t=new Set;return e.views.forEach((e=>{n(t,e)})),t},o=(e,t)=>{const i=new Set;for(const s of Object.keys(e.states))t.has(s)||a.includes(s.split(".",1)[0])||i.add(s);return i},c=(e,t)=>{const i=d(t);return o(e,i)}},3054:function(e,t,i){i.a(e,(async function(e,t){try{var a=i(44249),s=(i(9359),i(56475),i(70104),i(41298)),r=i(57243),n=i(15093),d=i(35359),o=i(69634),c=i(94571),l=i(27486),h=i(68958),p=i(36522),u=i(1416),y=i(17170),m=(i(36841),i(96194)),v=i(17951),g=i(279),f=i(62037),_=i(32817),k=i(33873),w=e([y,f,_]);[y,f,_]=w.then?(await w)():w;(0,a.Z)([(0,n.Mo)("hui-card-picker")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"suggestedCards",value:void 0},{kind:"field",decorators:[(0,h.t)({key:"dashboardCardClipboard",state:!0,subscribe:!0,storage:"sessionStorage"})],key:"_clipboard",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_cards",value:()=>[]},{kind:"field",key:"lovelace",value:void 0},{kind:"field",key:"cardPicked",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_filter",value:()=>""},{kind:"field",decorators:[(0,n.SB)()],key:"_width",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_height",value:void 0},{kind:"field",key:"_unusedEntities",value:void 0},{kind:"field",key:"_usedEntities",value:void 0},{kind:"method",key:"focus",value:async function(){const e=this.renderRoot.querySelector("search-input");e?e.focus():(await this.updateComplete,this.focus())}},{kind:"field",key:"_filterCards",value:()=>(0,l.Z)(((e,t)=>{if(!t)return e;let i=e.map((e=>e.card));const a={keys:["type","name","description"],isCaseSensitive:!1,minMatchCharLength:Math.min(t.length,2),threshold:.2,ignoreDiacritics:!0},r=new s.Z(i,a);return i=r.search(t).map((e=>e.item)),e.filter((e=>i.includes(e.card)))}))},{kind:"field",key:"_suggestedCards",value:()=>(0,l.Z)((e=>e.filter((e=>e.card.isSuggested))))},{kind:"field",key:"_customCards",value:()=>(0,l.Z)((e=>e.filter((e=>e.card.isCustom&&!e.card.isSuggested))))},{kind:"field",key:"_otherCards",value:()=>(0,l.Z)((e=>e.filter((e=>!e.card.isSuggested&&!e.card.isCustom))))},{kind:"method",key:"render",value:function(){if(!(this.hass&&this.lovelace&&this._unusedEntities&&this._usedEntities))return r.Ld;const e=this._suggestedCards(this._cards),t=this._otherCards(this._cards),i=this._customCards(this._cards);return r.dy`
      <search-input .hass=${this.hass} .filter=${this._filter} @value-changed=${this._handleSearchChange} .label=${this.hass.localize("ui.panel.lovelace.editor.edit_card.search_cards")}></search-input>
      <div id="content" style=${(0,o.V)({width:this._width?`${this._width}px`:"auto",height:this._height?`${this._height}px`:"auto"})}>
        ${this._filter?r.dy`<div class="cards-container">
              ${this._filterCards(this._cards,this._filter).map((e=>e.element))}
            </div>`:r.dy`
              <div class="cards-container">
                ${e.length>0?r.dy`
                      <div class="cards-container-header">
                        ${this.hass.localize("ui.panel.lovelace.editor.card.generic.suggested_cards")}
                      </div>
                    `:r.Ld}
                ${this._renderClipboardCard()}
                ${e.map((e=>e.element))}
              </div>
              <div class="cards-container">
                ${e.length>0?r.dy`
                      <div class="cards-container-header">
                        ${this.hass.localize("ui.panel.lovelace.editor.card.generic.other_cards")}
                      </div>
                    `:r.Ld}
                ${t.map((e=>e.element))}
              </div>
              <div class="cards-container">
                ${i.length>0?r.dy`
                      <div class="cards-container-header">
                        ${this.hass.localize("ui.panel.lovelace.editor.card.generic.custom_cards")}
                      </div>
                    `:r.Ld}
                ${i.map((e=>e.element))}
              </div>
            `}
        <div class="cards-container">
          <div class="card manual" @click=${this._cardPicked} .config=${{type:""}}>
            <div class="card-header">
              ${this.hass.localize("ui.panel.lovelace.editor.card.generic.manual")}
            </div>
            <div class="preview description">
              ${this.hass.localize("ui.panel.lovelace.editor.card.generic.manual_description")}
            </div>
            <ha-ripple></ha-ripple>
          </div>
        </div>
      </div>
    `}},{kind:"method",key:"shouldUpdate",value:function(e){const t=e.get("hass");return!t||t.locale!==this.hass.locale}},{kind:"method",key:"firstUpdated",value:function(){if(!this.hass||!this.lovelace)return;const e=(0,g.zJ)(this.lovelace),t=(0,g.Xr)(this.hass,e);this._usedEntities=[...e].filter((e=>this.hass.states[e]&&!(0,m.rk)(this.hass.states[e].state))),this._unusedEntities=[...t].filter((e=>this.hass.states[e]&&!(0,m.rk)(this.hass.states[e].state))),this._loadCards()}},{kind:"method",key:"_loadCards",value:function(){let e=k.C.map((e=>({name:this.hass.localize(`ui.panel.lovelace.editor.card.${e.type}.name`),description:this.hass.localize(`ui.panel.lovelace.editor.card.${e.type}.description`),isSuggested:this.suggestedCards?.includes(e.type)||!1,...e})));e=e.sort(((e,t)=>e.isSuggested&&!t.isSuggested?-1:!e.isSuggested&&t.isSuggested?1:(0,u.$K)(e.name||e.type,t.name||t.type,this.hass?.language))),v.kb.length>0&&(e=e.concat(v.kb.map((e=>({type:e.type,name:e.name,description:e.description,showElement:e.preview,isCustom:!0}))).sort(((e,t)=>(0,u.$K)(e.name||e.type,t.name||t.type,this.hass?.language))))),this._cards=e.map((e=>({card:e,element:r.dy`${(0,c.C)(this._renderCardElement(e),r.dy`
          <div class="card spinner">
            <ha-spinner></ha-spinner>
          </div>
        `)}`})))}},{kind:"method",key:"_renderClipboardCard",value:function(){return this._clipboard?r.dy` ${(0,c.C)(this._renderCardElement({type:this._clipboard.type,showElement:!0,isCustom:!1,name:this.hass.localize("ui.panel.lovelace.editor.card.generic.paste"),description:`${this.hass.localize("ui.panel.lovelace.editor.card.generic.paste_description",{type:this._clipboard.type})}`},this._clipboard),r.dy`
        <div class="card spinner">
          <ha-spinner></ha-spinner>
        </div>
      `)}`:r.Ld}},{kind:"method",key:"_handleSearchChange",value:function(e){const t=e.detail.value;if(t){if(!this._width||!this._height){const e=this.shadowRoot.getElementById("content");if(e&&!this._width){const t=e.clientWidth;t&&(this._width=t)}if(e&&!this._height){const t=e.clientHeight;t&&(this._height=t)}}}else this._width=void 0,this._height=void 0;this._filter=t}},{kind:"method",key:"_cardPicked",value:function(e){const t=e.currentTarget.config;(0,p.B)(this,"config-changed",{config:t})}},{kind:"method",key:"_tryCreateCardElement",value:function(e){const t=(0,f.l$)(e);return t.hass=this.hass,t.addEventListener("ll-rebuild",(i=>{i.stopPropagation(),this._rebuildCard(t,e)}),{once:!0}),t}},{kind:"method",key:"_rebuildCard",value:function(e,t){let i;try{i=this._tryCreateCardElement(t)}catch(e){return}e.parentElement&&e.parentElement.replaceChild(i,e)}},{kind:"method",key:"_renderCardElement",value:async function(e,t){let{type:i}=e;const{showElement:a,isCustom:s,name:n,description:o}=e,c=s?(0,v.cs)(i):void 0;let l;s&&(i=`${v.Qo}${i}`);let h=t??{type:i};if(this.hass&&this.lovelace&&(t||(h=await(0,_.U)(this.hass,i,this._unusedEntities,this._usedEntities)),a))try{l=this._tryCreateCardElement(h)}catch(e){l=void 0}return l&&(l.tabIndex=-1),r.dy`
      <div class="card" tabindex="0">
        <div class="overlay" @click=${this._cardPicked} .config=${h}></div>
        <div class="card-header">
          ${c?c.name||c.type:n}
        </div>
        <div class="preview ${(0,d.$)({description:!l||"HUI-ERROR-CARD"===l.tagName})}">
          ${l&&"HUI-ERROR-CARD"!==l.tagName?l:c?c.description||this.hass.localize("ui.panel.lovelace.editor.cardpicker.no_description"):o}
        </div>
        <ha-ripple></ha-ripple>
      </div>
    `}},{kind:"get",static:!0,key:"styles",value:function(){return[r.iv`.card-header,.description{text-align:center}search-input{display:block;--mdc-shape-small:var(--card-picker-search-shape);margin:var(--card-picker-search-margin);position:sticky;top:0;z-index:10;background-color:var(--ha-dialog-surface-background,var(--mdc-theme-surface,#fff))}.cards-container-header{font-size:16px;font-weight:500;padding:12px 8px;margin:0;grid-column:1/-1;position:sticky;top:56px;z-index:1;background:linear-gradient(90deg,var(--ha-dialog-surface-background,var(--mdc-theme-surface,#fff)) 0%,#ffffff00 80%)}.cards-container{display:grid;grid-gap:8px 8px;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));margin-top:20px}.card{height:100%;max-width:500px;display:flex;flex-direction:column;border-radius:var(--ha-card-border-radius,12px);background:var(--primary-background-color,#fafafa);cursor:pointer;position:relative;overflow:hidden;border:var(--ha-card-border-width,1px) solid var(--ha-card-border-color,var(--divider-color))}.icon,.overlay{position:absolute;box-sizing:border-box}.card-header{color:var(--ha-card-header-color,var(--primary-text-color));font-family:var(--ha-card-header-font-family, inherit);font-size:16px;font-weight:700;letter-spacing:-.012em;line-height:20px;padding:12px 16px;display:block}.preview{pointer-events:none;margin:20px;flex-grow:1;display:flex;align-items:center;justify-content:center}.preview>:first-child{display:block;width:100%}.spinner{align-items:center;justify-content:center}.overlay{width:100%;height:100%;z-index:1;border-radius:var(--ha-card-border-radius,12px)}.manual{max-width:none;grid-column:1/-1}.icon{top:8px;right:8px inset-inline-start: 8px;inset-inline-end:8px;border-radius:50%;--mdc-icon-size:16px;line-height:16px;color:var(--text-primary-color);padding:4px}.icon.custom{background:var(--warning-color)}`]}}]}}),r.oi);t()}catch(e){t(e)}}))},32817:function(e,t,i){i.a(e,(async function(e,a){try{i.d(t,{U:()=>n});var s=i(62037),r=e([s]);s=(r.then?(await r)():r)[0];const n=async(e,t,i,a)=>{let r={type:t};const n=await(0,s.Do)(t);if(n&&n.getStubConfig){const t=await n.getStubConfig(e,i,a);r={...r,...t}}return r};a()}catch(e){a(e)}}))},33873:function(e,t,i){i.d(t,{C:()=>a});const a=[{type:"alarm-panel",showElement:!0},{type:"button",showElement:!0},{type:"calendar",showElement:!0},{type:"entities",showElement:!0},{type:"entity",showElement:!0},{type:"gauge",showElement:!0},{type:"glance",showElement:!0},{type:"history-graph",showElement:!0},{type:"statistics-graph",showElement:!1},{type:"statistic",showElement:!0},{type:"humidifier",showElement:!0},{type:"light",showElement:!0},{type:"map",showElement:!0},{type:"markdown",showElement:!0},{type:"media-control",showElement:!0},{type:"picture",showElement:!0},{type:"picture-elements",showElement:!0},{type:"picture-entity",showElement:!0},{type:"picture-glance",showElement:!0},{type:"plant-status",showElement:!0},{type:"sensor",showElement:!0},{type:"thermostat",showElement:!0},{type:"weather-forecast",showElement:!0},{type:"area",showElement:!0},{type:"tile",showElement:!0},{type:"conditional"},{type:"entity-filter"},{type:"grid"},{type:"horizontal-stack"},{type:"iframe"},{type:"logbook"},{type:"vertical-stack"},{type:"todo-list"},{type:"heading",showElement:!0}]}};
//# sourceMappingURL=53403.2f763b0b0110d678.js.map