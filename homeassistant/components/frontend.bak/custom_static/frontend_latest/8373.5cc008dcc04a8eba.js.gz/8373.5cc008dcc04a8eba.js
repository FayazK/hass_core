export const __webpack_ids__=["8373"];export const __webpack_modules__={55421:function(i,t,s){s.a(i,(async function(i,e){try{s.r(t);var a=s(44249),o=(s(9359),s(70104),s(57243)),r=s(15093),n=s(33570),l=s(95975),d=i([l,n]);[l,n]=d.then?(await d)():d;(0,a.Z)([(0,r.Mo)("more-info-sun")],(function(i,t){return{F:class extends t{constructor(...t){super(...t),i(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass||!this.stateObj)return o.Ld;const i=new Date(this.stateObj.attributes.next_rising),t=new Date(this.stateObj.attributes.next_setting),s=i>t?["set","ris"]:["ris","set"];return o.dy`
      <hr/>
      ${s.map((s=>o.dy`
          <div class="row">
            <div class="key">
              <span>${"ris"===s?this.hass.localize("ui.dialogs.more_info_control.sun.rising"):this.hass.localize("ui.dialogs.more_info_control.sun.setting")}</span>
              <ha-relative-time .hass=${this.hass} .datetime=${"ris"===s?i:t}></ha-relative-time>
            </div>
            <div class="value">
              ${(0,n.mr)("ris"===s?i:t,this.hass.locale,this.hass.config)}
            </div>
          </div>
        `))}
      <div class="row">
        <div class="key">
          ${this.hass.localize("ui.dialogs.more_info_control.sun.elevation")}
        </div>
        <div class="value">
          ${this.hass.formatEntityAttributeValue(this.stateObj,"elevation")}
        </div>
      </div>
      <div class="row">
        <div class="key">
          ${this.hass.localize("ui.dialogs.more_info_control.sun.azimuth")}
        </div>
        <div class="value">
          ${this.hass.formatEntityAttributeValue(this.stateObj,"azimuth")}
        </div>
      </div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`.row{margin:0;display:flex;flex-direction:row;justify-content:space-between}ha-relative-time{display:inline-block;white-space:nowrap}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`}]}}),o.oi);e()}catch(i){e(i)}}))}};
//# sourceMappingURL=8373.5cc008dcc04a8eba.js.map