export const __webpack_ids__=["89793"];export const __webpack_modules__={5828:function(e,t,a){a.r(t),a.d(t,{HaIconButtonPrev:()=>d});var i=a(44249),n=a(57243),o=a(15093),s=a(5111);a(23334);let d=(0,i.Z)([(0,o.Mo)("ha-icon-button-prev")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)()],key:"label",value:void 0},{kind:"field",decorators:[(0,o.SB)()],key:"_icon",value:()=>"rtl"===s.E.document.dir?"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z":"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z"},{kind:"method",key:"render",value:function(){return n.dy`
      <ha-icon-button .disabled=${this.disabled} .label=${this.label||this.hass?.localize("ui.common.back")||"Back"} .path=${this._icon}></ha-icon-button>
    `}}]}}),n.oi)},51784:function(e,t,a){a.d(t,{dJ:()=>u,zB:()=>p});var i=a(44249),n=a(72621),o=a(67840),s=a(88854),d=a(57243),l=a(15093);let c;o.A.addInitializer((async e=>{await e.updateComplete;const t=e;t.dialog.prepend(t.scrim),t.scrim.style.inset=0,t.scrim.style.zIndex=0;const{getOpenAnimation:a,getCloseAnimation:i}=t;t.getOpenAnimation=()=>{const e=a.call(void 0);return e.container=[...e.container??[],...e.dialog??[]],e.dialog=[],e},t.getCloseAnimation=()=>{const e=i.call(void 0);return e.container=[...e.container??[],...e.dialog??[]],e.dialog=[],e}}));(0,i.Z)([(0,l.Mo)("ha-md-dialog")],(function(e,t){class i extends t{constructor(){super(),e(this),this.addEventListener("cancel",this._handleCancel),"function"!=typeof HTMLDialogElement&&(this.addEventListener("open",this._handleOpen),c||(c=a.e("73854").then(a.bind(a,85893)))),void 0===this.animate&&(this.quick=!0),void 0===this.animate&&(this.quick=!0)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({attribute:"disable-cancel-action",type:Boolean})],key:"disableCancelAction",value:()=>!1},{kind:"field",key:"_polyfillDialogRegistered",value:()=>!1},{kind:"method",key:"_handleOpen",value:async function(e){if(e.preventDefault(),this._polyfillDialogRegistered)return;this._polyfillDialogRegistered=!0,this._loadPolyfillStylesheet("/static/polyfills/dialog-polyfill.css");const t=this.shadowRoot?.querySelector("dialog");(await c).default.registerDialog(t),this.removeEventListener("open",this._handleOpen),this.show()}},{kind:"method",key:"_loadPolyfillStylesheet",value:async function(e){const t=document.createElement("link");return t.rel="stylesheet",t.href=e,new Promise(((a,i)=>{t.onload=()=>a(),t.onerror=()=>i(new Error(`Stylesheet failed to load: ${e}`)),this.shadowRoot?.appendChild(t)}))}},{kind:"method",key:"_handleCancel",value:function(e){if(this.disableCancelAction){e.preventDefault();const t=this.shadowRoot?.querySelector("dialog .container");void 0!==this.animate&&t?.animate([{transform:"rotate(-1deg)","animation-timing-function":"ease-in"},{transform:"rotate(1.5deg)","animation-timing-function":"ease-out"},{transform:"rotate(0deg)","animation-timing-function":"ease-in"}],{duration:200,iterations:2})}}},{kind:"field",static:!0,key:"styles",value(){return[...(0,n.Z)(i,"styles",this),d.iv`:host{--md-dialog-container-color:var(--card-background-color);--md-dialog-headline-color:var(--primary-text-color);--md-dialog-supporting-text-color:var(--primary-text-color);--md-sys-color-scrim:#000000;--md-dialog-headline-weight:400;--md-dialog-headline-size:1.574rem;--md-dialog-supporting-text-size:1rem;--md-dialog-supporting-text-line-height:1.5rem}:host([type=alert]){min-width:320px}@media all and (max-width:450px),all and (max-height:500px){:host(:not([type=alert])){min-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));max-width:calc(100vw - env(safe-area-inset-right) - env(safe-area-inset-left));min-height:100%;max-height:100%;--md-dialog-container-shape:0}}::slotted(ha-dialog-header[slot=headline]){display:contents}.scroller{overflow:var(--dialog-content-overflow,auto)}slot[name=content]::slotted(*){padding:var(--dialog-content-padding,24px)}.scrim{z-index:10}`]}}]}}),o.A);const r={...s.I,dialog:[[[{transform:"translateY(50px)"},{transform:"translateY(0)"}],{duration:500,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:0},{opacity:1}],{duration:50,easing:"linear",pseudoElement:"::before"}]]},h={...s.G,dialog:[[[{transform:"translateY(0)"},{transform:"translateY(50px)"}],{duration:150,easing:"cubic-bezier(.3,0,0,1)"}]],container:[[[{opacity:"1"},{opacity:"0"}],{delay:100,duration:50,easing:"linear",pseudoElement:"::before"}]]},u=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?r:s.I,p=()=>window.matchMedia("all and (max-width: 450px), all and (max-height: 500px)").matches?h:s.G},35956:function(e,t,a){a.a(e,(async function(e,i){try{a.r(t);var n=a(44249),o=(a(92745),a(92519),a(42179),a(89256),a(24931),a(88463),a(57449),a(19814),a(57243)),s=a(15093),d=a(72344),l=a(36522),c=a(87865),r=(a(59826),a(95198),a(23334),a(5828),a(13928),a(51784),a(19993),a(74633),a(34326),a(37583),a(26779)),h=a(28008),u=a(72473),p=a(68545),g=(a(5131),a(6384)),_=e([p,g,r]);[p,g,r]=_.then?(await _)():_;const m="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",f="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",k="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z",b=["welcome","key","setup","schedule","data","locations"],y=new Set(["setup"]),v=new Set(["schedule","data","locations"]),x={automatic_backups_configured:!1,create_backup:{agent_ids:[],include_folders:[],include_database:!0,include_addons:[],include_all_addons:!0,password:null,name:null},retention:{copies:3,days:null},schedule:{recurrence:r.wy.DAILY,time:null,days:[]},agents:{},last_attempted_automatic_backup:null,last_completed_automatic_backup:null,next_automatic_backup:null,next_automatic_backup_additional:!1};(0,n.Z)([(0,s.Mo)("ha-dialog-backup-onboarding")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_opened",value:()=>!1},{kind:"field",decorators:[(0,s.SB)()],key:"_step",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,s.IO)("ha-md-dialog")],key:"_dialog",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_config",value:void 0},{kind:"method",key:"showDialog",value:function(e){this._params=e,this._params.config?.create_backup.password?(this._config=this._params.config,this._step="setup"):(this._step=this._firstStep,this._config={...x,create_backup:{...x.create_backup,agent_ids:this._defaultAgents,password:(0,r.Ty)()}}),this._opened=!0}},{kind:"method",key:"closeDialog",value:function(){return this._params.cancel&&this._params.cancel(),this._opened&&(0,l.B)(this,"dialog-closed",{dialog:this.localName}),this._opened=!1,this._step=void 0,this._config=void 0,this._params=void 0,!0}},{kind:"get",key:"_firstStep",value:function(){return this._params?.skipWelcome?b[1]:b[0]}},{kind:"method",key:"_save",value:async function(e=!1){if(!this._config)return;const t={create_backup:{password:this._config.create_backup.password,include_database:this._config.create_backup.include_database,agent_ids:this._config.create_backup.agent_ids},schedule:this._config.schedule,retention:this._config.retention,automatic_backups_configured:e};(0,d.p)(this.hass,"hassio")&&(t.create_backup.include_folders=this._config.create_backup.include_folders||[],t.create_backup.include_all_addons=this._config.create_backup.include_all_addons,t.create_backup.include_addons=this._config.create_backup.include_addons||[]),await(0,r._r)(this.hass,t)}},{kind:"method",key:"_done",value:async function(){try{await this._save(!0),this._params?.submit(!0),this._dialog.close()}catch(e){console.error(e),(0,u.C)(this,{message:"Failed to save backup configuration"})}}},{kind:"method",key:"_previousStep",value:function(){const e=b.indexOf(this._step);0!==e&&(this._step=b[e-1])}},{kind:"method",key:"_nextStep",value:function(){this._step&&v.has(this._step)&&this._save();const e=b.indexOf(this._step);e!==b.length-1&&(this._step=b[e+1])}},{kind:"method",key:"updated",value:function(e){e.has("_step")&&"key"===this._step&&this._save()}},{kind:"method",key:"render",value:function(){if(!this._opened||!this._params||!this._step)return o.Ld;const e=this._step===b[b.length-1],t=this._step===this._firstStep;return o.dy`
      <ha-md-dialog disable-cancel-action open @closed=${this.closeDialog}>
        <ha-dialog-header slot="headline">
          ${t?o.dy`
                <ha-icon-button slot="navigationIcon" .label=${this.hass.localize("ui.common.close")} .path=${m} @click=${this.closeDialog}></ha-icon-button>
              `:o.dy`
                <ha-icon-button-prev slot="navigationIcon" @click=${this._previousStep}></ha-icon-button-prev>
              `}

          <span slot="title">${this._stepTitle}</span>
        </ha-dialog-header>
        <div slot="content">${this._renderStepContent()}</div>
        ${y.has(this._step)?o.Ld:o.dy`
              <div slot="actions">
                ${e?o.dy`
                      <ha-button @click=${this._done} .disabled=${!this._isStepValid()}>
                        ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.save_and_create")}
                      </ha-button>
                    `:o.dy`
                      <ha-button @click=${this._nextStep} .disabled=${!this._isStepValid()}>
                        ${this.hass.localize("ui.common.next")}
                      </ha-button>
                    `}
              </div>
            `}
      </ha-md-dialog>
    `}},{kind:"get",key:"_defaultAgents",value:function(){const e=[];return(0,d.p)(this.hass,"hassio")?e.push(r.Kn):e.push(r.UR),this._params?.cloudStatus?.logged_in&&e.push(r.$u),e}},{kind:"method",key:"_useRecommended",value:function(){this._config?.create_backup.password?(this._config={...x,create_backup:{...x.create_backup,agent_ids:this._defaultAgents,password:this._config.create_backup.password}},this._done()):this.showDialog(this._params)}},{kind:"get",key:"_stepTitle",value:function(){switch(this._step){case"key":case"setup":case"schedule":case"data":case"locations":return this.hass.localize(`ui.panel.config.backup.dialogs.onboarding.${this._step}.title`);default:return""}}},{kind:"method",key:"_isStepValid",value:function(){switch(this._step){case"key":case"setup":default:return!0;case"schedule":case"data":return!!this._config?.schedule;case"locations":return!!this._config?.create_backup.agent_ids.length}}},{kind:"method",key:"_renderStepContent",value:function(){if(!this._config)return o.Ld;switch(this._step){case"welcome":return o.dy`
          <div class="welcome">
            <img src="/static/images/voice-assistant/hi.png" alt="Casita ASCIA logo"/>
            <h1>
              ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.welcome.title")}
            </h1>
            <p class="secondary">
              ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.welcome.description")}
            </p>
          </div>
        `;case"key":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.key.description")}
          </p>
          <div class="encryption-key">
            <p>${this._config.create_backup.password}</p>
            <ha-icon-button .path=${f} @click=${this._copyKeyToClipboard}></ha-icon-button>
          </div>
          <ha-md-list>
            <ha-md-list-item>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_description")}
              </span>
              <ha-button slot="end" @click=${this._downloadKey}>
                <ha-svg-icon .path=${k} slot="icon"></ha-svg-icon>
                ${this.hass.localize("ui.panel.config.backup.encryption_key.download_emergency_kit_action")}
              </ha-button>
            </ha-md-list-item>
          </ha-md-list>
        `;case"setup":return o.dy`
          <ha-md-list class="full">
            <ha-md-list-item type="button" @click=${this._useRecommended}>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.recommended_heading")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.recommended_description")}
              </span>
              <ha-icon-next slot="end"></ha-icon-next>
            </ha-md-list-item>
            <ha-md-list-item type="button" @click=${this._nextStep}>
              <span slot="headline">
                ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.custom_heading")}
              </span>
              <span slot="supporting-text">
                ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.setup.custom_description")}
              </span>
              <ha-icon-next slot="end"></ha-icon-next>
            </ha-md-list-item>
          </ha-md-list>
        `;case"schedule":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.schedule.description")}
          </p>
          <ha-backup-config-schedule .hass=${this.hass} .value=${this._config} @value-changed=${this._scheduleChanged}></ha-backup-config-schedule>
        `;case"data":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.data.description")}
          </p>
          <ha-backup-config-data .hass=${this.hass} .value=${this._dataConfig(this._config)} @value-changed=${this._dataChanged} force-home-assistant hide-addon-version></ha-backup-config-data>
        `;case"locations":return o.dy`
          <p>
            ${this.hass.localize("ui.panel.config.backup.dialogs.onboarding.locations.description")}
          </p>
          <ha-backup-config-agents .hass=${this.hass} .value=${this._config.create_backup.agent_ids} .cloudStatus=${this._params.cloudStatus} @value-changed=${this._agentsConfigChanged}></ha-backup-config-agents>
        `}return o.Ld}},{kind:"method",key:"_downloadKey",value:function(){const e=this._config?.create_backup.password;e&&(0,r.VY)(this.hass,e)}},{kind:"method",key:"_copyKeyToClipboard",value:async function(){await(0,c.v)(this._config.create_backup.password,this.renderRoot.querySelector("div")),(0,u.C)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}},{kind:"method",key:"_dataConfig",value:function(e){const{include_addons:t,include_all_addons:a,include_database:i,include_folders:n}=e.create_backup;return{include_homeassistant:!0,include_database:i,include_folders:n||void 0,include_all_addons:a,include_addons:t||void 0}}},{kind:"method",key:"_dataChanged",value:function(e){const t=e.detail.value;this._config={...this._config,create_backup:{...this._config.create_backup,include_database:t.include_database,include_folders:t.include_folders||null,include_all_addons:t.include_all_addons,include_addons:t.include_addons||null}}}},{kind:"method",key:"_scheduleChanged",value:function(e){const t=e.detail.value;this._config={...this._config,schedule:t.schedule,retention:t.retention}}},{kind:"method",key:"_agentsConfigChanged",value:function(e){const t=e.detail.value;this._config={...this._config,create_backup:{...this._config.create_backup,agent_ids:t}}}},{kind:"get",static:!0,key:"styles",value:function(){return[h.Qx,h.yu,o.iv`.encryption-key p,.welcome{text-align:center}ha-md-dialog{width:90vw;max-width:560px;--dialog-content-padding:8px 24px;max-height:min(605px,100% - 48px)}ha-md-list{background:0 0;--md-list-item-leading-space:0;--md-list-item-trailing-space:0}ha-md-list.full{--md-list-item-leading-space:24px;--md-list-item-trailing-space:24px;margin-left:-24px;margin-right:-24px}@media all and (max-width:450px),all and (max-height:500px){ha-md-dialog{max-width:none}div[slot=content]{margin-top:0}}p{margin-top:0}.encryption-key{border:1px solid var(--divider-color);background-color:var(--primary-background-color);border-radius:8px;padding:16px;display:flex;flex-direction:row;align-items:center;gap:24px}.encryption-key p{margin:0;flex:1;font-family:"Roboto Mono",Consolas,Menlo,monospace;font-size:20px;font-style:normal;font-weight:400;line-height:28px}.encryption-key ha-icon-button{flex:none;margin:-16px}`]}}]}}),o.oi);i()}catch(e){i(e)}}))}};
//# sourceMappingURL=89793.7179eba001fa5e87.js.map