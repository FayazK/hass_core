export const __webpack_ids__=["78507"];export const __webpack_modules__={29891:function(t,i,e){var a=e(44249),o=e(72621),n=e(57243),s=e(15093),l=e(73358),r=e(59847),h=e(47194),d=e(96194),c=e(13560);e(55486),e(23334),e(1888);const u=t=>void 0!==t&&!l.tj.includes(t.state)&&!(0,d.rk)(t.state);(0,a.Z)([(0,s.Mo)("ha-entity-toggle")],(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,s.Cb)()],key:"label",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_isOn",value:()=>!1},{kind:"method",key:"render",value:function(){if(!this.stateObj)return n.dy` <ha-switch disabled=disabled></ha-switch> `;if(this.stateObj.attributes.assumed_state||this.stateObj.state===d.lz)return n.dy`
        <ha-icon-button .label=${`Turn ${(0,h.C)(this.stateObj)} off`} .path=${"M17,10H13L17,2H7V4.18L15.46,12.64M3.27,3L2,4.27L7,9.27V13H10V22L13.58,15.86L17.73,20L19,18.73L3.27,3Z"} .disabled=${this.stateObj.state===d.nZ} @click=${this._turnOff} class=${this._isOn||this.stateObj.state===d.lz?"":"state-active"}></ha-icon-button>
        <ha-icon-button .label=${`Turn ${(0,h.C)(this.stateObj)} on`} .path=${"M7,2V13H10V22L17,10H13L17,2H7Z"} .disabled=${this.stateObj.state===d.nZ} @click=${this._turnOn} class=${this._isOn?"state-active":""}></ha-icon-button>
      `;const t=n.dy`<ha-switch aria-label=${`Toggle ${(0,h.C)(this.stateObj)} ${this._isOn?"off":"on"}`} .checked=${this._isOn} .disabled=${this.stateObj.state===d.nZ} @change=${this._toggleChanged}></ha-switch>`;return this.label?n.dy`
      <ha-formfield .label=${this.label}>${t}</ha-formfield>
    `:t}},{kind:"method",key:"firstUpdated",value:function(t){(0,o.Z)(e,"firstUpdated",this,3)([t]),this.addEventListener("click",(t=>t.stopPropagation()))}},{kind:"method",key:"willUpdate",value:function(t){(0,o.Z)(e,"willUpdate",this,3)([t]),t.has("stateObj")&&(this._isOn=u(this.stateObj))}},{kind:"method",key:"_toggleChanged",value:function(t){const i=t.target.checked;i!==this._isOn&&this._callService(i)}},{kind:"method",key:"_turnOn",value:function(){this._callService(!0)}},{kind:"method",key:"_turnOff",value:function(){this._callService(!1)}},{kind:"method",key:"_callService",value:async function(t){if(!this.hass||!this.stateObj)return;(0,c.j)("light");const i=(0,r.N)(this.stateObj);let e,a;"lock"===i?(e="lock",a=t?"unlock":"lock"):"cover"===i?(e="cover",a=t?"open_cover":"close_cover"):"valve"===i?(e="valve",a=t?"open_valve":"close_valve"):"group"===i?(e="homeassistant",a=t?"turn_on":"turn_off"):(e=i,a=t?"turn_on":"turn_off");const o=this.stateObj;this._isOn=t,await this.hass.callService(e,a,{entity_id:this.stateObj.entity_id}),setTimeout((async()=>{this.stateObj===o&&(this._isOn=u(this.stateObj))}),2e3)}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`:host{white-space:nowrap;min-width:38px}ha-icon-button{--mdc-icon-button-size:40px;color:var(--ha-icon-button-inactive-color,var(--primary-text-color));transition:color .5s}ha-icon-button.state-active{color:var(--ha-icon-button-active-color,var(--primary-color))}ha-switch{padding:13px 5px}`}]}}),n.oi)},77980:function(t,i,e){e.a(t,(async function(t,i){try{var a=e(44249),o=(e(31622),e(57243)),n=e(15093),s=(e(99426),e(99254),e(58839)),l=e(33831),r=t([l]);l=(r.then?(await r)():r)[0];(0,a.Z)([(0,n.Mo)("blueprint-automation-editor")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"get",key:"_config",value:function(){return this.config}},{kind:"method",key:"render",value:function(){return o.dy`
      ${"off"===this.stateObj?.state?o.dy`
            <ha-alert alert-type="info">
              ${this.hass.localize("ui.panel.config.automation.editor.disabled")}
              <mwc-button slot="action" @click=${this._enable}>
                ${this.hass.localize("ui.panel.config.automation.editor.enable")}
              </mwc-button>
            </ha-alert>
          `:""}
      ${this.config.description?o.dy`<ha-markdown class="description" breaks .content=${this.config.description}></ha-markdown>`:o.Ld}
      ${this.renderCard()}
    `}},{kind:"method",key:"_getBlueprints",value:async function(){this._blueprints=await(0,s.wc)(this.hass,"automation")}},{kind:"method",key:"_enable",value:async function(){this.hass&&this.stateObj&&await this.hass.callService("automation","turn_on",{entity_id:this.stateObj.entity_id})}}]}}),l.k);i()}catch(t){i(t)}}))},55615:function(t,i,e){e.a(t,(async function(t,i){try{var a=e(44249),o=e(72621),n=(e(9359),e(1331),e(31526),e(70104),e(31622),e(57243)),s=e(15093),l=e(35359),r=e(60738),h=e(36522),d=e(83523),c=e(20172),u=e(76320),m=e(37394),g=(e(34273),e(20130),e(65981),e(23334),e(7285),e(37583),e(64889),e(14473)),f=e(58839),p=e(47805),_=e(96194),y=e(63318),v=e(76131),k=(e(87979),e(29166)),b=e(28008),$=e(72473),C=(e(98241),e(61751)),w=e(11432),A=e(77980),x=e(11808),L=e(12939),z=e(78819),H=e(40027),V=e(30635),M=e(16755),S=t([A,x]);[A,x]=S.then?(await S)():S;const I="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",O="M11,17H4A2,2 0 0,1 2,15V3A2,2 0 0,1 4,1H16V3H4V15H11V13L15,16L11,19V17M19,21V7H8V13H6V7A2,2 0 0,1 8,5H19A2,2 0 0,1 21,7V21A2,2 0 0,1 19,23H8A2,2 0 0,1 6,21V19H8V21H19Z",E="M15,9H5V5H15M12,19A3,3 0 0,1 9,16A3,3 0 0,1 12,13A3,3 0 0,1 15,16A3,3 0 0,1 12,19M17,3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V7L17,3Z",B="M12,14A2,2 0 0,1 14,16A2,2 0 0,1 12,18A2,2 0 0,1 10,16A2,2 0 0,1 12,14M23.46,8.86L21.87,15.75L15,14.16L18.8,11.78C17.39,9.5 14.87,8 12,8C8.05,8 4.77,10.86 4.12,14.63L2.15,14.28C2.96,9.58 7.06,6 12,6C15.58,6 18.73,7.89 20.5,10.72L23.46,8.86Z",Z="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",R="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",U="M6 2C4.9 2 4 2.9 4 4V20C4 21.1 4.9 22 6 22H10V20.1L20 10.1V8L14 2H6M13 3.5L18.5 9H13V3.5M20.1 13C20 13 19.8 13.1 19.7 13.2L18.7 14.2L20.8 16.3L21.8 15.3C22 15.1 22 14.7 21.8 14.5L20.5 13.2C20.4 13.1 20.3 13 20.1 13M18.1 14.8L12 20.9V23H14.1L20.2 16.9L18.1 14.8Z",j="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",F="M8,5.14V19.14L19,12.14L8,5.14Z",P="M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M10,16.5L16,12L10,7.5V16.5Z",D="M3 6V8H14V6H3M3 10V12H14V10H3M20 10.1C19.9 10.1 19.7 10.2 19.6 10.3L18.6 11.3L20.7 13.4L21.7 12.4C21.9 12.2 21.9 11.8 21.7 11.6L20.4 10.3C20.3 10.2 20.2 10.1 20 10.1M18.1 11.9L12 17.9V20H14.1L20.2 13.9L18.1 11.9M3 14V16H10V14H3Z",T="M18,17H10.5L12.5,15H18M6,17V14.5L13.88,6.65C14.07,6.45 14.39,6.45 14.59,6.65L16.35,8.41C16.55,8.61 16.55,8.92 16.35,9.12L8.47,17M19,3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3Z",W="M20 4H18V3H20.5C20.78 3 21 3.22 21 3.5V5.5C21 5.78 20.78 6 20.5 6H20V7H19V5H20V4M19 9H20V8H19V9M17 3H16V7H17V3M23 15V18C23 18.55 22.55 19 22 19H21V20C21 21.11 20.11 22 19 22H5C3.9 22 3 21.11 3 20V19H2C1.45 19 1 18.55 1 18V15C1 14.45 1.45 14 2 14H3C3 10.13 6.13 7 10 7H11V5.73C10.4 5.39 10 4.74 10 4C10 2.9 10.9 2 12 2S14 2.9 14 4C14 4.74 13.6 5.39 13 5.73V7H14C14.34 7 14.67 7.03 15 7.08V10H19.74C20.53 11.13 21 12.5 21 14H22C22.55 14 23 14.45 23 15M10 15.5C10 14.12 8.88 13 7.5 13S5 14.12 5 15.5 6.12 18 7.5 18 10 16.88 10 15.5M19 15.5C19 14.12 17.88 13 16.5 13S14 14.12 14 15.5 15.12 18 16.5 18 19 16.88 19 15.5M17 8H16V9H17V8Z",N="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4M9,9V15H15V9",q="M5.5,7A1.5,1.5 0 0,1 4,5.5A1.5,1.5 0 0,1 5.5,4A1.5,1.5 0 0,1 7,5.5A1.5,1.5 0 0,1 5.5,7M21.41,11.58L12.41,2.58C12.05,2.22 11.55,2 11,2H4C2.89,2 2,2.89 2,4V11C2,11.55 2.22,12.05 2.59,12.41L11.58,21.41C11.95,21.77 12.45,22 13,22C13.55,22 14.05,21.77 14.41,21.41L21.41,14.41C21.78,14.05 22,13.55 22,13C22,12.44 21.77,11.94 21.41,11.58Z",Q="M15,12C15,10.7 14.16,9.6 13,9.18V6.82C14.16,6.4 15,5.3 15,4A3,3 0 0,0 12,1A3,3 0 0,0 9,4C9,5.3 9.84,6.4 11,6.82V9.19C9.84,9.6 9,10.7 9,12C9,13.3 9.84,14.4 11,14.82V17.18C9.84,17.6 9,18.7 9,20A3,3 0 0,0 12,23A3,3 0 0,0 15,20C15,18.7 14.16,17.6 13,17.18V14.82C14.16,14.4 15,13.3 15,12M12,3A1,1 0 0,1 13,4A1,1 0 0,1 12,5A1,1 0 0,1 11,4A1,1 0 0,1 12,3M12,21A1,1 0 0,1 11,20A1,1 0 0,1 12,19A1,1 0 0,1 13,20A1,1 0 0,1 12,21Z";let G=(0,a.Z)(null,(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"automationId",value:()=>null},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"entityId",value:()=>null},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"automations",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_dirty",value:()=>!1},{kind:"field",decorators:[(0,s.SB)()],key:"_errors",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_yamlErrors",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_entityId",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_mode",value:()=>"gui"},{kind:"field",decorators:[(0,s.SB)()],key:"_readOnly",value:()=>!1},{kind:"field",decorators:[(0,s.SB)()],key:"_validationErrors",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_blueprintConfig",value:void 0},{kind:"field",decorators:[(0,r.F_)({context:V.we,subscribe:!0}),(0,M.v)({transformer:function(t){return t.find((({entity_id:t})=>t===this._entityId))},watch:["_entityId"]})],key:"_registryEntry",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_saving",value:()=>!1},{kind:"field",decorators:[(0,s.SB)(),(0,r.F_)({context:V.we,subscribe:!0})],key:"_entityRegistry",value:void 0},{kind:"field",key:"_configSubscriptions",value:()=>({})},{kind:"field",key:"_configSubscriptionsId",value:()=>1},{kind:"field",key:"_entityRegistryUpdate",value:void 0},{kind:"field",key:"_newAutomationId",value:void 0},{kind:"field",key:"_entityRegCreated",value:void 0},{kind:"method",key:"willUpdate",value:function(t){if((0,o.Z)(e,"willUpdate",this,3)([t]),this._entityRegCreated&&this._newAutomationId&&t.has("_entityRegistry")){const t=this._entityRegistry.find((t=>"automation"===t.platform&&t.unique_id===this._newAutomationId));t&&(this._entityRegCreated(t),this._entityRegCreated=void 0)}}},{kind:"method",key:"render",value:function(){if(!this._config)return n.Ld;const t=this._entityId?this.hass.states[this._entityId]:void 0,i="use_blueprint"in this._config;return n.dy`
      <hass-subpage .hass=${this.hass} .narrow=${this.narrow} .route=${this.route} .backCallback=${this._backTapped} .header=${this._config.alias||this.hass.localize("ui.panel.config.automation.editor.default_name")}>
        ${this._config?.id&&!this.narrow?n.dy`
              <mwc-button @click=${this._showTrace} slot="toolbar-icon">
                ${this.hass.localize("ui.panel.config.automation.editor.show_trace")}
              </mwc-button>
            `:""}
        <ha-button-menu slot="toolbar-icon">
          <ha-icon-button slot="trigger" .label=${this.hass.localize("ui.common.menu")} .path=${R}></ha-icon-button>

          <ha-list-item graphic="icon" .disabled=${!t} @click=${this._showInfo}>
            ${this.hass.localize("ui.panel.config.automation.editor.show_info")}
            <ha-svg-icon slot="graphic" .path=${j}></ha-svg-icon>
          </ha-list-item>

          <ha-list-item graphic="icon" .disabled=${!t} @click=${this._showSettings}>
            ${this.hass.localize("ui.panel.config.automation.picker.show_settings")}
            <ha-svg-icon slot="graphic" .path=${I}></ha-svg-icon>
          </ha-list-item>

          <ha-list-item graphic="icon" .disabled=${!t} @click=${this._editCategory}>
            ${this.hass.localize("ui.panel.config.scene.picker."+(this._registryEntry?.categories?.automation?"edit_category":"assign_category"))}
            <ha-svg-icon slot="graphic" .path=${q}></ha-svg-icon>
          </ha-list-item>

          <ha-list-item graphic="icon" .disabled=${!t} @click=${this._runActions}>
            ${this.hass.localize("ui.panel.config.automation.editor.run")}
            <ha-svg-icon slot="graphic" .path=${F}></ha-svg-icon>
          </ha-list-item>

          ${t&&this.narrow?n.dy`<a href="/config/automation/trace/${encodeURIComponent(this._config.id)}">
                <ha-list-item graphic="icon">
                  ${this.hass.localize("ui.panel.config.automation.editor.show_trace")}
                  <ha-svg-icon slot="graphic" .path=${Q}></ha-svg-icon>
                </ha-list-item>
              </a>`:n.Ld}

          <ha-list-item graphic="icon" @click=${this._promptAutomationAlias} .disabled=${this._readOnly||!this.automationId||"yaml"===this._mode}>
            ${this.hass.localize("ui.panel.config.automation.editor.rename")}
            <ha-svg-icon slot="graphic" .path=${T}></ha-svg-icon>
          </ha-list-item>
          ${i?n.Ld:n.dy`
                <ha-list-item graphic="icon" @click=${this._promptAutomationMode} .disabled=${this._readOnly||"yaml"===this._mode}>
                  ${this.hass.localize("ui.panel.config.automation.editor.change_mode")}
                  <ha-svg-icon slot="graphic" .path=${B}></ha-svg-icon>
                </ha-list-item>
              `}

          <ha-list-item .disabled=${this._blueprintConfig||!this._readOnly&&!this.automationId} graphic="icon" @click=${this._duplicate}>
            ${this.hass.localize(this._readOnly?"ui.panel.config.automation.editor.migrate":"ui.panel.config.automation.editor.duplicate")}
            <ha-svg-icon slot="graphic" .path=${O}></ha-svg-icon>
          </ha-list-item>

          ${i?n.dy`
                <ha-list-item graphic="icon" @click=${this._takeControl} .disabled=${this._readOnly}>
                  ${this.hass.localize("ui.panel.config.automation.editor.take_control")}
                  <ha-svg-icon slot="graphic" .path=${U}></ha-svg-icon>
                </ha-list-item>
              `:n.Ld}

          <ha-list-item graphic="icon" @click=${"gui"===this._mode?this._switchYamlMode:this._switchUiMode}>
            ${this.hass.localize("ui.panel.config.automation.editor.edit_"+("gui"===this._mode?"yaml":"ui"))}
            <ha-svg-icon slot="graphic" .path=${D}></ha-svg-icon>
          </ha-list-item>

          <li divider role="separator"></li>

          <ha-list-item graphic="icon" .disabled=${!t} @click=${this._toggle}>
            ${"off"===t?.state?this.hass.localize("ui.panel.config.automation.editor.enable"):this.hass.localize("ui.panel.config.automation.editor.disable")}
            <ha-svg-icon slot="graphic" .path=${"off"===t?.state?P:N}></ha-svg-icon>
          </ha-list-item>

          <ha-list-item .disabled=${!this.automationId} class=${(0,l.$)({warning:Boolean(this.automationId)})} graphic="icon" @click=${this._deleteConfirm}>
            ${this.hass.localize("ui.panel.config.automation.picker.delete")}
            <ha-svg-icon class=${(0,l.$)({warning:Boolean(this.automationId)})} slot="graphic" .path=${Z}>
            </ha-svg-icon>
          </ha-list-item>
        </ha-button-menu>
        <div class="content ${(0,l.$)({"yaml-mode":"yaml"===this._mode})}" @subscribe-automation-config=${this._subscribeAutomationConfig}>
          ${this._errors||t?.state===_.nZ?n.dy`<ha-alert alert-type="error" .title=${t?.state===_.nZ?this.hass.localize("ui.panel.config.automation.editor.unavailable"):void 0}>
                ${this._errors||this._validationErrors}
                ${t?.state===_.nZ?n.dy`<ha-svg-icon slot="icon" .path=${W}></ha-svg-icon>`:n.Ld}
              </ha-alert>`:""}
          ${this._blueprintConfig?n.dy`<ha-alert alert-type="info">
                ${this.hass.localize("ui.panel.config.automation.editor.confirm_take_control")}
                <div slot="action" style="display:flex">
                  <mwc-button @click=${this._takeControlSave}>${this.hass.localize("ui.common.yes")}</mwc-button>
                  <mwc-button @click=${this._revertBlueprint}>${this.hass.localize("ui.common.no")}</mwc-button>
                </div>
              </ha-alert>`:this._readOnly?n.dy`<ha-alert alert-type="warning" dismissable>${this.hass.localize("ui.panel.config.automation.editor.read_only")}
                  <mwc-button slot="action" @click=${this._duplicate}>
                    ${this.hass.localize("ui.panel.config.automation.editor.migrate")}
                  </mwc-button>
                </ha-alert>`:n.Ld}
          ${"gui"===this._mode?n.dy`
                <div class=${(0,l.$)({rtl:(0,c.HE)(this.hass)})}>
                  ${i?n.dy`
                        <blueprint-automation-editor .hass=${this.hass} .narrow=${this.narrow} .isWide=${this.isWide} .stateObj=${t} .config=${this._config} .disabled=${Boolean(this._readOnly)} @value-changed=${this._valueChanged}></blueprint-automation-editor>
                      `:n.dy`
                        <manual-automation-editor .hass=${this.hass} .narrow=${this.narrow} .isWide=${this.isWide} .stateObj=${t} .config=${this._config} .disabled=${Boolean(this._readOnly)} @value-changed=${this._valueChanged}></manual-automation-editor>
                      `}
                </div>
              `:"yaml"===this._mode?n.dy`${"off"===t?.state?n.dy`
                        <ha-alert alert-type="info">
                          ${this.hass.localize("ui.panel.config.automation.editor.disabled")}
                          <mwc-button slot="action" @click=${this._toggle}>
                            ${this.hass.localize("ui.panel.config.automation.editor.enable")}
                          </mwc-button>
                        </ha-alert>
                      `:""}
                  <ha-yaml-editor copy-clipboard .hass=${this.hass} .defaultValue=${this._preprocessYaml()} .readOnly=${this._readOnly} @value-changed=${this._yamlChanged}></ha-yaml-editor>`:n.Ld}
        </div>
        <ha-fab slot="fab" class=${(0,l.$)({dirty:!this._readOnly&&this._dirty})} .label=${this.hass.localize("ui.panel.config.automation.editor.save")} .disabled=${this._saving} extended @click=${this._handleSaveAutomation}>
          <ha-svg-icon slot="icon" .path=${E}></ha-svg-icon>
        </ha-fab>
      </hass-subpage>
    `}},{kind:"method",key:"updated",value:function(t){(0,o.Z)(e,"updated",this,3)([t]);const i=t.get("automationId");if(t.has("automationId")&&this.automationId&&this.hass&&i!==this.automationId&&(this._setEntityId(),this._loadConfig()),t.has("automationId")&&!this.automationId&&!this.entityId&&this.hass){const t=(0,g.Pl)();let i={description:""};t&&"use_blueprint"in t||(i={...i,mode:"single",triggers:[],conditions:[],actions:[]}),this._config={...i,...t?(0,g.EQ)(t):t},this._entityId=void 0,this._readOnly=!1,this._dirty=!0}t.has("entityId")&&this.entityId&&((0,g.SQ)(this.hass,this.entityId).then((t=>{this._config=(0,g.EQ)(t.config),this._checkValidation()})),this._entityId=this.entityId,this._dirty=!1,this._readOnly=!0),t.has("automations")&&this.automationId&&!this._entityId&&this._setEntityId(),t.has("_config")&&Object.values(this._configSubscriptions).forEach((t=>t(this._config)))}},{kind:"method",key:"_setEntityId",value:function(){const t=this.automations.find((t=>t.attributes.id===this.automationId));this._entityId=t?.entity_id}},{kind:"method",key:"_checkValidation",value:async function(){if(this._validationErrors=void 0,!this._entityId||!this._config)return;const t=this.hass.states[this._entityId];if(t?.state!==_.nZ)return;const i=await(0,p.w)(this.hass,{triggers:this._config.triggers,conditions:this._config.conditions,actions:this._config.actions});this._validationErrors=Object.entries(i).map((([t,i])=>i.valid?"":n.dy`${this.hass.localize(`ui.panel.config.automation.editor.${t}.name`)}:
            ${i.error}<br/>`))}},{kind:"method",key:"_loadConfig",value:async function(){try{const t=await(0,g.r4)(this.hass,this.automationId);this._dirty=!1,this._readOnly=!1,this._config=(0,g.EQ)(t),this._checkValidation()}catch(t){const i=this._entityRegistry.find((t=>"automation"===t.platform&&t.unique_id===this.automationId));if(i)return void(0,d.c)(`/config/automation/show/${i.entity_id}`,{replace:!0});await(0,v.showAlertDialog)(this,{text:404===t.status_code?this.hass.localize("ui.panel.config.automation.editor.load_error_not_editable"):this.hass.localize("ui.panel.config.automation.editor.load_error_unknown",{err_no:t.status_code})}),history.back()}}},{kind:"method",key:"_valueChanged",value:function(t){t.stopPropagation(),this._config=t.detail.value,this._readOnly||(this._dirty=!0,this._errors=void 0)}},{kind:"method",key:"_showInfo",value:function(){this.hass&&this._entityId&&(0,h.B)(this,"hass-more-info",{entityId:this._entityId})}},{kind:"method",key:"_showSettings",value:function(){(0,L.A)(this,{entityId:this._entityId,view:"settings"})}},{kind:"method",key:"_editCategory",value:function(){this._registryEntry?(0,z.U)(this,{scope:"automation",entityReg:this._registryEntry}):(0,v.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.scene.picker.no_category_support"),text:this.hass.localize("ui.panel.config.scene.picker.no_category_entity_reg")})}},{kind:"method",key:"_showTrace",value:async function(){if(this._config?.id){await this._confirmUnsavedChanged()&&(0,d.c)(`/config/automation/trace/${encodeURIComponent(this._config.id)}`)}}},{kind:"method",key:"_runActions",value:function(){this.hass&&this._entityId&&(0,g.Es)(this.hass,this.hass.states[this._entityId].entity_id)}},{kind:"method",key:"_toggle",value:async function(){if(!this.hass||!this._entityId)return;const t=this.hass.states[this._entityId],i="off"===t.state?"turn_on":"turn_off";await this.hass.callService("automation",i,{entity_id:t.entity_id})}},{kind:"method",key:"_preprocessYaml",value:function(){if(!this._config)return{};const t={...this._config};return delete t.id,t}},{kind:"method",key:"_yamlChanged",value:function(t){t.stopPropagation(),this._dirty=!0,t.detail.isValid?(this._yamlErrors=void 0,this._config={id:this._config?.id,...(0,g.EQ)(t.detail.value)},this._errors=void 0):this._yamlErrors=t.detail.errorMsg}},{kind:"method",key:"_confirmUnsavedChanged",value:async function(){return!this._dirty||new Promise((t=>{(0,w.h)(this,{config:this._config,domain:"automation",updateConfig:async(i,e)=>{this._config=i,this._entityRegistryUpdate=e,this._dirty=!0,this.requestUpdate();const a=this.automationId||String(Date.now());try{await this._saveAutomation(a)}catch(i){return this.requestUpdate(),void t(!1)}t(!0)},onClose:()=>t(!1),onDiscard:()=>t(!0),entityRegistryUpdate:this._entityRegistryUpdate,entityRegistryEntry:this._registryEntry,title:this.hass.localize(this.automationId?"ui.panel.config.automation.editor.leave.unsaved_confirm_title":"ui.panel.config.automation.editor.leave.unsaved_new_title"),description:this.hass.localize(this.automationId?"ui.panel.config.automation.editor.leave.unsaved_confirm_text":"ui.panel.config.automation.editor.leave.unsaved_new_text"),hideInputs:null!==this.automationId})}))}},{kind:"field",key:"_backTapped",value(){return async()=>{await this._confirmUnsavedChanged()&&(0,u.T)((()=>history.back()))}}},{kind:"method",key:"_takeControl",value:async function(){const t=this._config;try{const i=await(0,f.Uk)(this.hass,"automation",t.use_blueprint.path,t.use_blueprint.input||{}),e={...(0,g.EQ)(i.substituted_config),id:t.id,alias:t.alias,description:t.description};this._blueprintConfig=t,this._config=e,"yaml"===this._mode&&this.renderRoot.querySelector("ha-yaml-editor")?.setValue(this._config),this._readOnly=!0,this._errors=void 0}catch(t){this._errors=t.message}}},{kind:"method",key:"_revertBlueprint",value:function(){this._config=this._blueprintConfig,"yaml"===this._mode&&this.renderRoot.querySelector("ha-yaml-editor")?.setValue(this._config),this._blueprintConfig=void 0,this._readOnly=!1}},{kind:"method",key:"_takeControlSave",value:function(){this._readOnly=!1,this._dirty=!0,this._blueprintConfig=void 0}},{kind:"method",key:"_duplicate",value:async function(){(this._readOnly?await(0,v.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.automation.picker.migrate_automation"),text:this.hass.localize("ui.panel.config.automation.picker.migrate_automation_description")}):await this._confirmUnsavedChanged())&&(0,g.Ip)({...this._config,id:void 0,alias:this._readOnly?this._config?.alias:void 0})}},{kind:"method",key:"_deleteConfirm",value:async function(){(0,v.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.automation.picker.delete_confirm_title"),text:this.hass.localize("ui.panel.config.automation.picker.delete_confirm_text",{name:this._config?.alias}),confirmText:this.hass.localize("ui.common.delete"),destructive:!0,dismissText:this.hass.localize("ui.common.cancel"),confirm:()=>this._delete()})}},{kind:"method",key:"_delete",value:async function(){this.automationId&&(await(0,g.SC)(this.hass,this.automationId),history.back())}},{kind:"method",key:"_switchUiMode",value:async function(){if(this._yamlErrors){if(!await(0,v.showConfirmationDialog)(this,{text:n.dy`${this.hass.localize("ui.panel.config.automation.editor.switch_ui_yaml_error")}<br/><br/>${this._yamlErrors}`,confirmText:this.hass.localize("ui.common.continue"),destructive:!0,dismissText:this.hass.localize("ui.common.cancel")}))return}this._yamlErrors=void 0,this._mode="gui"}},{kind:"method",key:"_switchYamlMode",value:function(){this._mode="yaml"}},{kind:"method",key:"_promptAutomationAlias",value:async function(){return new Promise((t=>{(0,w.h)(this,{config:this._config,domain:"automation",updateConfig:async(i,e)=>{this._config=i,this._entityRegistryUpdate=e,this._dirty=!0,this.requestUpdate(),t(!0)},onClose:()=>t(!1),entityRegistryUpdate:this._entityRegistryUpdate,entityRegistryEntry:this._registryEntry})}))}},{kind:"method",key:"_promptAutomationMode",value:async function(){return new Promise((t=>{(0,C.q)(this,{config:this._config,updateConfig:i=>{this._config=i,this._dirty=!0,this.requestUpdate(),t()},onClose:()=>t()})}))}},{kind:"method",key:"_handleSaveAutomation",value:async function(){if(this._yamlErrors)return void(0,$.C)(this,{message:this._yamlErrors});const t=this.automationId||String(Date.now());if(!this.automationId){if(!await this._promptAutomationAlias())return}await this._saveAutomation(t),this.automationId||(0,d.c)(`/config/automation/edit/${t}`,{replace:!0})}},{kind:"method",key:"_saveAutomation",value:async function(t){let i;this._saving=!0,this._validationErrors=void 0,void 0===this._entityRegistryUpdate||this._entityId||(this._newAutomationId=t,i=new Promise((t=>{this._entityRegCreated=t})));try{if(await(0,g.sq)(this.hass,t,this._config),void 0!==this._entityRegistryUpdate){let t=this._entityId;if(i)try{t=(await(0,m.n)(5e3,i)).entity_id}catch(t){if(!(t instanceof Error&&"TimeoutError"===t.name))throw t;(0,v.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.automation.editor.new_automation_setup_failed_title",{type:this.hass.localize("ui.panel.config.automation.editor.type_automation")}),text:this.hass.localize("ui.panel.config.automation.editor.new_automation_setup_failed_text",{type:this.hass.localize("ui.panel.config.automation.editor.type_automation"),types:this.hass.localize("ui.panel.config.automation.editor.type_automation_plural")}),warning:!0})}t&&await(0,y.Nv)(this.hass,t,{categories:{automation:this._entityRegistryUpdate.category||null},labels:this._entityRegistryUpdate.labels||[],area_id:this._entityRegistryUpdate.area||null})}this._dirty=!1}catch(t){throw this._errors=t.body?.message||t.error||t.body,(0,$.C)(this,{message:t.body?.message||t.error||t.body}),t}finally{this._saving=!1}}},{kind:"method",key:"_subscribeAutomationConfig",value:function(t){const i=this._configSubscriptionsId++;this._configSubscriptions[i]=t.detail.callback,t.detail.unsub=()=>{delete this._configSubscriptions[i]},t.detail.callback(this._config)}},{kind:"method",key:"supportedShortcuts",value:function(){return{s:()=>this._handleSaveAutomation()}}},{kind:"get",key:"isDirty",value:function(){return this._dirty}},{kind:"method",key:"promptDiscardChanges",value:async function(){return this._confirmUnsavedChanged()}},{kind:"get",static:!0,key:"styles",value:function(){return[b.Qx,n.iv`.content{padding-bottom:20px}.yaml-mode{height:100%;display:flex;flex-direction:column;padding-bottom:0}:not(.yaml-mode)>ha-alert,blueprint-automation-editor,manual-automation-editor{margin:0 auto;max-width:1040px;padding:28px 20px 0;display:block}ha-yaml-editor{flex-grow:1;--actions-border-radius:0;--code-mirror-height:100%;min-height:0;display:flex;flex-direction:column}p{margin-bottom:0}ha-entity-toggle{margin-right:8px;margin-inline-end:8px;margin-inline-start:initial}ha-fab{position:relative;bottom:calc(-80px - env(safe-area-inset-bottom));transition:bottom .3s}ha-fab.dirty{bottom:0}li[role=separator]{border-bottom-color:var(--divider-color)}ha-button-menu a{text-decoration:none;color:var(--primary-color)}h1{margin:0}.header-name{display:flex;align-items:center;margin:0 auto;max-width:1040px;padding:28px 20px 0}`]}}]}}),(0,H.C)((0,k.U)(n.oi)));customElements.define("ha-automation-editor",G),i()}catch(t){i(t)}}))},87019:function(t,i,e){e.a(t,(async function(t,i){try{var a=e(44249),o=e(72621),n=(e(92745),e(9359),e(68107),e(56475),e(1331),e(31526),e(70104),e(52924),e(92519),e(42179),e(89256),e(24931),e(88463),e(57449),e(19814),e(75656),e(50100),e(18084),e(60738)),s=e(18672),l=e(13809),r=e(57243),h=e(15093),d=e(69634),c=e(27486),u=e(75011),m=e(72344),g=e(64214),f=e(94947),p=e(68958),_=e(36522),y=e(47194),v=e(83523),k=e(35076),b=(e(60370),e(10504),e(29891),e(51868),e(20130),e(75788),e(53678),e(76268),e(93258)),$=(e(43082),e(86735),e(23334),e(7843),e(96090),e(4573),e(37583),e(82100)),C=e(14473),w=e(36540),A=e(30635),x=e(12068),L=e(96194),z=e(63318),H=e(63860),V=e(2357),M=e(76131),S=(e(38419),e(6736)),I=e(28008),O=e(73192),E=e(9859),B=e(61107),Z=e(78819),R=e(11917),U=e(82967),j=e(26345),F=e(31694),P=t([b,g,f]);[b,g,f]=P.then?(await P)():P;const D="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z",T="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",W="M11,17H4A2,2 0 0,1 2,15V3A2,2 0 0,1 4,1H16V3H4V15H11V13L15,16L11,19V17M19,21V7H8V13H6V7A2,2 0 0,1 8,5H19A2,2 0 0,1 21,7V21A2,2 0 0,1 19,23H8A2,2 0 0,1 6,21V19H8V21H19Z",N="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",q="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",Q="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z",G="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",Y="M7,10L12,15L17,10H7Z",K="M8,5.14V19.14L19,12.14L8,5.14Z",X="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",J="M22 14H21C21 10.13 17.87 7 14 7H13V5.73C13.6 5.39 14 4.74 14 4C14 2.9 13.11 2 12 2S10 2.9 10 4C10 4.74 10.4 5.39 11 5.73V7H10C6.13 7 3 10.13 3 14H2C1.45 14 1 14.45 1 15V18C1 18.55 1.45 19 2 19H3V20C3 21.11 3.9 22 5 22H19C20.11 22 21 21.11 21 20V19H22C22.55 19 23 18.55 23 18V15C23 14.45 22.55 14 22 14M9.79 16.5C9.4 15.62 8.53 15 7.5 15S5.6 15.62 5.21 16.5C5.08 16.19 5 15.86 5 15.5C5 14.12 6.12 13 7.5 13S10 14.12 10 15.5C10 15.86 9.92 16.19 9.79 16.5M18.79 16.5C18.4 15.62 17.5 15 16.5 15S14.6 15.62 14.21 16.5C14.08 16.19 14 15.86 14 15.5C14 14.12 15.12 13 16.5 13S19 14.12 19 15.5C19 15.86 18.92 16.19 18.79 16.5Z",tt="M5.5,7A1.5,1.5 0 0,1 4,5.5A1.5,1.5 0 0,1 5.5,4A1.5,1.5 0 0,1 7,5.5A1.5,1.5 0 0,1 5.5,7M21.41,11.58L12.41,2.58C12.05,2.22 11.55,2 11,2H4C2.89,2 2,2.89 2,4V11C2,11.55 2.22,12.05 2.59,12.41L11.58,21.41C11.95,21.77 12.45,22 13,22C13.55,22 14.05,21.77 14.41,21.41L21.41,14.41C21.78,14.05 22,13.55 22,13C22,12.44 21.77,11.94 21.41,11.58Z",it="M20 2H4C2.9 2 2 2.9 2 4V20C2 21.11 2.9 22 4 22H20C21.11 22 22 21.11 22 20V4C22 2.9 21.11 2 20 2M4 6L6 4H10.9L4 10.9V6M4 13.7L13.7 4H18.6L4 18.6V13.7M20 18L18 20H13.1L20 13.1V18M20 10.3L10.3 20H5.4L20 5.4V10.3Z",et="M17,7H7A5,5 0 0,0 2,12A5,5 0 0,0 7,17H17A5,5 0 0,0 22,12A5,5 0 0,0 17,7M17,15A3,3 0 0,1 14,12A3,3 0 0,1 17,9A3,3 0 0,1 20,12A3,3 0 0,1 17,15Z",at="M17 6H7c-3.31 0-6 2.69-6 6s2.69 6 6 6h10c3.31 0 6-2.69 6-6s-2.69-6-6-6zm0 10H7c-2.21 0-4-1.79-4-4s1.79-4 4-4h10c2.21 0 4 1.79 4 4s-1.79 4-4 4zM7 9c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z",ot="M15,12C15,10.7 14.16,9.6 13,9.18V6.82C14.16,6.4 15,5.3 15,4A3,3 0 0,0 12,1A3,3 0 0,0 9,4C9,5.3 9.84,6.4 11,6.82V9.19C9.84,9.6 9,10.7 9,12C9,13.3 9.84,14.4 11,14.82V17.18C9.84,17.6 9,18.7 9,20A3,3 0 0,0 12,23A3,3 0 0,0 15,20C15,18.7 14.16,17.6 13,17.18V14.82C14.16,14.4 15,13.3 15,12M12,3A1,1 0 0,1 13,4A1,1 0 0,1 12,5A1,1 0 0,1 11,4A1,1 0 0,1 12,3M12,21A1,1 0 0,1 11,20A1,1 0 0,1 12,19A1,1 0 0,1 13,20A1,1 0 0,1 12,21Z";(0,a.Z)([(0,h.Mo)("ha-automation-picker")],(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",decorators:[(0,h.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,h.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,h.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,h.Cb)({attribute:!1})],key:"route",value:void 0},{kind:"field",decorators:[(0,h.Cb)({attribute:!1})],key:"automations",value:void 0},{kind:"field",decorators:[(0,h.SB)()],key:"_searchParms",value:()=>new URLSearchParams(window.location.search)},{kind:"field",decorators:[(0,h.SB)()],key:"_filteredAutomations",value:void 0},{kind:"field",decorators:[(0,p.t)({storage:"sessionStorage",key:"automation-table-search",state:!0,subscribe:!1})],key:"_filter",value:()=>""},{kind:"field",decorators:[(0,p.t)({storage:"sessionStorage",key:"automation-table-filters-full",state:!0,subscribe:!1,serializer:x.B,deserializer:x.l})],key:"_filters",value:()=>({})},{kind:"field",decorators:[(0,h.SB)()],key:"_expandedFilter",value:void 0},{kind:"field",decorators:[(0,h.SB)()],key:"_selected",value:()=>[]},{kind:"field",decorators:[(0,h.SB)()],key:"_categories",value:void 0},{kind:"field",decorators:[(0,h.SB)()],key:"_labels",value:void 0},{kind:"field",decorators:[(0,h.SB)(),(0,n.F_)({context:A.we,subscribe:!0})],key:"_entityReg",value:void 0},{kind:"field",decorators:[(0,h.SB)()],key:"_overflowAutomation",value:void 0},{kind:"field",decorators:[(0,p.t)({key:"automation-table-sort",state:!1,subscribe:!1})],key:"_activeSorting",value:void 0},{kind:"field",decorators:[(0,p.t)({key:"automation-table-grouping",state:!1,subscribe:!1})],key:"_activeGrouping",value:void 0},{kind:"field",decorators:[(0,p.t)({key:"automation-table-collapsed",state:!1,subscribe:!1})],key:"_activeCollapsed",value:void 0},{kind:"field",decorators:[(0,p.t)({key:"automation-table-column-order",state:!1,subscribe:!1})],key:"_activeColumnOrder",value:void 0},{kind:"field",decorators:[(0,p.t)({key:"automation-table-hidden-columns",state:!1,subscribe:!1})],key:"_activeHiddenColumns",value:void 0},{kind:"field",decorators:[(0,h.IO)("#overflow-menu")],key:"_overflowMenu",value:void 0},{kind:"field",key:"_sizeController",value(){return new s.Z(this,{callback:t=>t[0]?.contentRect.width})}},{kind:"field",key:"_automations",value(){return(0,c.Z)(((t,i,e,a,o,n)=>null===n?[]:(n?t.filter((t=>n.includes(t.entity_id))):t).map((t=>{const n=i.find((i=>i.entity_id===t.entity_id)),s=n?.categories.automation,l=o&&n?.labels;return{...t,name:(0,y.C)(t),area:n?.area_id?e[n?.area_id]?.name:void 0,last_triggered:t.attributes.last_triggered||void 0,formatted_state:this.hass.formatEntityState(t),category:s?a?.find((t=>t.category_id===s))?.name:void 0,labels:(l||[]).map((t=>o.find((i=>i.label_id===t)))),selectable:void 0!==n}}))))}},{kind:"field",key:"_columns",value(){return(0,c.Z)(((t,i,e)=>({icon:{title:"",label:i("ui.panel.config.automation.picker.headers.icon"),type:"icon",moveable:!1,showNarrow:!0,template:t=>r.dy`<ha-state-icon .hass=${this.hass} .stateObj=${t} style=${(0,d.V)({color:t.state===L.nZ?"var(--error-color)":"unset"})}></ha-state-icon>`},name:{title:i("ui.panel.config.automation.picker.headers.name"),main:!0,sortable:!0,filterable:!0,direction:"asc",flex:2,extraTemplate:t=>t.labels.length?r.dy`<ha-data-table-labels @label-clicked=${this._labelClicked} .labels=${t.labels}></ha-data-table-labels>`:r.Ld},area:{title:i("ui.panel.config.automation.picker.headers.area"),hidden:!0,groupable:!0,filterable:!0,sortable:!0},category:{title:i("ui.panel.config.automation.picker.headers.category"),hidden:!0,groupable:!0,filterable:!0,sortable:!0},labels:{title:"",hidden:!0,filterable:!0,template:t=>t.labels.map((t=>t.name)).join(" ")},last_triggered:{sortable:!0,title:i("ui.card.automation.last_triggered"),template:t=>{if(!t.last_triggered)return this.hass.localize("ui.components.relative_time.never");const i=new Date(t.last_triggered),a=new Date,o=(0,l.j)(a,i);return r.dy`
              ${o>3?(0,g.Fu)(i,this.hass.locale,this.hass.config):(0,f.G)(i,e)}
            `}},formatted_state:{minWidth:"82px",maxWidth:"82px",sortable:!0,groupable:!0,hidden:t,type:"overflow",title:this.hass.localize("ui.panel.config.automation.picker.state"),template:t=>r.dy`
            <ha-entity-toggle .stateObj=${t} .hass=${this.hass}></ha-entity-toggle>
          `},actions:{title:"",label:this.hass.localize("ui.panel.config.generic.headers.actions"),type:"icon-button",showNarrow:!0,moveable:!1,hideable:!1,template:t=>r.dy`
            <ha-icon-button .automation=${t} .label=${this.hass.localize("ui.common.overflow_menu")} .path=${q} @click=${this._showOverflowMenu}></ha-icon-button>
          `}})))}},{kind:"field",key:"_showOverflowMenu",value(){return t=>{this._overflowMenu.open&&t.target===this._overflowMenu.anchorElement?this._overflowMenu.close():(this._overflowAutomation=t.target.automation,this._overflowMenu.anchorElement=t.target,this._overflowMenu.show())}}},{kind:"method",key:"hassSubscribe",value:function(){return[(0,w.U)(this.hass.connection,"automation",(t=>{this._categories=t})),(0,H.f4)(this.hass.connection,(t=>{this._labels=t}))]}},{kind:"method",key:"render",value:function(){const t=r.dy`${this._categories?.map((t=>r.dy`<ha-md-menu-item .value=${t.category_id} .clickAction=${this._handleBulkCategory}>
            ${t.icon?r.dy`<ha-icon slot="start" .icon=${t.icon}></ha-icon>`:r.dy`<ha-svg-icon slot="start" .path=${tt}></ha-svg-icon>`}
            <div slot="headline">${t.name}</div>
          </ha-md-menu-item>`))}
      <ha-md-menu-item .value=${null} .clickAction=${this._handleBulkCategory}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.no_category")}
        </div>
      </ha-md-menu-item>
      <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
      <ha-md-menu-item .clickAction=${this._bulkCreateCategory}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.category.editor.add")}
        </div>
      </ha-md-menu-item>`,i=r.dy`${this._labels?.map((t=>{const i=t.color?(0,u.I)(t.color):void 0,e=this._selected.every((i=>this.hass.entities[i]?.labels.includes(t.label_id))),a=!e&&this._selected.some((i=>this.hass.entities[i]?.labels.includes(t.label_id)));return r.dy`<ha-md-menu-item .value=${t.label_id} .action=${e?"remove":"add"} @click=${this._handleBulkLabel} keep-open>
          <ha-checkbox slot="start" .checked=${e} .indeterminate=${a} reducedTouchTarget></ha-checkbox>
          <ha-label style=${i?`--color: ${i}`:""}>
            ${t.icon?r.dy`<ha-icon slot="icon" .icon=${t.icon}></ha-icon>`:r.Ld}
            ${t.name}
          </ha-label>
        </ha-md-menu-item>`}))}
      <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
      <ha-md-menu-item .clickAction=${this._bulkCreateLabel}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.labels.add_label")}
        </div></ha-md-menu-item>`,e=r.dy`${Object.values(this.hass.areas).map((t=>r.dy`<ha-md-menu-item .value=${t.area_id} .clickAction=${this._handleBulkArea}>
            ${t.icon?r.dy`<ha-icon slot="start" .icon=${t.icon}></ha-icon>`:r.dy`<ha-svg-icon slot="start" .path=${it}></ha-svg-icon>`}
            <div slot="headline">${t.name}</div>
          </ha-md-menu-item>`))}
      <ha-md-menu-item .value=${null} .clickAction=${this._handleBulkArea}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.no_area")}
        </div>
      </ha-md-menu-item>
      <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
      <ha-md-menu-item .clickAction=${this._bulkCreateArea}>
        <div slot="headline">
          ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.add_area")}
        </div>
      </ha-md-menu-item>`,a=this._sizeController.value&&this._sizeController.value<900||!this._sizeController.value&&"docked"===this.hass.dockedSidebar,o=a&&(!this._sizeController.value||this._sizeController.value<700),n=this._automations(this.automations,this._entityReg,this.hass.areas,this._categories,this._labels,this._filteredAutomations);return r.dy`
      <hass-tabs-subpage-data-table .hass=${this.hass} .narrow=${this.narrow} .backPath=${this._searchParms.has("historyBack")?void 0:"/config"} id="entity_id" .route=${this.route} .tabs=${U.configSections.automations} .searchLabel=${this.hass.localize("ui.panel.config.automation.picker.search",{number:n.length})} selectable .selected=${this._selected.length} @selection-changed=${this._handleSelectionChanged} has-filters .filters=${Object.values(this._filters).filter((t=>Array.isArray(t.value)?t.value.length:t.value&&Object.values(t.value).some((t=>Array.isArray(t)?t.length:t)))).length} .columns=${this._columns(this.narrow,this.hass.localize,this.hass.locale)} .initialGroupColumn=${this._activeGrouping??"category"} .initialCollapsedGroups=${this._activeCollapsed} .initialSorting=${this._activeSorting} .columnOrder=${this._activeColumnOrder} .hiddenColumns=${this._activeHiddenColumns} @columns-changed=${this._handleColumnsChanged} @sorting-changed=${this._handleSortingChanged} @grouping-changed=${this._handleGroupingChanged} @collapsed-changed=${this._handleCollapseChanged} .data=${n} .empty=${!this.automations.length} @row-click=${this._handleRowClicked} .noDataText=${this.hass.localize("ui.panel.config.automation.picker.no_automations")} @clear-filter=${this._clearFilter} .filter=${this._filter} @search-changed=${this._handleSearchChange} has-fab clickable class=${this.narrow?"narrow":""}>
        <ha-icon-button slot="toolbar-icon" .label=${this.hass.localize("ui.common.help")} .path=${Q} @click=${this._showHelp}></ha-icon-button>
        <ha-filter-floor-areas .hass=${this.hass} .type=${"automation"} .value=${this._filters["ha-filter-floor-areas"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-floor-areas"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-floor-areas>
        <ha-filter-devices .hass=${this.hass} .type=${"automation"} .value=${this._filters["ha-filter-devices"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-devices"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-devices>
        <ha-filter-entities .hass=${this.hass} .type=${"automation"} .value=${this._filters["ha-filter-entities"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-entities"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-entities>
        <ha-filter-labels .hass=${this.hass} .value=${this._filters["ha-filter-labels"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-labels"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-labels>
        <ha-filter-categories .hass=${this.hass} scope="automation" .value=${this._filters["ha-filter-categories"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-categories"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-categories>
        <ha-filter-blueprints .hass=${this.hass} .type=${"automation"} .value=${this._filters["ha-filter-blueprints"]?.value} @data-table-filter-changed=${this._filterChanged} slot="filter-pane" .expanded=${"ha-filter-blueprints"===this._expandedFilter} .narrow=${this.narrow} @expanded-changed=${this._filterExpanded}></ha-filter-blueprints>
          ${this.narrow?r.Ld:r.dy`<ha-md-button-menu slot="selection-bar">
                    <ha-assist-chip slot="trigger" .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.move_category")}>
                      <ha-svg-icon slot="trailing-icon" .path=${Y}></ha-svg-icon>
                    </ha-assist-chip>
                    ${t}
                  </ha-md-button-menu>
                  ${o?r.Ld:r.dy`<ha-md-button-menu slot="selection-bar">
                        <ha-assist-chip slot="trigger" .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.add_label")}>
                          <ha-svg-icon slot="trailing-icon" .path=${Y}></ha-svg-icon>
                        </ha-assist-chip>
                        ${i}
                      </ha-md-button-menu>`}
                  ${a?r.Ld:r.dy`<ha-md-button-menu slot="selection-bar">
                        <ha-assist-chip slot="trigger" .label=${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.move_area")}>
                          <ha-svg-icon slot="trailing-icon" .path=${Y}></ha-svg-icon>
                        </ha-assist-chip>
                        ${e}
                      </ha-md-button-menu>`}`}
          <ha-md-button-menu has-overflow slot="selection-bar">
            ${this.narrow?r.dy`<ha-assist-chip .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_action")} slot="trigger">
                    <ha-svg-icon slot="trailing-icon" .path=${Y}></ha-svg-icon>
                  </ha-assist-chip>`:r.dy`<ha-icon-button .path=${q} .label=${this.hass.localize("ui.panel.config.automation.picker.bulk_action")} slot="trigger"></ha-icon-button>`}
              <ha-svg-icon slot="trailing-icon" .path=${Y}></ha-svg-icon>
            ${this.narrow?r.dy`<ha-sub-menu>
                    <ha-md-menu-item slot="item">
                      <div slot="headline">
                        ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.move_category")}
                      </div>
                      <ha-svg-icon slot="end" .path=${D}></ha-svg-icon>
                    </ha-md-menu-item>
                    <ha-menu slot="menu">${t}</ha-menu>
                  </ha-sub-menu>`:r.Ld}
            ${this.narrow||o?r.dy`<ha-sub-menu>
                    <ha-md-menu-item slot="item">
                      <div slot="headline">
                        ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.add_label")}
                      </div>
                      <ha-svg-icon slot="end" .path=${D}></ha-svg-icon>
                    </ha-md-menu-item>
                    <ha-menu slot="menu">${i}</ha-menu>
                  </ha-sub-menu>`:r.Ld}
            ${this.narrow||a?r.dy`<ha-sub-menu>
                    <ha-md-menu-item slot="item">
                      <div slot="headline">
                        ${this.hass.localize("ui.panel.config.devices.picker.bulk_actions.move_area")}
                      </div>
                      <ha-svg-icon slot="end" .path=${D}></ha-svg-icon>
                    </ha-md-menu-item>
                    <ha-menu slot="menu">${e}</ha-menu>
                  </ha-sub-menu>`:r.Ld}
            <ha-md-menu-item .clickAction=${this._handleBulkEnable}>
              <ha-svg-icon slot="start" .path=${et}></ha-svg-icon>
              <div slot="headline">
                ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.enable")}
              </div>
            </ha-md-menu-item>
            <ha-md-menu-item .clickAction=${this._handleBulkDisable}>
              <ha-svg-icon slot="start" .path=${at}></ha-svg-icon>
              <div slot="headline">
                ${this.hass.localize("ui.panel.config.automation.picker.bulk_actions.disable")}
              </div>
            </ha-md-menu-item>
          </ha-md-button-menu>
        ${this.automations.length?r.Ld:r.dy`<div class="empty" slot="empty">
                <ha-svg-icon .path=${J}></ha-svg-icon>
                <h1>
                  ${this.hass.localize("ui.panel.config.automation.picker.empty_header")}
                </h1>
                <p>
                  ${this.hass.localize("ui.panel.config.automation.picker.empty_text_1")}
                </p>
                <p>
                  ${this.hass.localize("ui.panel.config.automation.picker.empty_text_2",{user:this.hass.user?.name||"Alice"})}
                </p>
                <a href=${(0,O.R)(this.hass,"/docs/automation/editor/")} target="_blank" rel="noreferrer">
                  <ha-button>
                    ${this.hass.localize("ui.panel.config.common.learn_more")}
                  </ha-button>
                </a>
              </div>`}
        <ha-fab slot="fab" .label=${this.hass.localize("ui.panel.config.automation.picker.add_automation")} extended @click=${this._createNew}>
          <ha-svg-icon slot="icon" .path=${X}></ha-svg-icon>
        </ha-fab>
      </hass-tabs-subpage-data-table>
      <ha-menu id="overflow-menu" positioning="fixed">
        <ha-md-menu-item .clickAction=${this._showInfo}>
          <ha-svg-icon .path=${G} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.editor.show_info")}
          </div>
        </ha-md-menu-item>

        <ha-md-menu-item .clickAction=${this._showSettings}>
          <ha-svg-icon .path=${T} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.picker.show_settings")}
          </div>
        </ha-md-menu-item>
        <ha-md-menu-item .clickAction=${this._editCategory}>
          <ha-svg-icon .path=${tt} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.picker."+(this._overflowAutomation?.category?"edit_category":"assign_category"))}
          </div>
        </ha-md-menu-item>
        <ha-md-menu-item .clickAction=${this._runActions}>
          <ha-svg-icon .path=${K} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.editor.run")}
          </div>
        </ha-md-menu-item>
        <ha-md-menu-item .clickAction=${this._showTrace}>
          <ha-svg-icon .path=${ot} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.editor.show_trace")}
          </div>
        </ha-md-menu-item>
        <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>
        <ha-md-menu-item .clickAction=${this._duplicate}>
          <ha-svg-icon .path=${W} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.picker.duplicate")}
          </div>
        </ha-md-menu-item>
        <ha-md-menu-item .clickAction=${this._toggle}>
          <ha-svg-icon .path=${"off"===this._overflowAutomation?.state?et:at} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${"off"===this._overflowAutomation?.state?this.hass.localize("ui.panel.config.automation.editor.enable"):this.hass.localize("ui.panel.config.automation.editor.disable")}
          </div>
        </ha-md-menu-item>
        <ha-md-menu-item .clickAction=${this._deleteConfirm} class="warning">
          <ha-svg-icon .path=${N} slot="start"></ha-svg-icon>
          <div slot="headline">
            ${this.hass.localize("ui.panel.config.automation.picker.delete")}
          </div>
        </ha-md-menu-item>
      </ha-menu>
    `}},{kind:"method",key:"updated",value:function(t){(0,o.Z)(e,"updated",this,3)([t]),t.has("_entityReg")&&this._applyFilters()}},{kind:"method",key:"firstUpdated",value:function(){this._searchParms.has("blueprint")&&this._filterBlueprint(),this._searchParms.has("label")&&this._filterLabel()}},{kind:"method",key:"_filterExpanded",value:function(t){t.detail.expanded?this._expandedFilter=t.target.localName:this._expandedFilter===t.target.localName&&(this._expandedFilter=void 0)}},{kind:"field",key:"_labelClicked",value(){return t=>{const i=t.detail.label;this._filters={...this._filters,"ha-filter-labels":{value:[i.label_id],items:void 0}},this._applyFilters()}}},{kind:"method",key:"_handleSearchChange",value:function(t){this._filter=t.detail.value}},{kind:"method",key:"_filterChanged",value:function(t){const i=t.target.localName;this._filters={...this._filters,[i]:t.detail},this._applyFilters()}},{kind:"method",key:"_applyFilters",value:function(){const t=Object.entries(this._filters);let i;for(const[e,a]of t){if(a.items){if(!i){i=a.items;continue}i="intersection"in i?i.intersection(a.items):new Set([...i].filter((t=>a.items.has(t))))}if("ha-filter-categories"===e&&Array.isArray(a.value)&&a.value.length){const t=new Set;if(this.automations.filter((t=>a.value[0]===this._entityReg.find((i=>i.entity_id===t.entity_id))?.categories.automation)).forEach((i=>t.add(i.entity_id))),!i){i=t;continue}i="intersection"in i?i.intersection(t):new Set([...i].filter((i=>t.has(i))))}if("ha-filter-labels"===e&&Array.isArray(a.value)&&a.value.length){const t=new Set;if(this.automations.filter((t=>this._entityReg.find((i=>i.entity_id===t.entity_id))?.labels.some((t=>a.value.includes(t))))).forEach((i=>t.add(i.entity_id))),!i){i=t;continue}i="intersection"in i?i.intersection(t):new Set([...i].filter((i=>t.has(i))))}}this._filteredAutomations=i?[...i]:void 0}},{kind:"method",key:"_filterLabel",value:function(){const t=this._searchParms.get("label");t&&(this._filters={...this._filters,"ha-filter-labels":{value:[t],items:void 0}},this._applyFilters())}},{kind:"method",key:"_filterBlueprint",value:async function(){const t=this._searchParms.get("blueprint");if(!t)return;const i=await(0,V.K)(this.hass,"automation_blueprint",t);this._filters={...this._filters,"ha-filter-blueprints":{value:[t],items:new Set(i.automation||[])}},this._applyFilters()}},{kind:"method",key:"_clearFilter",value:function(){this._filters={},this._applyFilters()}},{kind:"field",key:"_showInfo",value(){return t=>{const i=t.parentElement.anchorElement.automation;(0,_.B)(this,"hass-more-info",{entityId:i.entity_id})}}},{kind:"field",key:"_showSettings",value(){return t=>{const i=t.parentElement.anchorElement.automation;(0,_.B)(this,"hass-more-info",{entityId:i.entity_id,view:"settings"})}}},{kind:"field",key:"_runActions",value(){return t=>{const i=t.parentElement.anchorElement.automation;(0,C.Es)(this.hass,i.entity_id)}}},{kind:"field",key:"_editCategory",value(){return t=>{const i=t.parentElement.anchorElement.automation,e=this._entityReg.find((t=>t.entity_id===i.entity_id));e?(0,Z.U)(this,{scope:"automation",entityReg:e}):(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.automation.picker.no_category_support"),text:this.hass.localize("ui.panel.config.automation.picker.no_category_entity_reg")})}}},{kind:"field",key:"_showTrace",value(){return t=>{const i=t.parentElement.anchorElement.automation;i.attributes.id?(0,v.c)(`/config/automation/trace/${encodeURIComponent(i.attributes.id)}`):(0,M.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.automation.picker.traces_not_available")})}}},{kind:"field",key:"_toggle",value(){return async t=>{const i=t.parentElement.anchorElement.automation,e="off"===i.state?"turn_on":"turn_off";await this.hass.callService("automation",e,{entity_id:i.entity_id})}}},{kind:"field",key:"_deleteConfirm",value(){return async t=>{const i=t.parentElement.anchorElement.automation;(0,M.showConfirmationDialog)(this,{title:this.hass.localize("ui.panel.config.automation.picker.delete_confirm_title"),text:this.hass.localize("ui.panel.config.automation.picker.delete_confirm_text",{name:i.name}),confirmText:this.hass.localize("ui.common.delete"),dismissText:this.hass.localize("ui.common.cancel"),confirm:()=>this._delete(i),destructive:!0})}}},{kind:"method",key:"_delete",value:async function(t){try{await(0,C.SC)(this.hass,t.attributes.id)}catch(t){await(0,M.showAlertDialog)(this,{text:400===t.status_code?this.hass.localize("ui.panel.config.automation.editor.load_error_not_deletable"):this.hass.localize("ui.panel.config.automation.editor.load_error_unknown",{err_no:t.status_code})})}}},{kind:"field",key:"_duplicate",value(){return async t=>{const i=t.parentElement.anchorElement.automation;try{const t=await(0,C.r4)(this.hass,i.attributes.id);(0,C.HF)(t)}catch(t){if(404===t.status_code){const t=await(0,C.SQ)(this.hass,i.entity_id);return void(0,C.Ip)({...t.config,id:void 0})}await(0,M.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.automation.editor.load_error_unknown",{err_no:t.status_code})})}}}},{kind:"method",key:"_showHelp",value:function(){(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.automation.caption"),text:r.dy`
        ${this.hass.localize("ui.panel.config.automation.picker.introduction")}
        <p>
          <a href=${(0,O.R)(this.hass,"/docs/automation/editor/")} target="_blank" rel="noreferrer">
            ${this.hass.localize("ui.panel.config.automation.picker.learn_more")}
          </a>
        </p>
      `})}},{kind:"method",key:"_handleRowClicked",value:function(t){const i=this.automations.find((i=>i.entity_id===t.detail.id));i?.attributes.id?(0,v.c)(`/config/automation/edit/${encodeURIComponent(i.attributes.id)}`):(0,v.c)(`/config/automation/show/${encodeURIComponent(t.detail.id)}`)}},{kind:"method",key:"_handleSelectionChanged",value:function(t){this._selected=t.detail.value}},{kind:"method",key:"_createNew",value:function(){(0,m.p)(this.hass,"blueprint")?(0,F.X)(this,{mode:"automation"}):(0,v.c)("/config/automation/edit/new")}},{kind:"field",key:"_handleBulkCategory",value(){return async t=>{const i=t.value;this._bulkAddCategory(i)}}},{kind:"method",key:"_bulkAddCategory",value:async function(t){const i=[];this._selected.forEach((e=>{i.push((0,z.Nv)(this.hass,e,{categories:{automation:t}}))}));const e=await Promise.allSettled(i);if((0,k.M)(e)){const t=(0,k.a)(e);(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:t.length}),text:r.dy`<pre>
${t.map((t=>t.reason.message||t.reason.code||t.reason)).join("\r\n")}</pre>`})}}},{kind:"method",key:"_handleBulkLabel",value:async function(t){const i=t.currentTarget.value,e=t.currentTarget.action;this._bulkLabel(i,e)}},{kind:"method",key:"_bulkLabel",value:async function(t,i){const e=[];this._selected.forEach((a=>{e.push((0,z.Nv)(this.hass,a,{labels:"add"===i?this.hass.entities[a].labels.concat(t):this.hass.entities[a].labels.filter((i=>i!==t))}))}));const a=await Promise.allSettled(e);if((0,k.M)(a)){const t=(0,k.a)(a);(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:t.length}),text:r.dy`<pre>
${t.map((t=>t.reason.message||t.reason.code||t.reason)).join("\r\n")}</pre>`})}}},{kind:"field",key:"_handleBulkArea",value(){return t=>{const i=t.value;this._bulkAddArea(i)}}},{kind:"method",key:"_bulkAddArea",value:async function(t){const i=[];this._selected.forEach((e=>{i.push((0,z.Nv)(this.hass,e,{area_id:t}))}));const e=await Promise.allSettled(i);if((0,k.M)(e)){const t=(0,k.a)(e);(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:t.length}),text:r.dy`<pre>
${t.map((t=>t.reason.message||t.reason.code||t.reason)).join("\r\n")}</pre>`})}}},{kind:"field",key:"_bulkCreateArea",value(){return async()=>{(0,B.E)(this,{createEntry:async t=>{const i=await(0,$.Lo)(this.hass,t);return this._bulkAddArea(i.area_id),i}})}}},{kind:"field",key:"_handleBulkEnable",value(){return async()=>{const t=[];this._selected.forEach((i=>{t.push((0,E.S)(this.hass,i,!0))}));const i=await Promise.allSettled(t);if((0,k.M)(i)){const t=(0,k.a)(i);(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:t.length}),text:r.dy`<pre>
${t.map((t=>t.reason.message||t.reason.code||t.reason)).join("\r\n")}</pre>`})}}}},{kind:"field",key:"_handleBulkDisable",value(){return async()=>{const t=[];this._selected.forEach((i=>{t.push((0,E.S)(this.hass,i,!1))}));const i=await Promise.allSettled(t);if((0,k.M)(i)){const t=(0,k.a)(i);(0,M.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.common.multiselect.failed",{number:t.length}),text:r.dy`<pre>
${t.map((t=>t.reason.message||t.reason.code||t.reason)).join("\r\n")}</pre>`})}}}},{kind:"field",key:"_bulkCreateCategory",value(){return async()=>{(0,R.n)(this,{scope:"automation",createEntry:async t=>{const i=await(0,w.DM)(this.hass,"automation",t);return this._bulkAddCategory(i.category_id),i}})}}},{kind:"field",key:"_bulkCreateLabel",value(){return()=>{(0,j.T)(this,{createEntry:async t=>{const i=await(0,H.jo)(this.hass,t);return this._bulkLabel(i.label_id,"add"),i}})}}},{kind:"method",key:"_handleSortingChanged",value:function(t){this._activeSorting=t.detail}},{kind:"method",key:"_handleGroupingChanged",value:function(t){this._activeGrouping=t.detail.value??""}},{kind:"method",key:"_handleCollapseChanged",value:function(t){this._activeCollapsed=t.detail.value}},{kind:"method",key:"_handleColumnsChanged",value:function(t){this._activeColumnOrder=t.detail.columnOrder,this._activeHiddenColumns=t.detail.hiddenColumns}},{kind:"get",static:!0,key:"styles",value:function(){return[I.Qx,r.iv`:host{display:block;height:100%}hass-tabs-subpage-data-table{--data-table-row-height:60px}hass-tabs-subpage-data-table.narrow{--data-table-row-height:72px}.empty{--paper-font-headline_-_font-size:28px;--mdc-icon-size:80px;max-width:500px}ha-assist-chip{--ha-assist-chip-container-shape:10px}ha-md-button-menu ha-assist-chip{--md-assist-chip-trailing-space:8px}ha-label{--ha-label-background-color:var(--color, var(--grey-color));--ha-label-background-opacity:0.5}`]}}]}}),(0,S.f)(r.oi));i()}catch(t){i(t)}}))},74784:function(t,i,e){e.a(t,(async function(t,a){try{e.r(i);var o=e(44249),n=e(72621),s=(e(9359),e(68107),e(56475),e(15093)),l=e(27486),r=e(59847),h=e(22381),d=e(24312),c=e(55615),u=e(87019),m=t([c,u]);[c,u]=m.then?(await m)():m;const g=(t,i)=>t.length===i.length&&t.every(((t,e)=>t===i[e]));(0,o.Z)([(0,s.Mo)("ha-config-automation")],(function(t,i){class a extends i{constructor(...i){super(...i),t(this)}}return{F:a,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"showAdvanced",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"automations",value:()=>[]},{kind:"field",key:"_debouncedUpdateAutomations",value(){return(0,h.D)((t=>{const i=this._getAutomations(this.hass.states);g(i,t.automations)||(t.automations=i)}),10)}},{kind:"field",key:"routerOptions",value:()=>({defaultPage:"dashboard",routes:{dashboard:{tag:"ha-automation-picker",cache:!0},edit:{tag:"ha-automation-editor"},show:{tag:"ha-automation-editor"},trace:{tag:"ha-automation-trace",load:()=>Promise.all([e.e("65499"),e.e("44856"),e.e("84933")]).then(e.bind(e,79601))}}})},{kind:"field",key:"_getAutomations",value:()=>(0,l.Z)((t=>Object.values(t).filter((t=>"automation"===(0,r.N)(t)&&!t.attributes.restored))))},{kind:"method",key:"firstUpdated",value:function(t){(0,n.Z)(a,"firstUpdated",this,3)([t]),this.hass.loadBackendTranslation("device_automation")}},{kind:"method",key:"updatePageEl",value:function(t,i){if(t.hass=this.hass,t.narrow=this.narrow,t.isWide=this.isWide,t.route=this.routeTail,t.showAdvanced=this.showAdvanced,this.hass&&(t.automations&&i?i.has("hass")&&this._debouncedUpdateAutomations(t):t.automations=this._getAutomations(this.hass.states)),(!i||i.has("route"))&&"show"===this._currentPage){const i=decodeURIComponent(this.routeTail.path.substr(1));return t.automationId=null,void(t.entityId="new"===i?null:i)}if((!i||i.has("route"))&&"dashboard"!==this._currentPage){const i=decodeURIComponent(this.routeTail.path.substr(1));t.automationId="new"===i?null:i,t.entityId=null}}}]}}),d.n);a()}catch(t){a(t)}}))},11808:function(t,i,e){e.a(t,(async function(t,i){try{var a=e(44249),o=e(72621),n=(e(9359),e(31526),e(31622),e(57243)),s=e(15093),l=e(95262),r=e(36522),h=(e(54977),e(23334),e(99254),e(28008)),d=e(73192),c=e(40928),u=e(93831),m=e(79805),g=e(58776),f=e(35830),p=t([c,u,m]);[c,u,m]=p.then?(await p)():p;const _="M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z";(0,a.Z)([(0,s.Mo)("manual-automation-editor")],(function(t,i){class e extends i{constructor(...i){super(...i),t(this)}}return{F:e,d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({type:Boolean})],key:"disabled",value:()=>!1},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"config",value:void 0},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"firstUpdated",value:function(t){(0,o.Z)(e,"firstUpdated",this,3)([t]);if("1"===(0,g.io)("expanded")){this._clearParam("expanded");this.shadowRoot.querySelectorAll("ha-automation-trigger, ha-automation-condition, ha-automation-action").forEach((t=>{t.updateComplete.then((()=>{t.expandAll()}))}))}}},{kind:"method",key:"_clearParam",value:function(t){window.history.replaceState(null,"",(0,f.q)((0,g.pc)(t)))}},{kind:"method",key:"render",value:function(){return n.dy`
      ${"off"===this.stateObj?.state?n.dy`
            <ha-alert alert-type="info">
              ${this.hass.localize("ui.panel.config.automation.editor.disabled")}
              <mwc-button slot="action" @click=${this._enable}>
                ${this.hass.localize("ui.panel.config.automation.editor.enable")}
              </mwc-button>
            </ha-alert>
          `:n.Ld}
      ${this.config.description?n.dy`<ha-markdown class="description" breaks .content=${this.config.description}></ha-markdown>`:n.Ld}
      <div class="header">
        <h2 id="triggers-heading" class="name">
          ${this.hass.localize("ui.panel.config.automation.editor.triggers.header")}
        </h2>
        <a href=${(0,d.R)(this.hass,"/docs/automation/trigger/")} target="_blank" rel="noreferrer">
          <ha-icon-button .path=${_} .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.learn_more")}></ha-icon-button>
        </a>
      </div>
      ${(0,l.r)(this.config.triggers)?.length?n.Ld:n.dy`<p>
            ${this.hass.localize("ui.panel.config.automation.editor.triggers.description")}
          </p>`}

      <ha-automation-trigger role="region" aria-labelledby="triggers-heading" .triggers=${this.config.triggers||[]} .path=${["triggers"]} @value-changed=${this._triggerChanged} .hass=${this.hass} .disabled=${this.disabled}></ha-automation-trigger>

      <div class="header">
        <h2 id="conditions-heading" class="name">
          ${this.hass.localize("ui.panel.config.automation.editor.conditions.header")}
          <span class="small">(${this.hass.localize("ui.common.optional")})</span>
        </h2>
        <a href=${(0,d.R)(this.hass,"/docs/automation/condition/")} target="_blank" rel="noreferrer">
          <ha-icon-button .path=${_} .label=${this.hass.localize("ui.panel.config.automation.editor.conditions.learn_more")}></ha-icon-button>
        </a>
      </div>
      ${(0,l.r)(this.config.conditions)?.length?n.Ld:n.dy`<p>
            ${this.hass.localize("ui.panel.config.automation.editor.conditions.description",{user:this.hass.user?.name||"Alice"})}
          </p>`}

      <ha-automation-condition role="region" aria-labelledby="conditions-heading" .conditions=${this.config.conditions||[]} .path=${["conditions"]} @value-changed=${this._conditionChanged} .hass=${this.hass} .disabled=${this.disabled}></ha-automation-condition>

      <div class="header">
        <h2 id="actions-heading" class="name">
          ${this.hass.localize("ui.panel.config.automation.editor.actions.header")}
        </h2>
        <div>
          <a href=${(0,d.R)(this.hass,"/docs/automation/action/")} target="_blank" rel="noreferrer">
            <ha-icon-button .path=${_} .label=${this.hass.localize("ui.panel.config.automation.editor.actions.learn_more")}></ha-icon-button>
          </a>
        </div>
      </div>
      ${(0,l.r)(this.config.actions)?.length?n.Ld:n.dy`<p>
            ${this.hass.localize("ui.panel.config.automation.editor.actions.description")}
          </p>`}

      <ha-automation-action role="region" aria-labelledby="actions-heading" .actions=${this.config.actions||[]} .path=${["actions"]} @value-changed=${this._actionChanged} .hass=${this.hass} .narrow=${this.narrow} .disabled=${this.disabled}></ha-automation-action>
    `}},{kind:"method",key:"_triggerChanged",value:function(t){t.stopPropagation(),(0,r.B)(this,"value-changed",{value:{...this.config,triggers:t.detail.value}})}},{kind:"method",key:"_conditionChanged",value:function(t){t.stopPropagation(),(0,r.B)(this,"value-changed",{value:{...this.config,conditions:t.detail.value}})}},{kind:"method",key:"_actionChanged",value:function(t){t.stopPropagation(),(0,r.B)(this,"value-changed",{value:{...this.config,actions:t.detail.value}})}},{kind:"method",key:"_enable",value:async function(){this.hass&&this.stateObj&&await this.hass.callService("automation","turn_on",{entity_id:this.stateObj.entity_id})}},{kind:"get",static:!0,key:"styles",value:function(){return[h.Qx,n.iv`:host{display:block}ha-card{overflow:hidden}.description{margin:0}p{margin-top:0}.header{margin-top:16px;display:flex;align-items:center}.header:first-child{margin-top:-16px}.header .name{font-weight:400;flex:1;margin-bottom:16px}.header a{color:var(--secondary-text-color)}.header .small{font-size:small;font-weight:400;line-height:0}`]}}]}}),n.oi);i()}catch(t){i(t)}}))},98241:function(t,i,e){var a=e(44249),o=e(57243),n=e(15093),s=e(35359);(0,a.Z)([(0,n.Mo)("ha-config-section")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean})],key:"vertical",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"full-width"})],key:"fullWidth",value:()=>!1},{kind:"method",key:"render",value:function(){return o.dy`
      <div class="content ${(0,s.$)({narrow:!this.isWide,"full-width":this.fullWidth})}">
        <div class="header"><slot name="header"></slot></div>
        <div class="together layout ${(0,s.$)({narrow:!this.isWide,vertical:this.vertical||!this.isWide,horizontal:!this.vertical&&this.isWide})}">
          <div class="intro"><slot name="introduction"></slot></div>
          <div class="panel flex-auto"><slot></slot></div>
        </div>
      </div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>o.iv`.header,.intro{opacity:var(--dark-primary-opacity)}:host{display:block}.content{padding:28px 20px 0;max-width:1040px;margin:0 auto}.layout{display:flex}.horizontal{flex-direction:row}.full-width .layout,.vertical{flex-direction:column}.flex-auto{flex:1 1 auto}.header{font-family:var(--paper-font-headline_-_font-family);-webkit-font-smoothing:var(--paper-font-headline_-_-webkit-font-smoothing);font-size:var(--paper-font-headline_-_font-size);font-weight:var(--paper-font-headline_-_font-weight);letter-spacing:var(--paper-font-headline_-_letter-spacing);line-height:var(--paper-font-headline_-_line-height)}.together{margin-top:var(--config-section-content-together-margin-top,32px)}.intro{font-family:var(--paper-font-subhead_-_font-family);-webkit-font-smoothing:var(--paper-font-subhead_-_-webkit-font-smoothing);font-weight:var(--paper-font-subhead_-_font-weight);line-height:var(--paper-font-subhead_-_line-height);width:100%;font-size:14px;padding-bottom:20px}.horizontal .intro{max-width:400px;margin-right:40px;margin-inline-end:40px;margin-inline-start:initial}.panel{margin-top:-24px}.panel ::slotted(*){margin-top:24px;display:block}.narrow.content{max-width:640px}.narrow .together{margin-top:var(--config-section-narrow-content-together-margin-top,var(--config-section-content-together-margin-top,20px))}.narrow .intro{padding-bottom:20px;margin-right:0;margin-inline-end:0;margin-inline-start:initial;max-width:500px}.full-width{padding:0}`}]}}),o.oi)}};
//# sourceMappingURL=78507.81b8c7f6846ddda7.js.map