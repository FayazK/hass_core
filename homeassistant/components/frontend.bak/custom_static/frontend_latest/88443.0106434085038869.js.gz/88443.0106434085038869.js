export const __webpack_ids__=["88443"];export const __webpack_modules__={99426:function(e,t,i){i.r(t);var a=i(44249),s=i(57243),n=i(15093),o=i(35359),r=i(36522);i(23334),i(37583);const l={info:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",warning:"M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16",error:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",success:"M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"};(0,a.Z)([(0,n.Mo)("ha-alert")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)()],key:"title",value:()=>""},{kind:"field",decorators:[(0,n.Cb)({attribute:"alert-type"})],key:"alertType",value:()=>"info"},{kind:"field",decorators:[(0,n.Cb)({type:Boolean})],key:"dismissable",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"method",key:"render",value:function(){return s.dy`
      <div class="issue-type ${(0,o.$)({[this.alertType]:!0})}" role="alert">
        <div class="icon ${this.title?"":"no-title"}">
          <slot name="icon">
            <ha-svg-icon .path=${l[this.alertType]}></ha-svg-icon>
          </slot>
        </div>
        <div class=${(0,o.$)({content:!0,narrow:this.narrow})}>
          <div class="main-content">
            ${this.title?s.dy`<div class="title">${this.title}</div>`:s.Ld}
            <slot></slot>
          </div>
          <div class="action">
            <slot name="action">
              ${this.dismissable?s.dy`<ha-icon-button @click=${this._dismissClicked} label="Dismiss alert" .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}></ha-icon-button>`:s.Ld}
            </slot>
          </div>
        </div>
      </div>
    `}},{kind:"method",key:"_dismissClicked",value:function(){(0,r.B)(this,"alert-dismissed-clicked")}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`.action,.icon{z-index:1}.issue-type{position:relative;padding:8px;display:flex}.issue-type::after{position:absolute;top:0;right:0;bottom:0;left:0;opacity:.12;pointer-events:none;content:"";border-radius:4px}.icon.no-title{align-self:center}.content{display:flex;justify-content:space-between;align-items:center;width:100%;text-align:var(--float-start)}.content.narrow{flex-direction:column;align-items:flex-end}.action{width:min-content;--mdc-theme-primary:var(--primary-text-color)}.main-content{overflow-wrap:anywhere;word-break:break-word;margin-left:8px;margin-right:0;margin-inline-start:8px;margin-inline-end:0}.title{margin-top:2px;font-weight:700}.action ha-icon-button,.action mwc-button{--mdc-theme-primary:var(--primary-text-color);--mdc-icon-button-size:36px}.issue-type.info>.icon{color:var(--info-color)}.issue-type.info::after{background-color:var(--info-color)}.issue-type.warning>.icon{color:var(--warning-color)}.issue-type.warning::after{background-color:var(--warning-color)}.issue-type.error>.icon{color:var(--error-color)}.issue-type.error::after{background-color:var(--error-color)}.issue-type.success>.icon{color:var(--success-color)}.issue-type.success::after{background-color:var(--success-color)}:host ::slotted(ul){margin:0;padding-inline-start:20px}`}]}}),s.oi)},59826:function(e,t,i){var a=i(44249),s=i(31622),n=i(57243),o=i(15093),r=i(22344);(0,a.Z)([(0,o.Mo)("ha-button")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",static:!0,key:"styles",value:()=>[r.W,n.iv`::slotted([slot=icon]){margin-inline-start:0px;margin-inline-end:8px;direction:var(--direction);display:block}.mdc-button{height:var(--button-height,36px)}.trailing-icon{display:flex}.slot-container{overflow:var(--button-slot-container-overflow,visible)}:host([destructive]){--mdc-theme-primary:var(--error-color)}`]}]}}),s.Button)},55486:function(e,t,i){var a=i(44249),s=i(4918),n=i(6394),o=i(57243),r=i(15093),l=i(35359),c=i(36522);(0,a.Z)([(0,r.Mo)("ha-formfield")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({type:Boolean,reflect:!0})],key:"disabled",value:()=>!1},{kind:"method",key:"render",value:function(){const e={"mdc-form-field--align-end":this.alignEnd,"mdc-form-field--space-between":this.spaceBetween,"mdc-form-field--nowrap":this.nowrap};return o.dy` <div class="mdc-form-field ${(0,l.$)(e)}">
      <slot></slot>
      <label class="mdc-label" @click=${this._labelClick}>
        <slot name="label">${this.label}</slot>
      </label>
    </div>`}},{kind:"method",key:"_labelClick",value:function(){const e=this.input;if(e&&(e.focus(),!e.disabled))switch(e.tagName){case"HA-CHECKBOX":e.checked=!e.checked,(0,c.B)(e,"change");break;case"HA-RADIO":e.checked=!0,(0,c.B)(e,"change");break;default:e.click()}}},{kind:"field",static:!0,key:"styles",value:()=>[n.W,o.iv`:host(:not([alignEnd])) ::slotted(ha-switch){margin-right:10px;margin-inline-end:10px;margin-inline-start:inline}.mdc-form-field{align-items:var(--ha-formfield-align-items,center);gap:4px}.mdc-form-field>label{direction:var(--direction);margin-inline-start:0;margin-inline-end:auto;color:#fff!important;padding:0}:host([disabled]) label{color:var(--disabled-text-color)}`]}]}}),s.a)},2914:function(e,t,i){var a=i(44249),s=i(57243),n=i(15093);(0,a.Z)([(0,n.Mo)("ha-label")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({type:Boolean,reflect:!0})],key:"dense",value:()=>!1},{kind:"method",key:"render",value:function(){return s.dy`
      <span class="content">
        <slot name="icon"></slot>
        <slot></slot>
      </span>
    `}},{kind:"get",static:!0,key:"styles",value:function(){return[s.iv`.content>*,span{display:inline-flex}:host{--ha-label-text-color:var(--primary-text-color);--ha-label-icon-color:var(--primary-text-color);--ha-label-background-color:rgba(
            var(--rgb-primary-text-color),
            0.15
          );--ha-label-background-opacity:1;border:1px solid var(--outline-color);position:relative;box-sizing:border-box;display:inline-flex;flex-direction:row;align-items:center;font-size:12px;font-weight:500;line-height:16px;letter-spacing:.1px;vertical-align:middle;height:32px;padding:0 16px;border-radius:18px;color:var(--ha-label-text-color);--mdc-icon-size:12px;text-wrap:nowrap}.content>*{position:relative;flex-direction:row;align-items:center}:host:before{position:absolute;content:"";inset:0;border-radius:inherit;background-color:var(--ha-label-background-color);opacity:var(--ha-label-background-opacity)}::slotted([slot=icon]){margin-right:8px;margin-left:-8px;margin-inline-start:-8px;margin-inline-end:8px;display:flex}:host([dense]){height:20px;padding:0 12px;border-radius:10px}:host([dense]) ::slotted([slot=icon]){margin-right:4px;margin-left:-4px;margin-inline-start:-4px;margin-inline-end:4px}`]}}]}}),s.oi)},30509:function(e,t,i){var a=i(44249),s=i(57243),n=i(15093);(0,a.Z)([(0,n.Mo)("ha-settings-row")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({type:Boolean,reflect:!0})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,reflect:!0})],key:"slim",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"three-line"})],key:"threeLine",value:()=>!1},{kind:"field",decorators:[(0,n.Cb)({type:Boolean,attribute:"wrap-heading",reflect:!0})],key:"wrapHeading",value:()=>!1},{kind:"method",key:"render",value:function(){return s.dy`
      <div class="prefix-wrap">
        <slot name="prefix"></slot>
        <div class="body" ?two-line=${!this.threeLine} ?three-line=${this.threeLine}>
          <slot name="heading"></slot>
          <div class="secondary"><slot name="description"></slot></div>
        </div>
      </div>
      <div class="content"><slot></slot></div>
    `}},{kind:"field",static:!0,key:"styles",value:()=>s.iv`:host{display:flex;padding:0 16px;align-content:normal;align-self:auto;align-items:center}.body{padding-inline-start:0;padding:8px 16px 8px 0;padding-inline-end:16px;overflow:hidden;display:var(--layout-vertical_-_display,flex);flex-direction:var(--layout-vertical_-_flex-direction,column);justify-content:var(--layout-center-justified_-_justify-content,center);flex:var(--layout-flex_-_flex,1);flex-basis:var(--layout-flex_-_flex-basis,0.000000001px)}.body[three-line]{min-height:var(--paper-item-body-three-line-min-height,88px)}:host(:not([wrap-heading])) body>*{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.body>.secondary{display:block;padding-top:4px;font-family:var(
        --mdc-typography-body2-font-family,
        var(--mdc-typography-font-family, Roboto, sans-serif)
      );-webkit-font-smoothing:antialiased;font-size:var(--mdc-typography-body2-font-size, .875rem);font-weight:var(--mdc-typography-body2-font-weight,400);line-height:normal;color:var(--secondary-text-color)}.body[two-line]{min-height:calc(var(--paper-item-body-two-line-min-height,72px) - 16px);flex:1}.content{display:contents}:host(:not([narrow])) .content{display:var(--settings-row-content-display,flex);justify-content:flex-end;flex:1;padding:16px 0}.content ::slotted(*){width:var(--settings-row-content-width)}:host([narrow]){align-items:normal;flex-direction:column;border-top:1px solid var(--divider-color);padding-bottom:8px}::slotted(ha-switch){padding:16px 0}.secondary{white-space:normal}.prefix-wrap{display:var(--settings-row-prefix-display)}:host([narrow]) .prefix-wrap{display:flex;align-items:center}:host([slim]),:host([slim]) .content,:host([slim]) ::slotted(ha-switch){padding:0}:host([slim]) .body{min-height:0}`}]}}),s.oi)},1888:function(e,t,i){var a=i(44249),s=i(72621),n=i(62523),o=i(83835),r=i(57243),l=i(15093),c=i(13560);(0,a.Z)([(0,l.Mo)("ha-switch")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)({type:Boolean})],key:"haptic",value:()=>!1},{kind:"method",key:"firstUpdated",value:function(){(0,s.Z)(i,"firstUpdated",this,3)([]),this.addEventListener("change",(()=>{this.haptic&&(0,c.j)("light")}))}},{kind:"field",static:!0,key:"styles",value:()=>[o.W,r.iv`:host{--mdc-theme-secondary:var(--switch-checked-color)}.mdc-switch.mdc-switch--checked .mdc-switch__thumb{background-color:var(--switch-checked-button-color);border-color:var(--switch-checked-button-color)}.mdc-switch.mdc-switch--checked .mdc-switch__track{background-color:var(--switch-checked-track-color);border-color:var(--switch-checked-track-color)}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb{background-color:var(--switch-unchecked-button-color);border-color:var(--switch-unchecked-button-color)}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__track{background-color:var(--switch-unchecked-track-color);border-color:var(--switch-unchecked-track-color)}`]}]}}),n.H)},43546:function(e,t,i){i.d(t,{Cp:()=>o,TZ:()=>r,W2:()=>n,YY:()=>c,iI:()=>s,j2:()=>l,oT:()=>a});i(9359),i(70104);const a=e=>e.map((e=>{if("string"!==e.type)return e;switch(e.name){case"username":return{...e,autocomplete:"username",autofocus:!0};case"password":return{...e,autocomplete:"current-password"};case"code":return{...e,autocomplete:"one-time-code",autofocus:!0};default:return e}})),s=(e,t)=>e.callWS({type:"auth/sign_path",path:t}),n=async(e,t,i,a)=>e.callWS({type:"config/auth_provider/homeassistant/create",user_id:t,username:i,password:a}),o=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/change_password",current_password:t,new_password:i}),r=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/admin_change_password",user_id:t,password:i}),l=(e,t,i)=>e.callWS({type:"config/auth_provider/homeassistant/admin_change_username",user_id:t,username:i}),c=(e,t,i)=>e.callWS({type:"auth/delete_all_refresh_tokens",token_type:t,delete_current_token:i})},20742:function(e,t,i){i.r(t);var a=i(44249),s=(i(9359),i(1331),i(70104),i(57243)),n=i(15093),o=(i(99426),i(59826),i(73729)),r=(i(55486),i(23334),i(2914),i(30509),i(37583),i(1888),i(83166),i(43546)),l=i(4242),c=i(76131),d=i(28008),h=i(71364);const p="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z";(0,a.Z)([(0,n.Mo)("dialog-user-detail")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_name",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_isAdmin",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_localOnly",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_isActive",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_error",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,n.SB)()],key:"_submitting",value:()=>!1},{kind:"method",key:"showDialog",value:async function(e){this._params=e,this._error=void 0,this._name=e.entry.name||"",this._isAdmin=e.entry.group_ids.includes(l.Pb),this._localOnly=e.entry.local_only,this._isActive=e.entry.is_active,await this.updateComplete}},{kind:"method",key:"render",value:function(){if(!this._params)return s.Ld;const e=this._params.entry,t=(0,l.FH)(this.hass,e,!0);return s.dy`
      <ha-dialog open @closed=${this._close} scrimClickAction escapeKeyAction .heading=${(0,o.i)(this.hass,e.name)}>
        <div>
          ${this._error?s.dy`<div class="error">${this._error}</div>`:s.Ld}
          <div class="secondary">
            ${this.hass.localize("ui.panel.config.users.editor.id")}:
            ${e.id}<br/>
          </div>
          ${0===t.length?s.Ld:s.dy`
                <div class="badge-container">
                  ${t.map((([e,t])=>s.dy`
                      <ha-label>
                        <ha-svg-icon slot="icon" .path=${e}></ha-svg-icon>
                        ${t}
                      </ha-label>
                    `))}
                </div>
              `}
          <div class="form">
            ${e.system_generated?s.Ld:s.dy`
                  <ha-textfield dialogInitialFocus .value=${this._name} @input=${this._nameChanged} .label=${this.hass.localize("ui.panel.config.users.editor.name")}></ha-textfield>
                  <ha-settings-row>
                    <span slot="heading">
                      ${this.hass.localize("ui.panel.config.users.editor.username")}
                    </span>
                    <span slot="description">${e.username}</span>
                    ${this.hass.user?.is_owner?s.dy`
                          <ha-icon-button .path=${p} @click=${this._changeUsername} .label=${this.hass.localize("ui.panel.config.users.editor.change_username")}>
                          </ha-icon-button>
                        `:s.Ld}
                  </ha-settings-row>
                `}
            ${!e.system_generated&&this.hass.user?.is_owner?s.dy`
                  <ha-settings-row>
                    <span slot="heading">
                      ${this.hass.localize("ui.panel.config.users.editor.password")}
                    </span>
                    <span slot="description">************</span>
                    ${this.hass.user?.is_owner?s.dy`
                          <ha-icon-button .path=${p} @click=${this._changePassword} .label=${this.hass.localize("ui.panel.config.users.editor.change_password")}>
                          </ha-icon-button>
                        `:s.Ld}
                  </ha-settings-row>
                `:s.Ld}

            <ha-settings-row>
              <span slot="heading">
                ${this.hass.localize("ui.panel.config.users.editor.active")}
              </span>
              <span slot="description">
                ${this.hass.localize("ui.panel.config.users.editor.active_description")}
              </span>
              <ha-switch .disabled=${e.system_generated||e.is_owner} .checked=${this._isActive} @change=${this._activeChanged}>
              </ha-switch>
            </ha-settings-row>
            <ha-settings-row>
              <span slot="heading">
                ${this.hass.localize("ui.panel.config.users.editor.local_access_only")}
              </span>
              <span slot="description">
                ${this.hass.localize("ui.panel.config.users.editor.local_access_only_description")}
              </span>
              <ha-switch .disabled=${e.system_generated} .checked=${this._localOnly} @change=${this._localOnlyChanged}>
              </ha-switch>
            </ha-settings-row>
            <ha-settings-row>
              <span slot="heading">
                ${this.hass.localize("ui.panel.config.users.editor.admin")}
              </span>
              <span slot="description">
                ${this.hass.localize("ui.panel.config.users.editor.admin_description")}
              </span>
              <ha-switch .disabled=${e.system_generated||e.is_owner} .checked=${this._isAdmin} @change=${this._adminChanged}>
              </ha-switch>
            </ha-settings-row>
            ${this._isAdmin||e.system_generated?s.Ld:s.dy`
                  <ha-alert alert-type="info">
                    ${this.hass.localize("ui.panel.config.users.users_privileges_note")}
                  </ha-alert>
                `}
          </div>
          ${e.system_generated?s.dy`
                <ha-alert alert-type="info">
                  ${this.hass.localize("ui.panel.config.users.editor.system_generated_read_only_users")}
                </ha-alert>
              `:s.Ld}
        </div>

        <div slot="secondaryAction">
          <ha-button class="warning" @click=${this._deleteEntry} .disabled=${this._submitting||e.system_generated||e.is_owner}>
            ${this.hass.localize("ui.panel.config.users.editor.delete_user")}
          </ha-button>
        </div>

        <div slot="primaryAction">
          <ha-button @click=${this._updateEntry} .disabled=${!this._name||this._submitting||e.system_generated}>
            ${this.hass.localize("ui.panel.config.users.editor.update_user")}
          </ha-button>
        </div>
      </ha-dialog>
    `}},{kind:"method",key:"_nameChanged",value:function(e){this._error=void 0,this._name=e.target.value}},{kind:"method",key:"_adminChanged",value:function(e){this._isAdmin=e.target.checked}},{kind:"method",key:"_localOnlyChanged",value:function(e){this._localOnly=e.target.checked}},{kind:"method",key:"_activeChanged",value:function(e){this._isActive=e.target.checked}},{kind:"method",key:"_updateEntry",value:async function(){this._submitting=!0;try{await this._params.updateEntry({name:this._name.trim(),is_active:this._isActive,group_ids:[this._isAdmin?l.Pb:l.CE],local_only:this._localOnly}),this._close()}catch(e){this._error=e?.message||"Unknown error"}finally{this._submitting=!1}}},{kind:"method",key:"_deleteEntry",value:async function(){this._submitting=!0;try{await this._params.removeEntry()&&(this._params=void 0)}finally{this._submitting=!1}}},{kind:"method",key:"_changeUsername",value:async function(){const e=this._params?.entry.credentials.find((e=>"homeassistant"===e.type));if(!e)return void(0,c.showAlertDialog)(this,{title:"No ASCIA credentials found."});const t=await(0,c.showPromptDialog)(this,{inputLabel:this.hass.localize("ui.panel.config.users.change_username.new_username"),confirmText:this.hass.localize("ui.panel.config.users.change_username.change"),title:this.hass.localize("ui.panel.config.users.change_username.caption"),defaultValue:this._params.entry.username});if(t)try{await(0,r.j2)(this.hass,this._params.entry.id,t),this._params={...this._params,entry:{...this._params.entry,username:t}},this._params.replaceEntry(this._params.entry),(0,c.showAlertDialog)(this,{text:this.hass.localize("ui.panel.config.users.change_username.username_changed")})}catch(e){(0,c.showAlertDialog)(this,{title:this.hass.localize("ui.panel.config.users.change_username.failed"),text:e.message})}}},{kind:"method",key:"_changePassword",value:async function(){const e=this._params?.entry.credentials.find((e=>"homeassistant"===e.type));e?(0,h.o)(this,{userId:this._params.entry.id}):(0,c.showAlertDialog)(this,{title:"No ASCIA credentials found."})}},{kind:"method",key:"_close",value:function(){this._params=void 0}},{kind:"get",static:!0,key:"styles",value:function(){return[d.yu,s.iv`ha-dialog{--mdc-dialog-max-width:500px}.form{padding-top:16px}.secondary{color:var(--secondary-text-color)}ha-textfield{display:block}.badge-container{margin-top:4px}.badge-container>*{margin:4px 4px 4px 0;margin-inline-end:4px;margin-inline-start:0}ha-settings-row{padding:0}`]}}]}}),s.oi)},71364:function(e,t,i){i.d(t,{o:()=>n});var a=i(36522);const s=()=>Promise.all([i.e("63055"),i.e("99646")]).then(i.bind(i,45676)),n=(e,t)=>{(0,a.B)(e,"show-dialog",{dialogTag:"dialog-admin-change-password",dialogImport:s,dialogParams:t})}}};
//# sourceMappingURL=88443.0106434085038869.js.map