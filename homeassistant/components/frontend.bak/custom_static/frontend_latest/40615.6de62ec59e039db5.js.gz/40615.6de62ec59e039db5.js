export const __webpack_ids__=["40615"];export const __webpack_modules__={89530:function(e,a,t){t.a(e,(async function(e,i){try{t.r(a),t.d(a,{ZHAAddGroupPage:()=>p});var s=t(44249),d=t(72621),n=(t(9359),t(70104),t(31622),t(57243)),o=t(15093),r=t(83523),h=t(17170),l=t(74794),c=(t(87979),t(98241),t(83166),t(33718),e([h]));h=(c.then?(await c)():c)[0];let p=(0,s.Z)([(0,o.Mo)("zha-add-group-page")],(function(e,a){class t extends a{constructor(...a){super(...a),e(this)}}return{F:t,d:[{kind:"field",decorators:[(0,o.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,o.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,o.Cb)({attribute:!1,type:Array})],key:"deviceEndpoints",value:()=>[]},{kind:"field",decorators:[(0,o.SB)()],key:"_processingAdd",value:()=>!1},{kind:"field",decorators:[(0,o.SB)()],key:"_groupName",value:()=>""},{kind:"field",decorators:[(0,o.SB)()],key:"_groupId",value:void 0},{kind:"field",decorators:[(0,o.IO)("zha-device-endpoint-data-table",!0)],key:"_zhaDevicesDataTable",value:void 0},{kind:"field",key:"_firstUpdatedCalled",value:()=>!1},{kind:"field",key:"_selectedDevicesToAdd",value:()=>[]},{kind:"method",key:"connectedCallback",value:function(){(0,d.Z)(t,"connectedCallback",this,3)([]),this.hass&&this._firstUpdatedCalled&&this._fetchData()}},{kind:"method",key:"firstUpdated",value:function(e){(0,d.Z)(t,"firstUpdated",this,3)([e]),this.hass&&this._fetchData(),this._firstUpdatedCalled=!0}},{kind:"method",key:"render",value:function(){return n.dy`
      <hass-subpage .hass=${this.hass} .narrow=${this.narrow} .header=${this.hass.localize("ui.panel.config.zha.groups.create_group")}>
        <ha-config-section .isWide=${!this.narrow}>
          <p slot="introduction">
            ${this.hass.localize("ui.panel.config.zha.groups.create_group_details")}
          </p>
          <ha-textfield type="string" .value=${this._groupName} @change=${this._handleNameChange} .placeholder=${this.hass.localize("ui.panel.config.zha.groups.group_name_placeholder")}></ha-textfield>

          <ha-textfield type="number" .value=${this._groupId} @change=${this._handleGroupIdChange} .placeholder=${this.hass.localize("ui.panel.config.zha.groups.group_id_placeholder")}></ha-textfield>

          <div class="header">
            ${this.hass.localize("ui.panel.config.zha.groups.add_members")}
          </div>

          <zha-device-endpoint-data-table .hass=${this.hass} .deviceEndpoints=${this.deviceEndpoints} .narrow=${this.narrow} selectable @selection-changed=${this._handleAddSelectionChanged}>
          </zha-device-endpoint-data-table>

          <div class="buttons">
            <mwc-button .disabled=${!this._groupName||""===this._groupName||this._processingAdd} @click=${this._createGroup} class="button">
              ${this._processingAdd?n.dy`<ha-spinner size="small" .ariaLabel=${this.hass.localize("ui.panel.config.zha.groups.creating_group")}></ha-spinner>`:""}
              ${this.hass.localize("ui.panel.config.zha.groups.create")}</mwc-button>
          </div>
        </ha-config-section>
      </hass-subpage>
    `}},{kind:"method",key:"_fetchData",value:async function(){this.deviceEndpoints=await(0,l.pT)(this.hass)}},{kind:"method",key:"_handleAddSelectionChanged",value:function(e){this._selectedDevicesToAdd=e.detail.value}},{kind:"method",key:"_createGroup",value:async function(){this._processingAdd=!0;const e=this._selectedDevicesToAdd.map((e=>{const a=e.split("_");return{ieee:a[0],endpoint_id:a[1]}})),a=this._groupId?parseInt(this._groupId,10):void 0,t=await(0,l.Rp)(this.hass,this._groupName,a,e);this._selectedDevicesToAdd=[],this._processingAdd=!1,this._groupName="",this._zhaDevicesDataTable.clearSelection(),(0,r.c)(`/config/zha/group/${t.group_id}`,{replace:!0})}},{kind:"method",key:"_handleGroupIdChange",value:function(e){this._groupId=e.target.value}},{kind:"method",key:"_handleNameChange",value:function(e){this._groupName=e.target.value||""}},{kind:"get",static:!0,key:"styles",value:function(){return[n.iv`.header{font-family:var(--paper-font-display1_-_font-family);-webkit-font-smoothing:var(--paper-font-display1_-_-webkit-font-smoothing);font-size:var(--paper-font-display1_-_font-size);font-weight:var(--paper-font-display1_-_font-weight);letter-spacing:var(--paper-font-display1_-_letter-spacing);line-height:var(--paper-font-display1_-_line-height);opacity:var(--dark-primary-opacity)}.button{float:right}ha-config-section :last-child{padding-bottom:24px}.buttons{align-items:flex-end;padding:8px}.buttons .warning{--mdc-theme-primary:var(--error-color)}`]}}]}}),n.oi);i()}catch(e){i(e)}}))}};
//# sourceMappingURL=40615.6de62ec59e039db5.js.map