export const __webpack_ids__=["83537"];export const __webpack_modules__={40445:function(t,i,e){e.a(t,(async function(t,n){try{e.r(i);var s=e(44249),o=(e(9359),e(52924),e(57243)),a=e(15093),h=e(73358),r=e(73850),u=(e(29891),e(93331)),c=e(8069),d=e(62577),g=t([c]);c=(g.then?(await g)():g)[0];(0,s.Z)([(0,a.Mo)("hui-group-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_config",value:void 0},{kind:"method",key:"_computeCanToggle",value:function(t,i){return i.some((i=>{const e=(0,r.M)(i);return"group"===e?this._computeCanToggle(t,this.hass?.states[i].attributes.entity_id):h.Kk.has(e)}))}},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,u.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const t=this.hass.states[this._config.entity];return t?o.dy`
      <hui-generic-entity-row .hass=${this.hass} .config=${this._config}>
        ${this._computeCanToggle(this.hass,t.attributes.entity_id)?o.dy`
              <ha-entity-toggle .hass=${this.hass} .stateObj=${t}></ha-entity-toggle>
            `:o.dy`
              <div class="text-content">
                ${this.hass.formatEntityState(t)}
              </div>
            `}
      </hui-generic-entity-row>
    `:o.dy`
        <hui-warning>
          ${(0,d.i)(this.hass,this._config.entity)}
        </hui-warning>
      `}}]}}),o.oi);n()}catch(t){n(t)}}))}};
//# sourceMappingURL=83537.a51e3cc9c254b5c4.js.map