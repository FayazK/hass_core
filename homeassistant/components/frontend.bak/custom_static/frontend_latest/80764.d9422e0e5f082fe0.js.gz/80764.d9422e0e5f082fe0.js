/*! For license information please see 80764.d9422e0e5f082fe0.js.LICENSE.txt */
export const __webpack_ids__=["80764"];export const __webpack_modules__={48734:function(e,t,n){n.a(e,(async function(e,r){try{n.d(t,{P5:()=>p,Ve:()=>f});var o=n(16485),a=(n(9359),n(70104),n(92519),n(42179),n(89256),n(24931),n(88463),n(57449),n(19814),e([o]));o=(a.then?(await a)():a)[0];const s=new Set,i=new Map;let c,l="ltr",u="en";const d="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(d){const m=new MutationObserver(h);l=document.documentElement.dir||"ltr",u=document.documentElement.lang||navigator.language,m.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function p(...e){e.map((e=>{const t=e.$code.toLowerCase();i.has(t)?i.set(t,Object.assign(Object.assign({},i.get(t)),e)):i.set(t,e),c||(c=e)})),h()}function h(){d&&(l=document.documentElement.dir||"ltr",u=document.documentElement.lang||navigator.language),[...s.keys()].map((e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()}))}class f{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){s.add(this.host)}hostDisconnected(){s.delete(this.host)}dir(){return`${this.host.dir||l}`.toLowerCase()}lang(){return`${this.host.lang||u}`.toLowerCase()}getTranslationData(e){var t,n;const r=new Intl.Locale(e.replace(/_/g,"-")),o=null==r?void 0:r.language.toLowerCase(),a=null!==(n=null===(t=null==r?void 0:r.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==n?n:"";return{locale:r,language:o,region:a,primary:i.get(`${o}-${a}`),secondary:i.get(o)}}exists(e,t){var n;const{primary:r,secondary:o}=this.getTranslationData(null!==(n=t.lang)&&void 0!==n?n:this.lang());return t=Object.assign({includeFallback:!1},t),!!(r&&r[e]||o&&o[e]||t.includeFallback&&c&&c[e])}term(e,...t){const{primary:n,secondary:r}=this.getTranslationData(this.lang());let o;if(n&&n[e])o=n[e];else if(r&&r[e])o=r[e];else{if(!c||!c[e])return console.error(`No translation found for: ${String(e)}`),String(e);o=c[e]}return"function"==typeof o?o(...t):o}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,n){return new Intl.RelativeTimeFormat(this.lang(),n).format(e,t)}}r()}catch(g){r(g)}}))},68783:function(e,t,n){n.a(e,(async function(e,r){try{n.d(t,{A:()=>u});var o=n(64699),a=n(15073),s=n(81048),i=n(31027),c=n(57243),l=e([a]);a=(l.then?(await l)():l)[0];var u=class extends i.P{constructor(){super(...arguments),this.localize=new a.V(this)}render(){return c.dy`
      <svg part="base" class="spinner" role="progressbar" aria-label=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `}};u.styles=[s.N,o.D],r()}catch(e){r(e)}}))},31027:function(e,t,n){n.d(t,{P:()=>i});n(9359),n(31526);var r,o=n(52812),a=n(57243),s=n(15093),i=class extends a.oi{constructor(){super(),(0,o.Ko)(this,r,!1),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach((([e,t])=>{this.constructor.define(e,t)}))}emit(e,t){const n=new CustomEvent(e,(0,o.ih)({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(n),n}static define(e,t=this,n={}){const r=customElements.get(e);if(!r){try{customElements.define(e,t,n)}catch(r){customElements.define(e,class extends t{},n)}return}let o=" (unknown version)",a=o;"version"in t&&t.version&&(o=" v"+t.version),"version"in r&&r.version&&(a=" v"+r.version),o&&a&&o===a||console.warn(`Attempted to register <${e}>${o}, but <${e}>${a} has already been registered.`)}attributeChangedCallback(e,t,n){(0,o.ac)(this,r)||(this.constructor.elementProperties.forEach(((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])})),(0,o.qx)(this,r,!0)),super.attributeChangedCallback(e,t,n)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach(((t,n)=>{e.has(n)&&null==this[n]&&(this[n]=t)}))}};r=new WeakMap,i.version="2.20.1",i.dependencies={},(0,o.u2)([(0,s.Cb)()],i.prototype,"dir",2),(0,o.u2)([(0,s.Cb)()],i.prototype,"lang",2)},15073:function(e,t,n){n.a(e,(async function(e,r){try{n.d(t,{V:()=>i});var o=n(21262),a=n(48734),s=e([a,o]);[a,o]=s.then?(await s)():s;var i=class extends a.Ve{};(0,a.P5)(o.K),r()}catch(e){r(e)}}))},21262:function(e,t,n){n.a(e,(async function(e,r){try{n.d(t,{K:()=>i});var o=n(48734),a=e([o]);o=(a.then?(await a)():a)[0];var s={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};(0,o.P5)(s);var i=s;r()}catch(e){r(e)}}))},64699:function(e,t,n){n.d(t,{D:()=>r});var r=n(57243).iv`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`},52812:function(e,t,n){n.d(t,{EZ:()=>h,Ko:()=>v,ac:()=>g,ih:()=>p,qx:()=>y,u2:()=>f});var r=Object.defineProperty,o=Object.defineProperties,a=Object.getOwnPropertyDescriptor,s=Object.getOwnPropertyDescriptors,i=Object.getOwnPropertySymbols,c=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,u=e=>{throw TypeError(e)},d=(e,t,n)=>t in e?r(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n,p=(e,t)=>{for(var n in t||(t={}))c.call(t,n)&&d(e,n,t[n]);if(i)for(var n of i(t))l.call(t,n)&&d(e,n,t[n]);return e},h=(e,t)=>o(e,s(t)),f=(e,t,n,o)=>{for(var s,i=o>1?void 0:o?a(t,n):t,c=e.length-1;c>=0;c--)(s=e[c])&&(i=(o?s(t,n,i):s(i))||i);return o&&i&&r(t,n,i),i},m=(e,t,n)=>t.has(e)||u("Cannot "+n),g=(e,t,n)=>(m(e,t,"read from private field"),n?n.call(e):t.get(e)),v=(e,t,n)=>t.has(e)?u("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,n),y=(e,t,n,r)=>(m(e,t,"write to private field"),r?r.call(e,n):t.set(e,n),n)},81048:function(e,t,n){n.d(t,{N:()=>r});var r=n(57243).iv`:host{box-sizing:border-box}:host *,:host ::after,:host ::before{box-sizing:inherit}[hidden]{display:none!important}`},97677:function(e,t,n){n.a(e,(async function(e,r){try{n.d(t,{Z:()=>o.A});var o=n(68783),a=(n(64699),n(15073)),s=n(21262),i=(n(81048),n(31027),n(52812),e([a,s,o]));[a,s,o]=i.then?(await i)():i,r()}catch(e){r(e)}}))},43580:function(e,t,n){n.d(t,{Z:()=>r.D});var r=n(64699);n(52812)},75351:function(e,t,n){n.d(t,{Ud:()=>p});n(9359),n(70104),n(48136);const r=Symbol("Comlink.proxy"),o=Symbol("Comlink.endpoint"),a=Symbol("Comlink.releaseProxy"),s=Symbol("Comlink.finalizer"),i=Symbol("Comlink.thrown"),c=e=>"object"==typeof e&&null!==e||"function"==typeof e,l=new Map([["proxy",{canHandle:e=>c(e)&&e[r],serialize(e){const{port1:t,port2:n}=new MessageChannel;return u(e,t),[n,[n]]},deserialize:e=>(e.start(),p(e))}],["throw",{canHandle:e=>c(e)&&i in e,serialize({value:e}){let t;return t=e instanceof Error?{isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:{isError:!1,value:e},[t,[]]},deserialize(e){if(e.isError)throw Object.assign(new Error(e.value.message),e.value);throw e.value}}]]);function u(e,t=globalThis,n=["*"]){t.addEventListener("message",(function o(a){if(!a||!a.data)return;if(!function(e,t){for(const n of e){if(t===n||"*"===n)return!0;if(n instanceof RegExp&&n.test(t))return!0}return!1}(n,a.origin))return void console.warn(`Invalid origin '${a.origin}' for comlink proxy`);const{id:c,type:l,path:p}=Object.assign({path:[]},a.data),h=(a.data.argumentList||[]).map(E);let f;try{const t=p.slice(0,-1).reduce(((e,t)=>e[t]),e),n=p.reduce(((e,t)=>e[t]),e);switch(l){case"GET":f=n;break;case"SET":t[p.slice(-1)[0]]=E(a.data.value),f=!0;break;case"APPLY":f=n.apply(t,h);break;case"CONSTRUCT":f=function(e){return Object.assign(e,{[r]:!0})}(new n(...h));break;case"ENDPOINT":{const{port1:t,port2:n}=new MessageChannel;u(e,n),f=function(e,t){return b.set(e,t),e}(t,[t])}break;case"RELEASE":f=void 0;break;default:return}}catch(e){f={value:e,[i]:0}}Promise.resolve(f).catch((e=>({value:e,[i]:0}))).then((n=>{const[r,a]=w(n);t.postMessage(Object.assign(Object.assign({},r),{id:c}),a),"RELEASE"===l&&(t.removeEventListener("message",o),d(t),s in e&&"function"==typeof e[s]&&e[s]())})).catch((e=>{const[n,r]=w({value:new TypeError("Unserializable return value"),[i]:0});t.postMessage(Object.assign(Object.assign({},n),{id:c}),r)}))})),t.start&&t.start()}function d(e){(function(e){return"MessagePort"===e.constructor.name})(e)&&e.close()}function p(e,t){const n=new Map;return e.addEventListener("message",(function(e){const{data:t}=e;if(!t||!t.id)return;const r=n.get(t.id);if(r)try{r(t)}finally{n.delete(t.id)}})),v(e,n,[],t)}function h(e){if(e)throw new Error("Proxy has been released and is not useable")}function f(e){return k(e,new Map,{type:"RELEASE"}).then((()=>{d(e)}))}const m=new WeakMap,g="FinalizationRegistry"in globalThis&&new FinalizationRegistry((e=>{const t=(m.get(e)||0)-1;m.set(e,t),0===t&&f(e)}));function v(e,t,n=[],r=function(){}){let s=!1;const i=new Proxy(r,{get(r,o){if(h(s),o===a)return()=>{!function(e){g&&g.unregister(e)}(i),f(e),t.clear(),s=!0};if("then"===o){if(0===n.length)return{then:()=>i};const r=k(e,t,{type:"GET",path:n.map((e=>e.toString()))}).then(E);return r.then.bind(r)}return v(e,t,[...n,o])},set(r,o,a){h(s);const[i,c]=w(a);return k(e,t,{type:"SET",path:[...n,o].map((e=>e.toString())),value:i},c).then(E)},apply(r,a,i){h(s);const c=n[n.length-1];if(c===o)return k(e,t,{type:"ENDPOINT"}).then(E);if("bind"===c)return v(e,t,n.slice(0,-1));const[l,u]=y(i);return k(e,t,{type:"APPLY",path:n.map((e=>e.toString())),argumentList:l},u).then(E)},construct(r,o){h(s);const[a,i]=y(o);return k(e,t,{type:"CONSTRUCT",path:n.map((e=>e.toString())),argumentList:a},i).then(E)}});return function(e,t){const n=(m.get(t)||0)+1;m.set(t,n),g&&g.register(e,t,e)}(i,e),i}function y(e){const t=e.map(w);return[t.map((e=>e[0])),(n=t.map((e=>e[1])),Array.prototype.concat.apply([],n))];var n}const b=new WeakMap;function w(e){for(const[t,n]of l)if(n.canHandle(e)){const[r,o]=n.serialize(e);return[{type:"HANDLER",name:t,value:r},o]}return[{type:"RAW",value:e},b.get(e)||[]]}function E(e){switch(e.type){case"HANDLER":return l.get(e.name).deserialize(e.value);case"RAW":return e.value}}function k(e,t,n,r){return new Promise((o=>{const a=new Array(4).fill(0).map((()=>Math.floor(Math.random()*Number.MAX_SAFE_INTEGER).toString(16))).join("-");t.set(a,o),e.start&&e.start(),e.postMessage(Object.assign({id:a},n),r)}))}},67064:function(e,t,n){n.d(t,{F:()=>i});var r=n(2841),o=n(45779),a=n(53232);const s=e=>(0,a.dZ)(e)?e._$litType$.h:e.strings,i=(0,o.XM)(class extends o.Xe{constructor(e){super(e),this.tt=new WeakMap}render(e){return[e]}update(e,[t]){const n=(0,a.hN)(this.et)?s(this.et):null,o=(0,a.hN)(t)?s(t):null;if(null!==n&&(null===o||n!==o)){const t=(0,a.i9)(e).pop();let o=this.tt.get(n);if(void 0===o){const e=document.createDocumentFragment();o=(0,r.sY)(r.Ld,e),o.setConnected(!1),this.tt.set(n,o)}(0,a.hl)(o,[t]),(0,a._Y)(o,void 0,t)}if(null!==o){if(null===n||n!==o){const t=this.tt.get(o);if(void 0!==t){const n=(0,a.i9)(t).pop();(0,a.E_)(e),(0,a._Y)(e,void 0,n),(0,a.hl)(e,[n])}}this.et=t}else this.et=void 0;return this.render(t)}})}};
//# sourceMappingURL=80764.d9422e0e5f082fe0.js.map