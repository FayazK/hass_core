export const __webpack_ids__=["13027"];export const __webpack_modules__={81698:function(e,i,a){a.a(e,(async function(e,s){try{a.r(i),a.d(i,{CloudRegister:()=>h});var o=a(44249),t=a(57243),r=a(15093),l=a(36522),n=a(29095),c=(a(99426),a(54977),a(83166),a(94616)),d=(a(87979),a(28008)),u=(a(98241),a(34326),e([n]));n=(u.then?(await u)():u)[0];let h=(0,o.Z)([(0,r.Mo)("cloud-register")],(function(e,i){return{F:class extends i{constructor(...i){super(...i),e(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"is-wide",type:Boolean})],key:"isWide",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)({type:Boolean})],key:"narrow",value:()=>!1},{kind:"field",decorators:[(0,r.Cb)()],key:"email",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_requestInProgress",value:()=>!1},{kind:"field",decorators:[(0,r.SB)()],key:"_password",value:()=>""},{kind:"field",decorators:[(0,r.SB)()],key:"_error",value:void 0},{kind:"field",decorators:[(0,r.IO)("#email",!0)],key:"_emailField",value:void 0},{kind:"field",decorators:[(0,r.IO)("#password",!0)],key:"_passwordField",value:void 0},{kind:"method",key:"render",value:function(){return t.dy`
      <hass-subpage .hass=${this.hass} .narrow=${this.narrow} .header=${this.hass.localize("ui.panel.config.cloud.register.title")}>
        <div class="content">
          <ha-config-section .isWide=${this.isWide}>
            <span slot="header">${this.hass.localize("ui.panel.config.cloud.register.headline")}</span>
            <div slot="introduction">
              <p>
                ${this.hass.localize("ui.panel.config.cloud.register.information")}
              </p>
              <p>
                ${this.hass.localize("ui.panel.config.cloud.register.information2")}
              </p>
              <ul>
                <li>
                  ${this.hass.localize("ui.panel.config.cloud.register.feature_remote_control")}
                </li>
                <li>
                  ${this.hass.localize("ui.panel.config.cloud.register.feature_google_home")}
                </li>
                <li>
                  ${this.hass.localize("ui.panel.config.cloud.register.feature_amazon_alexa")}
                </li>
                <li>
                  ${this.hass.localize("ui.panel.config.cloud.register.feature_webhook_apps")}
                </li>
              </ul>
              <p>
                ${this.hass.localize("ui.panel.config.cloud.register.information3")}
                <a href="https://www.nabucasa.com" target="_blank">Nabu Casa, Inc</a>
                ${this.hass.localize("ui.panel.config.cloud.register.information3a")}
              </p>
              <p>
                ${this.hass.localize("ui.panel.config.cloud.register.information4")}
              </p>
              <ul>
                <li>
                  <a href="https://www.nabucasa.com/tos/" target="_blank" rel="noreferrer">
                    ${this.hass.localize("ui.panel.config.cloud.register.link_terms_conditions")}
                  </a>
                </li>
                <li>
                  <a href="https://www.nabucasa.com/privacy_policy/" target="_blank" rel="noreferrer">
                    ${this.hass.localize("ui.panel.config.cloud.register.link_privacy_policy")}
                  </a>
                </li>
              </ul>
            </div>
            <ha-card outlined .header=${this.hass.localize("ui.panel.config.cloud.register.create_account")}><div class="card-content register-form">
                ${this._error?t.dy`<ha-alert alert-type="error">${this._error}</ha-alert>`:""}
                <ha-textfield autofocus id="email" name="email" .label=${this.hass.localize("ui.panel.config.cloud.register.email_address")} type="email" autocomplete="email" required .value=${this.email??""} @keydown=${this._keyDown} validationMessage=${this.hass.localize("ui.panel.config.cloud.register.email_error_msg")}></ha-textfield>
                <ha-password-field id="password" name="password" .label=${this.hass.localize("ui.panel.config.cloud.register.password")} .value=${this._password} autocomplete="new-password" minlength="8" required @keydown=${this._keyDown} validationMessage=${this.hass.localize("ui.panel.config.cloud.register.password_error_msg")}></ha-password-field>
              </div>
              <div class="card-actions">
                <ha-progress-button @click=${this._handleRegister} .progress=${this._requestInProgress}>${this.hass.localize("ui.panel.config.cloud.register.start_trial")}</ha-progress-button>
                <button class="link" .disabled=${this._requestInProgress} @click=${this._handleResendVerifyEmail}>
                  ${this.hass.localize("ui.panel.config.cloud.register.resend_confirm_email")}
                </button>
              </div>
            </ha-card>
          </ha-config-section>
        </div>
      </hass-subpage>
    `}},{kind:"method",key:"_keyDown",value:function(e){"Enter"===e.key&&this._handleRegister()}},{kind:"method",key:"_handleRegister",value:async function(){const e=this._emailField,i=this._passwordField;if(!e.reportValidity())return i.reportValidity(),void e.focus();if(!i.reportValidity())return void i.focus();const a=e.value.toLowerCase(),s=i.value;this._requestInProgress=!0;try{await(0,c.bi)(this.hass,a,s),this._verificationEmailSent(a)}catch(e){this._password="",this._requestInProgress=!1,this._error=e&&e.body&&e.body.message?e.body.message:"Unknown error"}}},{kind:"method",key:"_handleResendVerifyEmail",value:async function(){const e=this._emailField;if(!e.reportValidity())return void e.focus();const i=e.value,a=async e=>{try{await(0,c._t)(this.hass,e),this._verificationEmailSent(e)}catch(i){"usernotfound"===(i&&i.body&&i.body.code)&&e!==e.toLowerCase()?await a(e.toLowerCase()):this._error=i&&i.body&&i.body.message?i.body.message:"Unknown error"}};await a(i)}},{kind:"method",key:"_verificationEmailSent",value:function(e){this._requestInProgress=!1,this._password="",(0,l.B)(this,"cloud-email-changed",{value:e}),(0,l.B)(this,"cloud-done",{flashMessage:this.hass.localize("ui.panel.config.cloud.register.account_created")})}},{kind:"get",static:!0,key:"styles",value:function(){return[d.Qx,t.iv`[slot=introduction]{margin:-1em 0}[slot=introduction] a,a{color:var(--primary-color)}h1{margin:0}.register-form{display:flex;flex-direction:column}.card-actions{display:flex;justify-content:space-between;align-items:center}`]}}]}}),t.oi);s()}catch(e){s(e)}}))}};
//# sourceMappingURL=13027.aee55529ef422796.js.map