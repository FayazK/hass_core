export const __webpack_ids__=["14517"];export const __webpack_modules__={17170:function(e,t,i){i.a(e,(async function(e,n){try{i.r(t),i.d(t,{HaSpinner:()=>h});var r=i(44249),o=i(72621),a=i(97677),s=i(43580),c=i(57243),l=i(15093),d=e([a]);a=(d.then?(await d)():d)[0];let h=(0,r.Z)([(0,l.Mo)("ha-spinner")],(function(e,t){class i extends t{constructor(...t){super(...t),e(this)}}return{F:i,d:[{kind:"field",decorators:[(0,l.Cb)()],key:"size",value:void 0},{kind:"method",key:"updated",value:function(e){if((0,o.Z)(i,"updated",this,3)([e]),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}},{kind:"field",static:!0,key:"styles",value:()=>[s.Z,c.iv`:host{--indicator-color:var(
          --ha-spinner-indicator-color,
          var(--primary-color)
        );--track-color:var(--ha-spinner-divider-color, var(--divider-color));--track-width:4px;--speed:3.5s;font-size:var(--ha-spinner-size, 48px)}`]}]}}),a.Z);n()}catch(e){n(e)}}))},54529:function(e,t,i){i.a(e,(async function(e,n){try{i.r(t),i.d(t,{STUB_IMAGE:()=>w});var r=i(44249),o=i(72621),a=i(57243),s=i(15093),c=i(20552),l=i(82393),d=i(73850),h=i(47194),u=(i(54977),i(72099)),f=i(3967),p=i(69223),g=i(1617),m=i(5684),v=i(93331),y=i(63848),b=i(62577),_=e([y]);y=(_.then?(await _)():_)[0];const w="https://demo.home-assistant.io/stub_config/bedroom.png";(0,r.Z)([(0,s.Mo)("hui-picture-entity-card")],(function(e,t){class n extends t{constructor(...t){super(...t),e(this)}}return{F:n,d:[{kind:"method",static:!0,key:"getConfigElement",value:async function(){return await i.e("17863").then(i.bind(i,55600)),document.createElement("hui-picture-entity-card-editor")}},{kind:"method",static:!0,key:"getStubConfig",value:function(e,t,i){return{type:"picture-entity",entity:(0,p.j)(e,1,t,i,["light","switch"])[0]||"",image:w}}},{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,s.SB)()],key:"_config",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"setConfig",value:function(e){if(!e||!e.entity)throw new Error("Entity must be specified");if(!(["camera","image","person"].includes((0,d.M)(e.entity))||e.image||e.state_image||e.camera_image))throw new Error("No image source configured");this._config={show_name:!0,show_state:!0,...e}}},{kind:"method",key:"shouldUpdate",value:function(e){return(0,v.G2)(this,e)}},{kind:"method",key:"updated",value:function(e){if((0,o.Z)(n,"updated",this,3)([e]),!this._config||!this.hass)return;const t=e.get("hass"),i=e.get("_config");t&&i&&t.themes===this.hass.themes&&i.theme===this._config.theme||(0,l.R)(this,this.hass.themes,this._config.theme)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return a.Ld;const e=this.hass.states[this._config.entity];if(!e)return a.dy`
        <hui-warning>
          ${(0,b.i)(this.hass,this._config.entity)}
        </hui-warning>
      `;const t=this._config.name||(0,h.C)(e),i=this.hass.formatEntityState(e);let n="";this._config.show_name&&this._config.show_state?n=a.dy`
        <div class="footer both">
          <div>${t}</div>
          <div>${i}</div>
        </div>
      `:this._config.show_name?n=a.dy`<div class="footer single">${t}</div>`:this._config.show_state&&(n=a.dy`<div class="footer single">${i}</div>`);const r=(0,d.M)(this._config.entity);let o=this._config.image;if(!o)switch(r){case"image":o=(0,u.U)(e);break;case"person":e.attributes.entity_picture&&(o=e.attributes.entity_picture)}return a.dy`
      <ha-card>
        <hui-image .hass=${this.hass} .image=${o} .stateImage=${this._config.state_image} .stateFilter=${this._config.state_filter} .cameraImage=${"camera"===r?this._config.entity:this._config.camera_image} .cameraView=${this._config.camera_view} .entity=${this._config.entity} .aspectRatio=${this._config.aspect_ratio} .fitMode=${this._config.fit_mode} @action=${this._handleAction} .actionHandler=${(0,f.K)({hasHold:(0,m._)(this._config.hold_action),hasDoubleClick:(0,m._)(this._config.double_tap_action)})} tabindex=${(0,c.o)((0,m._)(this._config.tap_action)||this._config.entity?"0":void 0)}></hui-image>
        ${n}
      </ha-card>
    `}},{kind:"field",static:!0,key:"styles",value:()=>a.iv`.footer,ha-card{overflow:hidden}ha-card{min-height:75px;position:relative;height:100%;box-sizing:border-box}hui-image{cursor:pointer;height:100%}.footer{white-space:nowrap;text-overflow:ellipsis;position:absolute;left:0;right:0;bottom:0;background-color:var(--ha-picture-card-background-color,rgba(0,0,0,.3));padding:16px;font-size:16px;line-height:16px;color:var(--ha-picture-card-text-color,#fff);pointer-events:none}.both{display:flex;justify-content:space-between}.single{text-align:center}`},{kind:"method",key:"_handleAction",value:function(e){(0,g.G)(this,this.hass,this._config,e.detail.action)}}]}}),a.oi);n()}catch(e){n(e)}}))},48734:function(e,t,i){i.a(e,(async function(e,n){try{i.d(t,{P5:()=>u,Ve:()=>p});var r=i(16485),o=(i(9359),i(70104),i(92519),i(42179),i(89256),i(24931),i(88463),i(57449),i(19814),e([r]));r=(o.then?(await o)():o)[0];const a=new Set,s=new Map;let c,l="ltr",d="en";const h="undefined"!=typeof MutationObserver&&"undefined"!=typeof document&&void 0!==document.documentElement;if(h){const g=new MutationObserver(f);l=document.documentElement.dir||"ltr",d=document.documentElement.lang||navigator.language,g.observe(document.documentElement,{attributes:!0,attributeFilter:["dir","lang"]})}function u(...e){e.map((e=>{const t=e.$code.toLowerCase();s.has(t)?s.set(t,Object.assign(Object.assign({},s.get(t)),e)):s.set(t,e),c||(c=e)})),f()}function f(){h&&(l=document.documentElement.dir||"ltr",d=document.documentElement.lang||navigator.language),[...a.keys()].map((e=>{"function"==typeof e.requestUpdate&&e.requestUpdate()}))}class p{constructor(e){this.host=e,this.host.addController(this)}hostConnected(){a.add(this.host)}hostDisconnected(){a.delete(this.host)}dir(){return`${this.host.dir||l}`.toLowerCase()}lang(){return`${this.host.lang||d}`.toLowerCase()}getTranslationData(e){var t,i;const n=new Intl.Locale(e.replace(/_/g,"-")),r=null==n?void 0:n.language.toLowerCase(),o=null!==(i=null===(t=null==n?void 0:n.region)||void 0===t?void 0:t.toLowerCase())&&void 0!==i?i:"";return{locale:n,language:r,region:o,primary:s.get(`${r}-${o}`),secondary:s.get(r)}}exists(e,t){var i;const{primary:n,secondary:r}=this.getTranslationData(null!==(i=t.lang)&&void 0!==i?i:this.lang());return t=Object.assign({includeFallback:!1},t),!!(n&&n[e]||r&&r[e]||t.includeFallback&&c&&c[e])}term(e,...t){const{primary:i,secondary:n}=this.getTranslationData(this.lang());let r;if(i&&i[e])r=i[e];else if(n&&n[e])r=n[e];else{if(!c||!c[e])return console.error(`No translation found for: ${String(e)}`),String(e);r=c[e]}return"function"==typeof r?r(...t):r}date(e,t){return e=new Date(e),new Intl.DateTimeFormat(this.lang(),t).format(e)}number(e,t){return e=Number(e),isNaN(e)?"":new Intl.NumberFormat(this.lang(),t).format(e)}relativeTime(e,t,i){return new Intl.RelativeTimeFormat(this.lang(),i).format(e,t)}}n()}catch(m){n(m)}}))},68783:function(e,t,i){i.a(e,(async function(e,n){try{i.d(t,{A:()=>d});var r=i(64699),o=i(15073),a=i(81048),s=i(31027),c=i(57243),l=e([o]);o=(l.then?(await l)():l)[0];var d=class extends s.P{constructor(){super(...arguments),this.localize=new o.V(this)}render(){return c.dy`
      <svg part="base" class="spinner" role="progressbar" aria-label=${this.localize.term("loading")}>
        <circle class="spinner__track"></circle>
        <circle class="spinner__indicator"></circle>
      </svg>
    `}};d.styles=[a.N,r.D],n()}catch(e){n(e)}}))},31027:function(e,t,i){i.d(t,{P:()=>s});i(9359),i(31526);var n,r=i(52812),o=i(57243),a=i(15093),s=class extends o.oi{constructor(){super(),(0,r.Ko)(this,n,!1),this.initialReflectedProperties=new Map,Object.entries(this.constructor.dependencies).forEach((([e,t])=>{this.constructor.define(e,t)}))}emit(e,t){const i=new CustomEvent(e,(0,r.ih)({bubbles:!0,cancelable:!1,composed:!0,detail:{}},t));return this.dispatchEvent(i),i}static define(e,t=this,i={}){const n=customElements.get(e);if(!n){try{customElements.define(e,t,i)}catch(n){customElements.define(e,class extends t{},i)}return}let r=" (unknown version)",o=r;"version"in t&&t.version&&(r=" v"+t.version),"version"in n&&n.version&&(o=" v"+n.version),r&&o&&r===o||console.warn(`Attempted to register <${e}>${r}, but <${e}>${o} has already been registered.`)}attributeChangedCallback(e,t,i){(0,r.ac)(this,n)||(this.constructor.elementProperties.forEach(((e,t)=>{e.reflect&&null!=this[t]&&this.initialReflectedProperties.set(t,this[t])})),(0,r.qx)(this,n,!0)),super.attributeChangedCallback(e,t,i)}willUpdate(e){super.willUpdate(e),this.initialReflectedProperties.forEach(((t,i)=>{e.has(i)&&null==this[i]&&(this[i]=t)}))}};n=new WeakMap,s.version="2.20.1",s.dependencies={},(0,r.u2)([(0,a.Cb)()],s.prototype,"dir",2),(0,r.u2)([(0,a.Cb)()],s.prototype,"lang",2)},15073:function(e,t,i){i.a(e,(async function(e,n){try{i.d(t,{V:()=>s});var r=i(21262),o=i(48734),a=e([o,r]);[o,r]=a.then?(await a)():a;var s=class extends o.Ve{};(0,o.P5)(r.K),n()}catch(e){n(e)}}))},21262:function(e,t,i){i.a(e,(async function(e,n){try{i.d(t,{K:()=>s});var r=i(48734),o=e([r]);r=(o.then?(await o)():o)[0];var a={$code:"en",$name:"English",$dir:"ltr",carousel:"Carousel",clearEntry:"Clear entry",close:"Close",copied:"Copied",copy:"Copy",currentValue:"Current value",error:"Error",goToSlide:(e,t)=>`Go to slide ${e} of ${t}`,hidePassword:"Hide password",loading:"Loading",nextSlide:"Next slide",numOptionsSelected:e=>0===e?"No options selected":1===e?"1 option selected":`${e} options selected`,previousSlide:"Previous slide",progress:"Progress",remove:"Remove",resize:"Resize",scrollToEnd:"Scroll to end",scrollToStart:"Scroll to start",selectAColorFromTheScreen:"Select a color from the screen",showPassword:"Show password",slideNum:e=>`Slide ${e}`,toggleColorFormat:"Toggle color format"};(0,r.P5)(a);var s=a;n()}catch(e){n(e)}}))},64699:function(e,t,i){i.d(t,{D:()=>n});var n=i(57243).iv`
  :host {
    --track-width: 2px;
    --track-color: rgb(128 128 128 / 25%);
    --indicator-color: var(--sl-color-primary-600);
    --speed: 2s;

    display: inline-flex;
    width: 1em;
    height: 1em;
    flex: none;
  }

  .spinner {
    flex: 1 1 auto;
    height: 100%;
    width: 100%;
  }

  .spinner__track,
  .spinner__indicator {
    fill: none;
    stroke-width: var(--track-width);
    r: calc(0.5em - var(--track-width) / 2);
    cx: 0.5em;
    cy: 0.5em;
    transform-origin: 50% 50%;
  }

  .spinner__track {
    stroke: var(--track-color);
    transform-origin: 0% 0%;
  }

  .spinner__indicator {
    stroke: var(--indicator-color);
    stroke-linecap: round;
    stroke-dasharray: 150% 75%;
    animation: spin var(--speed) linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
      stroke-dasharray: 0.05em, 3em;
    }

    50% {
      transform: rotate(450deg);
      stroke-dasharray: 1.375em, 1.375em;
    }

    100% {
      transform: rotate(1080deg);
      stroke-dasharray: 0.05em, 3em;
    }
  }
`},52812:function(e,t,i){i.d(t,{EZ:()=>f,Ko:()=>v,ac:()=>m,ih:()=>u,qx:()=>y,u2:()=>p});var n=Object.defineProperty,r=Object.defineProperties,o=Object.getOwnPropertyDescriptor,a=Object.getOwnPropertyDescriptors,s=Object.getOwnPropertySymbols,c=Object.prototype.hasOwnProperty,l=Object.prototype.propertyIsEnumerable,d=e=>{throw TypeError(e)},h=(e,t,i)=>t in e?n(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i,u=(e,t)=>{for(var i in t||(t={}))c.call(t,i)&&h(e,i,t[i]);if(s)for(var i of s(t))l.call(t,i)&&h(e,i,t[i]);return e},f=(e,t)=>r(e,a(t)),p=(e,t,i,r)=>{for(var a,s=r>1?void 0:r?o(t,i):t,c=e.length-1;c>=0;c--)(a=e[c])&&(s=(r?a(t,i,s):a(s))||s);return r&&s&&n(t,i,s),s},g=(e,t,i)=>t.has(e)||d("Cannot "+i),m=(e,t,i)=>(g(e,t,"read from private field"),i?i.call(e):t.get(e)),v=(e,t,i)=>t.has(e)?d("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,i),y=(e,t,i,n)=>(g(e,t,"write to private field"),n?n.call(e,i):t.set(e,i),i)},81048:function(e,t,i){i.d(t,{N:()=>n});var n=i(57243).iv`:host{box-sizing:border-box}:host *,:host ::after,:host ::before{box-sizing:inherit}[hidden]{display:none!important}`},97677:function(e,t,i){i.a(e,(async function(e,n){try{i.d(t,{Z:()=>r.A});var r=i(68783),o=(i(64699),i(15073)),a=i(21262),s=(i(81048),i(31027),i(52812),e([o,a,r]));[o,a,r]=s.then?(await s)():s,n()}catch(e){n(e)}}))},43580:function(e,t,i){i.d(t,{Z:()=>n.D});var n=i(64699);i(52812)}};
//# sourceMappingURL=14517.b92721c1503f183c.js.map