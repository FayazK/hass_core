/*! For license information please see 2600.089c005cd969f008.js.LICENSE.txt */
export const __webpack_ids__=["2600"];export const __webpack_modules__={25948:function(t,e,i){var a=i(9065),s=i(15093),r=i(60930),n=i(9714);let d=class extends r.K{};d.styles=[n.W],d=(0,a.__decorate)([(0,s.Mo)("mwc-select")],d)},12763:function(t,e,i){i.a(t,(async function(t,e){try{var a=i(44249),s=(i(9359),i(56475),i(70104),i(57243)),r=i(15093),n=i(25904),d=i(59519),o=i(28008),l=i(59389),c=(i(41307),t([l,d,n]));[l,d,n]=c.then?(await c)():c;(0,a.Z)([(0,r.Mo)("ha-attributes")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"field",decorators:[(0,r.Cb)({attribute:"extra-filters"})],key:"extraFilters",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_expanded",value:()=>!1},{kind:"get",key:"_filteredAttributes",value:function(){return this._computeDisplayAttributes(d.wk.concat(this.extraFilters?this.extraFilters.split(","):[]))}},{kind:"method",key:"willUpdate",value:function(t){(t.has("extraFilters")||t.has("stateObj"))&&this.toggleAttribute("empty",0===this._filteredAttributes.length)}},{kind:"method",key:"render",value:function(){if(!this.stateObj)return s.Ld;const t=this._filteredAttributes;return 0===t.length?s.Ld:s.dy`
      <ha-expansion-panel .header=${this.hass.localize("ui.components.attributes.expansion_header")} outlined @expanded-will-change=${this._expandedChanged}>
        <div class="attribute-container">
          ${this._expanded?s.dy`
                ${t.map((t=>s.dy`
                    <div class="data-entry">
                      <div class="key">
                        ${(0,n.computeAttributeNameDisplay)(this.hass.localize,this.stateObj,this.hass.entities,t)}
                      </div>
                      <div class="value">
                        <ha-attribute-value .hass=${this.hass} .attribute=${t} .stateObj=${this.stateObj}></ha-attribute-value>
                      </div>
                    </div>
                  `))}
              `:""}
        </div>
      </ha-expansion-panel>
      ${this.stateObj.attributes.attribution?s.dy`
            <div class="attribution">
              ${this.stateObj.attributes.attribution}
            </div>
          `:""}
    `}},{kind:"get",static:!0,key:"styles",value:function(){return[o.Qx,s.iv`.attribute-container{margin-bottom:8px;direction:ltr}.data-entry{display:flex;flex-direction:row;justify-content:space-between}.data-entry .value{max-width:60%;overflow-wrap:break-word;text-align:right}.key{flex-grow:1}.attribution{color:var(--secondary-text-color);text-align:center;margin-top:16px}hr{border-color:var(--divider-color);border-bottom:none;margin:16px 0}`]}},{kind:"method",key:"_computeDisplayAttributes",value:function(t){return this.stateObj?Object.keys(this.stateObj.attributes).filter((e=>-1===t.indexOf(e))):[]}},{kind:"method",key:"_expandedChanged",value:function(t){this._expanded=t.detail.expanded}}]}}),s.oi);e()}catch(t){e(t)}}))},20458:function(t,e,i){i.d(e,{qh:()=>a});const a=4},92081:function(t,e,i){i.a(t,(async function(t,a){try{i.r(e);var s=i(44249),r=(i(9359),i(70104),i(25948),i(87319),i(57243)),n=i(15093),d=i(49976),o=i(75278),l=i(12763),c=i(20458),u=t([l]);l=(u.then?(await u)():u)[0];const h="activity_list,current_activity";(0,s.Z)([(0,n.Mo)("more-info-remote")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,n.Cb)({attribute:!1})],key:"stateObj",value:void 0},{kind:"method",key:"render",value:function(){if(!this.hass||!this.stateObj)return r.Ld;const t=this.stateObj;return r.dy`
      ${(0,o.e)(t,c.qh)?r.dy`
            <mwc-select .label=${this.hass.localize("ui.dialogs.more_info_control.remote.activity")} .value=${t.attributes.current_activity||""} @selected=${this._handleActivityChanged} fixedMenuPosition naturalMenuWidth @closed=${d.U}>
              ${t.attributes.activity_list?.map((e=>r.dy`
                  <mwc-list-item .value=${e}>
                    ${this.hass.formatEntityAttributeValue(t,"activity",e)}
                  </mwc-list-item>
                `))}
            </mwc-select>
          `:r.Ld}

      <ha-attributes .hass=${this.hass} .stateObj=${this.stateObj} .extraFilters=${h}></ha-attributes>
    `}},{kind:"method",key:"_handleActivityChanged",value:function(t){const e=this.stateObj.attributes.current_activity,i=t.target.value;i&&e!==i&&this.hass.callService("remote","turn_on",{entity_id:this.stateObj.entity_id,activity:i})}},{kind:"field",static:!0,key:"styles",value:()=>r.iv`mwc-select{width:100%}`}]}}),r.oi);a()}catch(t){a(t)}}))}};
//# sourceMappingURL=2600.089c005cd969f008.js.map