export const __webpack_ids__=["21483"];export const __webpack_modules__={17705:function(t,e,a){a.d(e,{Cj:()=>n,Hs:()=>v,Kd:()=>p,Kj:()=>u,Nw:()=>y,PA:()=>l,Py:()=>r,Qm:()=>w,Z0:()=>f,_Y:()=>_,_m:()=>c,dL:()=>o,dO:()=>k,hN:()=>h,h_:()=>i,j2:()=>$,q6:()=>m,uR:()=>d});a(9359),a(52924);var s=a(47194);const l=99387==a.j?["entity_not_recorded","entity_no_longer_recorded","state_class_removed","units_changed","no_state"]:null,c=t=>t.sendMessagePromise({type:"recorder/info"}),d=(t,e)=>t.callWS({type:"recorder/list_statistic_ids",statistic_type:e}),r=(t,e)=>t.callWS({type:"recorder/get_statistics_metadata",statistic_ids:e}),o=(t,e,a,s,l="hour",c,d)=>t.callWS({type:"recorder/statistics_during_period",start_time:e.toISOString(),end_time:a?.toISOString(),statistic_ids:s,period:l,units:c,types:d}),_=(t,e,a,s)=>t.callWS({type:"recorder/statistic_during_period",statistic_id:e,units:s,fixed_period:a.fixed_period?{start_time:a.fixed_period.start instanceof Date?a.fixed_period.start.toISOString():a.fixed_period.start,end_time:a.fixed_period.end instanceof Date?a.fixed_period.end.toISOString():a.fixed_period.end}:void 0,calendar:a.calendar,rolling_window:a.rolling_window}),i=t=>t.callWS({type:"recorder/validate_statistics"}),n=(t,e,a)=>t.callWS({type:"recorder/update_statistics_metadata",statistic_id:e,unit_of_measurement:a}),h=(t,e)=>t.callWS({type:"recorder/clear_statistics",statistic_ids:e}),u=t=>{let e=null;if(!t)return null;for(const a of t)null!==a.change&&void 0!==a.change&&(null===e?e=a.change:e+=a.change);return e},m=(t,e)=>{let a=null;for(const s of e){if(!(s in t))continue;const e=u(t[s]);null!==e&&(null===a?a=e:a+=e)}return a},y=(t,e)=>t.some((t=>void 0!==t[e]&&null!==t[e])),b=["mean","min","max"],g=["sum","state","change"],f=(t,e)=>!(!b.includes(e)||!t.has_mean)||!(!g.includes(e)||!t.has_sum),$=(t,e,a,s,l)=>{const c=new Date(a).toISOString();return t.callWS({type:"recorder/adjust_sum_statistics",statistic_id:e,start_time:c,adjustment:s,adjustment_unit_of_measurement:l})},p=(t,e,a)=>{const l=t.states[e];return l?(0,s.C)(l):a?.name||e},k=(t,e,a)=>{let s;return e&&(s=t.states[e]?.attributes.unit_of_measurement),void 0===s?a?.statistics_unit_of_measurement:s},v=t=>t.includes(":"),w=t=>t.callWS({type:"recorder/update_statistics_issues"})},6736:function(t,e,a){a.d(e,{f:()=>d});var s=a(44249),l=a(72621),c=(a(9359),a(52924),a(15093));const d=t=>(0,s.Z)(null,(function(t,e){class a extends e{constructor(...e){super(...e),t(this)}}return{F:a,d:[{kind:"field",decorators:[(0,c.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:void 0},{kind:"field",key:"__unsubs",value:void 0},{kind:"method",key:"connectedCallback",value:function(){(0,l.Z)(a,"connectedCallback",this,3)([]),this._checkSubscribed()}},{kind:"method",key:"disconnectedCallback",value:function(){if((0,l.Z)(a,"disconnectedCallback",this,3)([]),this.__unsubs){for(;this.__unsubs.length;){const t=this.__unsubs.pop();t instanceof Promise?t.then((t=>t())):t()}this.__unsubs=void 0}}},{kind:"method",key:"updated",value:function(t){if((0,l.Z)(a,"updated",this,3)([t]),t.has("hass"))this._checkSubscribed();else if(this.hassSubscribeRequiredHostProps)for(const e of t.keys())if(this.hassSubscribeRequiredHostProps.includes(e))return void this._checkSubscribed()}},{kind:"method",key:"hassSubscribe",value:function(){return[]}},{kind:"method",key:"_checkSubscribed",value:function(){void 0===this.__unsubs&&this.isConnected&&void 0!==this.hass&&!this.hassSubscribeRequiredHostProps?.some((t=>void 0===this[t]))&&(this.__unsubs=this.hassSubscribe())}}]}}),t)},20548:function(t,e,a){a.d(e,{H:()=>c});var s=a(11259),l=a(4643);function c(t,e,a,c,d,r){const o=t.getPropertyValue(d+"-"+r).trim(),_=o.length>0?o:t.getPropertyValue(d).trim();let i=(0,s.Rq)(_);return 0===o.length&&r&&(i=(0,s.CO)((0,s.p3)(e?(0,l.C)((0,s.Rw)((0,s.wK)(i)),r):(0,l.W)((0,s.Rw)((0,s.wK)(i)),r)))),c?i+=a?"32":"7F":a&&(i+="7F"),i}},74549:function(t,e,a){a.a(t,(async function(t,s){try{a.r(e),a.d(e,{HuiEnergySourcesTableCard:()=>$});var l=a(44249),c=(a(9359),a(70104),a(52924),a(23985)),d=a(57243),r=a(15093),o=a(35359),_=a(69634),i=a(50602),n=a(20548),h=(a(54977),a(1118)),u=a(17705),m=a(6736),y=a(93331),b=a(36522),g=t([h,i]);[h,i]=g.then?(await g)():g;const f={grid_return:"--energy-grid-return-color",grid_consumption:"--energy-grid-consumption-color",battery_in:"--energy-battery-in-color",battery_out:"--energy-battery-out-color",solar:"--energy-solar-color",gas:"--energy-gas-color",water:"--energy-water-color"};let $=(0,l.Z)([(0,r.Mo)("hui-energy-sources-table-card")],(function(t,e){return{F:class extends e{constructor(...e){super(...e),t(this)}},d:[{kind:"field",decorators:[(0,r.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_config",value:void 0},{kind:"field",decorators:[(0,r.SB)()],key:"_data",value:void 0},{kind:"field",key:"hassSubscribeRequiredHostProps",value:()=>["_config"]},{kind:"method",key:"hassSubscribe",value:function(){return[(0,h.UB)(this.hass,{key:this._config?.collection_key}).subscribe((t=>{this._data=t}))]}},{kind:"method",key:"getCardSize",value:function(){return 3}},{kind:"method",key:"setConfig",value:function(t){this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,y.SN)(this,t)||t.size>1||!t.has("hass")}},{kind:"method",key:"render",value:function(){if(!this.hass||!this._config)return d.Ld;if(!this._data)return d.dy`${this.hass.localize("ui.panel.lovelace.cards.energy.loading")}`;let t=0,e=0,a=0,s=0,l=0,c=0,r=0,m=0,y=!1,b=!1,g=!1,$=0,p=0,k=0,v=0,w=0,C=0,S=0,K=0;const M=(0,h.Jj)(this._data.prefs),j=getComputedStyle(this),H=M.grid?.[0].flow_from.some((t=>t.stat_cost||t.entity_energy_price||t.number_energy_price))||M.grid?.[0].flow_to.some((t=>t.stat_compensation||t.entity_energy_price||t.number_energy_price))||M.gas?.some((t=>t.stat_cost||t.entity_energy_price||t.number_energy_price))||M.water?.some((t=>t.stat_cost||t.entity_energy_price||t.number_energy_price)),W=(0,h.vE)(this.hass,this._data.prefs,this._data.statsMetadata),x=(0,h.b)(this.hass),z=void 0!==this._data.statsCompare;return d.dy` <ha-card>
      ${this._config.title?d.dy`<h1 class="card-header">${this._config.title}</h1>`:""}
      <div class="mdc-data-table">
        <div class="mdc-data-table__table-container">
          <table class="mdc-data-table__table" aria-label="Energy sources">
            <thead>
              <tr class="mdc-data-table__header-row">
                <th class="mdc-data-table__header-cell"></th>
                <th class="mdc-data-table__header-cell" role="columnheader" scope="col">
                  ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.source")}
                </th>
                ${z?d.dy`<th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">
                        ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.previous_energy")}
                      </th>
                      ${H?d.dy`<th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">
                            ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.previous_cost")}
                          </th>`:""}`:""}
                <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">
                  ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.energy")}
                </th>
                ${H?d.dy` <th class="mdc-data-table__header-cell mdc-data-table__header-cell--numeric" role="columnheader" scope="col">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.cost")}
                    </th>`:""}
              </tr>
            </thead>
            <tbody class="mdc-data-table__content">
              ${M.solar?.map(((t,e)=>{const s=(0,u.Kj)(this._data.stats[t.stat_energy_from])||0;a+=s;const l=z&&(0,u.Kj)(this._data.statsCompare[t.stat_energy_from])||0;return k+=l,d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(t.stat_energy_from)})}" @click=${this._handleMoreInfo} .entity=${t.stat_energy_from}>
                  <td class="mdc-data-table__cell cell-bullet">
                    <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.solar,e),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.solar,e)})}></div>
                  </td>
                  <th class="mdc-data-table__cell" scope="row">
                    ${(0,u.Kd)(this.hass,t.stat_energy_from,this._data?.statsMetadata[t.stat_energy_from])}
                  </th>
                  ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${(0,i.uf)(l,this.hass.locale)} kWh
                        </td>
                        ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}`:""}
                  <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                    ${(0,i.uf)(s,this.hass.locale)} kWh
                  </td>
                  ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}
                </tr>`}))}
              ${M.solar?d.dy`<tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.solar_total")}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(k,this.hass.locale)}
                            kWh
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(a,this.hass.locale)} kWh
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}
                  </tr>`:""}
              ${M.battery?.map(((t,e)=>{const a=(0,u.Kj)(this._data.stats[t.stat_energy_from])||0,l=(0,u.Kj)(this._data.stats[t.stat_energy_to])||0;s+=a-l;const c=z&&(0,u.Kj)(this._data.statsCompare[t.stat_energy_from])||0,r=z&&(0,u.Kj)(this._data.statsCompare[t.stat_energy_to])||0;return v+=c-r,d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(t.stat_energy_from)})}" @click=${this._handleMoreInfo} .entity=${t.stat_energy_from}>
                    <td class="mdc-data-table__cell cell-bullet">
                      <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.battery_out,e),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.battery_out,e)})}></div>
                    </td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${(0,u.Kd)(this.hass,t.stat_energy_from,this._data?.statsMetadata[t.stat_energy_from])}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(c,this.hass.locale)}
                            kWh
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(a,this.hass.locale)} kWh
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}
                  </tr>
                  <tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(t.stat_energy_to)})}" @click=${this._handleMoreInfo} .entity=${t.stat_energy_to}>
                    <td class="mdc-data-table__cell cell-bullet">
                      <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.battery_in,e),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.battery_in,e)})}></div>
                    </td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${(0,u.Kd)(this.hass,t.stat_energy_to,this._data?.statsMetadata[t.stat_energy_to])}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(-1*r,this.hass.locale)}
                            kWh
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(-1*l,this.hass.locale)} kWh
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}
                  </tr>`}))}
              ${M.battery?d.dy`<tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.battery_total")}
                    </th>
                    ${z?d.dy` <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(v,this.hass.locale)}
                            kWh
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(s,this.hass.locale)} kWh
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell"></td>`:""}
                  </tr>`:""}
              ${M.grid?.map((a=>d.dy`${a.flow_from.map(((a,s)=>{const l=(0,u.Kj)(this._data.stats[a.stat_energy_from])||0;t+=l;const c=z&&(0,u.Kj)(this._data.statsCompare[a.stat_energy_from])||0;$+=c;const r=a.stat_cost||this._data.info.cost_sensors[a.stat_energy_from],h=r?(0,u.Kj)(this._data.stats[r])||0:null;null!==h&&(y=!0,e+=h);const m=z&&r?(0,u.Kj)(this._data.statsCompare[r])||0:null;return null!==m&&(p+=m),d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(a.stat_energy_from)})}" @click=${this._handleMoreInfo} .entity=${a.stat_energy_from}>
                      <td class="mdc-data-table__cell cell-bullet">
                        <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.grid_consumption,s),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.grid_consumption,s)})}></div>
                      </td>
                      <th class="mdc-data-table__cell" scope="row">
                        ${(0,u.Kd)(this.hass,a.stat_energy_from,this._data?.statsMetadata[a.stat_energy_from])}
                      </th>
                      ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                              ${(0,i.uf)(c,this.hass.locale)}
                              kWh
                            </td>
                            ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                                  ${null!==m?(0,i.uf)(m,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                                </td>`:""}`:""}
                      <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                        ${(0,i.uf)(l,this.hass.locale)} kWh
                      </td>
                      ${H?d.dy` <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${null!==h?(0,i.uf)(h,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                          </td>`:""}
                    </tr>`}))}
                  ${a.flow_to.map(((a,s)=>{const l=-1*((0,u.Kj)(this._data.stats[a.stat_energy_to])||0);t+=l;const c=a.stat_compensation||this._data.info.cost_sensors[a.stat_energy_to],r=c?-1*((0,u.Kj)(this._data.stats[c])||0):null;null!==r&&(y=!0,e+=r);const h=-1*(z&&(0,u.Kj)(this._data.statsCompare[a.stat_energy_to])||0);$+=h;const m=z&&c?-1*((0,u.Kj)(this._data.statsCompare[c])||0):null;return null!==m&&(p+=m),d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(a.stat_energy_to)})}" @click=${this._handleMoreInfo} .entity=${a.stat_energy_to}>
                      <td class="mdc-data-table__cell cell-bullet">
                        <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.grid_return,s),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.grid_return,s)})}></div>
                      </td>
                      <th class="mdc-data-table__cell" scope="row">
                        ${(0,u.Kd)(this.hass,a.stat_energy_to,this._data?.statsMetadata[a.stat_energy_to])}
                      </th>
                      ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                              ${(0,i.uf)(h,this.hass.locale)}
                              kWh
                            </td>
                            ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                                  ${null!==m?(0,i.uf)(m,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                                </td>`:""}`:""}
                      <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                        ${(0,i.uf)(l,this.hass.locale)} kWh
                      </td>
                      ${H?d.dy` <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${null!==r?(0,i.uf)(r,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                          </td>`:""}
                    </tr>`}))}`))}
              ${M.grid&&(M.grid?.[0].flow_from?.length||M.grid?.[0].flow_to?.length)?d.dy` <tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.grid_total")}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)($,this.hass.locale)}
                            kWh
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                                ${y?(0,i.uf)(p,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                              </td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(t,this.hass.locale)} kWh
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${y?(0,i.uf)(e,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                        </td>`:""}
                  </tr>`:""}
              ${M.gas?.map(((t,e)=>{const a=(0,u.Kj)(this._data.stats[t.stat_energy_from])||0;l+=a;const s=z&&(0,u.Kj)(this._data.statsCompare[t.stat_energy_from])||0;w+=s;const r=t.stat_cost||this._data.info.cost_sensors[t.stat_energy_from],h=r?(0,u.Kj)(this._data.stats[r])||0:null;null!==h&&(b=!0,c+=h);const m=z&&r?(0,u.Kj)(this._data.statsCompare[r])||0:null;return null!==m&&(C+=m),d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(t.stat_energy_from)})}" @click=${this._handleMoreInfo} .entity=${t.stat_energy_from}>
                  <td class="mdc-data-table__cell cell-bullet">
                    <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.gas,e),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.gas,e)})}></div>
                  </td>
                  <th class="mdc-data-table__cell" scope="row">
                    ${(0,u.Kd)(this.hass,t.stat_energy_from,this._data?.statsMetadata[t.stat_energy_from])}
                  </th>
                  ${z?d.dy` <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${(0,i.uf)(s,this.hass.locale)}
                          ${W}
                        </td>
                        ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                              ${null!==m?(0,i.uf)(m,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                            </td>`:""}`:""}
                  <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                    ${(0,i.uf)(a,this.hass.locale)} ${W}
                  </td>
                  ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                        ${null!==h?(0,i.uf)(h,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                      </td>`:""}
                </tr>`}))}
              ${M.gas?d.dy`<tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.gas_total")}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(w,this.hass.locale)}
                            ${W}
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                                ${b?(0,i.uf)(C,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                              </td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(l,this.hass.locale)} ${W}
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${b?(0,i.uf)(c,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                        </td>`:""}
                  </tr>`:""}
              ${M.water?.map(((t,e)=>{const a=(0,u.Kj)(this._data.stats[t.stat_energy_from])||0;r+=a;const s=z&&(0,u.Kj)(this._data.statsCompare[t.stat_energy_from])||0;S+=s;const l=t.stat_cost||this._data.info.cost_sensors[t.stat_energy_from],c=l?(0,u.Kj)(this._data.stats[l])||0:null;null!==c&&(g=!0,m+=c);const h=z&&l?(0,u.Kj)(this._data.statsCompare[l])||0:null;return null!==h&&(K+=h),d.dy`<tr class="mdc-data-table__row ${(0,o.$)({clickable:!(0,u.Hs)(t.stat_energy_from)})}" @click=${this._handleMoreInfo} .entity=${t.stat_energy_from}>
                  <td class="mdc-data-table__cell cell-bullet">
                    <div class="bullet" style=${(0,_.V)({borderColor:(0,n.H)(j,this.hass.themes.darkMode,!1,!1,f.water,e),backgroundColor:(0,n.H)(j,this.hass.themes.darkMode,!0,!1,f.water,e)})}></div>
                  </td>
                  <th class="mdc-data-table__cell" scope="row">
                    ${(0,u.Kd)(this.hass,t.stat_energy_from,this._data?.statsMetadata[t.stat_energy_from])}
                  </th>
                  ${z?d.dy` <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${(0,i.uf)(s,this.hass.locale)}
                          ${x}
                        </td>
                        ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                              ${null!==h?(0,i.uf)(h,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                            </td>`:""}`:""}
                  <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                    ${(0,i.uf)(a,this.hass.locale)} ${x}
                  </td>
                  ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                        ${null!==c?(0,i.uf)(c,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                      </td>`:""}
                </tr>`}))}
              ${M.water?d.dy`<tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.water_total")}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(S,this.hass.locale)}
                            ${x}
                          </td>
                          ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                                ${g?(0,i.uf)(K,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                              </td>`:""}`:""}
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(r,this.hass.locale)} ${x}
                    </td>
                    ${H?d.dy`<td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                          ${g?(0,i.uf)(m,this.hass.locale,{style:"currency",currency:this.hass.config.currency}):""}
                        </td>`:""}
                  </tr>`:""}
              ${[b,g,y].filter(Boolean).length>1?d.dy`<tr class="mdc-data-table__row total">
                    <td class="mdc-data-table__cell"></td>
                    <th class="mdc-data-table__cell" scope="row">
                      ${this.hass.localize("ui.panel.lovelace.cards.energy.energy_sources_table.total_costs")}
                    </th>
                    ${z?d.dy`<td class="mdc-data-table__cell"></td>
                          <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                            ${(0,i.uf)(C+p+K,this.hass.locale,{style:"currency",currency:this.hass.config.currency})}
                          </td>`:""}
                    <td class="mdc-data-table__cell"></td>
                    <td class="mdc-data-table__cell mdc-data-table__cell--numeric">
                      ${(0,i.uf)(c+e+m,this.hass.locale,{style:"currency",currency:this.hass.config.currency})}
                    </td>
                  </tr>`:""}
            </tbody>
          </table>
        </div>
      </div>
    </ha-card>`}},{kind:"method",key:"_handleMoreInfo",value:function(t){const e=t.currentTarget?.entity;e&&!(0,u.Hs)(e)&&(0,b.B)(this,"hass-more-info",{entityId:e})}},{kind:"get",static:!0,key:"styles",value:function(){return d.iv`${(0,d.$m)(c)} .mdc-data-table{width:100%;border:0}.mdc-data-table__cell,.mdc-data-table__header-cell{color:var(--primary-text-color);border-bottom-color:var(--divider-color);text-align:var(--float-start)}.mdc-data-table__row:not(.mdc-data-table__row--selected):hover{background-color:rgba(var(--rgb-primary-text-color),.04)}.clickable{cursor:pointer}.total{--mdc-typography-body2-font-weight:500}.total .mdc-data-table__cell{border-top:1px solid var(--divider-color)}ha-card{height:100%;overflow:hidden}.card-header{padding-bottom:0}.content{padding:16px}.has-header{padding-top:0}.cell-bullet{width:32px;padding-right:0;padding-inline-end:0;padding-inline-start:16px;direction:var(--direction)}.bullet{border-width:1px;border-style:solid;border-radius:4px;height:16px;width:32px}.mdc-data-table__cell--numeric{direction:ltr}`}}]}}),(0,m.f)(d.oi));s()}catch(t){s(t)}}))}};
//# sourceMappingURL=21483.91ce0a585a3be708.js.map