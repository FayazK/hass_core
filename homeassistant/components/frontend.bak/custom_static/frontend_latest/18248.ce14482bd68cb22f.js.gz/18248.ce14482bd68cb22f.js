export const __webpack_ids__=["18248"];export const __webpack_modules__={98962:function(e,t,a){a.r(t),a.d(t,{HuiEmptyStateCard:()=>o});var i=a(44249),n=(a(31622),a(57243)),s=a(15093);a(54977);let o=(0,i.Z)([(0,s.Mo)("hui-empty-state-card")],(function(e,t){return{F:class extends t{constructor(...t){super(...t),e(this)}},d:[{kind:"field",decorators:[(0,s.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"method",key:"getCardSize",value:function(){return 2}},{kind:"method",key:"setConfig",value:function(e){}},{kind:"method",key:"render",value:function(){return this.hass?n.dy`
      <ha-card .header=${this.hass.localize("ui.panel.lovelace.cards.empty_state.title")}>
        <div class="card-content">
          ${this.hass.localize("ui.panel.lovelace.cards.empty_state.no_devices")}
        </div>
        <div class="card-actions">
          <a href="/config/integrations/dashboard">
            <mwc-button>
              ${this.hass.localize("ui.panel.lovelace.cards.empty_state.go_to_integrations_page")}
            </mwc-button>
          </a>
        </div>
      </ha-card>
    `:n.Ld}},{kind:"field",static:!0,key:"styles",value:()=>n.iv`.content{margin-top:-1em;padding:16px}.card-actions a{text-decoration:none}mwc-button{margin-left:-8px;margin-inline-start:-8px;margin-inline-end:initial}`}]}}),n.oi)}};
//# sourceMappingURL=18248.ce14482bd68cb22f.js.map