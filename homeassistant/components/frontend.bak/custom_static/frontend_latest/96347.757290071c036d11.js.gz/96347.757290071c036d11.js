export const __webpack_ids__=["96347"];export const __webpack_modules__={97937:function(t,i,e){e.a(t,(async function(t,n){try{e.r(i);var s=e(44249),o=e(57243),a=e(15093),r=(e(29891),e(96194)),h=e(93331),c=e(8069),d=e(62577),u=t([c]);c=(u.then?(await u)():u)[0];(0,s.Z)([(0,a.Mo)("hui-valve-entity-row")],(function(t,i){return{F:class extends i{constructor(...i){super(...i),t(this)}},d:[{kind:"field",decorators:[(0,a.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,a.SB)()],key:"_config",value:void 0},{kind:"method",key:"setConfig",value:function(t){if(!t)throw new Error("Invalid configuration");this._config=t}},{kind:"method",key:"shouldUpdate",value:function(t){return(0,h.G2)(this,t)}},{kind:"method",key:"render",value:function(){if(!this._config||!this.hass)return o.Ld;const t=this.hass.states[this._config.entity];if(!t)return o.dy`
        <hui-warning>
          ${(0,d.i)(this.hass,this._config.entity)}
        </hui-warning>
      `;const i="open"===t.state||"closed"===t.state||(0,r.rk)(t.state);return o.dy`
      <hui-generic-entity-row .hass=${this.hass} .config=${this._config} .catchInteraction=${!i}>
        ${i?o.dy`
              <ha-entity-toggle .hass=${this.hass} .stateObj=${t}></ha-entity-toggle>
            `:o.dy`
              <div class="text-content">
                ${this.hass.formatEntityState(t)}
              </div>
            `}
      </hui-generic-entity-row>
    `}}]}}),o.oi);n()}catch(t){n(t)}}))}};
//# sourceMappingURL=96347.757290071c036d11.js.map