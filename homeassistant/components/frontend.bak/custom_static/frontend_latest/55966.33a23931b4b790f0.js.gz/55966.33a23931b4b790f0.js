export const __webpack_ids__=["55966"];export const __webpack_modules__={96814:function(i,e,a){a(9359),a(31526),i.exports=function i(e){return Object.freeze(e),Object.getOwnPropertyNames(e).forEach((function(a){!e.hasOwnProperty(a)||null===e[a]||"object"!=typeof e[a]&&"function"!=typeof e[a]||Object.isFrozen(e[a])||i(e[a])})),e}},58064:function(i,e,a){a.a(i,(async function(i,t){try{a.r(e),a.d(e,{HuiDialogSuggestBadge:()=>p});var s=a(44249),o=(a(9359),a(70104),a(96814)),n=a.n(o),d=a(57243),l=a(15093),h=a(36522),r=(a(64889),a(17170)),c=a(28008),g=a(58885),u=a(69040),m=a(27353),f=a(2593),_=i([r,u]);[r,u]=_.then?(await _)():_;let p=(0,s.Z)([(0,l.Mo)("hui-dialog-suggest-badge")],(function(i,e){return{F:class extends e{constructor(...e){super(...e),i(this)}},d:[{kind:"field",decorators:[(0,l.Cb)({attribute:!1})],key:"hass",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_params",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_badgeConfig",value:void 0},{kind:"field",decorators:[(0,l.SB)()],key:"_saving",value:()=>!1},{kind:"field",decorators:[(0,l.IO)("ha-yaml-editor")],key:"_yamlEditor",value:void 0},{kind:"method",key:"showDialog",value:function(i){this._params=i,this._badgeConfig=i.badgeConfig,Object.isFrozen(this._badgeConfig)||(this._badgeConfig=n()(this._badgeConfig)),this._yamlEditor&&this._yamlEditor.setValue(this._badgeConfig)}},{kind:"method",key:"closeDialog",value:function(){this._params=void 0,this._badgeConfig=void 0,(0,h.B)(this,"dialog-closed",{dialog:this.localName})}},{kind:"method",key:"_renderPreview",value:function(){return this._badgeConfig?d.dy`
        <div class="element-preview">
          ${this._badgeConfig.map((i=>d.dy`
              <hui-badge .hass=${this.hass} .config=${i} preview></hui-badge>
            `))}
        </div>
      `:d.Ld}},{kind:"method",key:"render",value:function(){return this._params?d.dy`
      <ha-dialog open scrimClickAction @closed=${this.closeDialog} .heading=${this.hass.localize("ui.panel.lovelace.editor.suggest_badge.header")}>
        <div>
          ${this._renderPreview()}
          ${this._params.yaml&&this._badgeConfig?d.dy`
                <div class="editor">
                  <ha-yaml-editor .hass=${this.hass} .defaultValue=${this._badgeConfig}></ha-yaml-editor>
                </div>
              `:d.Ld}
        </div>
        <mwc-button slot="secondaryAction" @click=${this.closeDialog} dialogInitialFocus>
          ${this._params.yaml?this.hass.localize("ui.common.close"):this.hass.localize("ui.common.cancel")}
        </mwc-button>
        ${this._params.yaml?d.Ld:d.dy`
              <mwc-button slot="primaryAction" .disabled=${this._saving} @click=${this._save}>
                ${this._saving?d.dy`
                      <ha-spinner aria-label="Saving" size="small"></ha-spinner>
                    `:this.hass.localize("ui.panel.lovelace.editor.suggest_badge.add")}
              </mwc-button>
            `}
      </ha-dialog>
    `:d.Ld}},{kind:"get",static:!0,key:"styles",value:function(){return[c.yu,d.iv`@media all and (max-width:450px),all and (max-height:500px){ha-dialog{max-height:100%;height:100%}}@media all and (min-width:850px){ha-dialog{width:845px}}ha-dialog{max-width:845px;--dialog-z-index:6}.hidden{display:none}.element-preview{position:relative;display:flex;align-items:flex-start;flex-wrap:wrap;justify-content:center;gap:8px;margin:0}.editor{padding-top:16px}`]}},{kind:"method",key:"_computeNewConfig",value:function(i,e){const{viewIndex:a}=(0,f.jb)(e),t=this._badgeConfig;return(0,m.xy)(i,[a],t)}},{kind:"method",key:"_save",value:async function(){if(!(this._params?.lovelaceConfig&&this._params?.path&&this._params?.saveConfig&&this._badgeConfig))return;this._saving=!0;const i=this._computeNewConfig(this._params.lovelaceConfig,this._params.path);await this._params.saveConfig(i),this._saving=!1,(0,g.f)(this,this.hass),this.closeDialog()}}]}}),d.oi);t()}catch(i){t(i)}}))},58885:function(i,e,a){a.d(e,{f:()=>s});var t=a(72473);const s=(i,e)=>(0,t.C)(i,{message:e.localize("ui.common.successfully_saved")})}};
//# sourceMappingURL=55966.33a23931b4b790f0.js.map